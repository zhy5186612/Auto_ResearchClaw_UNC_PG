# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repo is

A working copy of **AutoResearchClaw** (`researchclaw` on PyPI, version pinned at `0.3.1` in `pyproject.toml`; upstream README references `v0.4.0`). It is a Python 3.11+ package that runs a 23-stage autonomous research pipeline (idea → literature → experiments → paper) driven by LLM calls. The repo also contains a Next.js 14 frontend (`frontend-next/`) and a FastAPI server (invoked via `researchclaw serve`) for a browser UI.

**Two authoritative docs already exist — read them before answering pipeline questions:**
- `RESEARCHCLAW_CLAUDE.md` — pipeline structure, key APIs, testing commands
- `RESEARCHCLAW_AGENTS.md` — agent-facing bootstrapping (gates, modes, decision tree)
- `README.md` — full feature reference, HITL modes, config reference, CLI examples
- `info.txt` — scratchpad with Windows PowerShell commands the maintainer uses

Do not re-derive what those files already say; cite them.

## Setup and everyday commands

```bash
# Install (editable, with dev extras)
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

# Create local config from the tracked template
researchclaw init                    # writes config.arc.yaml (gitignored)
# or:  cp config.researchclaw.example.yaml config.arc.yaml

# Run the pipeline
researchclaw run --config config.arc.yaml --topic "..." --auto-approve

# Validate config / check environment
researchclaw validate --config config.arc.yaml
researchclaw doctor

# Full test suite (~2700 tests; 434 top-level test_ functions across ~89 files)
pytest tests/

# Single test file / single test
pytest tests/test_cli.py -q
pytest tests/test_hitl_foundation.py::test_specific_thing -q

# Real-LLM E2E (needs API key in config — costs real money, do not run casually)
python tests/e2e_real_llm.py
```

Frontend + FastAPI:

```bash
# Backend
python -m researchclaw serve --config config.next-fastapi.example.yaml --host 127.0.0.1 --port 8080

# Frontend (separate terminal)
cd frontend-next && npm run dev       # http://localhost:3000

# Or containerized
docker compose -f docker-compose.next-fastapi.yml up --build
```

## Config file conventions

- `config.researchclaw.example.yaml` — tracked template, never put secrets here
- `config.arc.yaml` — local config, gitignored, created by `researchclaw init`
- `config.yaml` — also gitignored, supported as fallback
- CLI honors `--config <path>` and env-var API keys via `llm.api_key_env`

## Architecture (the bits that require reading multiple files)

**Pipeline orchestration is table-driven, not classical inheritance.** The 23 stages flow through three coupled files:

- `researchclaw/pipeline/stages.py` — `Stage` IntEnum (1–23), `NEXT_STAGE` transition map, gate-stage flags, rollback rules
- `researchclaw/pipeline/contracts.py` — `StageContract` per stage: `required_keys`, `produced_keys`, `is_gate`
- `researchclaw/pipeline/executor.py` — dispatch table `_STAGE_EXECUTORS` mapping each `Stage` to a function; per-stage implementations live in `researchclaw/pipeline/stage_impls/_*.py` (`_topic`, `_literature`, `_synthesis`, `_experiment_design`, `_code_generation`, `_execution`, `_analysis`, `_paper_writing`, `_review_publish`)
- `researchclaw/pipeline/runner.py` — top-level `execute_pipeline()` and `execute_iterative_pipeline()` loops, gate handling, resume logic

**When adding or modifying a stage:** update all three of stages.py / contracts.py / stage_impls, plus tests. The `StageContract.produced_keys` are how downstream stages find inputs — mismatches surface as `KeyError` at runtime, not at import.

**Gate stages** are 5, 9, 20 (`security.hitl_required_stages`). Rejection rolls the pipeline back per rules in `stages.py`. `--auto-approve` bypasses gates entirely. The HITL v0.4.0 system (`researchclaw/hitl/`, `researchclaw/copilot/`, `researchclaw/collaboration/`) adds 6 intervention modes on top — see the "Human-in-the-Loop Co-Pilot" section in README.md.

**Experiment execution** has multiple backends in `researchclaw/experiment/`: `sandbox.py` (local subprocess), `docker_sandbox.py`, `ssh_sandbox.py`, `colab_sandbox.py`, `agentic_sandbox.py`. Selected by `experiment.mode` in config. `validator.py` runs AST + security + import checks before any generated code executes in Stage 10 — do not bypass this in changes.

**LLM adapter layer** — `researchclaw/llm/`:
- `client.py` — `LLMClient` for OpenAI-compatible endpoints, `from_rc_config()` factory
- `acp_client.py` — Agent Client Protocol backend (delegates to Claude Code / Codex / Gemini CLIs instead of a raw API key)
- `anthropic_adapter.py` — direct Anthropic wrapper

**Optional integrations** — each lives in its own subpackage and is opt-in via config: `metaclaw_bridge/` (cross-run lesson→skill learning), `overleaf/` (bidirectional LaTeX sync), `mcp/` (MCP server exposure), `skills/` (loadable SKILL.md skills, with 19 built-ins).

**Artifacts** — every run writes to `artifacts/rc-<timestamp>-<hash>/` with `deliverables/` (final LaTeX/BibTeX/charts), stage manifests with SHA256 checksums, and (if HITL enabled) chat logs. The gitignored top-level `artifacts/` dir is where these accumulate.

**Frontend** (`frontend-next/`) is a small Next.js 14 app (`app/page.js` is essentially the whole UI). It talks to `researchclaw serve` (FastAPI) via REST + WebSocket. Env vars: `NEXT_PUBLIC_API_BASE_URL`, `NEXT_PUBLIC_WS_BASE_URL`.

## Repo-local quirks

- **Package versions differ from README.** `pyproject.toml` says `0.3.1`; README describes `v0.4.0` features. Both HITL and MetaClaw code is present in-tree, so the README is closer to truth than the version string.
- **CLI has ~20 subcommands** (see `researchclaw/cli.py` `add_parser` calls). `run`, `validate`, `doctor`, `init`, `setup`, `serve`, `attach`, `status`, `approve`, `reject`, `guide`, `skills`, `overleaf`, `trends`, `calendar`, `mcp`, `project`, `report`, `dashboard`, `wizard`.
- **`tools/`** ships vendored `pandoc` and `tectonic` binaries for LaTeX export — do not delete or regenerate them; they are the fallback when the system has no LaTeX toolchain.
- **`pg-root-ssl-python-mega-patch-0.0.26.tar.gz`** at the repo root is an internal SSL patch for P&G/Netskope TLS interception. Modern `pip` builds a wheel from its sdist and installs from that, which **bypasses the patch's `install`-command post-hook** — so the certs it appends to `certifi/cacert.pem` never actually land, and even when they do a subsequent `pip install` that reinstalls certifi wipes them. To paper over this, `researchclaw/utils/ca_bootstrap.py` runs at package import time: it collects extra roots from `$RESEARCHCLAW_EXTRA_CA_BUNDLE`, `~/.researchclaw/extra-ca.pem`, `researchclaw/data/extra-ca/*.pem`, and the vendored tarball, merges them with `certifi.where()` into `~/.cache/researchclaw/ca/merged.pem`, and sets `SSL_CERT_FILE` / `REQUESTS_CA_BUNDLE` for the process. Off-corporate machines have no extras and it's a no-op. Set `RESEARCHCLAW_DISABLE_CA_BOOTSTRAP=1` to opt out. See `info.txt` for the old manual install command.
- **`__researchclaw/`, `__tests/`, `.logs/`** — leading-underscore/double-underscore dirs are throwaway/backup scratch. Files like `___All_Errors.txt` and `__dev-server*.log_Error.txt` are captured logs, not source.
- **Empty `__pycache__` after fresh checkout is normal** — a large amount of it was pulled in via the OneDrive extraction that populated this working tree.

## PR / contribution rules (from CONTRIBUTING.md)

- Branch from `main`; one concern per PR
- `pytest tests/` must pass before merge
- Add tests for new functionality
