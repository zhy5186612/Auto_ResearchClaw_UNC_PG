# Framework Diagram Prompt

**Paper**: Bayesian Time Series and Bayesian Belief Network for Causal Reasoning

## Image Generation Prompt

Create a clean academic methodology framework/architecture overview diagram for a top-tier ML conference paper titled “Bayesian Time Series and Bayesian Belief Network for Causal Reasoning.” Vector-art, flat design, subtle soft shadows, rounded-corner modules, white or very light grey background (#F7F8FA). Use a sophisticated muted palette: primary muted blue #4477AA, teal #44AA99, warm accent #CCBB44 for highlights, soft purple #AA3377 for causal reasoning elements; neutral greys #666666 text, #D9DEE7 borders. Left-to-right data flow with clear directional arrows.

Diagram layout (single row with stacked sub-rows where needed): 
1) Input module (blue): “Problem & Data Sources” with small sub-labels inside: “Time Series”, “Context/Domain Notes”. 
2) Experiment Design module (teal): “Experiment Designer” (annotation: “hypotheses, priors, causal queries”). 
3) Code Generation module (blue): “Executable Code Generator” (annotation: “reproducible scripts”). 
4) Execution module (teal): “Evaluation Workflow Runner” (annotation: “run available pipeline”). 
5) Artifacts module (blue): “Produced Artifacts” with tiny internal chips: “logs”, “summaries”, “diagnostics”. 
6) Analysis & Drafting module (purple): “Causal Analysis & Draft Drafting” with key note: “use summaries + diagnostic metadata only”. 
7) Output module (warm accent): “Final Report” with small badge: “no unverified numeric claims”.

Include a side panel (right or bottom) titled “Models” with two rounded boxes: “Bayesian Time Series” (blue) and “Bayesian Belief Network” (purple), both feeding into “Causal Analysis & Draft Drafting” via arrows labeled minimally: “posterior” and “causal structure”. Add a small guardrail callout near output: “Verification Gate” (warm accent) connected by a thin arrow from “Produced Artifacts” to “Final Report”. Use consistent typography (sans-serif, e.g., Helvetica/Inter), minimal text, crisp alignment, ample whitespace. No photorealism, no 3D, no gradients beyond subtle shadow.

## Usage Instructions

1. Copy the prompt above into an AI image generator (DALL-E 3, Midjourney, Ideogram, etc.)
2. Generate the image at high resolution (2048x1024 or similar landscape)
3. Save as `framework_diagram.png` in the same `charts/` folder
4. Insert into the paper's Method section using:
   - LaTeX: `\includegraphics[width=\textwidth]{charts/framework_diagram.png}`
   - Markdown: `![Framework Overview](charts/framework_diagram.png)`
