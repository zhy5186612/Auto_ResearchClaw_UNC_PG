# Code Package for Bayesian Time Series and Bayesian Belief Network for Causal Reasoning

## Description
This directory contains the experiment project used for the paper.

## Project Files
- `evaluate.py`
- `main.py`
- `methods.py`

## How to Run
`python main.py`

## Dependencies
Install dependencies with `pip install -r requirements.txt` if needed.
