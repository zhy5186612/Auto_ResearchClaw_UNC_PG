from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, List

import numpy as np

# ---------------------------------------------------------------------
# Robust Config import with fallback
# NOTE: If your repo contains a local `config.py`, consider renaming it
# to avoid collisions with third-party packages. Kept as-is because the
# provided code references `config.Config`.
# ---------------------------------------------------------------------
try:
    from config import Config  # type: ignore
except ModuleNotFoundError:

    @dataclass
    class Config:
        primary_metric_name: str = "primary_metric"
        metrics: List[str] = field(
            default_factory=lambda: [
                "InterventionalNegativeLogLikelihood",
                "PredictiveIntervalCoverage90",
                "DoEffectRMSE",
                "NegativeControlViolationRate",
                "RuntimePerQuery_ms",
                "rmse",
                "runtime_sec",
                "success_rate",
                "primary_metric",
            ]
        )

def _to_jsonable(x: Any) -> Any:
    if x is None or isinstance(x, (bool, int, float, str)):
        return x
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if is_dataclass(x):
        return _to_jsonable(asdict(x))
    if isinstance(x, dict):
        return {str(k): _to_jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_to_jsonable(v) for v in x]
    if hasattr(x, "detach") and hasattr(x, "cpu") and hasattr(x, "numpy"):
        try:
            return _to_jsonable(x.detach().cpu().numpy())
        except Exception:
            return str(x)
    if hasattr(x, "item") and callable(getattr(x, "item")):
        try:
            return float(x.item())
        except Exception:
            return str(x)
    return str(x)

def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

def gaussian_nll(y_true: np.ndarray, mean: np.ndarray, std: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=np.float64).reshape(-1)
    mean = np.asarray(mean, dtype=np.float64).reshape(-1)
    std = np.asarray(std, dtype=np.float64).reshape(-1)
    if not (y_true.shape == mean.shape == std.shape):
        raise ValueError(f"Shape mismatch: y_true={y_true.shape}, mean={mean.shape}, std={std.shape}")
    var = std**2 + 1e-8
    return float(np.mean(0.5 * np.log(2.0 * np.pi * var) + 0.5 * ((y_true - mean) ** 2) / var))

def interval_coverage(y_true: np.ndarray, mean: np.ndarray, std: np.ndarray, nominal: float) -> float:
    y_true = np.asarray(y_true, dtype=np.float64).reshape(-1)
    mean = np.asarray(mean, dtype=np.float64).reshape(-1)
    std = np.asarray(std, dtype=np.float64).reshape(-1)
    if not (y_true.shape == mean.shape == std.shape):
        raise ValueError(f"Shape mismatch: y_true={y_true.shape}, mean={mean.shape}, std={std.shape}")
    _ = float(nominal)
    z = 1.6448536269514722
    lo = mean - z * std
    hi = mean + z * std
    return float(np.mean((y_true >= lo) & (y_true <= hi)))

def ace90(coverage: float) -> float:
    return abs(float(coverage) - 0.90)

def shd(G_prob: np.ndarray, G_true: np.ndarray, threshold: float = 0.5) -> int:
    G_prob = np.asarray(G_prob, dtype=np.float64)
    G_true = np.asarray(G_true, dtype=np.int64)

    L = 1
    if G_true.ndim == 3:
        L = int(G_true.shape[0])
    elif G_prob.ndim == 3:
        L = int(G_prob.shape[0])

    if G_prob.ndim == 2 and G_true.ndim == 3:
        G_prob = np.broadcast_to(G_prob[None, :, :], (L,) + G_prob.shape).copy()
    if G_true.ndim == 2 and G_prob.ndim == 3:
        G_true = np.broadcast_to(G_true[None, :, :], (L,) + G_true.shape).copy()

    if not (G_prob.ndim == G_true.ndim and G_prob.shape == G_true.shape):
        raise ValueError(f"Shape mismatch: G_prob={G_prob.shape}, G_true={G_true.shape}")

    G_hat = (G_prob >= float(threshold)).astype(np.int64)

    if G_hat.ndim == 2:
        np.fill_diagonal(G_hat, 0)
    else:
        for lag in range(G_hat.shape[0]):
            np.fill_diagonal(G_hat[lag], 0)

    shd_val = 0
    p = int(G_true.shape[-1])

    if G_true.ndim == 2:
        np.fill_diagonal(G_true, 0)
        for i in range(p):
            for j in range(i + 1, p):
                t_ij, t_ji = int(G_true[i, j]), int(G_true[j, i])
                h_ij, h_ji = int(G_hat[i, j]), int(G_hat[j, i])
                if t_ij == 1 and t_ji == 0:
                    if h_ij == 1 and h_ji == 0:
                        continue
                    if h_ij == 0 and h_ji == 1:
                        shd_val += 1
                    elif h_ij == 0 and h_ji == 0:
                        shd_val += 1
                    else:
                        shd_val += 1
                elif t_ij == 0 and t_ji == 1:
                    if h_ij == 0 and h_ji == 1:
                        continue
                    if h_ij == 1 and h_ji == 0:
                        shd_val += 1
                    elif h_ij == 0 and h_ji == 0:
                        shd_val += 1
                    else:
                        shd_val += 1
                else:
                    if h_ij == 0 and h_ji == 0:
                        continue
                    shd_val += int(h_ij == 1) + int(h_ji == 1)
        return int(shd_val)

    shd_total = int(np.sum(np.abs(G_hat - G_true)))
    return int(shd_total)

def auc_pr_error(scores: np.ndarray, labels: np.ndarray) -> float:
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels, dtype=np.int64).reshape(-1)
    if scores.shape != labels.shape:
        raise ValueError(f"Shape mismatch: scores={scores.shape}, labels={labels.shape}")

    pos = int(np.sum(labels == 1))
    neg = int(np.sum(labels == 0))
    if pos == 0 or neg == 0:
        return 1.0

    order = np.argsort(-scores, kind="mergesort")
    y = labels[order]
    tp = np.cumsum(y == 1)
    fp = np.cumsum(y == 0)

    precision = tp / np.maximum(tp + fp, 1)
    recall = tp / float(pos)

    recall_full = np.concatenate([np.array([0.0], dtype=np.float64), recall.astype(np.float64)])
    precision_full = np.concatenate([np.array([1.0], dtype=np.float64), precision.astype(np.float64)])
    recall_full = np.maximum.accumulate(recall_full)

    auc = float(np.trapezoid(y=precision_full, x=recall_full))
    auc = float(np.clip(auc, 0.0, 1.0))
    return float(1.0 - auc)

def negative_control_violation_rate(ate_nc: np.ndarray, threshold: float) -> float:
    ate_nc = np.asarray(ate_nc, dtype=np.float64).reshape(-1)
    return float(np.mean(np.abs(ate_nc) > float(threshold)))

def write_results_json(path: str, cells: list[dict]) -> None:
    _ensure_dir(path)
    payload = {"cells": _to_jsonable(cells)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

def write_predictions_json(path: str, rows: list[dict]) -> None:
    _ensure_dir(path)
    payload = {"predictions": _to_jsonable(rows)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

def write_feature_probs_json(path: str, rows: list[dict]) -> None:
    _ensure_dir(path)
    payload = {"edges": _to_jsonable(rows)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

def plot_pr_curve(scores: np.ndarray, labels: np.ndarray, *, ax=None, title: str | None = None):
    import matplotlib.pyplot as plt

    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels, dtype=np.int64).reshape(-1)
    if scores.shape != labels.shape:
        raise ValueError(f"Shape mismatch: scores={scores.shape}, labels={labels.shape}")

    order = np.argsort(-scores, kind="mergesort")
    y = labels[order]
    pos = int(np.sum(y == 1))
    if pos == 0:
        raise ValueError("No positive labels; PR curve undefined.")

    tp = np.cumsum(y == 1)
    fp = np.cumsum(y == 0)
    precision = tp / np.maximum(tp + fp, 1)
    recall = tp / float(pos)

    recall_full = np.concatenate([np.array([0.0], dtype=np.float64), recall.astype(np.float64)])
    precision_full = np.concatenate([np.array([1.0], dtype=np.float64), precision.astype(np.float64)])
    auc = float(np.trapezoid(y=precision_full, x=recall_full))

    if ax is None:
        _, ax = plt.subplots(figsize=(5, 4))
    ax.plot(recall_full, precision_full, lw=2)
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.grid(True, alpha=0.3)

    if title is None:
        title = f"PR curve (AUC={auc:.3f})"
    ax.set_title(title)
    return ax

def plot_calibration_hist(std: np.ndarray, *, ax=None, title: str | None = None):
    import matplotlib.pyplot as plt

    std = np.asarray(std, dtype=np.float64).reshape(-1)
    if ax is None:
        _, ax = plt.subplots(figsize=(5, 4))
    ax.hist(std, bins=30, alpha=0.8)
    ax.set_xlabel("Predictive std")
    ax.set_ylabel("Count")
    ax.grid(True, alpha=0.3)
    ax.set_title(title or "Predictive uncertainty histogram")
    return ax

def metric_definitions(cfg: Config | None = None) -> list[dict]:
    cfg = Config() if cfg is None else cfg

    defs: list[dict] = []
    lower_is_better = {
        "InterventionalNegativeLogLikelihood",
        "DoEffectRMSE",
        "StructureRecovery_SHD",
        "StructureRecovery_AUCPR",
        "rmse",
        "bias",
        "variance",
        "runtime_sec",
        "RuntimePerQuery_ms",
        "NegativeControlViolationRate",
        "primary_metric",
    }
    for name in cfg.metrics:
        direction = "lower" if name in lower_is_better else "higher"
        units = "nats" if "LogLikelihood" in name else ("ms" if name == "RuntimePerQuery_ms" else "unitless")
        defs.append(
            {
                "name": name,
                "role": "primary" if name == cfg.primary_metric_name else "secondary",
                "direction": direction,
                "units": units,
                "formula": "project-defined",
                "interpretation": "project-defined",
                "literature_basis": "standard",
                "citation_keys": [],
                "is_novel": False,
                "novelty_justification": "",
                "proof_or_validation": "",
            }
        )
    return defs