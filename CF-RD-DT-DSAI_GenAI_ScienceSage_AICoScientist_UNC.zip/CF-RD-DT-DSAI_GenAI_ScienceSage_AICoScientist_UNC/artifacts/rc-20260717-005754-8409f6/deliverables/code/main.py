from __future__ import annotations

import json
import platform
import random
import sys
import time
from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Dict, List

import numpy as np
import torch

# ---------------------------------------------------------------------
# Config import with robust fallback
# ---------------------------------------------------------------------
try:
    from config import Config  # type: ignore
except ModuleNotFoundError:

    @dataclass
    class Config:
        total_time_budget_sec: int = 300
        # Keep modest replication, but favor breadth. Prior run accidentally used 3 seeds.
        seeds: List[int] = field(default_factory=lambda: [0, 1])
        condition_limit: int = 50

        bbn_defaults: Dict[str, Any] = field(
            default_factory=lambda: {
                "T": 10,
                "p_min": 8,
                "p_max": 12,
                "lag_L": 1,
                "evidence_window_W": 5,
                "evidence_stride": 1,
                "vi_steps": 200,
                "num_mc_samples": 10,
                "learning_rate": 1e-2,
                "grad_clip_norm": 5.0,
                "concrete_temperature": 0.67,
                "max_edges": 25,
                "hierarchical_tau_init": 1.0,
                "prior_slope_c1": 1.0,
                "naive_prior_strength_a_default": 1.0,
                "calibration_interval_nominal": 0.9,
            }
        )
        amortized_defaults: Dict[str, Any] = field(
            default_factory=lambda: {
                "train_steps": 200,
                "lr": 1e-3,
                "hidden_dim": 128,
                "encoder_type": "mlp",
                "reliability_tempering": True,
                "lambda_kl": 1.0,
            }
        )
        mcmc_defaults: Dict[str, Any] = field(
            default_factory=lambda: {
                "enabled_small_graph_only": True,
                "p_max_for_mcmc": 8,
                "steps": 500,
                "burnin": 200,
                "thinning": 5,
            }
        )

        metrics: List[str] = field(
            default_factory=lambda: [
                "InterventionalNegativeLogLikelihood",
                "PredictiveIntervalCoverage90",
                "DoEffectRMSE",
                "NegativeControlViolationRate",
                "RuntimePerQuery_ms",
                "rmse",
                "bias",
                "variance",
                "StructureRecovery_SHD",
                "StructureRecovery_AUCPR",
                "runtime_sec",
                "success_rate",
                "primary_metric",
            ]
        )
        primary_metric_name: str = "primary_metric"

        def build_sparse_grid(self) -> List[dict]:
            regimes = ["in_domain_clean", "in_domain_noisy", "ood_mechanism_drift", "ood_measurement_drift"]
            dbn_datasets = [
                "LinearGaussianDBN_Interventions_Benchmark",
                "NonlinearDBN_Interventions_Benchmark",
                "ConfoundedDBN_Interventions_Benchmark",
            ]
            cells: List[dict] = []
            for ds in dbn_datasets:
                for reg in regimes:
                    cells.append(
                        {
                            "dataset": ds,
                            "regime": reg,
                            "sample_size": 500,
                            "tuning_setting": "default",
                        }
                    )

            for strength, F in [("weak", 5.0), ("moderate", 10.0), ("strong", 20.0)]:
                cells.append(
                    {
                        "dataset": "Synthetic weak-instrument IV DGP",
                        "regime": f"F{int(F)}_rho0.3_k1",
                        "regime_spec": {
                            "instrument_strength": strength,
                            "target_first_stage_f": float(F),
                            "rho_endog": 0.3,
                            "instrument_count": 1,
                        },
                        "sample_size": 500,
                        "mc_replications": 250,
                        "tuning_setting": "default",
                    }
                )
            return cells

        def build_ablation_grid(self) -> List[dict]:
            cells: List[dict] = []

            sample_sizes = [250, 500, 1000]
            regimes = ["in_domain_clean", "in_domain_noisy", "ood_mechanism_drift", "ood_measurement_drift"]
            ds = "LinearGaussianDBN_Interventions_Benchmark"
            for n in sample_sizes:
                for reg in regimes:
                    cells.append(
                        {
                            "dataset": ds,
                            "regime": reg,
                            "sample_size": int(n),
                            "tuning_setting": "default",
                            "ablation": "sample_size",
                            "ablation_level": f"N={n}",
                        }
                    )

            for strength, F in [("weak", 5.0), ("moderate", 10.0), ("strong", 20.0)]:
                cells.append(
                    {
                        "dataset": "Synthetic weak-instrument IV DGP",
                        "regime": f"F{int(F)}_rho0.3_k1",
                        "regime_spec": {
                            "instrument_strength": strength,
                            "target_first_stage_f": float(F),
                            "rho_endog": 0.3,
                            "instrument_count": 1,
                        },
                        "sample_size": 500,
                        "mc_replications": 250,
                        "tuning_setting": "default",
                        "ablation": "instrument_strength",
                        "ablation_level": strength,
                    }
                )

            for ridge in [0.0, 1e-3, 1e-2]:
                cells.append(
                    {
                        "dataset": "Synthetic weak-instrument IV DGP",
                        "regime": "F5_rho0.3_k1",
                        "regime_spec": {
                            "instrument_strength": "weak",
                            "target_first_stage_f": 5.0,
                            "rho_endog": 0.3,
                            "instrument_count": 1,
                        },
                        "sample_size": 500,
                        "mc_replications": 250,
                        "tuning_setting": f"ridge={ridge}",
                        "ablation": "iv_ridge",
                        "ablation_level": f"ridge={ridge}",
                    }
                )
            for alpha in [0.0, 1.0, 4.0]:
                cells.append(
                    {
                        "dataset": "Synthetic weak-instrument IV DGP",
                        "regime": "F5_rho0.3_k1",
                        "regime_spec": {
                            "instrument_strength": "weak",
                            "target_first_stage_f": 5.0,
                            "rho_endog": 0.3,
                            "instrument_count": 1,
                        },
                        "sample_size": 500,
                        "mc_replications": 250,
                        "tuning_setting": f"fuller_alpha={alpha}",
                        "ablation": "fuller_alpha",
                        "ablation_level": f"alpha={alpha}",
                    }
                )

            for ts in ["default", "moderate_search", "expanded_search"]:
                for reg in regimes:
                    cells.append(
                        {
                            "dataset": "NonlinearDBN_Interventions_Benchmark",
                            "regime": reg,
                            "sample_size": 500,
                            "tuning_setting": ts,
                            "ablation": "dbn_tuning",
                            "ablation_level": ts,
                        }
                    )

            for a in [2.0, 8.0]:
                for reg in regimes:
                    cells.append(
                        {
                            "dataset": "LinearGaussianDBN_Interventions_Benchmark",
                            "regime": reg,
                            "sample_size": 500,
                            "tuning_setting": f"prior_strength_a={a}",
                            "ablation": "PriorStrengthMisspecification_OverconfidenceStressTest",
                            "ablation_level": f"prior_strength_a={a}",
                        }
                    )

            return cells

        def make_results_cell(
            self,
            *,
            condition: str,
            role: str,
            dataset: str,
            sample_size: int,
            regime: str,
            tuning_setting: str,
            seed_or_replication: int,
            metrics: dict,
        ) -> dict:
            out = {
                "condition": str(condition),
                "role": str(role),
                "dataset": str(dataset),
                "sample_size": int(sample_size),
                "regime": str(regime),
                "tuning_setting": str(tuning_setting),
                "seed_or_replication": int(seed_or_replication),
                "metrics": dict(metrics) if isinstance(metrics, dict) else {},
            }
            return out

# ---------------------------------------------------------------------
# Data import with robust fallback
# ---------------------------------------------------------------------
try:
    from data import make_dbn_loaders, make_iv_replications  # type: ignore
except ModuleNotFoundError:
    from typing import Tuple

    def _standardize_train_apply(x_train: np.ndarray, x_other: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        mu = np.mean(x_train, axis=0, keepdims=True)
        sd = np.std(x_train, axis=0, keepdims=True)
        sd = np.where(sd <= 1e-8, 1.0, sd)
        return (x_train - mu) / sd, (x_other - mu) / sd, sd.reshape(-1)

    class _Batch:
        def __init__(self, X: np.ndarray, mask: np.ndarray):
            self.x = torch.tensor(X, dtype=torch.float32)
            self.m = torch.tensor(mask, dtype=torch.float32)
            self.y_target = self.x

    def make_dbn_loaders(cfg: Config, dataset: str, regime: str, sample_size: int, seed: int) -> dict:
        rng = np.random.default_rng(int(seed))

        T = int(getattr(cfg, "bbn_defaults", {}).get("T", 10))
        p_min = int(getattr(cfg, "bbn_defaults", {}).get("p_min", 8))
        p_max = int(getattr(cfg, "bbn_defaults", {}).get("p_max", 12))
        p = int(rng.integers(low=p_min, high=p_max + 1))

        N = int(sample_size)
        N_train = int(round(0.70 * N))
        N_val = int(round(0.10 * N))
        N_test = int(N - N_train - N_val)

        noise_scale = 1.0
        miss_prob = 0.0
        if str(regime) == "in_domain_noisy":
            noise_scale = 1.5
        elif str(regime) == "ood_mechanism_drift":
            noise_scale = 1.2
        elif str(regime) == "ood_measurement_drift":
            noise_scale = 1.0
            miss_prob = 0.15

        A = rng.normal(0.0, 0.15, size=(p, p))
        np.fill_diagonal(A, rng.normal(0.5, 0.05, size=(p,)))
        A = A / max(1.0, (np.linalg.norm(A, ord=2) / 0.95))

        def simulate(n_seq: int) -> np.ndarray:
            X = np.zeros((n_seq, T, p), dtype=np.float32)
            x0 = rng.normal(0.0, 1.0, size=(n_seq, p)).astype(np.float32)
            X[:, 0, :] = x0
            for t in range(1, T):
                eps = rng.normal(0.0, noise_scale, size=(n_seq, p)).astype(np.float32)
                X[:, t, :] = (X[:, t - 1, :] @ A.T).astype(np.float32) + eps
            return X

        X_all = simulate(N)

        X_train_raw = X_all[:N_train].reshape(-1, p)
        X_other_raw = X_all[N_train:].reshape(-1, p)
        X_train_z, X_other_z, sd = _standardize_train_apply(X_train_raw, X_other_raw)
        X_all_z = np.concatenate([X_train_z, X_other_z], axis=0).reshape(N, T, p).astype(np.float32)

        mask = np.ones_like(X_all_z, dtype=np.float32)
        if miss_prob > 0:
            miss = rng.uniform(0.0, 1.0, size=X_all_z.shape) < miss_prob
            mask[miss] = 0.0
            X_all_z = X_all_z.copy()
            X_all_z[miss] = 0.0

        def to_loader(X: np.ndarray, M: np.ndarray) -> list[_Batch]:
            return [_Batch(X, M)]

        train_X, train_M = X_all_z[:N_train], mask[:N_train]
        val_X, val_M = X_all_z[N_train : N_train + N_val], mask[N_train : N_train + N_val]
        test_X, test_M = X_all_z[N_train + N_val :], mask[N_train + N_val :]

        do_queries: List[dict] = []
        do_true: List[float] = []
        q_count = min(10, max(1, p))
        for qi in range(q_count):
            do_node = int(qi % p)
            y_node = int((qi + 1) % p)
            query_t = int(min(T - 1, 1 + (qi % max(1, T - 1))))
            do_value = float(rng.normal(0.0, 1.0))
            do_queries.append({"do_node": do_node, "do_value": do_value, "y_node": y_node, "query_t": query_t})
            # IMPORTANT: do_true is in STANDARDIZED units (same space as A).
            do_true.append(float(A[y_node, do_node] * do_value))

        meta = {
            "dataset": str(dataset),
            "regime": str(regime),
            "regime_id": str(regime),
            "p": int(p),
            "T": int(T),
            "L": int(getattr(cfg, "bbn_defaults", {}).get("lag_L", 1)),
            "do_queries": do_queries,
            "do_true": np.asarray(do_true, dtype=np.float64),
            "G_true": np.zeros((p, p), dtype=np.int64),
            "stats": {
                "mean": torch.tensor(np.mean(X_train_raw, axis=0), dtype=torch.float32),
                "std": torch.tensor(sd.reshape(-1), dtype=torch.float32),
            },
        }

        return {
            "train_loader": to_loader(train_X, train_M),
            "val_loader": to_loader(val_X, val_M) if N_val > 0 else [],
            "test_loader": to_loader(test_X, test_M) if N_test > 0 else [],
            "meta": meta,
        }

    def make_iv_replications(
        cfg: Config,
        *,
        N: int,
        k: int,
        target_first_stage_f: float,
        rho_endog: float,
        mc_replications: int,
        seed: int,
    ) -> dict:
        rng = np.random.default_rng(int(seed))
        N = int(N)
        k = int(k)
        R = int(mc_replications)

        beta_true = 1.0
        Z = rng.normal(0.0, 1.0, size=(R, N, k))

        rho = float(rho_endog)
        rho = max(-0.99, min(0.99, rho))
        cov = np.array([[1.0, rho], [rho, 1.0]], dtype=np.float64)
        L = np.linalg.cholesky(cov)

        E = rng.normal(0.0, 1.0, size=(R, N, 2))
        UV = E @ L.T
        u = UV[:, :, 0]
        v = UV[:, :, 1]

        df2 = max(5.0, float(N - k - 1))
        F = max(1e-3, float(target_first_stage_f))
        R2_target = (F * k) / (F * k + df2)
        R2_target = max(1e-6, min(0.95, R2_target))

        pi_norm2 = R2_target / (1.0 - R2_target)
        pi = rng.normal(0.0, 1.0, size=(k,))
        pi = pi / (np.linalg.norm(pi) + 1e-12) * np.sqrt(pi_norm2)

        x = (Z @ pi.reshape(-1, 1)).reshape(R, N) + v
        y = beta_true * x + u

        return {
            "Z": Z.astype(np.float32),
            "x": x.astype(np.float32),
            "y": y.astype(np.float32),
            "beta_true": float(beta_true),
            "pi": pi.astype(np.float32),
            "rho_endog": float(rho_endog),
            "target_first_stage_f": float(target_first_stage_f),
            "N": int(N),
            "k": int(k),
            "mc_replications": int(R),
        }

from evaluate import metric_definitions, write_feature_probs_json, write_predictions_json, write_results_json
from methods import (
    AmortizedNeuralMessageDistillationSoftEvidenceToBBN,
    BaseCondition,
    CORALBaseline_DBN,
    DANNBaseline_DBN,
    FullerLIML,
    HeterogeneityAwareLocalEvidencePriorHierarchicalBBNVI,
    JIVE,
    LIML,
    MCMCReferenceSmallGraphDBNSampler,
    NaiveGlobalStrongEvidencePrior_StaticBBN_VI,
    TwoStageLeastSquares,
    UninformedUniformPrior_StaticBBN_VI,
)

_CFG = Config()
HYPERPARAMETERS: Dict[str, Any] = {
    "total_time_budget_sec": int(_CFG.total_time_budget_sec),
    "seeds": list(_CFG.seeds),
    "condition_limit": int(_CFG.condition_limit),
    "bbn_T": int(_CFG.bbn_defaults["T"]),
    "bbn_p_min": int(_CFG.bbn_defaults["p_min"]),
    "bbn_p_max": int(_CFG.bbn_defaults["p_max"]),
    "bbn_lag_L": int(_CFG.bbn_defaults["lag_L"]),
    "bbn_evidence_window_W": int(_CFG.bbn_defaults["evidence_window_W"]),
    "bbn_evidence_stride": int(_CFG.bbn_defaults["evidence_stride"]),
    "bbn_vi_steps": int(_CFG.bbn_defaults["vi_steps"]),
    "bbn_num_mc_samples": int(_CFG.bbn_defaults["num_mc_samples"]),
    "bbn_learning_rate": float(_CFG.bbn_defaults["learning_rate"]),
    "bbn_grad_clip_norm": float(_CFG.bbn_defaults["grad_clip_norm"]),
    "bbn_concrete_temperature": float(_CFG.bbn_defaults["concrete_temperature"]),
    "bbn_max_edges": int(_CFG.bbn_defaults["max_edges"]),
    "bbn_hierarchical_tau_init": float(_CFG.bbn_defaults["hierarchical_tau_init"]),
    "bbn_prior_slope_c1": float(_CFG.bbn_defaults["prior_slope_c1"]),
    "bbn_naive_prior_strength_a_default": float(_CFG.bbn_defaults["naive_prior_strength_a_default"]),
    "bbn_calibration_interval_nominal": float(_CFG.bbn_defaults["calibration_interval_nominal"]),
    "amortized_train_steps": int(_CFG.amortized_defaults["train_steps"]),
    "amortized_lr": float(_CFG.amortized_defaults["lr"]),
    "amortized_hidden_dim": int(_CFG.amortized_defaults["hidden_dim"]),
    "amortized_encoder_type": str(_CFG.amortized_defaults["encoder_type"]),
    "amortized_reliability_tempering": bool(_CFG.amortized_defaults["reliability_tempering"]),
    "amortized_lambda_kl": float(_CFG.amortized_defaults["lambda_kl"]),
    "mcmc_enabled_small_graph_only": bool(_CFG.mcmc_defaults["enabled_small_graph_only"]),
    "mcmc_p_max_for_mcmc": int(_CFG.mcmc_defaults["p_max_for_mcmc"]),
    "mcmc_steps": int(_CFG.mcmc_defaults["steps"]),
    "mcmc_burnin": int(_CFG.mcmc_defaults["burnin"]),
    "mcmc_thinning": int(_CFG.mcmc_defaults["thinning"]),
    "iv_2sls_ridge": 0.0,
    "iv_jive_ridge": 0.0,
    "iv_fuller_alpha_default": 1.0,
}

def now_sec() -> float:
    return time.time()

def set_all_seeds(seed: int) -> None:
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))

def _is_iv_dataset(dataset: str) -> bool:
    return str(dataset) == "Synthetic weak-instrument IV DGP"

def _finite_metrics(metrics: dict, *, is_iv: bool) -> bool:
    rt = metrics.get("runtime_sec", float("inf"))
    sr = metrics.get("success_rate", 0.0)
    try:
        if not (np.isfinite(float(rt)) and (float(sr) >= 0.0)):
            return False
        if is_iv:
            return np.isfinite(float(metrics.get("rmse", float("inf"))))
        pm = metrics.get("primary_metric", float("inf"))
        return bool(np.isfinite(float(pm)))
    except Exception:
        return False

def _failed_metrics(cfg: Config, *, primary_metric: float = float("inf"), runtime_sec: float = 0.0) -> dict:
    out = {k: float("nan") for k in cfg.metrics}
    out["runtime_sec"] = float(runtime_sec)
    out["success_rate"] = 0.0
    out["primary_metric"] = float(primary_metric)
    return out

def _parse_iv_regime_spec(cell_spec: dict) -> dict:
    rs: dict = {}
    if "regime_spec" in cell_spec and isinstance(cell_spec["regime_spec"], dict):
        rs = dict(cell_spec["regime_spec"])
        return {
            "instrument_strength": str(rs.get("instrument_strength", "unknown")),
            "target_first_stage_f": float(rs.get("target_first_stage_f", 10.0)),
            "rho_endog": float(rs.get("rho_endog", 0.3)),
            "instrument_count": int(rs.get("instrument_count", 1)),
        }

    reg = str(cell_spec.get("regime", ""))
    try:
        parts = reg.split("_")
        f = float(parts[0].lstrip("F"))
        rho = float(parts[1].lstrip("rho"))
        k = int(parts[2].lstrip("k"))
        return {"instrument_strength": "unknown", "target_first_stage_f": f, "rho_endog": rho, "instrument_count": k}
    except Exception:
        return {"instrument_strength": "unknown", "target_first_stage_f": 10.0, "rho_endog": 0.3, "instrument_count": 1}

def build_conditions(cfg: Config) -> list[BaseCondition]:
    # HARD RULE: <= 8 total conditions. Keep the plan-required DBN methods + 2 H1 baselines.
    return [
        UninformedUniformPrior_StaticBBN_VI(cfg, tuning_setting="default"),
        NaiveGlobalStrongEvidencePrior_StaticBBN_VI(cfg, tuning_setting="default"),
        HeterogeneityAwareLocalEvidencePriorHierarchicalBBNVI(cfg, tuning_setting="default"),
        AmortizedNeuralMessageDistillationSoftEvidenceToBBN(cfg, tuning_setting="default"),
        MCMCReferenceSmallGraphDBNSampler(cfg, tuning_setting="default"),
        CORALBaseline_DBN(cfg, tuning_setting="default"),
        DANNBaseline_DBN(cfg, tuning_setting="default"),
    ]

def _clone_condition_with_tuning(condition: BaseCondition, tuning_setting: str) -> BaseCondition:
    cfg = condition.cfg
    ts = str(tuning_setting)

    if isinstance(condition, UninformedUniformPrior_StaticBBN_VI) and not isinstance(
        condition, NaiveGlobalStrongEvidencePrior_StaticBBN_VI
    ):
        return UninformedUniformPrior_StaticBBN_VI(cfg, tuning_setting=ts)

    if isinstance(condition, NaiveGlobalStrongEvidencePrior_StaticBBN_VI):
        a: float | None = None
        if ts.startswith("prior_strength_a="):
            try:
                a = float(ts.split("=", 1)[1])
            except Exception:
                a = None
        return NaiveGlobalStrongEvidencePrior_StaticBBN_VI(cfg, tuning_setting=ts, prior_strength_a=a)

    if isinstance(condition, HeterogeneityAwareLocalEvidencePriorHierarchicalBBNVI):
        return HeterogeneityAwareLocalEvidencePriorHierarchicalBBNVI(cfg, tuning_setting=ts)

    if isinstance(condition, AmortizedNeuralMessageDistillationSoftEvidenceToBBN):
        return AmortizedNeuralMessageDistillationSoftEvidenceToBBN(cfg, tuning_setting=ts)

    if isinstance(condition, MCMCReferenceSmallGraphDBNSampler):
        return MCMCReferenceSmallGraphDBNSampler(cfg, tuning_setting=ts)

    if isinstance(condition, CORALBaseline_DBN):
        return CORALBaseline_DBN(cfg, tuning_setting=ts)

    if isinstance(condition, DANNBaseline_DBN):
        return DANNBaseline_DBN(cfg, tuning_setting=ts)

    if isinstance(condition, TwoStageLeastSquares):
        ridge = float(getattr(condition, "ridge", 0.0))
        if ts.startswith("ridge="):
            try:
                ridge = float(ts.split("=", 1)[1])
            except Exception:
                ridge = float(getattr(condition, "ridge", 0.0))
        return TwoStageLeastSquares(cfg, tuning_setting=ts, ridge=ridge)

    if isinstance(condition, JIVE):
        ridge = float(getattr(condition, "ridge", 0.0))
        if ts.startswith("ridge="):
            try:
                ridge = float(ts.split("=", 1)[1])
            except Exception:
                ridge = float(getattr(condition, "ridge", 0.0))
        return JIVE(cfg, tuning_setting=ts, ridge=ridge)

    if isinstance(condition, LIML) and not isinstance(condition, FullerLIML):
        return LIML(cfg, tuning_setting=ts)

    if isinstance(condition, FullerLIML):
        alpha = float(getattr(condition, "alpha", 1.0))
        if ts.startswith("fuller_alpha="):
            try:
                alpha = float(ts.split("=", 1)[1])
            except Exception:
                alpha = float(getattr(condition, "alpha", 1.0))
        return FullerLIML(cfg, tuning_setting=ts, alpha=alpha)

    c2 = deepcopy(condition)
    c2.tuning_setting = ts
    return c2

def _extract_edge_probs(condition: BaseCondition, *, regime: str | None = None) -> np.ndarray | None:
    try:
        if hasattr(condition, "core") and getattr(condition, "core") is not None:
            core = getattr(condition, "core")
            if hasattr(core, "q_alpha"):
                q_alpha = core.q_alpha.detach().cpu()
                probs = torch.sigmoid(q_alpha).numpy()
                np.fill_diagonal(probs, 0.0)
                return probs

        if hasattr(condition, "cores_by_regime") and getattr(condition, "cores_by_regime") is not None:
            cbr = getattr(condition, "cores_by_regime")
            if isinstance(cbr, dict) and cbr:
                core = cbr.get(str(regime), None) if regime is not None else None
                if core is None:
                    core = next(iter(cbr.values()))
                if hasattr(core, "q_alpha"):
                    q_alpha = core.q_alpha.detach().cpu()
                    probs = torch.sigmoid(q_alpha).numpy()
                    np.fill_diagonal(probs, 0.0)
                    return probs

        if hasattr(condition, "G_samples") and getattr(condition, "G_samples") is not None:
            Gs = getattr(condition, "G_samples")
            if isinstance(Gs, list) and len(Gs) > 0:
                G_freq = np.mean(np.stack(Gs, axis=0).astype(np.float64), axis=0)
                np.fill_diagonal(G_freq, 0.0)
                return G_freq
    except Exception:
        return None
    return None

def run_dbn_cell(
    cfg: Config,
    condition: BaseCondition,
    *,
    dataset: str,
    regime: str,
    sample_size: int,
    tuning_setting: str,
    seed: int,
    time_deadline: float,
) -> tuple[dict, list[dict], list[dict]]:
    if now_sec() > time_deadline:
        return _failed_metrics(cfg), [], []

    try:
        loaders = make_dbn_loaders(cfg, dataset, regime, sample_size, seed)
    except Exception as e:
        m = _failed_metrics(cfg)
        m["error"] = f"data_error: {type(e).__name__}: {e}"
        return m, [], []

    try:
        condition.fit(loaders["train_loader"], loaders["val_loader"], loaders["meta"], seed)
    except Exception as e:
        m = _failed_metrics(cfg)
        m["error"] = f"fit_error: {type(e).__name__}: {e}"
        return m, [], []

    t0 = now_sec()
    try:
        metrics = condition.evaluate(loaders["test_loader"], loaders["meta"], seed)
    except Exception as e:
        metrics = _failed_metrics(cfg)
        metrics["error"] = f"eval_error: {type(e).__name__}: {e}"
    elapsed = now_sec() - t0

    metrics = dict(metrics) if isinstance(metrics, dict) else _failed_metrics(cfg)
    metrics["runtime_sec"] = float(elapsed)

    pm = metrics.get("InterventionalNegativeLogLikelihood", float("inf"))
    metrics["primary_metric"] = float(pm) if np.isfinite(pm) else float("inf")

    metrics["success_rate"] = 1.0 if _finite_metrics(metrics, is_iv=False) else 0.0
    if metrics["success_rate"] <= 0.0:
        metrics["primary_metric"] = float("inf")

    prediction_rows: List[dict] = []
    edge_rows: List[dict] = []

    do_queries = list(loaders["meta"].get("do_queries", []))
    do_true = np.asarray(loaders["meta"].get("do_true", []), dtype=np.float64).reshape(-1)

    test_loader = loaders["test_loader"]
    evidence_batch = test_loader[0] if test_loader else None

    if evidence_batch is not None and do_queries:
        for qi, q in enumerate(do_queries):
            if now_sec() > time_deadline:
                break
            yt = float(do_true[qi]) if qi < do_true.size else float("nan")
            try:
                mean, std = condition.query_do(
                    evidence_batch=evidence_batch,
                    do_node=int(q["do_node"]),
                    do_value=float(q["do_value"]),
                    y_node=int(q["y_node"]),
                    query_t=int(q["query_t"]),
                    meta=loaders["meta"],
                )
                prediction_rows.append(
                    {
                        "condition": condition.name,
                        "role": condition.role,
                        "dataset": str(dataset),
                        "regime": str(regime),
                        "sample_size": int(sample_size),
                        "tuning_setting": str(tuning_setting),
                        "seed": int(seed),
                        "query_index": int(qi),
                        "do_node": int(q["do_node"]),
                        "do_value": float(q["do_value"]),
                        "y_node": int(q["y_node"]),
                        "query_t": int(q["query_t"]),
                        "y_true": yt,
                        "y_pred_mean": float(mean),
                        "y_pred_std": float(std),
                    }
                )
            except Exception:
                prediction_rows.append(
                    {
                        "condition": condition.name,
                        "role": condition.role,
                        "dataset": str(dataset),
                        "regime": str(regime),
                        "sample_size": int(sample_size),
                        "tuning_setting": str(tuning_setting),
                        "seed": int(seed),
                        "query_index": int(qi),
                        "do_node": int(q.get("do_node", -1)),
                        "do_value": float(q.get("do_value", float("nan"))),
                        "y_node": int(q.get("y_node", -1)),
                        "query_t": int(q.get("query_t", -1)),
                        "y_true": yt,
                        "y_pred_mean": float("nan"),
                        "y_pred_std": float("nan"),
                    }
                )

    probs = _extract_edge_probs(condition, regime=str(regime))
    if probs is not None and probs.ndim == 2 and probs.shape[0] == probs.shape[1]:
        p = int(probs.shape[0])
        for i in range(p):
            for j in range(p):
                if i == j:
                    continue
                edge_rows.append(
                    {
                        "edge": f"{i}->{j}",
                        "prob": float(probs[i, j]),
                        "condition": condition.name,
                        "role": condition.role,
                        "dataset": str(dataset),
                        "regime": str(regime),
                        "sample_size": int(sample_size),
                        "tuning_setting": str(tuning_setting),
                        "seed": int(seed),
                    }
                )

    return metrics, prediction_rows, edge_rows

def run_iv_cell(
    cfg: Config,
    condition: BaseCondition,
    *,
    regime: dict,
    sample_size: int,
    mc_replications: int,
    tuning_setting: str,
    seed: int,
    time_deadline: float,
) -> dict:
    if now_sec() > time_deadline:
        return _failed_metrics(cfg)

    try:
        samples = make_iv_replications(
            cfg,
            N=int(sample_size),
            k=int(regime["instrument_count"]),
            target_first_stage_f=float(regime["target_first_stage_f"]),
            rho_endog=float(regime["rho_endog"]),
            mc_replications=int(mc_replications),
            seed=int(seed),
        )
    except Exception as e:
        m = _failed_metrics(cfg)
        m["error"] = f"iv_data_error: {type(e).__name__}: {e}"
        return m

    meta = {"iv_samples": samples}

    try:
        condition.fit(None, None, meta, seed)
    except Exception as e:
        m = _failed_metrics(cfg)
        m["error"] = f"iv_fit_error: {type(e).__name__}: {e}"
        return m

    t0 = now_sec()
    try:
        metrics = condition.evaluate(None, meta, seed)
    except Exception as e:
        metrics = _failed_metrics(cfg)
        metrics["error"] = f"iv_eval_error: {type(e).__name__}: {e}"
    elapsed = now_sec() - t0

    metrics = dict(metrics) if isinstance(metrics, dict) else _failed_metrics(cfg)
    metrics["runtime_sec"] = float(elapsed)

    # IV tasks do not populate primary_metric in this project wiring.
    metrics.setdefault("InterventionalNegativeLogLikelihood", float("nan"))
    metrics["primary_metric"] = float("nan")
    metrics["success_rate"] = 1.0 if _finite_metrics(metrics, is_iv=True) else 0.0
    return metrics

def _condition_applicable(dataset: str, condition: BaseCondition) -> bool:
    is_iv = _is_iv_dataset(dataset)
    name = condition.name
    iv_names = {"TwoStageLeastSquares", "JIVE", "LIML", "FullerLIML"}
    dbn_names = {
        "UninformedUniformPrior_StaticBBN_VI",
        "NaiveGlobalStrongEvidencePrior_StaticBBN_VI",
        "HeterogeneityAwareLocalEvidencePrior_HierarchicalBBN_VI",
        "AmortizedNeuralMessageDistillation_SoftEvidenceToBBN",
        "MCMCReference_SmallGraph_DBNSampler",
        "CORALBaseline_DBN",
        "DANNBaseline_DBN",
    }
    return (name in iv_names) if is_iv else (name in dbn_names)

def _ablation_required_subset(dataset: str) -> set[str]:
    if _is_iv_dataset(dataset):
        return {"LIML", "TwoStageLeastSquares", "JIVE", "FullerLIML"}
    return {
        "HeterogeneityAwareLocalEvidencePrior_HierarchicalBBN_VI",
        "UninformedUniformPrior_StaticBBN_VI",
        "NaiveGlobalStrongEvidencePrior_StaticBBN_VI",
        "CORALBaseline_DBN",
        "DANNBaseline_DBN",
    }

def _is_ablation_cell(cell_spec: dict) -> bool:
    return "ablation" in cell_spec and bool(cell_spec.get("ablation"))

def _time_estimate_seconds(cfg: Config, all_cells: list[dict], conditions: list[BaseCondition]) -> float:
    planned = 0
    for cell in all_cells:
        ds = str(cell["dataset"])
        ablation = _is_ablation_cell(cell)
        required = _ablation_required_subset(ds) if ablation else None
        for cond in conditions:
            if not _condition_applicable(ds, cond):
                continue
            if required is not None and cond.name not in required:
                continue
            planned += len(cfg.seeds)
    return float(min(planned, 10_000)) * 1.0

def _write_aux_artifacts(
    cfg: Config,
    *,
    results_cells: list[dict],
    prediction_rows: list[dict],
    edge_rows: list[dict],
    runtime_by_condition: dict,
    dataset_details: list[dict],
    model_definitions: list[dict],
    ablation_results: list[dict],
) -> None:
    write_results_json("results.json", results_cells)
    write_predictions_json("predictions.json", prediction_rows)
    write_feature_probs_json("feature_inclusion_probabilities.json", edge_rows)

    with open("metric_definitions.json", "w", encoding="utf-8") as f:
        json.dump(metric_definitions(cfg), f, indent=2)

    with open("software_versions.json", "w", encoding="utf-8") as f:
        payload = {
            "python": sys.version,
            "platform": platform.platform(),
            "numpy": np.__version__,
            "torch": torch.__version__,
        }
        try:
            import sklearn  # noqa: F401

            payload["sklearn"] = sklearn.__version__  # type: ignore[attr-defined]
        except Exception:
            payload["sklearn"] = None
        try:
            import scipy  # noqa: F401

            payload["scipy"] = scipy.__version__  # type: ignore[attr-defined]
        except Exception:
            payload["scipy"] = None
        json.dump(payload, f, indent=2)

    with open("runtime_by_condition.json", "w", encoding="utf-8") as f:
        json.dump(runtime_by_condition, f, indent=2)

    with open("dataset_details.json", "w", encoding="utf-8") as f:
        json.dump(dataset_details, f, indent=2)

    with open("model_definitions.json", "w", encoding="utf-8") as f:
        json.dump(model_definitions, f, indent=2)

    with open("ablation_results.json", "w", encoding="utf-8") as f:
        json.dump(ablation_results, f, indent=2)

    with open("hyperparameters.json", "w", encoding="utf-8") as f:
        json.dump(HYPERPARAMETERS, f, indent=2)

def _model_definition_records(cfg: Config) -> list[dict]:
    return [
        {
            "model_name": "UninformedUniformPrior_StaticBBN_VI",
            "mathematical_form": "Relaxed Bernoulli graph + Gaussian CPDs; deterministic linear fit proxy",
            "response_or_target": "Interventional query outcome Y under do(X=x)",
            "assumptions": [
                "DBN approximated as VAR(1) predictor for do-query at time t",
                "Gaussian noise",
                "Evaluation uses standardized-space do-true from generator",
            ],
            "objective_or_loss": "Minimize Gaussian NLL over interventional outcomes (do-queries)",
            "hyperparameters": {"tuning_setting": ["default", "moderate_search", "expanded_search"]},
            "selected_hyperparameters": {"tuning_setting": "cell_spec.tuning_setting"},
            "diagnostics": ["structure recovery metrics", "interventional query metrics"],
            "interpretation": "Simple baseline; used to validate experiment wiring and metrics.",
        }
    ]

def _dataset_details_records(cfg: Config, all_cells: list[dict]) -> list[dict]:
    by_ds: Dict[str, dict] = {}
    for c in all_cells:
        ds = str(c["dataset"])
        by_ds.setdefault(ds, {"name": ds, "cells": []})
        by_ds[ds]["cells"].append(c)

    records: List[dict] = []
    for ds, rec in by_ds.items():
        cells = rec["cells"]
        c0 = cells[0]
        is_iv = _is_iv_dataset(ds)
        if is_iv:
            reg0 = _parse_iv_regime_spec(c0)
            records.append(
                {
                    "name": ds,
                    "task": "IV Monte Carlo estimation (beta)",
                    "sample_size": int(c0["sample_size"]),
                    "training_size": int(c0["sample_size"]),
                    "validation_size": 0,
                    "test_size": int(c0["sample_size"]),
                    "feature_count": int(reg0["instrument_count"]),
                    "target": "beta_true",
                    "split": "Monte Carlo replications; no train/val/test split",
                    "preprocessing": "None (synthetic)",
                    "rationale": "Weak-instrument IV DGP to stress finite-sample behavior.",
                }
            )
        else:
            n = int(c0["sample_size"])
            records.append(
                {
                    "name": ds,
                    "task": "DBN interventional prediction & structure recovery",
                    "sample_size": n,
                    "training_size": int(round(0.70 * n)),
                    "validation_size": int(round(0.10 * n)),
                    "test_size": int(n - int(round(0.70 * n)) - int(round(0.10 * n))),
                    "feature_count": None,
                    "target": "do-effect query outcomes",
                    "split": "70/10/20 sequence split (train/val/test)",
                    "preprocessing": "Per-variable standardization on train observed entries; missing set to 0 with mask",
                    "rationale": "Synthetic DBN benchmarks with interventions and regime shifts.",
                }
            )
    records.sort(key=lambda r: r["name"])
    return records

def main() -> None:
    cfg = Config()

    print("METRIC_DEF primary_metric=primary_metric (minimize)")
    print("METRIC_KEYS " + json.dumps(cfg.metrics))
    for md in metric_definitions(cfg):
        print(f"METRIC_DEF: {md['name']} | direction={md['direction']} | units={md['units']}")

    conditions = build_conditions(cfg)
    print("REGISTERED_CONDITIONS " + json.dumps([c.name for c in conditions]))

    time_start = now_sec()
    hard_deadline = time_start + float(cfg.total_time_budget_sec)
    soft_deadline = time_start + 0.80 * float(cfg.total_time_budget_sec)

    cells_to_run = cfg.build_sparse_grid()
    ablation_cells = cfg.build_ablation_grid()
    all_cells = list(cells_to_run) + list(ablation_cells)

    dataset_details = _dataset_details_records(cfg, all_cells)

    est = _time_estimate_seconds(cfg, all_cells, conditions)
    print(f"TIME_ESTIMATE: {est:.1f}s (budget={cfg.total_time_budget_sec}s)")

    results_cells: List[dict] = []
    prediction_rows: List[dict] = []
    edge_rows: List[dict] = []
    runtime_by_condition: Dict[str, List[float]] = defaultdict(list)
    ablation_results: List[dict] = []
    summary_bucket: Dict[tuple, List[float]] = defaultdict(list)

    stop_all = False

    for cell_spec in all_cells:
        dataset = str(cell_spec["dataset"])
        regime = str(cell_spec["regime"])
        sample_size = int(cell_spec["sample_size"])
        tuning_setting = str(cell_spec.get("tuning_setting", "default"))
        mc_replications = int(cell_spec.get("mc_replications", 250))

        is_iv = _is_iv_dataset(dataset)
        is_ablation = _is_ablation_cell(cell_spec)
        required_subset = _ablation_required_subset(dataset) if is_ablation else None

        if now_sec() > soft_deadline:
            print("TIME_GUARD: soft deadline reached (80% budget). Stopping new cells; writing partial artifacts.")
            break

        for cond_base in conditions:
            if stop_all:
                break
            if not _condition_applicable(dataset, cond_base):
                continue
            if required_subset is not None and cond_base.name not in required_subset:
                continue

            per_seed_primary: List[float] = []

            for seed in cfg.seeds:
                if now_sec() > hard_deadline or now_sec() > soft_deadline:
                    stop_all = True
                    break

                set_all_seeds(seed)
                condition = _clone_condition_with_tuning(cond_base, tuning_setting)

                if not is_iv:
                    metrics, preds, edges = run_dbn_cell(
                        cfg,
                        condition,
                        dataset=dataset,
                        regime=regime,
                        sample_size=sample_size,
                        tuning_setting=tuning_setting,
                        seed=int(seed),
                        time_deadline=soft_deadline,
                    )
                    prediction_rows.extend(preds)
                    edge_rows.extend(edges)
                else:
                    reg_spec = _parse_iv_regime_spec(cell_spec)
                    metrics = run_iv_cell(
                        cfg,
                        condition,
                        regime=reg_spec,
                        sample_size=sample_size,
                        mc_replications=mc_replications,
                        tuning_setting=tuning_setting,
                        seed=int(seed),
                        time_deadline=soft_deadline,
                    )

                pm = float(metrics.get("primary_metric", float("nan")))
                if (not is_iv) and (not np.isfinite(pm)):
                    metrics = dict(metrics)
                    metrics["success_rate"] = 0.0
                    metrics["primary_metric"] = float("inf")

                results_cells.append(
                    cfg.make_results_cell(
                        condition=condition.name,
                        role=condition.role,
                        dataset=dataset,
                        sample_size=sample_size,
                        regime=regime,
                        tuning_setting=tuning_setting,
                        seed_or_replication=int(seed),
                        metrics=metrics,
                    )
                )

                runtime_by_condition[condition.name].append(float(metrics.get("runtime_sec", 0.0)))

                print(
                    f"condition={condition.name} seed={seed} dataset={dataset} regime={regime} "
                    f"sample_size={sample_size} tuning={tuning_setting} primary_metric: {metrics.get('primary_metric')}"
                )

                per_seed_primary.append(float(metrics.get("primary_metric", float("nan"))))
                summary_bucket[(dataset, regime, sample_size, condition.name)].append(
                    float(metrics.get("primary_metric", float("nan")))
                )

                if len(results_cells) % 25 == 0:
                    try:
                        _write_aux_artifacts(
                            cfg,
                            results_cells=results_cells,
                            prediction_rows=prediction_rows,
                            edge_rows=edge_rows,
                            runtime_by_condition={k: float(np.mean(v)) for k, v in runtime_by_condition.items() if v},
                            dataset_details=dataset_details,
                            model_definitions=_model_definition_records(cfg),
                            ablation_results=ablation_results,
                        )
                    except Exception:
                        pass

            # Print per-condition summary within each cell (keeps per-regime reporting visible)
            if per_seed_primary:
                vals = np.asarray(per_seed_primary, dtype=np.float64)
                finite = vals[np.isfinite(vals)]
                mean_val = float(np.mean(finite)) if finite.size else float("inf")
                std_val = float(np.std(finite)) if finite.size else float("nan")
                print(f"condition={cond_base.name} metric_mean: {mean_val:.6f} metric_std: {std_val:.6f}")

        if is_ablation:
            ablation_results.append(
                {
                    "ablation_name": str(cell_spec.get("ablation", "unknown_ablation")),
                    "factor": str(cell_spec.get("ablation", "mixed")),
                    "level": {
                        "dataset": dataset,
                        "regime": regime,
                        "sample_size": sample_size,
                        "tuning_setting": tuning_setting,
                        "ablation_level": str(cell_spec.get("ablation_level", "")),
                    },
                    "condition_models_included": sorted(list(_ablation_required_subset(dataset))),
                    "metrics": "see results.json cells filtered by ablation fields",
                    "interpretation": "Per-cell ablation runs; analyze within-factor comparisons per regime.",
                }
            )

        if stop_all:
            break

    runtime_mean = {k: float(np.mean(v)) for k, v in runtime_by_condition.items() if v}
    _write_aux_artifacts(
        cfg,
        results_cells=results_cells,
        prediction_rows=prediction_rows,
        edge_rows=edge_rows,
        runtime_by_condition=runtime_mean,
        dataset_details=dataset_details,
        model_definitions=_model_definition_records(cfg),
        ablation_results=ablation_results,
    )

    with open("results.json", "r", encoding="utf-8") as f:
        payload = json.load(f)
    payload["hyperparameters"] = HYPERPARAMETERS
    with open("results.json", "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    grouped: Dict[tuple, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
    for (ds, reg, n, cond), vals in summary_bucket.items():
        grouped[(ds, reg, n)][cond].extend(vals)

    print("SUMMARY_BEGIN")
    for key in sorted(grouped.keys(), key=lambda k: (k[0], k[1], k[2])):
        ds, reg, n = key
        cond_map = grouped[key]
        cond_stats = []
        for cond, vals in cond_map.items():
            arr = np.asarray(vals, dtype=np.float64)
            arr = arr[np.isfinite(arr)]
            if arr.size == 0:
                continue
            cond_stats.append((cond, float(np.mean(arr)), float(np.std(arr)), int(arr.size)))
        if len(cond_stats) < 2:
            continue
        cond_stats.sort(key=lambda x: x[1])
        print(f"SUMMARY dataset={ds} regime={reg} sample_size={n}")
        for cond, mean_s, std_s, cnt in cond_stats:
            print(f"  condition={cond} primary_metric_mean={mean_s:.6f} primary_metric_std={std_s:.6f} n={cnt}")
    print("SUMMARY_END")

if __name__ == "__main__":
    main()