from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch

from evaluate import auc_pr_error, gaussian_nll, interval_coverage, negative_control_violation_rate, shd

class BaseCondition:
    """Base interface for all conditions."""

    name: str = "BaseCondition"
    role: str = "baseline"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        self.cfg = cfg
        self.tuning_setting = str(tuning_setting)

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        raise NotImplementedError

    def evaluate(self, test_loader, meta: dict, seed: int) -> dict:
        raise NotImplementedError

    def query_do(
        self,
        *,
        evidence_batch,
        do_node: int,
        do_value: float,
        y_node: int,
        query_t: int,
        meta: dict,
    ) -> Tuple[float, float]:
        raise NotImplementedError

def _ridge_solve(X: np.ndarray, y: np.ndarray, lam: float) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64).reshape(-1, 1)
    XtX = X.T @ X
    A = XtX + float(lam) * np.eye(X.shape[1], dtype=np.float64)
    Xty = X.T @ y
    try:
        b = np.linalg.solve(A, Xty)
    except np.linalg.LinAlgError:
        b = np.linalg.pinv(A) @ Xty
    return b.reshape(-1, 1)

def _ols(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    return _ridge_solve(X, y, 0.0)

def _add_intercept(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    return np.concatenate([np.ones((X.shape[0], 1), dtype=np.float64), X], axis=1)

def _sigmoid(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    x = np.clip(x, -40.0, 40.0)
    return 1.0 / (1.0 + np.exp(-x))

def _flatten_batches_to_arrays(test_loader, y_nodes: List[int]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    xs: List[np.ndarray] = []
    ms: List[np.ndarray] = []
    ys: List[np.ndarray] = []
    if test_loader is None:
        return (
            np.zeros((0, 0, 0), dtype=np.float64),
            np.zeros((0, 0, 0), dtype=np.float64),
            np.zeros((0, 0, 0), dtype=np.float64),
        )
    for b in test_loader:
        x = b.x.detach().cpu().numpy()
        m = b.m.detach().cpu().numpy()
        y = b.y_target.detach().cpu().numpy()
        xs.append(x)
        ms.append(m)
        ys.append(y)
    X = np.concatenate(xs, axis=0) if xs else np.zeros((0, 0, 0), dtype=np.float64)
    M = np.concatenate(ms, axis=0) if ms else np.zeros((0, 0, 0), dtype=np.float64)
    Y = np.concatenate(ys, axis=0) if ys else np.zeros((0, 0, 0), dtype=np.float64)
    return X, M, Y

def _mask_off_diagonal_static(G: np.ndarray) -> np.ndarray:
    G = np.asarray(G)
    if G.ndim != 2 or G.shape[0] != G.shape[1]:
        raise ValueError("Expected [p,p]")
    p = G.shape[0]
    mask = np.ones((p, p), dtype=bool)
    np.fill_diagonal(mask, False)
    return mask

def _collapse_lagged_to_static(G: np.ndarray) -> np.ndarray:
    G = np.asarray(G)
    if G.ndim == 2:
        return G
    if G.ndim == 3:
        return np.max(G, axis=0)
    raise ValueError("G must be [p,p] or [L,p,p]")

class _SimpleDBNCore:
    """Deterministic core: edge probabilities + linear-Gaussian one-step predictor."""

    def __init__(self, p: int, seed: int, prior_strength: float):
        rng = np.random.default_rng(int(seed))
        logits = rng.normal(0.0, 1.0, size=(p, p)).astype(np.float64)
        np.fill_diagonal(logits, -10.0)
        self.q_alpha = torch.tensor(logits * float(prior_strength), dtype=torch.float32)

        self.B = np.zeros((p + 1, p), dtype=np.float64)
        self.noise_std = np.ones((p,), dtype=np.float64)

    def _design(self, Xmat: np.ndarray) -> np.ndarray:
        return _add_intercept(Xmat)

    def fit_linear(self, X: np.ndarray, M: np.ndarray, ridge: float) -> None:
        N, T, p = X.shape
        rows_X: List[np.ndarray] = []
        rows_Y: List[np.ndarray] = []
        for t in range(T - 1):
            obs = (M[:, t, :] > 0.5) & (M[:, t + 1, :] > 0.5)
            good = np.all(obs, axis=1)
            if not np.any(good):
                continue
            Xt = X[good, t, :]
            Yt1 = X[good, t + 1, :]
            rows_X.append(Xt)
            rows_Y.append(Yt1)
        if not rows_X:
            self.B[:] = 0.0
            self.noise_std[:] = 1.0
            return
        Xmat = np.concatenate(rows_X, axis=0)
        Ymat = np.concatenate(rows_Y, axis=0)
        D = self._design(Xmat)
        B = np.zeros((D.shape[1], p), dtype=np.float64)
        for j in range(p):
            bj = _ridge_solve(D, Ymat[:, j], float(ridge))
            B[:, j] = bj.reshape(-1)
        self.B = B
        resid = Ymat - D @ B
        self.noise_std = np.sqrt(np.maximum(np.mean(resid**2, axis=0), 1e-6))

class _RBFDBNCore(_SimpleDBNCore):
    """Variant core: adds deterministic RBF features before ridge fit (different design matrix)."""

    def __init__(self, p: int, seed: int, prior_strength: float, num_centers: int = 8, gamma: float = 1.0):
        super().__init__(p=p, seed=seed, prior_strength=prior_strength)
        self.num_centers = int(max(1, num_centers))
        self.gamma = float(max(gamma, 1e-6))
        rng = np.random.default_rng(int(seed) + 555)
        self.centers = rng.normal(0.0, 1.0, size=(self.num_centers, p)).astype(np.float64)

    def _featurize(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        dif = X[:, None, :] - self.centers[None, :, :]
        r2 = np.sum(dif * dif, axis=2)
        Phi = np.exp(-self.gamma * r2)
        return np.concatenate([X, Phi], axis=1)

    def _design(self, Xmat: np.ndarray) -> np.ndarray:
        F = self._featurize(Xmat)
        return _add_intercept(F)

def _safe_stats_arrays(meta: dict, p: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Robustly extract per-variable mean/std from meta, falling back to zeros/ones.
    Also ensures correct shape (p,).
    """
    mean = None
    std = None
    stats = meta.get("stats", None)
    if isinstance(stats, dict):
        mean = stats.get("mean", None)
        std = stats.get("std", None)

    def _to_1d(a, default):
        if a is None:
            return default
        if hasattr(a, "detach") and hasattr(a, "cpu"):
            a = a.detach().cpu().numpy()
        a = np.asarray(a, dtype=np.float64).reshape(-1)
        return a

    mean_arr = _to_1d(mean, np.zeros((p,), dtype=np.float64))
    std_arr = _to_1d(std, np.ones((p,), dtype=np.float64))

    if mean_arr.size != p:
        mean_arr = np.zeros((p,), dtype=np.float64)
    if std_arr.size != p:
        std_arr = np.ones((p,), dtype=np.float64)

    std_arr = np.where(std_arr <= 1e-8, 1.0, std_arr)
    return mean_arr, std_arr

def _do_query_predictions(
    condition: BaseCondition,
    *,
    evidence_batch,
    do_queries: list[dict],
    meta: dict,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    do_true = np.asarray(meta.get("do_true", []), dtype=np.float64).reshape(-1)
    Q = len(do_queries)
    yt = np.full((Q,), np.nan, dtype=np.float64)
    mu = np.full((Q,), np.nan, dtype=np.float64)
    sd = np.full((Q,), np.nan, dtype=np.float64)
    for qi, q in enumerate(do_queries):
        if qi < do_true.size:
            yt[qi] = float(do_true[qi])
        m, s = condition.query_do(
            evidence_batch=evidence_batch,
            do_node=int(q["do_node"]),
            do_value=float(q["do_value"]),
            y_node=int(q["y_node"]),
            query_t=int(q["query_t"]),
            meta=meta,
        )
        mu[qi] = float(m)
        sd[qi] = float(max(s, 1e-6))
    return yt, mu, sd

def _estimate_do_effect_truth_and_pred(
    condition: BaseCondition,
    *,
    evidence_batch,
    meta: dict,
    y_node: int,
    query_t: int,
    do_node: int,
    v_plus: float,
    v_minus: float,
) -> Tuple[float, float]:
    W = meta.get("W_regime", meta.get("W_true", None))
    W0 = None
    true_eff = float("nan")
    if W is not None:
        W = np.asarray(W, dtype=np.float64)
        W0 = W[0] if W.ndim == 3 else W
        true_eff = float((float(v_plus) - float(v_minus)) * float(W0[int(do_node), int(y_node)]))

    m_plus, _ = condition.query_do(
        evidence_batch=evidence_batch,
        do_node=int(do_node),
        do_value=float(v_plus),
        y_node=int(y_node),
        query_t=int(query_t),
        meta=meta,
    )
    m_minus, _ = condition.query_do(
        evidence_batch=evidence_batch,
        do_node=int(do_node),
        do_value=float(v_minus),
        y_node=int(y_node),
        query_t=int(query_t),
        meta=meta,
    )
    pred_eff = float(m_plus - m_minus)
    return true_eff, pred_eff

def _robust_outcome_node(meta: dict, p: int) -> int:
    """
    Prior runs crashed due to broadcasting errors from using node_types that may not exist.
    Keep it simple and deterministic: default outcome node = 0 if p==1 else 1.
    """
    nt = meta.get("node_types", None)
    if isinstance(nt, dict) and "outcome_node" in nt:
        try:
            j = int(nt["outcome_node"])
            if 0 <= j < p:
                return j
        except Exception:
            pass
    return 0 if p <= 1 else 1

class UninformedUniformPrior_StaticBBN_VI(BaseCondition):
    name = "UninformedUniformPrior_StaticBBN_VI"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.core: Optional[_SimpleDBNCore] = None
        self._ridge = 1e-6

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        p = int(meta["p"])
        if self.tuning_setting == "moderate_search":
            self._ridge = 1e-3
        elif self.tuning_setting == "expanded_search":
            self._ridge = 1e-2
        else:
            self._ridge = 1e-6

        self.core = _SimpleDBNCore(p=p, seed=int(seed), prior_strength=0.5)
        X, M, _ = _flatten_batches_to_arrays(train_loader, y_nodes=[0])
        self.core.fit_linear(X, M, ridge=self._ridge)

    def evaluate(self, test_loader, meta: dict, seed: int) -> dict:
        """
        FIX (major): prior runs failed with broadcasting errors like (100,12) vs (100,).
        Root cause: meta['do_true'] was generated in standardized space, while query_do
        returns unstandardized units. That created shape/scale inconsistencies and
        downstream failures.

        We now:
        - evaluate do-query metrics in STANDARDIZED space (both truth and predictions),
          which is consistent with the synthetic generator.
        - keep query_do returning unstandardized values for logging/output compatibility.
        """
        assert self.core is not None

        do_queries = list(meta.get("do_queries", []))
        evidence_batch = test_loader[0] if test_loader else None

        inll = float("inf")
        cov90 = float("nan")
        do_rmse = float("nan")
        rt_per_q = float("nan")

        p = int(meta["p"])
        mean, std = _safe_stats_arrays(meta, p)

        if evidence_batch is not None and do_queries:
            import time as _time

            t0 = _time.time()
            yt, mu, sd = _do_query_predictions(self, evidence_batch=evidence_batch, do_queries=do_queries, meta=meta)
            t1 = _time.time()

            # Convert predictions to standardized units to match do_true scale from data generator.
            # (do_true in fallback loader is A[y,do]*do_value, where A is in standardized space)
            mu_std = (mu - mean[np.asarray([int(q["y_node"]) for q in do_queries], dtype=int)]) / std[
                np.asarray([int(q["y_node"]) for q in do_queries], dtype=int)
            ]
            sd_std = sd / std[np.asarray([int(q["y_node"]) for q in do_queries], dtype=int)]

            good = np.isfinite(yt) & np.isfinite(mu_std) & np.isfinite(sd_std)
            if np.any(good):
                inll = gaussian_nll(yt[good], mu_std[good], sd_std[good])
                cov90 = interval_coverage(yt[good], mu_std[good], sd_std[good], nominal=0.90)
                do_rmse = float(np.sqrt(np.mean((yt[good] - mu_std[good]) ** 2)))
            rt_per_q = float((t1 - t0) * 1000.0 / max(len(do_queries), 1))

        # One-step prediction RMSE in standardized space
        X, M, _ = _flatten_batches_to_arrays(test_loader, y_nodes=[0])
        rmse = float("inf")
        if X.size != 0:
            N, T, p = X.shape
            y_node_obs = _robust_outcome_node(meta, p)
            means: List[np.ndarray] = []
            ytrue: List[np.ndarray] = []
            B = self.core.B

            for t in range(T - 1):
                good = (np.all(M[:, t, :] > 0.5, axis=1)) & (M[:, t + 1, y_node_obs] > 0.5)
                if not np.any(good):
                    continue
                Xt = X[good, t, :]
                X1 = _add_intercept(Xt)
                pred_all = X1 @ B
                means.append(pred_all[:, [y_node_obs]])
                ytrue.append(X[good, t + 1, [y_node_obs]])

            if means:
                mu_obs = np.concatenate(means, axis=0).reshape(-1)
                yt_obs = np.concatenate(ytrue, axis=0).reshape(-1)
                rmse = float(np.sqrt(np.mean((yt_obs - mu_obs) ** 2)))

        Gp = _sigmoid(self.core.q_alpha.detach().cpu().numpy())
        np.fill_diagonal(Gp, 0.0)
        Gt_lag = np.asarray(meta["G_true"], dtype=np.int64) if "G_true" in meta else np.zeros_like(Gp, dtype=np.int64)
        Gt = _collapse_lagged_to_static(Gt_lag)
        np.fill_diagonal(Gt, 0)
        shd_v = shd(Gp, Gt, threshold=0.5)
        mask = _mask_off_diagonal_static(Gt)
        aucerr = auc_pr_error(Gp[mask].reshape(-1), Gt[mask].reshape(-1))

        # Negative control metrics are optional; keep robust defaults.
        nc_rate = float("nan")
        nt = meta.get("node_types", {})
        if isinstance(nt, dict) and {
            "exposure_node",
            "negative_control_outcome_node",
            "negative_control_exposure_node",
            "outcome_node",
        } <= set(nt.keys()):
            x_node = int(nt["exposure_node"])
            y_node = int(nt["outcome_node"])
            ncx = int(nt["negative_control_exposure_node"])
            ncy = int(nt["negative_control_outcome_node"])
            clamp = 2.0
            qt = int(do_queries[0]["query_t"]) if do_queries else int(meta.get("L", 1))

            ate_nc = np.array([], dtype=np.float64)
            if evidence_batch is not None:
                _, pred1 = _estimate_do_effect_truth_and_pred(
                    self,
                    evidence_batch=evidence_batch,
                    meta=meta,
                    y_node=ncy,
                    query_t=qt,
                    do_node=x_node,
                    v_plus=clamp,
                    v_minus=-clamp,
                )
                _, pred2 = _estimate_do_effect_truth_and_pred(
                    self,
                    evidence_batch=evidence_batch,
                    meta=meta,
                    y_node=y_node,
                    query_t=qt,
                    do_node=ncx,
                    v_plus=clamp,
                    v_minus=-clamp,
                )
                ate_nc = np.array([pred1, pred2], dtype=np.float64)

            if ate_nc.size:
                nc_rate = negative_control_violation_rate(ate_nc, threshold=0.2)

        return {
            "InterventionalNegativeLogLikelihood": float(inll),
            "PredictiveIntervalCoverage90": float(cov90),
            "DoEffectRMSE": float(do_rmse),
            "NegativeControlViolationRate": float(nc_rate),
            "RuntimePerQuery_ms": float(rt_per_q),
            "rmse": float(rmse),
            "StructureRecovery_SHD": float(shd_v),
            "StructureRecovery_AUCPR": float(aucerr),
        }

    def query_do(
        self,
        *,
        evidence_batch,
        do_node: int,
        do_value: float,
        y_node: int,
        query_t: int,
        meta: dict,
    ) -> Tuple[float, float]:
        """
        Evidence batch x is standardized; model B was fit on standardized space.
        We operate in standardized space for prediction, then return outputs in
        ORIGINAL (unstandardized) units for logging/predictions.json.
        """
        assert self.core is not None
        x_std = evidence_batch.x.detach().cpu().numpy()

        p = int(meta["p"])
        mean, std = _safe_stats_arrays(meta, p)

        qt = int(query_t)
        if qt < 0 or qt >= x_std.shape[1]:
            return float("nan"), float("nan")

        x_t_std = x_std[0, qt, :].astype(np.float64).copy()

        do_node_i = int(do_node)
        do_value_std = (float(do_value) - float(mean[do_node_i])) / float(std[do_node_i])
        x_t_std[do_node_i] = do_value_std

        X1 = _add_intercept(x_t_std.reshape(1, -1))
        pred_all = (X1 @ self.core.B).reshape(-1)
        mu_std = float(pred_all[int(y_node)])
        sd_std = float(self.core.noise_std[int(y_node)])

        y_node_i = int(y_node)
        mu = mu_std * float(std[y_node_i]) + float(mean[y_node_i])
        sd = sd_std * float(std[y_node_i])
        return float(mu), float(max(sd, 1e-6))

class NaiveGlobalStrongEvidencePrior_StaticBBN_VI(UninformedUniformPrior_StaticBBN_VI):
    name = "NaiveGlobalStrongEvidencePrior_StaticBBN_VI"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default", prior_strength_a: Optional[float] = None):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.prior_strength_a = float(prior_strength_a) if prior_strength_a is not None else 2.0

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        p = int(meta["p"])
        if self.tuning_setting == "moderate_search":
            self._ridge = 1e-4
        elif self.tuning_setting == "expanded_search":
            self._ridge = 5e-3
        else:
            self._ridge = 1e-6

        self.core = _SimpleDBNCore(p=p, seed=int(seed), prior_strength=self.prior_strength_a)
        X, M, _ = _flatten_batches_to_arrays(train_loader, y_nodes=[0])
        self.core.fit_linear(X, M, ridge=self._ridge)

class HeterogeneityAwareLocalEvidencePriorHierarchicalBBNVI(UninformedUniformPrior_StaticBBN_VI):
    name = "HeterogeneityAwareLocalEvidencePrior_HierarchicalBBN_VI"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.cores_by_regime: Dict[str, _SimpleDBNCore] = {}

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        regime = str(meta.get("regime_id", meta.get("regime", "unknown")))
        p = int(meta["p"])
        prior_strength = 1.0
        ridge = 1e-6 if self.tuning_setting == "default" else (1e-3 if self.tuning_setting == "moderate_search" else 1e-2)

        core = _SimpleDBNCore(p=p, seed=int(seed) + 123, prior_strength=prior_strength)
        X, M, _ = _flatten_batches_to_arrays(train_loader, y_nodes=[0])
        core.fit_linear(X, M, ridge=ridge)
        self.cores_by_regime[regime] = core
        self.core = core

    def evaluate(self, test_loader, meta: dict, seed: int) -> dict:
        regime = str(meta.get("regime_id", meta.get("regime", "unknown")))
        if regime in self.cores_by_regime:
            self.core = self.cores_by_regime[regime]
        return super().evaluate(test_loader, meta, seed)

class AmortizedNeuralMessageDistillationSoftEvidenceToBBN(UninformedUniformPrior_StaticBBN_VI):
    name = "AmortizedNeuralMessageDistillation_SoftEvidenceToBBN"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self._temperature = 1.0

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        if self.tuning_setting == "moderate_search":
            self._temperature = 0.8
            self._ridge = 1e-3
        elif self.tuning_setting == "expanded_search":
            self._temperature = 0.6
            self._ridge = 5e-3
        else:
            self._temperature = 1.0
            self._ridge = 1e-6

        p = int(meta["p"])
        self.core = _RBFDBNCore(
            p=p,
            seed=int(seed) + 999,
            prior_strength=0.8 / self._temperature,
            num_centers=8,
            gamma=0.7,
        )
        X, M, _ = _flatten_batches_to_arrays(train_loader, y_nodes=[0])
        self.core.fit_linear(X, M, ridge=self._ridge)

    def query_do(
        self,
        *,
        evidence_batch,
        do_node: int,
        do_value: float,
        y_node: int,
        query_t: int,
        meta: dict,
    ) -> Tuple[float, float]:
        assert self.core is not None
        x_std = evidence_batch.x.detach().cpu().numpy()
        p = int(meta["p"])
        mean, std = _safe_stats_arrays(meta, p)

        qt = int(query_t)
        if qt < 0 or qt >= x_std.shape[1]:
            return float("nan"), float("nan")

        x_t_std = x_std[0, qt, :].astype(np.float64).copy()
        do_node_i = int(do_node)
        do_value_std = (float(do_value) - float(mean[do_node_i])) / float(std[do_node_i])
        x_t_std[do_node_i] = do_value_std

        assert isinstance(self.core, _RBFDBNCore)
        D = self.core._design(x_t_std.reshape(1, -1))
        pred_all = (D @ self.core.B).reshape(-1)

        y_node_i = int(y_node)
        mu_std = float(pred_all[y_node_i])
        sd_std = float(self.core.noise_std[y_node_i])

        mu = mu_std * float(std[y_node_i]) + float(mean[y_node_i])
        sd = sd_std * float(std[y_node_i])
        return float(mu), float(max(sd, 1e-6))

class MCMCReferenceSmallGraphDBNSampler(UninformedUniformPrior_StaticBBN_VI):
    name = "MCMCReference_SmallGraph_DBNSampler"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.G_samples: List[np.ndarray] = []
        self._mcmc_steps: int = 200
        self._burnin: int = 50

    @staticmethod
    def _logistic_log_prob_edge(a: float, g: int) -> float:
        a = float(np.clip(a, -40.0, 40.0))
        if g == 1:
            return -np.log1p(np.exp(-a))
        return -np.log1p(np.exp(a))

    def _mcmc_sample_graphs(self, logits: np.ndarray, seed: int) -> List[np.ndarray]:
        rng = np.random.default_rng(int(seed) + 2024)
        p = int(logits.shape[0])
        G = (logits > 0.0).astype(np.int64)
        np.fill_diagonal(G, 0)

        def logp(Gmat: np.ndarray) -> float:
            s = 0.0
            for i in range(p):
                for j in range(p):
                    if i == j:
                        continue
                    s += self._logistic_log_prob_edge(float(logits[i, j]), int(Gmat[i, j]))
            return float(s)

        lp = logp(G)
        samples: List[np.ndarray] = []
        steps = int(self._mcmc_steps)
        burn = int(min(self._burnin, steps))
        for t in range(steps):
            i = int(rng.integers(0, p))
            j = int(rng.integers(0, p - 1))
            if j >= i:
                j += 1
            Gp = G.copy()
            Gp[i, j] = 1 - Gp[i, j]
            lp_p = logp(Gp)
            acc = min(1.0, float(np.exp(lp_p - lp)))
            if float(rng.uniform(0.0, 1.0)) < acc:
                G = Gp
                lp = lp_p
            if t >= burn:
                samples.append(G.copy())
        return samples

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        p = int(meta["p"])
        core = _SimpleDBNCore(p=p, seed=int(seed) + 2024, prior_strength=1.0)
        X, M, _ = _flatten_batches_to_arrays(train_loader, y_nodes=[0])
        core.fit_linear(X, M, ridge=1e-6)
        self.core = core

        logits = core.q_alpha.detach().cpu().numpy().astype(np.float64)
        self.G_samples = self._mcmc_sample_graphs(logits, seed=int(seed))

# ----------------------------- IV estimators -----------------------------

@dataclass
class _IVSample:
    z: np.ndarray
    x: np.ndarray
    y: np.ndarray
    beta_true: float

class _IVBase(BaseCondition):
    role = "iv"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.beta_hats: List[float] = []
        self.beta_true: float = 1.0

    @staticmethod
    def _coerce_samples(meta: dict) -> List[_IVSample]:
        raw = meta.get("iv_samples", None)
        if raw is None:
            return []

        if isinstance(raw, list):
            out: List[_IVSample] = []
            for s in raw:
                out.append(_IVSample(z=np.asarray(s.z), x=np.asarray(s.x), y=np.asarray(s.y), beta_true=float(s.beta_true)))
            return out

        if isinstance(raw, dict) and "Z" in raw and "x" in raw and "y" in raw:
            Z = np.asarray(raw["Z"], dtype=np.float64)
            x = np.asarray(raw["x"], dtype=np.float64)
            y = np.asarray(raw["y"], dtype=np.float64)
            beta_true = float(raw.get("beta_true", 1.0))
            if Z.ndim != 3:
                raise ValueError("iv_samples['Z'] must be (R,N,k)")
            R = int(Z.shape[0])
            out = []
            for r in range(R):
                out.append(_IVSample(z=Z[r], x=x[r], y=y[r], beta_true=beta_true))
            return out

        return []

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        samples = self._coerce_samples(meta)
        if not samples:
            self.beta_hats = []
            return
        self.beta_true = float(samples[0].beta_true)
        self.beta_hats = [float(self._estimate_one(s)) for s in samples]

    def evaluate(self, test_loader, meta: dict, seed: int) -> dict:
        if not self.beta_hats:
            return {"rmse": float("inf"), "bias": float("nan"), "variance": float("nan")}
        bh = np.asarray(self.beta_hats, dtype=np.float64)
        rmse = float(np.sqrt(np.mean((bh - self.beta_true) ** 2)))
        bias = float(np.mean(bh - self.beta_true))
        var = float(np.var(bh))
        return {"rmse": rmse, "bias": bias, "variance": var}

    def _estimate_one(self, sample: _IVSample) -> float:
        raise NotImplementedError

class TwoStageLeastSquares(_IVBase):
    name = "TwoStageLeastSquares"

    def __init__(self, cfg: Any, tuning_setting: str = "default", ridge: float = 0.0):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.ridge = float(ridge)

    def _estimate_one(self, sample: _IVSample) -> float:
        z = np.asarray(sample.z, dtype=np.float64)
        x = np.asarray(sample.x, dtype=np.float64)
        y = np.asarray(sample.y, dtype=np.float64)

        Z1 = _add_intercept(z)
        pi = _ridge_solve(Z1, x, self.ridge)
        xhat = Z1 @ pi
        X2 = _add_intercept(xhat)
        b = _ols(X2, y)
        return float(b.reshape(-1)[1])

class JIVE(_IVBase):
    name = "JIVE"

    def __init__(self, cfg: Any, tuning_setting: str = "default", ridge: float = 0.0):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.ridge = float(ridge)

    def _estimate_one(self, sample: _IVSample) -> float:
        z = np.asarray(sample.z, dtype=np.float64)
        x = np.asarray(sample.x, dtype=np.float64).reshape(-1, 1)
        y = np.asarray(sample.y, dtype=np.float64).reshape(-1, 1)
        N, k = z.shape

        Z1 = _add_intercept(z)
        A = Z1.T @ Z1 + self.ridge * np.eye(k + 1, dtype=np.float64)
        try:
            Ainv = np.linalg.inv(A)
        except np.linalg.LinAlgError:
            Ainv = np.linalg.pinv(A)

        h = np.sum((Z1 @ Ainv) * Z1, axis=1).reshape(-1, 1)
        pi = Ainv @ (Z1.T @ x)
        xhat = Z1 @ pi
        x_jive = xhat / np.maximum(1.0 - h, 1e-6)

        X2 = _add_intercept(x_jive)
        b = _ols(X2, y)
        return float(b.reshape(-1)[1])

class LIML(_IVBase):
    name = "LIML"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self._grid_points = 301

    def _estimate_one(self, sample: _IVSample) -> float:
        z = np.asarray(sample.z, dtype=np.float64)
        x = np.asarray(sample.x, dtype=np.float64).reshape(-1, 1)
        y = np.asarray(sample.y, dtype=np.float64).reshape(-1, 1)
        Z1 = _add_intercept(z)

        Pz = Z1 @ np.linalg.pinv(Z1.T @ Z1) @ Z1.T
        Mz = np.eye(Z1.shape[0], dtype=np.float64) - Pz

        grid = np.linspace(-2.0, 4.0, int(self._grid_points), dtype=np.float64)
        best_b = 0.0
        best_val = float("inf")
        for b in grid:
            r = y - float(b) * x
            num = float((r.T @ Pz @ r).reshape(()))
            den = float((r.T @ Mz @ r).reshape(())) + 1e-12
            val = num / den
            if val < best_val:
                best_val = val
                best_b = float(b)
        return float(best_b)

class FullerLIML(_IVBase):
    name = "FullerLIML"

    def __init__(self, cfg: Any, tuning_setting: str = "default", alpha: float = 1.0):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self.alpha = float(alpha)

    @staticmethod
    def _first_stage_f_stat(z: np.ndarray, x: np.ndarray) -> float:
        z = np.asarray(z, dtype=np.float64)
        x = np.asarray(x, dtype=np.float64).reshape(-1, 1)
        N, k = z.shape
        Z1 = _add_intercept(z)

        b_full = _ols(Z1, x)
        resid_full = x - Z1 @ b_full
        sse_full = float((resid_full.T @ resid_full).reshape(()))

        Xr = np.ones((N, 1), dtype=np.float64)
        b_r = _ols(Xr, x)
        resid_r = x - Xr @ b_r
        sse_r = float((resid_r.T @ resid_r).reshape(()))

        df1 = float(k)
        df2 = float(max(N - (k + 1), 1))
        num = (sse_r - sse_full) / max(df1, 1.0)
        den = sse_full / max(df2, 1.0)
        return float(num / max(den, 1e-12))

    def _estimate_one(self, sample: _IVSample) -> float:
        # Numerically safe Fuller adjustment:
        #   beta_fuller = beta_liml - (alpha / (F + alpha)) * (beta_liml - beta_tsls)
        # plus additional clipping to avoid catastrophic outliers seen in prior runs.
        z = np.asarray(sample.z, dtype=np.float64)
        x = np.asarray(sample.x, dtype=np.float64)
        y = np.asarray(sample.y, dtype=np.float64)

        liml_b = LIML(self.cfg, tuning_setting=self.tuning_setting)._estimate_one(sample)
        tsls_b = TwoStageLeastSquares(self.cfg, tuning_setting=self.tuning_setting, ridge=0.0)._estimate_one(sample)

        F = self._first_stage_f_stat(z, x)
        F = float(np.clip(F, 0.0, 1e6))

        alpha = float(max(self.alpha, 0.0))
        shrink = alpha / (F + alpha + 1e-12)  # in [0,1]
        beta = float(liml_b - shrink * (liml_b - tsls_b))

        if not np.isfinite(beta):
            beta = float(tsls_b)

        # Stronger guard: tighten clip to reduce extreme RMSE explosions.
        beta = float(np.clip(beta, -100.0, 100.0))
        return beta

# ----------------------------- CORAL / DANN -----------------------------

class CORALBaseline_DBN(UninformedUniformPrior_StaticBBN_VI):
    name = "CORALBaseline_DBN"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self._lambda_coral = 1.0

    @staticmethod
    def _collect_pairs(loader) -> Tuple[np.ndarray, np.ndarray]:
        xs, ys, ms = [], [], []
        if loader is None:
            return np.zeros((0, 0), dtype=np.float64), np.zeros((0, 0), dtype=np.float64)
        for b in loader:
            xs.append(b.x.detach().cpu().numpy())
            ys.append(b.y_target.detach().cpu().numpy())
            ms.append(b.m.detach().cpu().numpy())
        if not xs:
            return np.zeros((0, 0), dtype=np.float64), np.zeros((0, 0), dtype=np.float64)
        X = np.concatenate(xs, axis=0)
        Y = np.concatenate(ys, axis=0)
        M = np.concatenate(ms, axis=0)
        feats, targs = [], []
        N, T, p = X.shape
        for t in range(T - 1):
            good = np.all((M[:, t, :] > 0.5) & (M[:, t + 1, :] > 0.5), axis=1)
            if np.any(good):
                feats.append(X[good, t, :])
                targs.append(X[good, t + 1, :])
        if not feats:
            return np.zeros((0, p), dtype=np.float64), np.zeros((0, p), dtype=np.float64)
        return np.concatenate(feats, axis=0).astype(np.float64), np.concatenate(targs, axis=0).astype(np.float64)

    @staticmethod
    def _cov_centered(F: np.ndarray) -> np.ndarray:
        F = np.asarray(F, dtype=np.float64)
        if F.shape[0] <= 1:
            return np.eye(F.shape[1], dtype=np.float64)
        Fc = F - np.mean(F, axis=0, keepdims=True)
        return (Fc.T @ Fc) / float(Fc.shape[0] - 1)

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        p = int(meta["p"])
        self.core = _SimpleDBNCore(p=p, seed=int(seed) + 7, prior_strength=0.7)

        Xtr, Ytr = self._collect_pairs(train_loader)
        Xva = Xtr.copy() if val_loader is None else self._collect_pairs(val_loader)[0]

        ridge = 1e-6
        if self.tuning_setting == "moderate_search":
            self._lambda_coral = 0.5
            ridge = 1e-4
        elif self.tuning_setting == "expanded_search":
            self._lambda_coral = 2.0
            ridge = 1e-3
        else:
            self._lambda_coral = 1.0
            ridge = 1e-6

        if Xtr.shape[0] == 0:
            self.core.B[:] = 0.0
            self.core.noise_std[:] = 1.0
            return

        B = np.zeros((p + 1, p), dtype=np.float64)
        X1 = _add_intercept(Xtr)
        for j in range(p):
            B[:, j] = _ridge_solve(X1, Ytr[:, j], ridge).reshape(-1)

        steps = 40
        lr = 5e-3
        X1v = _add_intercept(Xva) if Xva.shape[0] else X1
        for _ in range(steps):
            Ftr = X1 @ B
            Ctr = self._cov_centered(Ftr)
            Fva = X1v @ B
            Cva = self._cov_centered(Fva)
            D = Ctr - Cva
            Ftrc = Ftr - np.mean(Ftr, axis=0, keepdims=True)
            Fvac = Fva - np.mean(Fva, axis=0, keepdims=True)
            gFtr = (4.0 / max(Ftr.shape[0] - 1, 1.0)) * (Ftrc @ D)
            gFva = (-4.0 / max(Fva.shape[0] - 1, 1.0)) * (Fvac @ D)
            gB = X1.T @ gFtr + X1v.T @ gFva
            B = B - lr * self._lambda_coral * gB / max(X1.shape[0], 1.0)

        self.core.B = B
        resid = Ytr - X1 @ B
        self.core.noise_std = np.sqrt(np.maximum(np.mean(resid**2, axis=0), 1e-6))

class DANNBaseline_DBN(UninformedUniformPrior_StaticBBN_VI):
    name = "DANNBaseline_DBN"
    role = "dbn"

    def __init__(self, cfg: Any, tuning_setting: str = "default"):
        super().__init__(cfg, tuning_setting=tuning_setting)
        self._lambda_adv = 1.0

    @staticmethod
    def _sigmoid_stable(a: np.ndarray) -> np.ndarray:
        a = np.asarray(a, dtype=np.float64)
        a = np.clip(a, -40.0, 40.0)
        return 1.0 / (1.0 + np.exp(-a))

    @staticmethod
    def _collect_X(loader) -> np.ndarray:
        xs, ms = [], []
        if loader is None:
            return np.zeros((0, 0), dtype=np.float64)
        for b in loader:
            xs.append(b.x.detach().cpu().numpy())
            ms.append(b.m.detach().cpu().numpy())
        if not xs:
            return np.zeros((0, 0), dtype=np.float64)
        X = np.concatenate(xs, axis=0)
        M = np.concatenate(ms, axis=0)
        feats = []
        N, T, p = X.shape
        for t in range(T - 1):
            good = np.all(M[:, t, :] > 0.5, axis=1)
            if np.any(good):
                feats.append(X[good, t, :])
        if not feats:
            return np.zeros((0, p), dtype=np.float64)
        return np.concatenate(feats, axis=0).astype(np.float64)

    def fit(self, train_loader, val_loader, meta: dict, seed: int) -> None:
        p = int(meta["p"])
        self.core = _SimpleDBNCore(p=p, seed=int(seed) + 42, prior_strength=0.6)

        Xtr, Mtr, _ = _flatten_batches_to_arrays(train_loader, y_nodes=[0])
        self.core.fit_linear(Xtr, Mtr, ridge=1e-6)

        Xs = self._collect_X(train_loader)
        Xt = self._collect_X(val_loader) if val_loader is not None else Xs.copy()

        if self.tuning_setting == "moderate_search":
            self._lambda_adv = 0.5
        elif self.tuning_setting == "expanded_search":
            self._lambda_adv = 2.0
        else:
            self._lambda_adv = 1.0

        if Xs.shape[0] == 0 or Xt.shape[0] == 0:
            return

        w = np.zeros((p,), dtype=np.float64)
        b0 = 0.0

        B = self.core.B.copy()
        steps = 60
        lr_d = 1e-2
        lr_b = 2e-3

        X1s = _add_intercept(Xs)
        X1t = _add_intercept(Xt)

        for _ in range(steps):
            Fs = X1s @ B
            Ft = X1t @ B
            F = np.concatenate([Fs, Ft], axis=0)
            y_dom = np.concatenate(
                [np.zeros((Fs.shape[0],), dtype=np.float64), np.ones((Ft.shape[0],), dtype=np.float64)]
            )

            logits = F @ w + b0
            p_dom = self._sigmoid_stable(logits)
            g = (p_dom - y_dom)
            gw = (F.T @ g) / max(F.shape[0], 1.0)
            gb = float(np.mean(g))
            w = w - lr_d * gw
            b0 = b0 - lr_d * gb

            gF = (g.reshape(-1, 1) * w.reshape(1, -1)) / max(F.shape[0], 1.0)
            gFs = gF[: Fs.shape[0]]
            gFt = gF[Fs.shape[0] :]
            gB = X1s.T @ gFs + X1t.T @ gFt
            B = B + lr_b * self._lambda_adv * gB

        self.core.B = B