# Bayesian Time Series and Bayesian Belief Network for Causal Reasoning

## Abstract
This evidence-limited manuscript reports the research question, planned experimental comparison, available execution evidence, and limitations. The experimental evidence did not satisfy every correctness gate, so the paper avoids unsupported superiority or deployment claims and presents the results as an auditable degraded run.


> **Note:** This paper was produced in degraded mode. Quality gate score (2.3/4.0) was below threshold. Unverified numerical results in tables have been replaced with `Not reported` and require independent verification.


## Introduction
The study addresses Bayesian Time Series and Bayesian Belief Network for causal reasoning. The intended contribution is a comparative evaluation grounded in the pipeline’s experiment design and collected evidence. Because execution quality checks identified unresolved issues, the manuscript is intentionally conservative and focuses on what was actually observed.

## Method
The pipeline designed an experiment, generated executable code, ran the available evaluation workflow, and analyzed produced artifacts. The final draft uses only available experiment summaries and diagnostic metadata; unverified numerical claims are not promoted to scientific conclusions.

## Experiment Status
The experiment run did not satisfy all correctness gates, and multiple sections were flagged as not being centered on the user topic. The diagnostic report is stored separately as `failed_run_diagnostic_report.md` when available. The main manuscript does not include diagnostic markers or failed-run report text.

### Correctness Gate Findings
- Method section is no longer centered on the user topic.
- Experiments section is no longer centered on the user topic.
- Results section is no longer centered on the user topic.

### Non-Blocking Warnings
- Stage 19 auto-corrected a blocked or diagnostic-only paper artifact into a manuscript-shaped degraded revision.

#

![Fig Delta Primary Metric](charts/fig_delta_primary_metric.png)

![Fig Main Primary Metric Bar](charts/fig_main_primary_metric_bar.png)

![Fig Seed Distribution Primary Metric](charts/fig_seed_distribution_primary_metric.png)

# Results
The available quantitative evidence is summarized below. These values are reported as execution evidence, not as final claims of model superiority.

- `NaiveGlobalStrongEvidencePrior_StaticBBN_VI/primary_metric`: mean = 1.162222, observations = 32  
- `UninformedUniformPrior_StaticBBN_VI/primary_metric`: mean = 1.154075, observations = 172

## Limitations
The run should be interpreted as degraded until the experiment artifacts satisfy all correctness gates. Required follow-up includes repairing failed or missing conditions, confirming comparative tables and figures, and rerunning citation and result verification before making strong scientific claims.

## Conclusion
The pipeline produced a traceable evidence-limited manuscript rather than blocking the downstream finalization stages. The current evidence can be used for debugging and audit, while the reported limitations identify what must be repaired before publication-quality conclusions are drawn.