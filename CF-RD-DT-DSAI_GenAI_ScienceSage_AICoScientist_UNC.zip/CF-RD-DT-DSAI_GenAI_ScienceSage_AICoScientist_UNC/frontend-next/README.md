# frontend-next

Next.js frontend for the ResearchClaw FastAPI backend.

## Run locally

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`.

## Required backend endpoints

- `GET /api/health`
- `GET /api/config`
- `GET /api/pipeline/status`
- `POST /api/pipeline/start`
- `POST /api/pipeline/stop`
- `GET /api/runs`
- `WS /ws/events`
