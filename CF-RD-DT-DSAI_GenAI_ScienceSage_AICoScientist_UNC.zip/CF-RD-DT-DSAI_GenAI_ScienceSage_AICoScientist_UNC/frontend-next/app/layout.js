import "./globals.css";

export const metadata = {
  title: "ResearchClaw Control Console",
  description: "Next.js frontend for the ResearchClaw FastAPI backend",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
