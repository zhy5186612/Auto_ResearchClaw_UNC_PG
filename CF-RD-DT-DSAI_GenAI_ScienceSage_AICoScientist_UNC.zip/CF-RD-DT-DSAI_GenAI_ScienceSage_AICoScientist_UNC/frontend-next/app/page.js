"use client";

import {
  ChevronDown,
  ChevronRight,
  Database,
  File,
  Folder,
  FolderOpen,
  Globe,
  GraduationCap,
  Pause,
  PencilLine,
  Play,
  RefreshCw,
  Route,
  ScrollText,
  SendHorizontal,
  Trash2,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { apiGet, apiPost, buildApiUrl, buildWsUrl } from "../lib/api";

const LIBRARY_STORAGE_KEY = "researchclaw.paper.viewer.library";
const BLANK_SESSION_STORAGE_KEY = "researchclaw.session.blank";

const STAGE_INFO = {
  TOPIC_INIT:         { num: 1,  label: "Topic Init",          desc: "Defining the research question, scope, and constraints" },
  PROBLEM_DECOMPOSE:  { num: 2,  label: "Problem Decompose",   desc: "Breaking the problem into sub-problems and identifying key variables" },
  SEARCH_STRATEGY:    { num: 3,  label: "Search Strategy",     desc: "Designing search queries and verifying available data sources" },
  LITERATURE_COLLECT: { num: 4,  label: "Literature Collect",  desc: "Executing searches and collecting candidate papers" },
  LITERATURE_SCREEN:  { num: 5,  label: "Literature Screen",   desc: "Filtering papers by relevance, quality, and recency" },
  KNOWLEDGE_EXTRACT:  { num: 6,  label: "Knowledge Extract",   desc: "Extracting structured knowledge cards from selected papers" },
  SYNTHESIS:          { num: 7,  label: "Synthesis",           desc: "Clustering topics and identifying research gaps" },
  HYPOTHESIS_GEN:     { num: 8,  label: "Hypothesis Gen",      desc: "Generating and ranking falsifiable hypotheses" },
  EXPERIMENT_DESIGN:  { num: 9,  label: "Experiment Design",   desc: "Designing the experiment protocol and methodology" },
  CODE_GENERATION:    { num: 10, label: "Code Generation",     desc: "Generating and validating executable experiment code" },
  RESOURCE_PLANNING:  { num: 11, label: "Resource Planning",   desc: "Scheduling resources, dependencies, and compute requirements" },
  EXPERIMENT_RUN:     { num: 12, label: "Experiment Run",      desc: "Executing experiments in the configured environment" },
  ITERATIVE_REFINE:   { num: 13, label: "Iterative Refine",    desc: "Iterating the Edit → Run → Evaluate loop for improvements" },
  RESULT_ANALYSIS:    { num: 14, label: "Result Analysis",     desc: "Statistical analysis and generating performance metrics" },
  RESEARCH_DECISION:  { num: 15, label: "Research Decision",   desc: "Making the PROCEED / PIVOT / ITERATE decision" },
  PAPER_OUTLINE:      { num: 16, label: "Paper Outline",       desc: "Generating the paper outline and section structure" },
  PAPER_DRAFT:        { num: 17, label: "Paper Draft",         desc: "Writing the full manuscript using real experiment data" },
  PEER_REVIEW:        { num: 18, label: "Peer Review",         desc: "Running simulated peer review with critique agents" },
  PAPER_REVISION:     { num: 19, label: "Paper Revision",      desc: "Revising the paper based on peer review feedback" },
  QUALITY_GATE:       { num: 20, label: "Quality Gate",        desc: "Running automated quality scoring and validation checks" },
  KNOWLEDGE_ARCHIVE:  { num: 21, label: "Knowledge Archive",   desc: "Archiving findings, lessons learned, and knowledge base entries" },
  EXPORT_PUBLISH:     { num: 22, label: "Export & Publish",    desc: "Generating charts, tables, and exporting final artifacts" },
  CITATION_VERIFY:    { num: 23, label: "Citation Verify",     desc: "Verifying and formatting all citations and references" },
};

const STAGE_NAME_BY_NUM = Object.fromEntries(
  Object.entries(STAGE_INFO).map(([name, meta]) => [meta.num, name])
);

const MODE_OPTIONS = ["AutoPilot", "CoPilot"];
const AUTOPILOT_STAGE_MODE = "autonomous";

function normalizeModeLabel(modeLabel) {
  const normalized = String(modeLabel || "").trim().toLowerCase();
  if (["copilot", "co-pilot", "human-in-loop", "human_in_loop"].includes(normalized)) {
    return "CoPilot";
  }
  return "AutoPilot";
}

const SOURCE_OPTIONS = [
  {
    value: "auto",
    label: "Auto",
    Icon: Route,
  },
  {
    value: "web",
    label: "Web",
    Icon: Globe,
  },
  {
    value: "paper",
    label: "Paper",
    Icon: GraduationCap,
  },
  {
    value: "patent",
    label: "Patent",
    Icon: ScrollText,
  },
  {
    value: "slr",
    label: "SLR",
    Icon: Database,
  },
];

const SOURCE_OPTION_MAP = Object.fromEntries(
  SOURCE_OPTIONS.map((option) => [option.value, option])
);

function fmt(value) {
  if (value == null) return "n/a";
  if (typeof value === "string") return value;
  return JSON.stringify(value, null, 2);
}

function EventRow({ item }) {
  const time = new Date(item.ts).toLocaleTimeString();
  return (
    <li className="event-row">
      <span className="event-time">{time}</span>
      <span className="event-type">{item.type}</span>
      <code className="event-payload">{fmt(item.payload)}</code>
    </li>
  );
}

function ResearchSignal() {
  return (
    <div className="research-signal" aria-hidden="true">
      <span className="research-signal-core" />
      <span className="research-signal-ring research-signal-ring-1" />
      <span className="research-signal-ring research-signal-ring-2" />
      <span className="research-signal-ring research-signal-ring-3" />
    </div>
  );
}

function SourceGlyph({ value }) {
  const selectedSource = SOURCE_OPTION_MAP[value] || SOURCE_OPTIONS[0];
  const Icon = selectedSource.Icon;
  return <Icon aria-hidden="true" strokeWidth={1.8} />;
}

function HitlSourcePicker({ value, onChange, disabled = false }) {
  const [isOpen, setIsOpen] = useState(false);
  const pickerRef = useRef(null);
  const selectedSource = SOURCE_OPTION_MAP[value] || SOURCE_OPTIONS[0];

  useEffect(() => {
    if (!isOpen) {
      return undefined;
    }
    const handlePointerDown = (event) => {
      if (!pickerRef.current || pickerRef.current.contains(event.target)) {
        return;
      }
      setIsOpen(false);
    };
    document.addEventListener("pointerdown", handlePointerDown);
    return () => document.removeEventListener("pointerdown", handlePointerDown);
  }, [isOpen]);

  return (
    <div className="hitl-source-picker">
      <div className="source-control hitl-source-control" ref={pickerRef}>
        <button
          type="button"
          className={`source-trigger hitl-source-trigger ${isOpen ? "source-trigger-open" : ""}`}
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          disabled={disabled}
          onClick={() => !disabled && setIsOpen((open) => !open)}
        >
          <span className="source-trigger-value">
            <SourceGlyph value={selectedSource.value} />
            <span>{selectedSource.label}</span>
          </span>
          <svg className="source-trigger-chevron" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
            <path d="m5.5 7.5 4.5 5 4.5-5" />
          </svg>
        </button>
        {isOpen ? (
          <div className="source-menu hitl-source-menu" role="listbox" aria-label="Source">
            <div className="source-menu-title">Source</div>
            {SOURCE_OPTIONS.map((option) => {
              const isSelected = option.value === selectedSource.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  className={`source-option ${isSelected ? "source-option-selected" : ""}`}
                  role="option"
                  aria-selected={isSelected}
                  onClick={() => {
                    onChange(option.value);
                    setIsOpen(false);
                  }}
                >
                  <span className="source-option-icon">
                    <SourceGlyph value={option.value} />
                  </span>
                  <span className="source-option-label">{option.label}</span>
                </button>
              );
            })}
          </div>
        ) : null}
      </div>
    </div>
  );
}

function ConfirmOpenModal({ item, onCancel, onContinue }) {
  if (!item) {
    return null;
  }
  const isCompletePdf = Boolean(item.is_complete && item.pdf_url);

  return (
    <div className="confirm-modal-backdrop" role="presentation" onClick={onCancel}>
      <div
        className="confirm-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-open-title"
        aria-describedby="confirm-open-body"
        onClick={(event) => event.stopPropagation()}
      >
        <h3 id="confirm-open-title">Continue opening this session?</h3>
        {isCompletePdf ? (
          <p id="confirm-open-body">
            All stages done running and a complete pdf is ready to view. Continue?
          </p>
        ) : (
          <p id="confirm-open-body">
            Some stages are still in progress.
            <br />
            <br />
            Opening this will continue the remaining stages and archive your current running session. Do you want to continue?
          </p>
        )}
        <div className="confirm-modal-actions">
          <button type="button" className="confirm-modal-cancel" onClick={onCancel}>
            Cancel
          </button>
          <button type="button" className="confirm-modal-continue" onClick={onContinue}>
            Terminate &amp; Continue
          </button>
        </div>
      </div>
    </div>
  );
}

function ConfirmNewSessionModal({ open, onCancel, onContinue }) {
  if (!open) {
    return null;
  }

  return (
    <div className="confirm-modal-backdrop" role="presentation" onClick={onCancel}>
      <div
        className="confirm-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-new-session-title"
        aria-describedby="confirm-new-session-body"
        onClick={(event) => event.stopPropagation()}
      >
        <p id="confirm-new-session-body" className="confirm-modal-body">
          <strong id="confirm-new-session-title">A session is still running.</strong>
          <br />
          <br />
          Starting a new session will stop and archive the current running session. Continue?
        </p>
        <div className="confirm-modal-actions">
          <button type="button" className="confirm-modal-cancel" onClick={onCancel}>
            Cancel
          </button>
          <button type="button" className="confirm-modal-continue" onClick={onContinue}>
            Terminate &amp; Start New Session
          </button>
        </div>
      </div>
    </div>
  );
}

function formatDateTime(value) {
  if (!value) {
    return "n/a";
  }
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    return String(value);
  }
  return parsed.toLocaleString();
}

function artifactNodeKey(runId, path = "") {
  return `${runId}:${path}`;
}

function displayLibraryName(name) {
  return String(name || "").trim().toLowerCase() === "progress experiment"
    ? "workflow progress"
    : name;
}

function stablePaperPdfUrl(url) {
  const text = String(url || "").trim();
  if (!text) {
    return "";
  }
  try {
    const parsed = new URL(text, "http://researchclaw.local");
    parsed.searchParams.delete("force_regenerate");
    return `${parsed.pathname}${parsed.search}${parsed.hash}`;
  } catch {
    return text.replace(/([?&])force_regenerate=1(&|$)/, (match, prefix, suffix) => (
      prefix === "?" && suffix ? "?" : ""
    ));
  }
}

function ArtifactTreeNode({
  runId,
  entry,
  depth,
  expandedNodes,
  treeNodes,
  treeLoading,
  onToggleFolder,
}) {
  const nodeKey = artifactNodeKey(runId, entry.path);
  const isDir = entry.kind === "dir";
  const isExpanded = Boolean(expandedNodes[nodeKey]);
  const childEntries = treeNodes[nodeKey] || [];
  const isLoading = Boolean(treeLoading[nodeKey]);
  const displayName = displayLibraryName(entry.name);

  return (
    <div className="artifact-tree-node">
      {isDir ? (
        <>
          <button
            type="button"
            className="artifact-tree-toggle"
            style={{ paddingLeft: `${depth * 16}px` }}
            onClick={() => onToggleFolder(runId, entry.path)}
          >
            <span className="artifact-tree-caret" aria-hidden="true">
              {isExpanded ? <ChevronDown strokeWidth={1.8} /> : <ChevronRight strokeWidth={1.8} />}
            </span>
            <span className="artifact-tree-icon" aria-hidden="true">
              {isExpanded ? <FolderOpen strokeWidth={1.8} /> : <Folder strokeWidth={1.8} />}
            </span>
            <span className="artifact-tree-name">{displayName}</span>
            <span className="artifact-tree-meta">{entry.child_count || 0} items</span>
          </button>
          {isExpanded ? (
            <div className="artifact-tree-children">
              {isLoading ? <p className="artifact-tree-empty">Loading...</p> : null}
              {!isLoading && childEntries.length === 0 ? (
                <p className="artifact-tree-empty">Empty folder</p>
              ) : null}
              {!isLoading
                ? childEntries.map((child) => (
                    <ArtifactTreeNode
                      key={child.path}
                      runId={runId}
                      entry={child}
                      depth={depth + 1}
                      expandedNodes={expandedNodes}
                      treeNodes={treeNodes}
                      treeLoading={treeLoading}
                      onToggleFolder={onToggleFolder}
                    />
                  ))
                : null}
            </div>
          ) : null}
        </>
      ) : (
        <a
          className="artifact-tree-file"
          style={{ paddingLeft: `${depth * 16 + 24}px` }}
          href={buildApiUrl(entry.url)}
          target="_blank"
          rel="noreferrer"
        >
          <span className="artifact-tree-icon" aria-hidden="true">
            <File strokeWidth={1.8} />
          </span>
          <span className="artifact-tree-name">{displayName}</span>
          <span className="artifact-tree-meta">{formatDateTime(entry.modified_at)}</span>
        </a>
      )}
    </div>
  );
}

function humanizeToken(value) {
  return String(value || "")
    .replaceAll(/[_-]+/g, " ")
    .replaceAll(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function stripMarkup(text) {
  return String(text || "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/^[-*+]\s+/gm, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

function firstSentence(text, fallback = "") {
  const cleaned = stripMarkup(text);
  if (!cleaned) {
    return fallback;
  }
  const match = cleaned.match(/(.+?[.!?])(?:\s|$)/);
  return (match ? match[1] : cleaned).trim();
}

function extractMarkdownSections(content) {
  const sections = [];
  const regex = /^##\s+(.+?)\s*$([\s\S]*?)(?=^##\s+|\Z)/gm;
  let match = regex.exec(content);
  while (match) {
    sections.push({
      heading: stripMarkup(match[1]),
      body: stripMarkup(match[2]),
    });
    match = regex.exec(content);
  }
  return sections;
}

function summarizeArtifactBlock(name, content) {
  const lowerName = String(name || "").toLowerCase();
  const outputs = [];
  const warnings = [];
  const recommendations = [];
  let overview = "";

  if (lowerName.endsWith(".json")) {
    try {
      const payload = JSON.parse(content);
      if (lowerName === "hardware_profile.json") {
        const gpuName = payload.gpu_name || "Detected local hardware";
        const vramText = Number.isFinite(payload.vram_mb) ? `${payload.vram_mb} MB VRAM` : "VRAM not reported";
        outputs.push({ label: "Hardware", text: `${gpuName} with ${vramText}.` });
        if (payload.warning) {
          warnings.push(stripMarkup(payload.warning));
        }
        recommendations.push(
          payload.has_gpu
            ? "This setup is suitable for classical machine-learning experiments. Consider a stronger remote GPU only for heavier deep-learning workloads."
            : "CPU execution is available. For heavier training workloads, a remote GPU environment may be more efficient."
        );
        overview = "The system checked the available compute environment for this research run.";
        return { overview, outputs, warnings, recommendations };
      }

      for (const key of ["topic", "title", "summary", "focus", "novel_angle", "recommendation"]) {
        if (payload[key]) {
          outputs.push({ label: humanizeToken(key), text: firstSentence(payload[key]) });
        }
      }
      if (payload.warning) {
        warnings.push(firstSentence(payload.warning));
      }
      if (payload.recommendation) {
        recommendations.push(firstSentence(payload.recommendation));
      }
      overview = outputs[0]?.text || "A structured stage artifact was generated for review.";
      return { overview, outputs, warnings, recommendations };
    } catch {
      // Fall through to plain-text parsing.
    }
  }

  if (lowerName === "goal.md") {
    const sections = extractMarkdownSections(content);
    for (const section of sections) {
      if (section.body) {
        outputs.push({ label: section.heading, text: firstSentence(section.body, section.body) });
      }
    }
    overview = outputs[0]?.text || "The research direction and novelty were defined for this run.";
    return { overview, outputs, warnings, recommendations };
  }

  const genericText = stripMarkup(content).replace(/^Stage\s+\d+.*?:\s*/i, "");
  overview = firstSentence(genericText, "A stage artifact is available for review.");
  if (genericText) {
    outputs.push({ label: humanizeToken(name.replace(/\.[^.]+$/, "")), text: overview });
  }
  return { overview, outputs, warnings, recommendations };
}

function buildCopilotReview(waiting, stageMeta) {
  const rawSummary = String(waiting?.context_summary || "");
  const lines = rawSummary.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const statusMatch = lines[0]?.match(/completed:\s*([^\n]+)/i);
  const status = statusMatch ? humanizeToken(statusMatch[1]) : "Awaiting review";
  const artifactMatch = rawSummary.match(/Artifacts:\s*([^\n]+)/i);
  const artifactNames = artifactMatch
    ? artifactMatch[1].split(",").map((item) => item.trim()).filter(Boolean)
    : Array.isArray(waiting?.output_files)
      ? waiting.output_files
      : [];

  const fileBlocks = [];
  const blockRegex = /---\s+([^\n-][^\n]*?)\s+---\s*\n([\s\S]*?)(?=\n---\s+[^\n-][^\n]*?\s+---|$)/g;
  let blockMatch = blockRegex.exec(rawSummary);
  while (blockMatch) {
    fileBlocks.push({ name: blockMatch[1].trim(), content: blockMatch[2].trim() });
    blockMatch = blockRegex.exec(rawSummary);
  }

  const outputs = [];
  const warnings = [];
  const recommendations = [];
  const overviewCandidates = [];

  for (const block of fileBlocks) {
    const summary = summarizeArtifactBlock(block.name, block.content);
    if (summary.overview) {
      overviewCandidates.push(summary.overview);
    }
    outputs.push(...summary.outputs);
    warnings.push(...summary.warnings);
    recommendations.push(...summary.recommendations);
  }

  if (artifactNames.length > 0) {
    outputs.unshift({
      label: "Key Outputs",
      text: artifactNames.join(", "),
    });
  }

  const stageTitle = stageMeta?.label || humanizeToken(waiting?.stage_name || "Current Stage");
  const overview = overviewCandidates[0]
    || stageMeta?.desc
    || "The pipeline completed this stage and is waiting for your review before continuing.";

  return {
    title: `Stage ${waiting?.stage || stageMeta?.num || ""} Complete: ${stageTitle}`,
    status,
    reason: humanizeToken(waiting?.reason || "gate_approval"),
    overview,
    outputs: outputs.filter((item, index, array) => item.text && array.findIndex((entry) => entry.label === item.label && entry.text === item.text) === index).slice(0, 5),
    warnings: warnings.filter(Boolean).slice(0, 3),
    recommendations: recommendations.filter(Boolean).slice(0, 3),
  };
}

function buildStageResponse(runId, waiting, stageMeta, isCurrent = false) {
  if (!runId || !waiting) {
    return null;
  }

  const review = buildCopilotReview(waiting, stageMeta);
  return {
    key: `${runId}:${waiting.stage}:${waiting.reason || "waiting"}`,
    runId,
    stage: waiting.stage,
    stageName: waiting.stage_name,
    title: review?.title || `Stage ${waiting.stage} - ${waiting.stage_name}`,
    status: review?.status || "Awaiting review",
    reason: review?.reason || humanizeToken(waiting.reason),
    overview: review?.overview || "The pipeline is paused for review before continuing.",
    outputs: review?.outputs || [],
    warnings: review?.warnings || [],
    recommendations: review?.recommendations || [],
    isCurrent,
  };
}

const HITL_POSITIVE_REASON_OPTIONS = [
  { id: "accurate", label: "Accurate" },
  { id: "helpful", label: "Helpful" },
  { id: "clear_explanation", label: "Clear explanation" },
  { id: "well_formatted", label: "Well formatted" },
  { id: "good_examples", label: "Good examples" },
  { id: "easy_to_understand", label: "Easy to understand" },
  { id: "relevant_to_question", label: "Relevant to my question" },
  { id: "good_code_solution", label: "Good code solution" },
  { id: "insightful", label: "Insightful or informative" },
];

const HITL_NEGATIVE_REASON_OPTIONS = [
  { id: "incorrect_answer", label: "Incorrect answer" },
  { id: "missing_details", label: "Missing details" },
  { id: "irrelevant", label: "Irrelevant" },
  { id: "confusing_explanation", label: "Confusing explanation" },
  { id: "code_error", label: "Code error" },
  { id: "too_verbose", label: "Too verbose" },
  { id: "flowchart_too_simple", label: "Flowchart too simple or linear" },
];

function createHitlResponseActionState() {
  return {
    vote: null,
    feedbackPanelVisible: false,
    note: "",
    draft: "",
    noteTouched: false,
    editing: false,
    positiveReasons: {},
    positiveOther: "",
    negativeReasons: {},
    negativeOther: "",
    submittedPositiveLabels: [],
    submittedPositiveOther: "",
    submittedNegativeLabels: [],
    submittedNegativeOther: "",
    lastPositiveNotes: [],
    lastNegativeNotes: [],
    lastRevisionRequest: "",
    confirmingContinue: false,
  };
}

function selectedReasonLabels(options, selectedMap) {
  return options
    .filter((option) => Boolean(selectedMap?.[option.id]))
    .map((option) => option.label);
}

function buildHitlPositiveFeedback(selectedMap, otherText) {
  const labels = selectedReasonLabels(HITL_POSITIVE_REASON_OPTIONS, selectedMap);
  const trimmedOther = String(otherText || "").trim();
  const notes = [];
  if (labels.length > 0) {
    notes.push(`What you liked: ${labels.join(", ")}.`);
  }
  if (trimmedOther) {
    notes.push(`Other: ${trimmedOther}`);
  }
  return {
    labels,
    other: trimmedOther,
    notes,
  };
}

function buildHitlNegativeFeedback(selectedMap, otherText) {
  const labels = selectedReasonLabels(HITL_NEGATIVE_REASON_OPTIONS, selectedMap);
  const trimmedOther = String(otherText || "").trim();
  const notes = [];
  if (labels.length > 0) {
    notes.push(`What went wrong: ${labels.join(", ")}.`);
  }
  if (trimmedOther) {
    notes.push(`Other: ${trimmedOther}`);
  }
  return {
    labels,
    other: trimmedOther,
    notes,
  };
}

function buildHitlRegenerateRequest(response, actionState, supplementalQuery = "") {
  const positiveLabels = actionState.submittedPositiveLabels || [];
  const positiveOther = String(actionState.submittedPositiveOther || "").trim();
  const negativeLabels = actionState.submittedNegativeLabels || [];
  const negativeOther = String(actionState.submittedNegativeOther || "").trim();
  const savedComment = String(actionState.note || "").trim();
  const extraQuery = String(supplementalQuery || "").trim();

  const lines = [
    `Please regenerate the stage ${response.stage} output for ${response.stageName || "this stage"}.`,
  ];

  if (positiveLabels.length > 0 || positiveOther) {
    const preserve = [];
    if (positiveLabels.length > 0) {
      preserve.push(positiveLabels.join(", "));
    }
    if (positiveOther) {
      preserve.push(`Other: ${positiveOther}`);
    }
    lines.push(`Preserve these strengths: ${preserve.join(" | ")}.`);
  }

  if (negativeLabels.length > 0 || negativeOther) {
    const revise = [];
    if (negativeLabels.length > 0) {
      revise.push(negativeLabels.join(", "));
    }
    if (negativeOther) {
      revise.push(`Other: ${negativeOther}`);
    }
    lines.push(`Address these issues: ${revise.join(" | ")}.`);
  }

  if (savedComment) {
    lines.push(`Additional comment: ${savedComment}`);
  }

  if (extraQuery) {
    lines.push(`Additional query: ${extraQuery}`);
  }

  if (lines.length === 1) {
    lines.push("Revise the response before approval.");
  }

  return lines.join(" ");
}

function buildHitlApproveRequest(response, actionState, supplementalQuery = "") {
  const positiveLabels = actionState.submittedPositiveLabels || [];
  const positiveOther = String(actionState.submittedPositiveOther || "").trim();
  const negativeLabels = actionState.submittedNegativeLabels || [];
  const negativeOther = String(actionState.submittedNegativeOther || "").trim();
  const savedComment = String(actionState.note || "").trim();
  const extraQuery = String(supplementalQuery || "").trim();

  const lines = [
    `Approved stage ${response.stage} for progression to the next stage.`,
  ];

  if (positiveLabels.length > 0 || positiveOther) {
    const preserve = [];
    if (positiveLabels.length > 0) {
      preserve.push(positiveLabels.join(", "));
    }
    if (positiveOther) {
      preserve.push(`Other: ${positiveOther}`);
    }
    lines.push(`Carry forward these strengths: ${preserve.join(" | ")}.`);
  }

  if (negativeLabels.length > 0 || negativeOther) {
    const improve = [];
    if (negativeLabels.length > 0) {
      improve.push(negativeLabels.join(", "));
    }
    if (negativeOther) {
      improve.push(`Other: ${negativeOther}`);
    }
    lines.push(`Improve these areas in the next stage: ${improve.join(" | ")}.`);
  }

  if (savedComment) {
    lines.push(`Researcher note: ${savedComment}`);
  }

  if (extraQuery) {
    lines.push(`Additional query for the next stage: ${extraQuery}`);
  }

  if (lines.length === 1 && !extraQuery) {
    return "";
  }

  return lines.join(" ");
}

function QueryComposer({
  docked,
  topic,
  onTopicChange,
  startPipeline,
  isPipelineRunning,
  busy,
  sourceType,
  onSourceTypeChange,
  error,
  onStop,
  onRefresh,
}) {
  const [isSourceMenuOpen, setIsSourceMenuOpen] = useState(false);
  const sourceMenuRef = useRef(null);
  const selectedSource = SOURCE_OPTION_MAP[sourceType] || SOURCE_OPTIONS[0];

  const handleTopicInput = (event) => {
    const nextValue = event.target.value;
    onTopicChange(nextValue);
    const target = event.target;
    const maxHeight = docked ? 180 : 280;
    target.style.height = "auto";
    const nextHeight = Math.min(target.scrollHeight, maxHeight);
    target.style.height = `${nextHeight}px`;
    target.style.overflowY = target.scrollHeight > maxHeight ? "auto" : "hidden";
  };

  useEffect(() => {
    if (!isSourceMenuOpen) {
      return undefined;
    }
    const handlePointerDown = (event) => {
      if (!sourceMenuRef.current || sourceMenuRef.current.contains(event.target)) {
        return;
      }
      setIsSourceMenuOpen(false);
    };
    document.addEventListener("pointerdown", handlePointerDown);
    return () => document.removeEventListener("pointerdown", handlePointerDown);
  }, [isSourceMenuOpen]);

  return (
    <div className={`composer-wrap ${docked ? "composer-wrap-docked" : "composer-wrap-centered"}`}>
      <form onSubmit={startPipeline} className={`composer-shell ${docked ? "composer-shell-docked" : ""}`}>
        <div className="query-input-shell">
          <textarea
            id="topic"
            value={topic}
            onChange={handleTopicInput}
            onInput={handleTopicInput}
            onKeyDown={(event) => {
              if (
                event.key === "Enter"
                && !event.shiftKey
                && !event.nativeEvent.isComposing
              ) {
                event.preventDefault();
                if (!busy && topic.trim()) {
                  event.currentTarget.form?.requestSubmit();
                }
              }
            }}
            placeholder="Enter a research topic"
            disabled={isPipelineRunning}
            rows={1}
          />
          <button type="submit" className="composer-send query-submit-arrow" disabled={busy || !topic.trim()} aria-label="Start research">
            <SendHorizontal aria-hidden="true" strokeWidth={1.9} />
          </button>
          <div className="input-row-controls">
            <div className="input-row-left-controls">
              <div className="source-control" ref={sourceMenuRef}>
                <button
                  type="button"
                  className={`source-trigger ${isSourceMenuOpen ? "source-trigger-open" : ""}`}
                  aria-haspopup="listbox"
                  aria-expanded={isSourceMenuOpen}
                  disabled={isPipelineRunning}
                  onClick={() => !isPipelineRunning && setIsSourceMenuOpen((open) => !open)}
                >
                  <span className="source-trigger-value">
                    <SourceGlyph value={selectedSource.value} />
                    <span>{selectedSource.label}</span>
                  </span>
                  <svg className="source-trigger-chevron" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
                    <path d="m5.5 7.5 4.5 5 4.5-5" />
                  </svg>
                </button>
                {isSourceMenuOpen ? (
                  <div className="source-menu" role="listbox" aria-label="Source">
                    <div className="source-menu-title">Source</div>
                    {SOURCE_OPTIONS.map((option) => {
                      const isSelected = option.value === selectedSource.value;
                      return (
                        <button
                          key={option.value}
                          type="button"
                          className={`source-option ${isSelected ? "source-option-selected" : ""}`}
                          role="option"
                          aria-selected={isSelected}
                          onClick={() => {
                            onSourceTypeChange(option.value);
                            setIsSourceMenuOpen(false);
                          }}
                        >
                          <span className="source-option-icon">
                            <SourceGlyph value={option.value} />
                          </span>
                          <span className="source-option-label">{option.label}</span>
                        </button>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            </div>
            <div className="composer-inline-actions">
              {docked ? (
                <button
                  type="button"
                  className="ghost composer-inline-button composer-inline-icon-button"
                  disabled={busy}
                  onClick={onRefresh}
                  aria-label="Refresh"
                  title="Refresh"
                >
                  <RefreshCw aria-hidden="true" strokeWidth={1.8} />
                </button>
              ) : null}
              {isPipelineRunning ? (
                <button
                  type="button"
                  className="ghost composer-inline-button composer-inline-icon-button"
                  disabled={busy}
                  onClick={onStop}
                  aria-label="Stop"
                  title="Stop"
                >
                  <Pause aria-hidden="true" strokeWidth={1.8} />
                </button>
              ) : null}
            </div>
          </div>
        </div>
      </form>
      {error ? <p className="query-error">Error: {error}</p> : null}
    </div>
  );
}

export default function HomePage() {
  const [topic, setTopic] = useState("");
  const [health, setHealth] = useState(null);
  const [config, setConfig] = useState(null);
  const [status, setStatus] = useState(null);
  const [runs, setRuns] = useState([]);
  const [events, setEvents] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [wsState, setWsState] = useState("disconnected");
  const [selectedRunId, setSelectedRunId] = useState("");
  const [paperAssets, setPaperAssets] = useState(null);
  const [paperLoading, setPaperLoading] = useState(false);
  const [paperError, setPaperError] = useState("");
  const [paperMarkdown, setPaperMarkdown] = useState("");
  const [paperMarkdownLoading, setPaperMarkdownLoading] = useState(false);
  const [paperMarkdownError, setPaperMarkdownError] = useState("");
  const [paperAssetsReloadToken, setPaperAssetsReloadToken] = useState(0);
  const [pdfFrameLoaded, setPdfFrameLoaded] = useState(false);
  const [loadedPdfFrameKey, setLoadedPdfFrameKey] = useState("");
  const [paperPdfUrlCache, setPaperPdfUrlCache] = useState({});
  const [showLibrary, setShowLibrary] = useState(false);
  const [suppressAutoSelect, setSuppressAutoSelect] = useState(true);
  const [isBlankSession, setIsBlankSession] = useState(true);
  const [sessionHeading, setSessionHeading] = useState("");
  const [libraryItems, setLibraryItems] = useState([]);
  const [libraryRuns, setLibraryRuns] = useState([]);
  const [libraryLoading, setLibraryLoading] = useState(false);
  const [libraryError, setLibraryError] = useState("");
  const [expandedLibraryRuns, setExpandedLibraryRuns] = useState({});
  const [expandedLibraryNodes, setExpandedLibraryNodes] = useState({});
  const [libraryTreeNodes, setLibraryTreeNodes] = useState({});
  const [libraryTreeLoading, setLibraryTreeLoading] = useState({});
  const [libraryActionBusy, setLibraryActionBusy] = useState({});
  const [storageReady, setStorageReady] = useState(false);
  const [activeRunId, setActiveRunId] = useState("");
  const [runProgress, setRunProgress] = useState(null);
  const [liveStageByRun, setLiveStageByRun] = useState({});
  const [pendingLibraryOpenRun, setPendingLibraryOpenRun] = useState(null);
  const [pendingNewSessionConfirm, setPendingNewSessionConfirm] = useState(false);
  const [researchMode, setResearchMode] = useState("AutoPilot");
  const [sourceType, setSourceType] = useState("auto");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [hitlStatus, setHitlStatus] = useState(null);
  const [hitlBusy, setHitlBusy] = useState(false);
  const [hitlMessage, setHitlMessage] = useState("");
  const [hitlQueryLocked, setHitlQueryLocked] = useState(false);
  const [hitlResponseHistory, setHitlResponseHistory] = useState([]);
  const [openedPreservedResponses, setOpenedPreservedResponses] = useState([]);
  const [libraryContinueRequired, setLibraryContinueRequired] = useState({});
  const [hitlResponseActions, setHitlResponseActions] = useState({});
  const [overlayBounds, setOverlayBounds] = useState(null);
  const autoOpenedPdfRunRef = useRef("");
  const finalPaperRefreshRunRef = useRef("");
  const completedLibraryPdfRunRef = useRef("");
  const hitlLockedResponseKeyRef = useRef("");
  const hitlResponseClearedAfterLockRef = useRef(false);
  const viewerMainRef = useRef(null);
  const socketRef = useRef(null);
  const reconnectTimerRef = useRef(null);
  const reconnectAttemptRef = useRef(0);
  const forceBlankSessionRef = useRef(false);
  const pipelineStatus = String(status?.status || "").toLowerCase();
  const isStageCheckpointWaiting = Boolean(hitlStatus?.waiting);
  const isPipelineRunning = busy || (pipelineStatus === "running" && !isStageCheckpointWaiting);
  const isPipelineWaiting = pipelineStatus === "waiting" || isStageCheckpointWaiting;
  const isPipelineStopping = pipelineStatus === "stopping";
  const isPipelineFailed = pipelineStatus === "failed";
  const headingText =
    (sessionHeading || "").trim() || (status?.topic || "").trim() || "Research Session";
  const landingHeading =
    researchMode === "CoPilot"
      ? "Let's research and discover together"
      : "I will research and discover for you automatically";
  const isHumanInLoopMode = researchMode === "CoPilot";
  const isAutoPilotMode = researchMode === "AutoPilot";
  const showsStageHistory = isHumanInLoopMode || isAutoPilotMode;
  const composerDocked = false;
  const showLandingState = isBlankSession && !isPipelineRunning && !isPipelineWaiting && !isPipelineStopping && !activeRunId;
  const cachedPaperPdfUrl = selectedRunId ? (paperPdfUrlCache[selectedRunId] || "") : "";
  const fallbackPaperPdfUrl = selectedRunId && !isBlankSession ? `/api/runs/${selectedRunId}/paper/pdf` : "";
  const effectivePaperPdfUrl = paperAssets?.pdf_url || cachedPaperPdfUrl || fallbackPaperPdfUrl;
  const isCompletedLibraryRunSelected = Boolean(
    selectedRunId
    && completedLibraryPdfRunRef.current === selectedRunId
  );
  const isStableCompletedLibraryPdfView = Boolean(
    isCompletedLibraryRunSelected
    && effectivePaperPdfUrl
  );
  const pdfCacheBustToken = `${selectedRunId || "none"}-${paperAssetsReloadToken}`;
  const paperPdfViewerUrl = effectivePaperPdfUrl
    ? isStableCompletedLibraryPdfView
      ? buildApiUrl(effectivePaperPdfUrl)
      : `${buildApiUrl(effectivePaperPdfUrl)}${effectivePaperPdfUrl.includes("?") ? "&" : "?"}_ts=${pdfCacheBustToken}`
    : "";
  const pdfFrameReadyKey = paperPdfViewerUrl
    ? isCompletedLibraryRunSelected
      ? `completed:${selectedRunId}`
      : `${selectedRunId || "none"}:${paperPdfViewerUrl}`
    : "";
  const isPdfFrameReady = Boolean(
    isStableCompletedLibraryPdfView
    || pdfFrameLoaded
    || (pdfFrameReadyKey && loadedPdfFrameKey === pdfFrameReadyKey)
  );

  const isViewerEntry = (item) => {
    if (!item || typeof item !== "object") {
      return false;
    }
    return typeof item.open_url === "string" && item.open_url.includes("/paper/pdf");
  };

  const wsUrl = useMemo(() => buildWsUrl("/ws/events"), []);
  const visibleEvents = useMemo(
    () =>
      events.filter((item) => {
        if (
          item.type === "client.error" ||
          item.type === "client.disconnected" ||
          item.type === "client.connected"
        ) {
          return false;
        }
        if (
          item.type === "server.event" &&
          item.payload &&
          typeof item.payload === "object" &&
          (item.payload.type === "heartbeat" || item.payload.type === "connected")
        ) {
          return false;
        }
        return true;
      }),
    [events]
  );

  const currentStage = useMemo(() => {
    const targetRunId = activeRunId || status?.run_id || "";
    const waitingStageName = showsStageHistory
      ? (hitlStatus?.waiting?.stage_name || runProgress?.hitl?.waiting?.stage_name || null)
      : null;
    const heartbeatMatchesRun =
      !targetRunId ||
      !runProgress?.heartbeat?.run_id ||
      runProgress.heartbeat.run_id === targetRunId;
    const heartbeatStageName = heartbeatMatchesRun
      ? runProgress?.heartbeat?.last_stage_name
      : null;
    const statusMatchesRun = !targetRunId || !status?.run_id || status.run_id === targetRunId;
    const statusCurrentStageName = statusMatchesRun ? status?.current_stage_name : null;

    if (waitingStageName) {
      return waitingStageName;
    }

    if ((isPipelineRunning || isPipelineWaiting) && targetRunId && liveStageByRun[targetRunId]) {
      return liveStageByRun[targetRunId];
    }

    if (isPipelineRunning && heartbeatStageName) {
      return heartbeatStageName;
    }

    if (isPipelineRunning && statusCurrentStageName) {
      return statusCurrentStageName;
    }

    if (isPipelineRunning && runProgress?.next_stage_name) {
      return runProgress.next_stage_name;
    }

    for (const item of visibleEvents) {
      if (
        item.type === "server.event" &&
        item.payload?.type === "stage_start" &&
        item.payload?.data?.stage &&
        (!targetRunId || item.payload?.data?.run_id === targetRunId)
      ) {
        return item.payload.data.stage;
      }
    }

    const fromStage = Number(status?.from_stage || 0);
    if (isPipelineRunning && Number.isFinite(fromStage) && fromStage > 0 && STAGE_NAME_BY_NUM[fromStage]) {
      return STAGE_NAME_BY_NUM[fromStage];
    }

    if (!isPipelineRunning && runProgress?.next_stage_name) {
      return runProgress.next_stage_name;
    }

    const stageDirs = Array.isArray(runProgress?.stages_completed)
      ? runProgress.stages_completed
      : [];
    let maxStage = 0;
    for (const dirName of stageDirs) {
      const match = /^stage-(\d+)$/i.exec(String(dirName));
      if (match) {
        const stageNum = Number.parseInt(match[1], 10);
        if (Number.isFinite(stageNum) && stageNum > maxStage) {
          maxStage = stageNum;
        }
      }
    }
    if (maxStage > 0 && STAGE_NAME_BY_NUM[maxStage]) {
      return STAGE_NAME_BY_NUM[maxStage];
    }

    if (heartbeatStageName) {
      return heartbeatStageName;
    }

    if (runProgress?.checkpoint?.last_completed_name) {
      return runProgress.checkpoint.last_completed_name;
    }

    return null;
  }, [visibleEvents, activeRunId, status, runProgress, hitlStatus, isPipelineRunning, isPipelineWaiting, showsStageHistory, liveStageByRun]);

  const completedStageCount = useMemo(() => {
    const counts = [];
    const checkpointStage = Number(runProgress?.checkpoint?.last_completed_stage || 0);
    if (Number.isFinite(checkpointStage) && checkpointStage > 0) {
      counts.push(checkpointStage);
    }

    const statusStageCount = Number(status?.stages_done || 0);
    if (Number.isFinite(statusStageCount) && statusStageCount > 0) {
      counts.push(statusStageCount);
    }

    const stageDirs = Array.isArray(runProgress?.stages_completed)
      ? runProgress.stages_completed
      : [];
    let maxStageDir = 0;
    for (const dirName of stageDirs) {
      const match = /^stage-(\d+)$/i.exec(String(dirName));
      if (match) {
        const stageNum = Number.parseInt(match[1], 10);
        if (Number.isFinite(stageNum) && stageNum > maxStageDir) {
          maxStageDir = stageNum;
        }
      }
    }
    if (maxStageDir > 0) {
      counts.push(maxStageDir);
    }

    return Math.max(0, ...counts);
  }, [runProgress, status]);

  const hasCompletedAllStages = Boolean(activeRunId) && (
    completedStageCount >= Object.keys(STAGE_INFO).length
    || runProgress?.next_stage === null
    || (pipelineStatus === "completed" && Number(status?.stages_failed || 0) === 0)
  );

  useEffect(() => {
    if (!composerDocked || !viewerMainRef.current) {
      setOverlayBounds(null);
      return undefined;
    }

    const updateOverlayBounds = () => {
      const node = viewerMainRef.current;
      if (!node) {
        return;
      }
      const rect = node.getBoundingClientRect();
      const styles = window.getComputedStyle(node);
      const paddingLeft = Number.parseFloat(styles.paddingLeft) || 0;
      const paddingRight = Number.parseFloat(styles.paddingRight) || 0;
      const left = Math.max(rect.left + paddingLeft, 0);
      const right = Math.max(window.innerWidth - rect.right + paddingRight, 0);
      const width = Math.max(window.innerWidth - left - right, 0);
      setOverlayBounds((prev) => {
        if (
          prev
          && Math.abs(prev.left - left) < 1
          && Math.abs(prev.width - width) < 1
        ) {
          return prev;
        }
        return { left, width, right };
      });
    };

    updateOverlayBounds();
    const resizeObserver = new ResizeObserver(() => updateOverlayBounds());
    resizeObserver.observe(viewerMainRef.current);
    window.addEventListener("resize", updateOverlayBounds);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener("resize", updateOverlayBounds);
    };
  }, [composerDocked, isSidebarCollapsed, showLibrary]);

  const runStageMeta = currentStage && STAGE_INFO[currentStage] ? STAGE_INFO[currentStage] : null;
  const hitlWaiting = showsStageHistory ? (hitlStatus?.waiting || null) : null;
  const hitlModeLabel = hitlStatus?.session?.mode || (researchMode === "CoPilot" ? "co-pilot" : AUTOPILOT_STAGE_MODE);
  const copilotReview = useMemo(
    () => (hitlWaiting ? buildCopilotReview(hitlWaiting, runStageMeta) : null),
    [hitlWaiting, runStageMeta]
  );
  const currentHitlResponse = useMemo(() => {
    return buildStageResponse(activeRunId, hitlWaiting, runStageMeta, true);
  }, [activeRunId, hitlWaiting, runStageMeta]);
  const visibleHitlResponses = useMemo(
    () => {
      if (!showsStageHistory) {
        return [];
      }
      const preservedForRun = openedPreservedResponses.filter((item) => item?.runId === activeRunId);
      const combined = [...hitlResponseHistory];
      for (const preserved of preservedForRun) {
        if (!combined.some((item) => item.key === preserved.key)) {
          combined.push(preserved);
        }
      }

      return combined
        .map((item, index) => ({ item, index }))
        .sort((left, right) => {
          const leftStage = Number(left.item?.stage || 0);
          const rightStage = Number(right.item?.stage || 0);
          if (leftStage !== rightStage) {
            return leftStage - rightStage;
          }
          if (left.item?.isCurrent !== right.item?.isCurrent) {
            return left.item?.isCurrent ? 1 : -1;
          }
          return left.index - right.index;
        })
        .map(({ item }) => item);
    },
    [hitlResponseHistory, openedPreservedResponses, activeRunId, showsStageHistory]
  );

  useEffect(() => {
    setHitlResponseHistory([]);
    setHitlResponseActions({});
    setHitlQueryLocked(false);
    hitlLockedResponseKeyRef.current = "";
    hitlResponseClearedAfterLockRef.current = false;
  }, [activeRunId]);

  useEffect(() => {
    const currentResponseKey = currentHitlResponse?.key || "";
    if (!currentResponseKey) {
      if (hitlQueryLocked) {
        hitlResponseClearedAfterLockRef.current = true;
      }
      return;
    }

    if (!hitlQueryLocked) {
      setHitlMessage("");
      return;
    }

    const lockedResponseKey = hitlLockedResponseKeyRef.current;
    const hasNextVisibleResponse =
      hitlResponseClearedAfterLockRef.current ||
      (lockedResponseKey && currentResponseKey !== lockedResponseKey);
    if (!hasNextVisibleResponse) {
      return;
    }

    hitlLockedResponseKeyRef.current = "";
    hitlResponseClearedAfterLockRef.current = false;
    setHitlQueryLocked(false);
    setHitlMessage("");
  }, [currentHitlResponse?.key, hitlQueryLocked]);

  useEffect(() => {
    if (!currentHitlResponse) {
      setHitlResponseHistory((prev) => prev.map((item) => ({ ...item, isCurrent: false })));
      return;
    }
    setHitlResponseHistory((prev) => {
      const next = prev.map((item) => ({ ...item, isCurrent: item.key === currentHitlResponse.key }));
      const existingIndex = next.findIndex((item) => item.key === currentHitlResponse.key);
      if (existingIndex >= 0) {
        next[existingIndex] = { ...next[existingIndex], ...currentHitlResponse, isCurrent: true };
        return next;
      }
      return [...next.map((item) => ({ ...item, isCurrent: false })), currentHitlResponse];
    });
  }, [currentHitlResponse]);

  const updateHitlResponseAction = (responseKey, updater) => {
    setHitlResponseActions((prev) => {
      const current = prev[responseKey] || createHitlResponseActionState();
      const nextValue = typeof updater === "function" ? updater(current) : { ...current, ...updater };
      return { ...prev, [responseKey]: nextValue };
    });
  };

  const handleHitlVote = (responseKey, vote) => {
    updateHitlResponseAction(responseKey, (current) => ({
      ...current,
      vote,
      feedbackPanelVisible: current.vote === vote ? !Boolean(current.feedbackPanelVisible) : true,
    }));
  };

  const handleHitlPositiveReasonToggle = (responseKey, reasonId) => {
    updateHitlResponseAction(responseKey, (current) => {
      const positiveReasons = { ...(current.positiveReasons || {}) };
      positiveReasons[reasonId] = !positiveReasons[reasonId];
      return {
        ...current,
        vote: "up",
        feedbackPanelVisible: true,
        positiveReasons,
      };
    });
  };

  const handleHitlNegativeReasonToggle = (responseKey, reasonId) => {
    updateHitlResponseAction(responseKey, (current) => {
      const negativeReasons = { ...(current.negativeReasons || {}) };
      negativeReasons[reasonId] = !negativeReasons[reasonId];
      return {
        ...current,
        vote: "down",
        feedbackPanelVisible: true,
        negativeReasons,
      };
    });
  };

  const handleHitlPositiveSubmit = (response) => {
    const actionState = hitlResponseActions[response.key] || createHitlResponseActionState();
    const { labels, other, notes } = buildHitlPositiveFeedback(actionState.positiveReasons, actionState.positiveOther);
    if (notes.length === 0) {
      return;
    }
    updateHitlResponseAction(response.key, (current) => ({
      ...current,
      feedbackPanelVisible: false,
      submittedPositiveLabels: labels,
      submittedPositiveOther: other,
      lastPositiveNotes: notes,
    }));
  };

  const handleHitlNegativeSubmit = (response) => {
    const actionState = hitlResponseActions[response.key] || createHitlResponseActionState();
    const { labels, other, notes } = buildHitlNegativeFeedback(actionState.negativeReasons, actionState.negativeOther);
    if (notes.length === 0) {
      return;
    }
    updateHitlResponseAction(response.key, (current) => ({
      ...current,
      feedbackPanelVisible: false,
      submittedNegativeLabels: labels,
      submittedNegativeOther: other,
      lastNegativeNotes: notes,
    }));
  };

  const handleHitlCommentToggle = (responseKey) => {
    updateHitlResponseAction(responseKey, (current) => {
      const opening = !current.editing;
      return {
        ...current,
        editing: opening,
        draft: opening ? (current.draft || current.note || "") : current.draft,
        noteTouched: opening ? false : current.noteTouched,
      };
    });
  };

  const handleHitlCommentChange = (responseKey, draft) => {
    updateHitlResponseAction(responseKey, { draft, noteTouched: true });
  };

  const handleHitlCommentSave = (response) => {
    updateHitlResponseAction(response.key, (current) => ({
      ...current,
      note: (current.draft || "").trim(),
      draft: (current.draft || "").trim(),
      noteTouched: false,
      editing: false,
    }));
  };

  const handleHitlRegenerateRequest = async (response) => {
    if (!response.isCurrent) {
      return;
    }
    const actionState = hitlResponseActions[response.key] || createHitlResponseActionState();
    const request = buildHitlRegenerateRequest(response, actionState, hitlMessage);
    updateHitlResponseAction(response.key, { lastRevisionRequest: request });
    await submitHitlResponse("regenerate", request, response);
  };

  const handleLibraryContinuePrompt = (response) => {
    updateHitlResponseAction(response.key, { confirmingContinue: true });
  };

  const handleLibraryContinueCancel = (response) => {
    updateHitlResponseAction(response.key, { confirmingContinue: false });
  };

  const handleLibraryContinueConfirm = async (response) => {
    updateHitlResponseAction(response.key, { confirmingContinue: false });
    const submitted = await submitHitlResponse("approve", "", response);
    if (submitted) {
      setLibraryContinueRequired((prev) => {
        const next = { ...prev };
        delete next[response.key];
        return next;
      });
    }
  };

  const appendEvent = (type, payload) => {
    // Keep transient websocket lifecycle noise out of the visible feed.
    if (
      type === "client.error" ||
      type === "client.disconnected" ||
      type === "client.connected"
    ) {
      return;
    }
    if (
      type === "server.event" &&
      payload &&
      typeof payload === "object" &&
      (payload.type === "heartbeat" || payload.type === "connected")
    ) {
      return;
    }
    setEvents((prev) => [{ type, payload, ts: Date.now() }, ...prev].slice(0, 50));
  };

  const refreshAll = async () => {
    try {
      setError("");
      const [healthData, configData, statusData, runsData] = await Promise.all([
        apiGet("/api/health"),
        apiGet("/api/config"),
        apiGet("/api/pipeline/status"),
        apiGet("/api/runs"),
      ]);
      setHealth(healthData);
      setConfig(configData);
      const statusToSet = forceBlankSessionRef.current ? { status: "idle" } : statusData;
      setStatus(statusToSet);
      setRuns((runsData && runsData.runs) || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  };

  const refreshLibrary = async () => {
    try {
      setLibraryLoading(true);
      setLibraryError("");
      const data = await apiGet("/api/runs/library");
      setLibraryRuns((data && data.runs) || []);
    } catch (err) {
      setLibraryError(err instanceof Error ? err.message : String(err));
    } finally {
      setLibraryLoading(false);
    }
  };

  const loadLibraryTree = async (runId, path = "") => {
    const key = artifactNodeKey(runId, path);
    if (libraryTreeNodes[key] || libraryTreeLoading[key]) {
      return;
    }
    try {
      setLibraryTreeLoading((prev) => ({ ...prev, [key]: true }));
      const data = await apiGet(`/api/runs/${runId}/tree?path=${encodeURIComponent(path)}`);
      setLibraryTreeNodes((prev) => ({ ...prev, [key]: (data && data.entries) || [] }));
    } catch (err) {
      setLibraryError(err instanceof Error ? err.message : String(err));
    } finally {
      setLibraryTreeLoading((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }
  };

  const toggleLibraryRun = async (runId) => {
    const nextOpen = !expandedLibraryRuns[runId];
    setExpandedLibraryRuns((prev) => ({ ...prev, [runId]: nextOpen }));
    if (nextOpen) {
      await loadLibraryTree(runId, "");
    }
  };

  const toggleLibraryFolder = async (runId, path) => {
    const key = artifactNodeKey(runId, path);
    const nextOpen = !expandedLibraryNodes[key];
    setExpandedLibraryNodes((prev) => ({ ...prev, [key]: nextOpen }));
    if (nextOpen) {
      await loadLibraryTree(runId, path);
    }
  };

  const hasCurrentRunningSession = () => {
    const currentStatus = String(status?.status || "").toLowerCase();
    return (
      ["running", "waiting", "stopping"].includes(currentStatus)
      || Boolean(activeRunId && !hasCompletedAllStages && !isBlankSession)
    );
  };

  const terminateCurrentSessionGracefully = async () => {
    if (!hasCurrentRunningSession()) {
      return;
    }
    try {
      await apiPost("/api/pipeline/stop", {});
    } catch {
      // The backend may already have no live worker for a restored waiting run.
    }
    for (let attempt = 0; attempt < 12; attempt += 1) {
      try {
        const nextStatus = await apiGet("/api/pipeline/status");
        const nextStatusText = String(nextStatus?.status || "").toLowerCase();
        if (!["running", "waiting", "stopping"].includes(nextStatusText)) {
          return;
        }
      } catch {
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
  };

  const openCompletedLibraryRun = (item) => {
    const pdfUrl = stablePaperPdfUrl(item.pdf_url || `/api/runs/${item.run_id}/paper/pdf`);
    forceBlankSessionRef.current = false;
    autoOpenedPdfRunRef.current = item.run_id;
    finalPaperRefreshRunRef.current = item.run_id;
    completedLibraryPdfRunRef.current = item.run_id;
    setShowLibrary(false);
    setSuppressAutoSelect(true);
    setIsBlankSession(false);
    setSessionHeading(item.folder_name || item.topic || "Research Session");
    setResearchMode(normalizeModeLabel(item.mode_label));
    setSourceType(item.source_type || "auto");
    setActiveRunId(item.run_id);
    setSelectedRunId(item.run_id);
    setRunProgress(null);
    setHitlStatus(null);
    setOpenedPreservedResponses([]);
    setLibraryContinueRequired({});
    setStatus((prev) => ({
      ...(prev || {}),
      run_id: item.run_id,
      topic: item.topic || prev?.topic || "",
      status: "completed",
    }));
    setPaperAssets(pdfUrl ? {
      run_id: item.run_id,
      has_pdf: true,
      has_markdown: false,
      pdf_url: pdfUrl,
      markdown_url: null,
      tex_url: null,
    } : null);
    setPaperLoading(!pdfUrl);
    setPdfFrameLoaded(false);
    if (pdfUrl) {
      setPaperPdfUrlCache((prev) => ({ ...prev, [item.run_id]: pdfUrl }));
    }
    setPaperMarkdown("");
    setPaperMarkdownLoading(false);
    setPaperMarkdownError("");
    setLiveStageByRun((prev) => {
      const next = { ...prev };
      delete next[item.run_id];
      return next;
    });
  };

  const closePendingLibraryOpen = () => {
    setPendingLibraryOpenRun(null);
  };

  const continuePendingLibraryOpen = async () => {
    if (!pendingLibraryOpenRun) {
      return;
    }
    const item = pendingLibraryOpenRun;
    const busyKey = `open:${item.run_id}`;
    try {
      setLibraryActionBusy((prev) => ({ ...prev, [busyKey]: true }));
      setLibraryError("");
      closePendingLibraryOpen();
      await terminateCurrentSessionGracefully();
      if (item.is_complete) {
        openCompletedLibraryRun(item);
        return;
      }
      completedLibraryPdfRunRef.current = "";
      setLoadedPdfFrameKey("");
      const result = await apiPost(`/api/runs/${item.run_id}/open`, {});
      const resolvedRun = result?.run || item;
      const [runDetails, nextHitlStatus] = await Promise.all([
        apiGet(`/api/runs/${item.run_id}`),
        apiGet(`/api/runs/${item.run_id}/hitl/status`).catch(() => null),
      ]);
      const resolvedModeLabel = normalizeModeLabel(resolvedRun.mode_label);
      const hydratedHitlStatus = nextHitlStatus || runDetails?.hitl || null;
      const preservedResponses = Array.isArray(result?.preserved_history)
        ? result.preserved_history
            .map((waiting) => {
              const stageMeta = waiting?.stage_name && STAGE_INFO[waiting.stage_name]
                ? STAGE_INFO[waiting.stage_name]
                : null;
              return buildStageResponse(item.run_id, waiting, stageMeta, false);
            })
            .filter(Boolean)
        : [];
      const preservedWaitingStageMeta = result?.preserved_waiting?.stage_name && STAGE_INFO[result.preserved_waiting.stage_name]
        ? STAGE_INFO[result.preserved_waiting.stage_name]
        : null;
      const preservedWaitingResponse = buildStageResponse(item.run_id, result?.preserved_waiting, preservedWaitingStageMeta, true);
      const preservedResponsesWithCurrent =
        (resolvedModeLabel === "AutoPilot" || resolvedModeLabel === "CoPilot") && preservedWaitingResponse
          ? [
              ...preservedResponses
                .filter((response) => response.key !== preservedWaitingResponse.key)
                .map((response) => ({ ...response, isCurrent: false })),
              preservedWaitingResponse,
            ]
          : preservedResponses;
      const stageName =
        hydratedHitlStatus?.waiting?.stage_name
        || runDetails?.hitl?.waiting?.stage_name
        || runDetails?.heartbeat?.last_stage_name
        || runDetails?.next_stage_name
        || resolvedRun.resume_stage_name
        || runDetails?.checkpoint?.last_completed_name
        || null;

      forceBlankSessionRef.current = false;
      setShowLibrary(false);
      setSuppressAutoSelect(true);
      setIsBlankSession(true);
      setSessionHeading(resolvedRun.folder_name || resolvedRun.topic || "Research Session");
      setResearchMode(resolvedModeLabel);
      setSourceType(resolvedRun.source_type || "auto");
      setActiveRunId(item.run_id);
      setSelectedRunId(item.run_id);
      setRunProgress(runDetails);
      setHitlStatus(hydratedHitlStatus);
      setLibraryContinueRequired(
        resolvedModeLabel === "CoPilot" && preservedWaitingResponse
          ? { [preservedWaitingResponse.key]: true }
          : {}
      );
      setOpenedPreservedResponses(
        resolvedModeLabel === "CoPilot" || resolvedModeLabel === "AutoPilot"
          ? preservedResponsesWithCurrent
          : []
      );
      setStatus((prev) => ({
        ...(prev || {}),
        run_id: item.run_id,
        topic: resolvedRun.topic || prev?.topic || "",
        status: hydratedHitlStatus?.waiting && !result?.resumed
          ? "waiting"
          : result?.resumed
            ? "running"
            : resolvedRun.is_complete
              ? "completed"
              : "idle",
      }));
      setLiveStageByRun((prev) => {
        const next = { ...prev };
        if (stageName) {
          next[item.run_id] = stageName;
        } else {
          delete next[item.run_id];
        }
        return next;
      });
      await refreshAll();
    } catch (err) {
      setLibraryError(err instanceof Error ? err.message : String(err));
    } finally {
      setLibraryActionBusy((prev) => {
        const next = { ...prev };
        delete next[busyKey];
        return next;
      });
    }
  };

  const handleOpenLibraryRun = async (item) => {
    if (!item) {
      return;
    }
    setPendingLibraryOpenRun(item);
  };

  const handleRenameLibraryRun = async (item) => {
    const nextName = window.prompt("Rename research folder", item.folder_name || item.topic || "");
    if (!nextName) {
      return;
    }
    const trimmed = nextName.trim();
    if (!trimmed || trimmed === item.folder_name) {
      return;
    }
    const busyKey = `rename:${item.run_id}`;
    try {
      setLibraryActionBusy((prev) => ({ ...prev, [busyKey]: true }));
      setLibraryError("");
      await apiPost(`/api/runs/${item.run_id}/rename`, { name: trimmed });
      if (activeRunId === item.run_id) {
        setSessionHeading(trimmed);
      }
      await refreshLibrary();
    } catch (err) {
      setLibraryError(err instanceof Error ? err.message : String(err));
    } finally {
      setLibraryActionBusy((prev) => {
        const next = { ...prev };
        delete next[busyKey];
        return next;
      });
    }
  };

  const handleDeleteLibraryRun = async (item) => {
    const confirmed = window.confirm(`Delete "${item.folder_name}" and all of its artifacts?`);
    if (!confirmed) {
      return;
    }
    const busyKey = `delete:${item.run_id}`;
    try {
      setLibraryActionBusy((prev) => ({ ...prev, [busyKey]: true }));
      setLibraryError("");
      await apiPost(`/api/runs/${item.run_id}/delete`, {});
      if (activeRunId === item.run_id) {
        setActiveRunId("");
        setSelectedRunId("");
        setRunProgress(null);
        setHitlStatus(null);
        setHitlMessage("");
        setSessionHeading("");
        setIsBlankSession(true);
      }
      setExpandedLibraryRuns((prev) => {
        const next = { ...prev };
        delete next[item.run_id];
        return next;
      });
      setExpandedLibraryNodes((prev) => {
        const next = { ...prev };
        Object.keys(next)
          .filter((key) => key.startsWith(`${item.run_id}:`))
          .forEach((key) => delete next[key]);
        return next;
      });
      setLibraryTreeNodes((prev) => {
        const next = { ...prev };
        Object.keys(next)
          .filter((key) => key.startsWith(`${item.run_id}:`))
          .forEach((key) => delete next[key]);
        return next;
      });
      await refreshLibrary();
      await refreshAll();
    } catch (err) {
      setLibraryError(err instanceof Error ? err.message : String(err));
    } finally {
      setLibraryActionBusy((prev) => {
        const next = { ...prev };
        delete next[busyKey];
        return next;
      });
    }
  };

  useEffect(() => {
    refreshAll();
    const timer = setInterval(refreshAll, 10000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!storageReady || !showLibrary) {
      return;
    }
    refreshLibrary();
  }, [storageReady, showLibrary]);

  useEffect(() => {
    if (isCompletedLibraryRunSelected) {
      return;
    }
    if (!isBlankSession && status?.run_id) {
      setActiveRunId(status.run_id);
    }
  }, [status, isBlankSession, isCompletedLibraryRunSelected]);

  useEffect(() => {
    try {
      const libraryRaw = window.localStorage.getItem(LIBRARY_STORAGE_KEY);
      if (libraryRaw) {
        const parsed = JSON.parse(libraryRaw);
        if (Array.isArray(parsed)) {
          setLibraryItems(parsed.filter(isViewerEntry));
        }
      }

      const blankRaw = window.localStorage.getItem(BLANK_SESSION_STORAGE_KEY);
      if (blankRaw === "1") {
        forceBlankSessionRef.current = true;
        setShowLibrary(false);
        setSuppressAutoSelect(true);
        setIsBlankSession(true);
      } else if (blankRaw === "0") {
        forceBlankSessionRef.current = false;
        setSuppressAutoSelect(false);
        setIsBlankSession(false);
      }
    } catch {
      setLibraryItems([]);
    } finally {
      setStorageReady(true);
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(libraryItems));
    } catch {
      // Ignore storage quota or privacy mode errors.
    }
  }, [libraryItems]);

  useEffect(() => {
    try {
      window.localStorage.setItem(BLANK_SESSION_STORAGE_KEY, isBlankSession ? "1" : "0");
    } catch {
      // Ignore storage write errors.
    }
  }, [isBlankSession]);

  useEffect(() => {
    if (!storageReady) {
      return;
    }
    if (!selectedRunId && runs.length > 0 && !suppressAutoSelect) {
      setSelectedRunId(runs[0].run_id);
    }
  }, [runs, selectedRunId, suppressAutoSelect, storageReady]);

  useEffect(() => {
    if (!storageReady || runs.length === 0) {
      return;
    }

    let cancelled = false;
    const seedLibraryFromRuns = async () => {
      const checks = await Promise.all(
        runs.slice(0, 50).map(async (run, idx) => {
          try {
            const assets = await apiGet(`/api/runs/${run.run_id}/paper/assets`);
            if (!assets.pdf_url) {
              return null;
            }
            return {
              run_id: run.run_id,
              viewed_at: Date.now() - idx,
              has_pdf: Boolean(assets.has_pdf),
              has_markdown: Boolean(assets.has_markdown),
              open_url: assets.pdf_url,
              from_assets: true,
            };
          } catch {
            return null;
          }
        })
      );

      if (cancelled) {
        return;
      }

      const discovered = checks.filter(Boolean);
      if (discovered.length === 0) {
        return;
      }

      setLibraryItems((prev) => {
        const merged = new Map(prev.filter(isViewerEntry).map((item) => [item.run_id, item]));
        for (const item of discovered) {
          if (!merged.has(item.run_id)) {
            merged.set(item.run_id, item);
          }
        }
        return Array.from(merged.values()).sort((a, b) => (b.viewed_at || 0) - (a.viewed_at || 0)).slice(0, 60);
      });
    };

    seedLibraryFromRuns();
    return () => {
      cancelled = true;
    };
  }, [runs, storageReady]);

  useEffect(() => {
    if (!selectedRunId) {
      setPaperAssets(null);
      setPaperError("");
      setPaperMarkdown("");
      setPaperMarkdownLoading(false);
      setPaperMarkdownError("");
      setPdfFrameLoaded(false);
      setLoadedPdfFrameKey("");
      return;
    }

    if (isCompletedLibraryRunSelected && paperAssets?.pdf_url) {
      setPaperLoading(false);
      setPaperError("");
      return;
    }

    const loadPaperAssets = async () => {
      try {
        setPaperLoading(true);
        setPaperError("");
        const data = await apiGet(`/api/runs/${selectedRunId}/paper/assets`);
        setPaperAssets(data);
        if (data?.pdf_url) {
          setPaperPdfUrlCache((prev) => ({ ...prev, [selectedRunId]: data.pdf_url }));
        }
      } catch (err) {
        setPaperError(err instanceof Error ? err.message : String(err));
      } finally {
        setPaperLoading(false);
      }
    };

    loadPaperAssets();
  }, [selectedRunId, paperAssetsReloadToken, paperAssets?.pdf_url, isCompletedLibraryRunSelected]);

  useEffect(() => {
    if (!paperPdfViewerUrl) {
      setPdfFrameLoaded(false);
      return;
    }
    if (pdfFrameReadyKey && loadedPdfFrameKey === pdfFrameReadyKey) {
      setPdfFrameLoaded(true);
      return;
    }
    setPdfFrameLoaded(false);
  }, [paperPdfViewerUrl, pdfFrameReadyKey, loadedPdfFrameKey]);

  useEffect(() => {
    if (!paperAssets?.markdown_url || paperAssets?.pdf_url) {
      setPaperMarkdown("");
      setPaperMarkdownLoading(false);
      setPaperMarkdownError("");
      return;
    }

    let cancelled = false;

    const loadPaperMarkdown = async () => {
      try {
        setPaperMarkdownLoading(true);
        setPaperMarkdownError("");
        const response = await fetch(buildApiUrl(paperAssets.markdown_url), {
          method: "GET",
          headers: { Accept: "text/plain" },
          cache: "no-store",
        });
        const text = await response.text();
        if (!response.ok) {
          throw new Error(text || response.statusText || "Failed to load markdown");
        }
        if (!cancelled) {
          setPaperMarkdown(text);
        }
      } catch (err) {
        if (!cancelled) {
          setPaperMarkdown("");
          setPaperMarkdownError(err instanceof Error ? err.message : String(err));
        }
      } finally {
        if (!cancelled) {
          setPaperMarkdownLoading(false);
        }
      }
    };

    loadPaperMarkdown();
    return () => {
      cancelled = true;
    };
  }, [paperAssets]);

  useEffect(() => {
    if (!selectedRunId || !paperAssets || paperLoading || paperError) {
      return;
    }
    if (!paperAssets.pdf_url) {
      return;
    }
    const entry = {
      run_id: selectedRunId,
      viewed_at: Date.now(),
      has_pdf: Boolean(paperAssets.has_pdf),
      has_markdown: Boolean(paperAssets.has_markdown),
      open_url: paperAssets.pdf_url,
      from_assets: false,
    };
    setLibraryItems((prev) => [entry, ...prev.filter((item) => item.run_id !== entry.run_id)].slice(0, 60));
  }, [selectedRunId, paperAssets, paperLoading, paperError]);

  useEffect(() => {
    if (isCompletedLibraryRunSelected) {
      return;
    }
    if (!activeRunId || !storageReady || showLibrary) {
      return;
    }

    if (autoOpenedPdfRunRef.current === activeRunId) {
      return;
    }

    let cancelled = false;
    let timer = null;

    const openPdfIfReady = async () => {
      if (autoOpenedPdfRunRef.current === activeRunId) {
        if (timer) {
          clearInterval(timer);
          timer = null;
        }
        return;
      }
      try {
        const assets = await apiGet(`/api/runs/${activeRunId}/paper/assets`);
        if (cancelled || !assets?.pdf_url) {
          return;
        }
        autoOpenedPdfRunRef.current = activeRunId;
        forceBlankSessionRef.current = false;
        setSuppressAutoSelect(true);
        setIsBlankSession(false);
        setSelectedRunId(activeRunId);
        setPaperAssets(assets);
        setPaperPdfUrlCache((prev) => ({ ...prev, [activeRunId]: assets.pdf_url }));
        setPaperLoading(false);
        setPdfFrameLoaded(false);
        if (timer) {
          clearInterval(timer);
          timer = null;
        }
      } catch {
        // Keep session view active if PDF is not yet ready.
      }
    };

    openPdfIfReady();
    timer = setInterval(openPdfIfReady, 4000);
    return () => {
      cancelled = true;
      if (timer) {
        clearInterval(timer);
      }
    };
  }, [activeRunId, storageReady, showLibrary, isCompletedLibraryRunSelected]);

  useEffect(() => {
    if (isCompletedLibraryRunSelected) {
      return;
    }
    if (!activeRunId || !hasCompletedAllStages || showLibrary) {
      return;
    }

    if (finalPaperRefreshRunRef.current === activeRunId) {
      return;
    }

    if (
      selectedRunId === activeRunId
      && (paperAssets?.pdf_url || paperPdfUrlCache[activeRunId] || isPdfFrameReady)
    ) {
      finalPaperRefreshRunRef.current = activeRunId;
      setPaperLoading(false);
      return;
    }

    finalPaperRefreshRunRef.current = activeRunId;
    forceBlankSessionRef.current = false;
    setSuppressAutoSelect(true);
    setIsBlankSession(false);
    setPaperAssets(null);
    setPaperError("");
    setPaperLoading(true);
    setPdfFrameLoaded(false);
    setPaperPdfUrlCache((prev) => ({
      ...prev,
      [activeRunId]: prev[activeRunId] || `/api/runs/${activeRunId}/paper/pdf`,
    }));
    setSelectedRunId(activeRunId);
    setPaperAssetsReloadToken((prev) => prev + 1);
  }, [activeRunId, hasCompletedAllStages, showLibrary, selectedRunId, paperAssets?.pdf_url, paperPdfUrlCache, isPdfFrameReady, isCompletedLibraryRunSelected]);

  useEffect(() => {
    let disposed = false;
    let pingTimer = null;

    const clearPingTimer = () => {
      if (pingTimer) {
        clearInterval(pingTimer);
        pingTimer = null;
      }
    };

    const scheduleReconnect = () => {
      if (disposed) {
        return;
      }
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
      }
      const delayMs = Math.min(1000 * (2 ** Math.min(reconnectAttemptRef.current, 4)), 10000);
      reconnectAttemptRef.current += 1;
      setWsState("reconnecting");
      reconnectTimerRef.current = setTimeout(() => {
        reconnectTimerRef.current = null;
        connect();
      }, delayMs);
    };

    const connect = () => {
      if (disposed) {
        return;
      }

      const ws = new WebSocket(wsUrl);
      socketRef.current = ws;
      setWsState(reconnectAttemptRef.current > 0 ? "reconnecting" : "connecting");

      ws.onopen = () => {
        reconnectAttemptRef.current = 0;
        setWsState("connected");
        appendEvent("client.connected", { wsUrl });
        ws.send(JSON.stringify({ type: "ping" }));
      };

      ws.onmessage = (evt) => {
        let parsed;
        try {
          parsed = JSON.parse(evt.data);
        } catch {
          parsed = evt.data;
        }

        if (
          parsed &&
          typeof parsed === "object" &&
          parsed.type === "stage_start" &&
          parsed.data?.run_id &&
          parsed.data?.stage
        ) {
          setLiveStageByRun((prev) => ({
            ...prev,
            [parsed.data.run_id]: parsed.data.stage,
          }));
        }

        appendEvent("server.event", parsed);
      };

      ws.onclose = () => {
        clearPingTimer();
        if (socketRef.current === ws) {
          socketRef.current = null;
        }
        if (disposed) {
          setWsState("disconnected");
          return;
        }
        appendEvent("client.disconnected", { wsUrl });
        scheduleReconnect();
      };

      ws.onerror = () => {
        setWsState("error");
        appendEvent("client.error", { wsUrl });
      };

      pingTimer = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: "ping" }));
        }
      }, 12000);
    };

    connect();

    return () => {
      disposed = true;
      clearPingTimer();
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      reconnectAttemptRef.current = 0;
      const ws = socketRef.current;
      socketRef.current = null;
      if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        ws.close();
      }
    };
  }, [wsUrl]);

  useEffect(() => {
    if (!activeRunId) {
      setRunProgress(null);
      return;
    }

    let cancelled = false;

    const loadRunProgress = async () => {
      try {
        const data = await apiGet(`/api/runs/${activeRunId}`);
        if (!cancelled) {
          setRunProgress(data);
        }
      } catch {
        if (!cancelled) {
          setRunProgress(null);
        }
      }
    };

    loadRunProgress();
    const timer = setInterval(loadRunProgress, isPipelineRunning ? 5000 : 12000);

    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [activeRunId, isPipelineRunning]);

  useEffect(() => {
    if (!activeRunId || !runProgress) {
      return;
    }

    const progressedStage =
      runProgress?.hitl?.waiting?.stage_name
      || (isPipelineRunning ? runProgress?.heartbeat?.last_stage_name : null)
      || runProgress?.next_stage_name
      || runProgress?.checkpoint?.last_completed_name
      || null;

    if (!progressedStage || !STAGE_INFO[progressedStage]) {
      return;
    }

    setLiveStageByRun((prev) => {
      if (prev[activeRunId] === progressedStage) {
        return prev;
      }
      return {
        ...prev,
        [activeRunId]: progressedStage,
      };
    });
  }, [activeRunId, runProgress, isPipelineRunning]);

  useEffect(() => {
    if (!activeRunId) {
      setHitlStatus(null);
      setHitlMessage("");
      return;
    }

    let cancelled = false;

    const loadHitlStatus = async () => {
      try {
        const data = await apiGet(`/api/runs/${activeRunId}/hitl/status`);
        if (!cancelled) {
          setHitlStatus(data);
        }
      } catch {
        if (!cancelled) {
          setHitlStatus(null);
        }
      }
    };

    loadHitlStatus();
    const timer = setInterval(loadHitlStatus, hitlStatus?.waiting ? 2000 : 5000);

    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [activeRunId, hitlStatus?.waiting]);

  const submitHitlResponse = async (action, overrideMessage = null, responseOverride = null) => {
    if (!activeRunId) {
      return false;
    }
    const targetResponse = responseOverride || currentHitlResponse;
    const requestMessage = overrideMessage ?? hitlMessage;
    const shouldLockQuery = action === "approve" || action === "regenerate";
    const currentStageNum = Number(targetResponse?.stage || hitlWaiting?.stage || 0);
    const optimisticStageNum = action === "approve"
      ? currentStageNum + 1
      : action === "regenerate"
        ? currentStageNum
        : 0;
    const optimisticStageName = optimisticStageNum > 0 ? STAGE_NAME_BY_NUM[optimisticStageNum] || null : null;
    try {
      if (shouldLockQuery) {
        hitlLockedResponseKeyRef.current = targetResponse?.key || currentHitlResponse?.key || "";
        hitlResponseClearedAfterLockRef.current = false;
        setHitlQueryLocked(true);
        if (targetResponse?.key) {
          setOpenedPreservedResponses((prev) =>
            prev.map((item) => item.key === targetResponse.key ? { ...item, isCurrent: false } : item)
          );
        }
      }
      setHitlBusy(true);
      setError("");
      await apiPost(`/api/runs/${activeRunId}/hitl/respond`, {
        action,
        message: requestMessage,
        guidance: action === "inject" || action === "regenerate" ? requestMessage : "",
        stage: targetResponse?.stage || hitlWaiting?.stage,
        source_type: sourceType,
      });
      if (shouldLockQuery) {
        if (optimisticStageName) {
          setLiveStageByRun((prev) => ({
            ...prev,
            [activeRunId]: optimisticStageName,
          }));
        }
        setHitlStatus((prev) => (prev ? { ...prev, waiting: null } : prev));
        setStatus((prev) => ({
          ...(prev || {}),
          run_id: activeRunId,
          status: "running",
        }));
      }
      if (action !== "inject") {
        setHitlMessage("");
      }
      const [updatedHitlStatus, updatedRunProgress] = await Promise.all([
        apiGet(`/api/runs/${activeRunId}/hitl/status`).catch(() => null),
        apiGet(`/api/runs/${activeRunId}`).catch(() => null),
      ]);
      setHitlStatus(updatedHitlStatus);
      if (updatedRunProgress) {
        setRunProgress(updatedRunProgress);
      }
      await refreshAll();
      return true;
    } catch (err) {
      if (shouldLockQuery) {
        hitlLockedResponseKeyRef.current = "";
        hitlResponseClearedAfterLockRef.current = false;
        setHitlQueryLocked(false);
      }
      setError(err instanceof Error ? err.message : String(err));
      return false;
    } finally {
      setHitlBusy(false);
    }
  };

  const startPipeline = async (event) => {
    event.preventDefault();
    const submittedTopic = (topic || "").trim();
    if (!submittedTopic) {
      return;
    }
    forceBlankSessionRef.current = false;
    completedLibraryPdfRunRef.current = "";
    setLoadedPdfFrameKey("");
    setShowLibrary(false);
    setSuppressAutoSelect(true);
    setIsBlankSession(true);
    setSessionHeading(submittedTopic || "Research Session");
    setTopic("");
    try {
      setBusy(true);
      setError("");
      const payload = {
        topic: submittedTopic || undefined,
        auto_approve: researchMode !== "CoPilot",
        mode: researchMode === "CoPilot" ? "co-pilot" : AUTOPILOT_STAGE_MODE,
        source_type: sourceType,
      };
      const result = await apiPost("/api/pipeline/start", payload);
      setStatus({
        ...(result || {}),
        status: result?.status || "running",
        topic: submittedTopic,
        source_type: sourceType,
        mode: researchMode === "CoPilot" ? "co-pilot" : AUTOPILOT_STAGE_MODE,
        from_stage: 1,
      });
      if (result?.run_id) {
        setActiveRunId(result.run_id);
      }
      setOpenedPreservedResponses([]);
      setLibraryContinueRequired({});
      appendEvent("pipeline.start", result);
      await refreshAll();
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      setError(errMsg);
      setStatus((prev) => (prev ? { ...prev, status: "failed", error: errMsg } : { status: "failed", error: errMsg }));
    } finally {
      setBusy(false);
    }
  };

  const stopPipeline = async () => {
    try {
      setBusy(true);
      setError("");
      const result = await apiPost("/api/pipeline/stop", {});
      setStatus((prev) => (prev ? { ...prev, status: "stopping" } : { status: "stopping" }));
      appendEvent("pipeline.stop", result);
      await refreshAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  const clearToBlankNewSession = async ({ terminateCurrent = false } = {}) => {
    forceBlankSessionRef.current = true;
    if (terminateCurrent) {
      await terminateCurrentSessionGracefully();
    }

    setShowLibrary(false);
    setSuppressAutoSelect(true);
    setIsBlankSession(true);
    setSessionHeading("");
    setTopic("");
    setEvents([]);
    setError("");
    setPaperError("");
    setSelectedRunId("");
    setPaperAssets(null);
    setPaperMarkdown("");
    setPaperMarkdownLoading(false);
    setPaperMarkdownError("");
    setActiveRunId("");
    setRunProgress(null);
    setStatus({ status: "idle" });
    setHitlStatus(null);
    setOpenedPreservedResponses([]);
    setLibraryContinueRequired({});
    setHitlMessage("");
    autoOpenedPdfRunRef.current = "";
    finalPaperRefreshRunRef.current = "";
    completedLibraryPdfRunRef.current = "";
    setLoadedPdfFrameKey("");
    await refreshAll();
  };

  const startNewSession = async () => {
    if (hasCurrentRunningSession()) {
      setPendingNewSessionConfirm(true);
      return;
    }
    await clearToBlankNewSession();
  };

  const cancelNewSessionConfirm = () => {
    setPendingNewSessionConfirm(false);
  };

  const terminateAndStartNewSession = async () => {
    setPendingNewSessionConfirm(false);
    await clearToBlankNewSession({ terminateCurrent: true });
  };

  const showingMarkdownPreview = Boolean(paperAssets?.markdown_url && !effectivePaperPdfUrl);
  const isPreparingPdf = Boolean(
    selectedRunId
    && !isBlankSession
    && !paperError
    && !isPdfFrameReady
    && (
      paperLoading
      || (!paperAssets && !paperError)
      || effectivePaperPdfUrl
    )
  );

  return (
    <main className="shell">
      <div className={`dashboard-layout ${isSidebarCollapsed ? "sidebar-hidden" : ""}`}>
        {isSidebarCollapsed ? (
          <button
            type="button"
            className="sidebar-reveal"
            aria-label="Show sidebar"
            onClick={() => setIsSidebarCollapsed(false)}
          >
            &gt;
          </button>
        ) : null}
        {!isSidebarCollapsed ? (
          <>
            <aside className="sidebar">
              <div className="sidebar-topbar">
                <button
                  type="button"
                  className="sidebar-toggle"
                  aria-label="Hide sidebar"
                  onClick={() => setIsSidebarCollapsed((prev) => !prev)}
                >
                  {"<"}
                </button>
              </div>
              <div className="sidebar-content">
                <section className="hero sidebar-hero">
                  <p className="sidebar-live-row">
                    <span className={`pill pill-${wsState}`}>{wsState}</span>
                  </p>
                  <div className="session-tabs">
                    <button
                      type="button"
                      className={`session-tab ${showLibrary ? "active" : ""}`}
                      onClick={() => setShowLibrary((prev) => !prev)}
                    >
                      <span className="session-tab-icon" aria-hidden="true">
                        <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M2.75 5.5h12.5" />
                          <path d="M4.25 5.5V4.25A1.5 1.5 0 0 1 5.75 2.75h2l1.25 1.5h3.25a1.5 1.5 0 0 1 1.5 1.5V13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5.5Z" />
                        </svg>
                      </span>
                      <span>{showLibrary ? "Back to Session" : "My Library"}</span>
                    </button>
                    <button type="button" className="session-tab" onClick={startNewSession}>
                      <span className="session-tab-icon" aria-hidden="true">
                        <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M9 3.5v11" />
                          <path d="M3.5 9h11" />
                        </svg>
                      </span>
                      <span>New Session</span>
                    </button>
                  </div>
                </section>
              </div>
            </aside>
            <div className="vertical-divider" />
          </>
        ) : null}
        <section className="viewer-main" ref={viewerMainRef}>
          {!storageReady ? <div className="empty-session" /> : null}
          {storageReady && showLibrary ? (
            <>
              <h2>My Library</h2>
              <p className="muted">Browse each research folder, inspect its artifacts, and reopen or manage runs directly.</p>
              {libraryError ? <p className="error">Library error: {libraryError}</p> : null}
              <ul className="library-list">
                {libraryLoading ? (
                  <li className="library-folder-card muted">Loading research folders...</li>
                ) : null}
                {!libraryLoading && libraryRuns.length === 0 ? (
                  <li className="library-folder-card muted">No research folders found in artifacts yet.</li>
                ) : null}
                {libraryRuns.map((item) => {
                  const rootKey = artifactNodeKey(item.run_id, "");
                  const rootEntries = libraryTreeNodes[rootKey] || [];
                  const folderDisplayName = displayLibraryName(item.folder_name);
                  const openActionLabel = item.is_complete ? "Open" : "Continue";
                  const pdfActionLabel = item.is_complete ? "Completed PDF" : "PDF";
                  const pdfActionUrl = item.is_complete ? stablePaperPdfUrl(item.pdf_url) : item.pdf_url;
                  const runBusy = Boolean(
                    libraryActionBusy[`open:${item.run_id}`]
                    || libraryActionBusy[`rename:${item.run_id}`]
                    || libraryActionBusy[`delete:${item.run_id}`]
                  );

                  return (
                    <li className="library-folder-card" key={item.run_id}>
                      <div className="library-folder-header">
                        <button
                          type="button"
                          className="library-entry-toggle"
                          onClick={() => toggleLibraryRun(item.run_id)}
                        >
                          <span className="library-folder-caret" aria-hidden="true">
                            {expandedLibraryRuns[item.run_id] ? <ChevronDown strokeWidth={1.8} /> : <ChevronRight strokeWidth={1.8} />}
                          </span>
                          <span className="library-folder-icon" aria-hidden="true">
                            {expandedLibraryRuns[item.run_id] ? <FolderOpen strokeWidth={1.8} /> : <Folder strokeWidth={1.8} />}
                          </span>
                          <span className="library-folder-title-wrap">
                            <span className="library-folder-title">{folderDisplayName}</span>
                            {folderDisplayName !== item.topic ? (
                              <span className="library-folder-subtitle">Topic: {item.topic}</span>
                            ) : null}
                          </span>
                        </button>
                        <span className="library-mode-badge">{item.mode_label}</span>
                      </div>
                      <p className="library-meta">
                        Generated {formatDateTime(item.generated_at)} · Last edited {formatDateTime(item.last_edited_at)}
                        {item.is_complete ? " · All stages complete" : item.resume_stage_name ? ` · Next stage: ${item.resume_stage_name}` : ""}
                      </p>
                      <div className="library-actions">
                        <button
                          type="button"
                          className="library-action"
                          disabled={runBusy}
                          onClick={() => handleRenameLibraryRun(item)}
                        >
                          <PencilLine strokeWidth={1.8} />
                          <span>Rename</span>
                        </button>
                        <button
                          type="button"
                          className="library-action"
                          disabled={runBusy}
                          onClick={() => handleOpenLibraryRun(item)}
                        >
                          <Play strokeWidth={1.8} />
                          <span>{openActionLabel}</span>
                        </button>
                        <button
                          type="button"
                          className="library-action library-action-danger"
                          disabled={runBusy}
                          onClick={() => handleDeleteLibraryRun(item)}
                        >
                          <Trash2 strokeWidth={1.8} />
                          <span>Delete</span>
                        </button>
                        {pdfActionUrl ? (
                          <a className="library-action" href={buildApiUrl(pdfActionUrl)} target="_blank" rel="noreferrer">
                            <File strokeWidth={1.8} />
                            <span>{pdfActionLabel}</span>
                          </a>
                        ) : (
                          <span className="library-action library-action-disabled">
                            <File strokeWidth={1.8} />
                            <span>{pdfActionLabel}</span>
                          </span>
                        )}
                      </div>
                      {expandedLibraryRuns[item.run_id] ? (
                        <div className="library-tree-shell">
                          {libraryTreeLoading[rootKey] ? <p className="artifact-tree-empty">Loading folder contents...</p> : null}
                          {!libraryTreeLoading[rootKey] && rootEntries.length === 0 ? (
                            <p className="artifact-tree-empty">No artifacts found inside this run folder.</p>
                          ) : null}
                          {!libraryTreeLoading[rootKey]
                            ? rootEntries.map((entry) => (
                                <ArtifactTreeNode
                                  key={entry.path}
                                  runId={item.run_id}
                                  entry={entry}
                                  depth={0}
                                  expandedNodes={expandedLibraryNodes}
                                  treeNodes={libraryTreeNodes}
                                  treeLoading={libraryTreeLoading}
                                  onToggleFolder={toggleLibraryFolder}
                                />
                              ))
                            : null}
                        </div>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
            </>
          ) : storageReady && selectedRunId && !isBlankSession ? (
            <div className="paper-viewer-focus">
              {isPreparingPdf && !effectivePaperPdfUrl ? (
                <div className="pdf-preparing">
                  <span>Preparing PDF</span>
                  <span className="blink-dots" aria-hidden="true">
                    <span>.</span><span>.</span><span>.</span>
                  </span>
                </div>
              ) : null}
              {paperError ? <p className="error">Paper viewer error: {paperError}</p> : null}
              {paperMarkdownLoading ? <p className="muted">Loading final markdown preview...</p> : null}
              {paperMarkdownError ? <p className="error">Markdown preview error: {paperMarkdownError}</p> : null}

              {effectivePaperPdfUrl ? (
                <div className="pdf-shell">
                  {isPreparingPdf ? (
                    <div className="pdf-preparing pdf-preparing-overlay">
                      <span>Preparing PDF</span>
                      <span className="blink-dots" aria-hidden="true">
                        <span>.</span><span>.</span><span>.</span>
                      </span>
                    </div>
                  ) : null}
                  <iframe
                    title="Final paper PDF"
                    src={paperPdfViewerUrl}
                    className={`pdf-frame ${isPdfFrameReady ? "pdf-frame-ready" : "pdf-frame-loading"}`}
                    onLoad={() => {
                      if (pdfFrameReadyKey) {
                        setLoadedPdfFrameKey(pdfFrameReadyKey);
                      }
                      setPdfFrameLoaded(true);
                    }}
                  />
                </div>
              ) : null}

              {showingMarkdownPreview && paperMarkdown ? (
                <div className="markdown-shell">
                  <pre className="markdown-frame">{paperMarkdown}</pre>
                </div>
              ) : null}

              {paperAssets && !effectivePaperPdfUrl && !paperAssets.markdown_url && !paperLoading && !isPdfFrameReady ? (
                <p className="muted">
                  No compiled PDF found for this run yet. You can still open markdown/tex artifacts when
                  available.
                </p>
              ) : null}
            </div>
          ) : storageReady && isBlankSession ? (
            <div className={`empty-session ${composerDocked ? "empty-session-active" : ""}`}>
              <div className="landing-mode-bar">
                <div className="mode-dropdown">
                  <select
                    id="research-mode"
                    className="mode-select"
                    value={researchMode}
                    onChange={(event) => setResearchMode(event.target.value)}
                    disabled={isPipelineRunning}
                  >
                    {MODE_OPTIONS.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                  <svg className="mode-chevron" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
                    <path d="m4 6 4 4 4-4" />
                  </svg>
                </div>
              </div>

              {showLandingState ? (
                <div className="landing-intro">
                  <ResearchSignal />
                  <h1 className="session-heading">{landingHeading}</h1>
                  <QueryComposer
                    docked={false}
                    topic={topic}
                    onTopicChange={setTopic}
                    startPipeline={startPipeline}
                    isPipelineRunning={isPipelineRunning}
                    busy={busy}
                    sourceType={sourceType}
                    onSourceTypeChange={setSourceType}
                    error={error}
                    onStop={stopPipeline}
                    onRefresh={refreshAll}
                  />
                </div>
              ) : (
                <div className="session-status-view">
                  <h1 className="session-heading">{headingText}</h1>
                  <p className="landing-copy session-copy">
                    {isPipelineRunning
                      ? isHumanInLoopMode
                        ? "ResearchClaw is actively moving through the pipeline."
                        : "ResearchClaw is running the current AutoPilot stage. Continue will appear when the stage is ready."
                      : isHumanInLoopMode
                        ? "The last session is preserved here. You can inspect runs from the library or continue through CoPilot stage reviews."
                        : "Review AutoPilot stage history here. Use Continue under the latest stage to proceed."}
                  </p>
                  {visibleHitlResponses.length > 0 ? (
                    <div className="copilot-history">
                      {visibleHitlResponses.map((response) => {
                        const actionState = hitlResponseActions[response.key] || createHitlResponseActionState();
                        const isLockedResponse = hitlQueryLocked && hitlLockedResponseKeyRef.current === response.key;
                        const showAutoPilotContinue = isAutoPilotMode && (response.isCurrent || isLockedResponse);
                        const showCoPilotLibraryContinue = isHumanInLoopMode && Boolean(libraryContinueRequired[response.key]) && (response.isCurrent || isLockedResponse);
                        const canSubmitPositive = Object.values(actionState.positiveReasons || {}).some(Boolean) || actionState.positiveOther.trim();
                        const canSubmitNegative = Object.values(actionState.negativeReasons || {}).some(Boolean) || actionState.negativeOther.trim();
                        return (
                          <div className={`copilot-panel ${response.isCurrent ? "copilot-panel-current" : "copilot-panel-archived"}`} key={response.key}>
                            <div className="copilot-panel-topbar">
                              <h3>{response.title}</h3>
                              {response.isCurrent ? <span className="copilot-current-badge">Current</span> : null}
                            </div>
                            <div className="copilot-review-grid">
                              <div className="copilot-review-block">
                                <p className="copilot-review-label">Completion status</p>
                                <p className="copilot-review-text">{response.status}</p>
                              </div>
                              <div className="copilot-review-block">
                                <p className="copilot-review-label">Pause reason</p>
                                <p className="copilot-review-text">{response.reason}</p>
                              </div>
                            </div>
                            <div className="copilot-review-block copilot-review-block-full">
                              <p className="copilot-review-label">Plain-English summary</p>
                              <p className="copilot-summary">{response.overview}</p>
                            </div>
                            {response.outputs?.length ? (
                              <div className="copilot-review-block copilot-review-block-full">
                                <p className="copilot-review-label">Key outputs</p>
                                <div className="copilot-review-stack">
                                  {response.outputs.map((item) => (
                                    <div className="copilot-review-item" key={`${response.key}:${item.label}:${item.text}`}>
                                      <p className="copilot-review-item-label">{item.label}</p>
                                      <p className="copilot-review-item-text">{item.text}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ) : null}
                            {response.warnings?.length ? (
                              <div className="copilot-review-block copilot-review-block-full">
                                <p className="copilot-review-label">Warnings</p>
                                <div className="copilot-review-stack">
                                  {response.warnings.map((warning) => (
                                    <p className="copilot-review-note copilot-review-warning" key={`${response.key}:${warning}`}>{warning}</p>
                                  ))}
                                </div>
                              </div>
                            ) : null}
                            {response.recommendations?.length ? (
                              <div className="copilot-review-block copilot-review-block-full">
                                <p className="copilot-review-label">Recommendations</p>
                                <div className="copilot-review-stack">
                                  {response.recommendations.map((recommendation) => (
                                    <p className="copilot-review-note copilot-review-recommendation" key={`${response.key}:${recommendation}`}>{recommendation}</p>
                                  ))}
                                </div>
                              </div>
                            ) : null}

                            {showCoPilotLibraryContinue ? (
                              <div className="copilot-reaction-bar copilot-library-continue-bar" aria-label="CoPilot continuation">
                                {actionState.confirmingContinue ? (
                                  <>
                                    <span className="copilot-continue-question">Continue?</span>
                                    <button
                                      type="button"
                                      className="copilot-continue-confirm"
                                      disabled={!response.isCurrent || hitlBusy || hitlQueryLocked}
                                      onClick={() => handleLibraryContinueConfirm(response)}
                                    >
                                      Yes
                                    </button>
                                    <button
                                      type="button"
                                      className="copilot-continue-cancel"
                                      disabled={hitlBusy}
                                      onClick={() => handleLibraryContinueCancel(response)}
                                    >
                                      No
                                    </button>
                                  </>
                                ) : (
                                  <button
                                    type="button"
                                    className="autopilot-continue-button"
                                    disabled={!response.isCurrent || hitlBusy || hitlQueryLocked}
                                    onClick={() => handleLibraryContinuePrompt(response)}
                                  >
                                    {hitlBusy || hitlQueryLocked ? "Continuing..." : "Continue"}
                                  </button>
                                )}
                                <div className="copilot-reaction-source">
                                  <HitlSourcePicker
                                    value={sourceType}
                                    onChange={setSourceType}
                                    disabled={!response.isCurrent || hitlBusy || hitlQueryLocked}
                                  />
                                </div>
                              </div>
                            ) : isHumanInLoopMode ? (
                              <div className="copilot-reaction-bar" aria-label="Response actions">
                                <button
                                  type="button"
                                  className={`copilot-reaction-button ${actionState.vote === "up" ? "active-up" : ""}`}
                                  onClick={() => handleHitlVote(response.key, "up")}
                                  title="Thumbs up"
                                >
                                  👍
                                </button>
                                <button
                                  type="button"
                                  className={`copilot-reaction-button ${actionState.vote === "down" ? "active-down" : ""}`}
                                  onClick={() => handleHitlVote(response.key, "down")}
                                  title="Thumbs down"
                                >
                                  👎
                                </button>
                                <button
                                  type="button"
                                  className="copilot-reaction-button"
                                  onClick={() => handleHitlRegenerateRequest(response)}
                                  title="Regenerate"
                                  disabled={!response.isCurrent || hitlBusy}
                                >
                                  🔄
                                </button>
                                <button
                                  type="button"
                                  className={`copilot-reaction-button ${actionState.editing ? "active-note" : ""}`}
                                  onClick={() => handleHitlCommentToggle(response.key)}
                                  title="Note"
                                >
                                  📝
                                </button>
                                {response.isCurrent ? (
                                  <button
                                    type="button"
                                    className="copilot-reaction-approve"
                                    disabled={hitlBusy}
                                    onClick={() => submitHitlResponse("approve", buildHitlApproveRequest(response, actionState, ""), response)}
                                  >
                                    {hitlBusy ? "Sending..." : "Approve"}
                                  </button>
                                ) : null}
                                <div className="copilot-reaction-source">
                                  <HitlSourcePicker
                                    value={sourceType}
                                    onChange={setSourceType}
                                    disabled={!response.isCurrent || hitlBusy || hitlQueryLocked}
                                  />
                                </div>
                              </div>
                            ) : showAutoPilotContinue ? (
                              <div className="copilot-reaction-bar autopilot-continue-bar" aria-label="AutoPilot continuation">
                                <button
                                  type="button"
                                  className="autopilot-continue-button"
                                  disabled={!response.isCurrent || hitlBusy || hitlQueryLocked}
                                  onClick={() => submitHitlResponse("approve", "", response)}
                                >
                                  {hitlBusy || hitlQueryLocked ? "Continuing..." : "Continue"}
                                </button>
                                <div className="copilot-reaction-source">
                                  <HitlSourcePicker
                                    value={sourceType}
                                    onChange={setSourceType}
                                    disabled={!response.isCurrent || hitlBusy || hitlQueryLocked}
                                  />
                                </div>
                              </div>
                            ) : null}

                            {isHumanInLoopMode && actionState.vote === "up" && actionState.feedbackPanelVisible ? (
                              <div className="copilot-feedback-panel">
                                <div className="copilot-feedback-title">What did you like about this response?</div>
                                <div className="copilot-feedback-options">
                                  {HITL_POSITIVE_REASON_OPTIONS.map((option) => (
                                    <label className="copilot-feedback-option" key={`${response.key}:${option.id}`}>
                                      <input
                                        type="checkbox"
                                        checked={Boolean(actionState.positiveReasons?.[option.id])}
                                        onChange={() => handleHitlPositiveReasonToggle(response.key, option.id)}
                                      />
                                      <span>{option.label}</span>
                                    </label>
                                  ))}
                                  <label className="copilot-feedback-option copilot-feedback-other">
                                    <span>Other:</span>
                                    <input
                                      type="text"
                                      value={actionState.positiveOther || ""}
                                      onChange={(event) => updateHitlResponseAction(response.key, { positiveOther: event.target.value, vote: "up", feedbackPanelVisible: true })}
                                      placeholder="Add your note"
                                    />
                                  </label>
                                </div>
                                <div className="copilot-feedback-actions">
                                  <button type="button" disabled={!canSubmitPositive} onClick={() => handleHitlPositiveSubmit(response)}>
                                    Submit
                                  </button>
                                </div>
                              </div>
                            ) : null}

                            {isHumanInLoopMode && actionState.vote === "down" && actionState.feedbackPanelVisible ? (
                              <div className="copilot-feedback-panel copilot-feedback-panel-negative">
                                <div className="copilot-feedback-title">What went wrong?</div>
                                <div className="copilot-feedback-options">
                                  {HITL_NEGATIVE_REASON_OPTIONS.map((option) => (
                                    <label className="copilot-feedback-option" key={`${response.key}:${option.id}`}>
                                      <input
                                        type="checkbox"
                                        checked={Boolean(actionState.negativeReasons?.[option.id])}
                                        onChange={() => handleHitlNegativeReasonToggle(response.key, option.id)}
                                      />
                                      <span>{option.label}</span>
                                    </label>
                                  ))}
                                  <label className="copilot-feedback-option copilot-feedback-other">
                                    <span>Other:</span>
                                    <input
                                      type="text"
                                      value={actionState.negativeOther || ""}
                                      onChange={(event) => updateHitlResponseAction(response.key, { negativeOther: event.target.value, vote: "down", feedbackPanelVisible: true })}
                                      placeholder="Add your note"
                                    />
                                  </label>
                                </div>
                                <div className="copilot-feedback-actions">
                                  <button type="button" disabled={!canSubmitNegative} onClick={() => handleHitlNegativeSubmit(response)}>
                                    Submit
                                  </button>
                                </div>
                              </div>
                            ) : null}

                            {isHumanInLoopMode && actionState.editing ? (
                              <div className="copilot-comment-box">
                                <input
                                  type="text"
                                  value={actionState.draft || ""}
                                  onChange={(event) => handleHitlCommentChange(response.key, event.target.value)}
                                  placeholder="Add a note for this stage"
                                />
                                <button
                                  type="button"
                                  disabled={!actionState.noteTouched || !(actionState.draft || "").trim()}
                                  onClick={() => handleHitlCommentSave(response)}
                                >
                                  Submit
                                </button>
                              </div>
                            ) : null}

                            {actionState.lastPositiveNotes?.length ? (
                              <div className="copilot-feedback-notes">
                                {actionState.lastPositiveNotes.map((note) => (
                                  <p className="copilot-feedback-note copilot-feedback-note-positive" key={`${response.key}:positive:${note}`}>{note}</p>
                                ))}
                              </div>
                            ) : null}
                            {actionState.lastNegativeNotes?.length ? (
                              <div className="copilot-feedback-notes">
                                {actionState.lastNegativeNotes.map((note) => (
                                  <p className="copilot-feedback-note copilot-feedback-note-negative" key={`${response.key}:negative:${note}`}>{note}</p>
                                ))}
                              </div>
                            ) : null}
                            {actionState.lastRevisionRequest ? (
                              <p className="copilot-feedback-note copilot-feedback-note-neutral">Last regeneration request: {actionState.lastRevisionRequest}</p>
                            ) : null}

                          </div>
                        );
                      })}
                    </div>
                  ) : null}
                  {isPipelineRunning ? (
                    <p className="running-label">
                      Running research stages
                      <span className="blink-dots">
                        <span>.</span><span>.</span><span>.</span>
                      </span>
                    </p>
                  ) : null}
                  <div className="stage-update-card">
                    <div className="stage-update-header">
                      <span className="current-update-label">Current Update:</span>&nbsp;
                      {runStageMeta ? (
                        <strong>
                          Stage {runStageMeta.num} of {Object.keys(STAGE_INFO).length}
                          {" "}- {runStageMeta.label}
                        </strong>
                      ) : isPipelineRunning ? (
                        <strong>Stage 1 - Initializing pipeline...</strong>
                      ) : isPipelineWaiting ? (
                        <strong>Pipeline paused for review</strong>
                      ) : isPipelineStopping ? (
                        <strong>Stopping pipeline...</strong>
                      ) : isPipelineFailed ? (
                        <strong>Pipeline failed to start</strong>
                      ) : (
                        <strong>Session ready for the next research turn</strong>
                      )}
                    </div>
                    <div className="stage-update-desc">
                      {runStageMeta
                        ? runStageMeta.desc
                        : isPipelineRunning
                          ? STAGE_INFO.TOPIC_INIT.desc
                          : isPipelineWaiting
                            ? isAutoPilotMode
                              ? "AutoPilot is waiting for Continue before moving to the next stage."
                              : "The pipeline is waiting for human review or approval before continuing."
                            : isPipelineStopping
                              ? "The current run is being stopped."
                              : isPipelineFailed
                                ? (status?.error || error || "The pipeline failed before stage progress could be displayed. Check the backend log for details.")
                          : isHumanInLoopMode
                            ? "Select a run from the library to inspect its paper artifacts, or continue through CoPilot stage reviews."
                            : "Select a run from the library to inspect its paper artifacts, or start a fresh thread from New Session."}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </section>
      </div>

      <ConfirmOpenModal
        item={pendingLibraryOpenRun}
        onCancel={closePendingLibraryOpen}
        onContinue={continuePendingLibraryOpen}
      />
      <ConfirmNewSessionModal
        open={pendingNewSessionConfirm}
        onCancel={cancelNewSessionConfirm}
        onContinue={terminateAndStartNewSession}
      />

      {storageReady && composerDocked ? (
        <div
          className="query-overlay query-overlay-hitl"
          style={overlayBounds ? { left: `${overlayBounds.left}px`, width: `${overlayBounds.width}px` } : undefined}
        >
          <QueryComposer
            docked={true}
            topic={topic}
            onTopicChange={setTopic}
            startPipeline={startPipeline}
            isPipelineRunning={isPipelineRunning}
            busy={busy}
            sourceType={sourceType}
            onSourceTypeChange={setSourceType}
            error={error}
            onStop={stopPipeline}
            onRefresh={refreshAll}
          />
        </div>
      ) : null}
    </main>
  );
}
