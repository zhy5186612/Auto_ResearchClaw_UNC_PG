/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  reactStrictMode: true,
  async rewrites() {
    const backend = process.env.BACKEND_URL;
    if (!backend) return [];

    const cleanBackend = backend.replace(/\/+$/, "");
    return [
      {
        source: "/api/:path*",
        destination: `${cleanBackend}/api/:path*`,
      },
      {
        source: "/ws/:path*",
        destination: `${cleanBackend}/ws/:path*`,
      },
    ];
  },
};

export default nextConfig;
