import { rmSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const cacheDir = resolve(root, ".next");
const relativeTarget = relative(root, cacheDir);

if (!relativeTarget || relativeTarget.startsWith("..") || relativeTarget.includes(`..${sep}`)) {
  throw new Error(`Refusing to remove path outside frontend root: ${cacheDir}`);
}

rmSync(cacheDir, {
  recursive: true,
  force: true,
  maxRetries: 3,
  retryDelay: 200,
});
