"""ResearchClaw — Autonomous Research Pipeline."""

# Order matters: merge extra CA roots into a bundle and point SSL_CERT_FILE at
# it BEFORE anything creates an SSL context. ssl_compat's fallback then works
# against the merged bundle if the default context is broken.
from researchclaw.utils.ca_bootstrap import install as _install_ca_bootstrap
from researchclaw.utils.ssl_compat import install_default_https_context_fallback

_install_ca_bootstrap()
install_default_https_context_fallback()

__version__ = "0.3.1"
