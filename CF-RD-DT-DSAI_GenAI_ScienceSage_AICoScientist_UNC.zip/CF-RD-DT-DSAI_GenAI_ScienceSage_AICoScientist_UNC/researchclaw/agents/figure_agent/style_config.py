"""Academic chart styling configuration for FigureAgent.

Defines global constants for chart styling that conform to AI conference
publication standards (IEEE, NeurIPS, ICML, ICLR).  Used by CodeGen Agent
when generating matplotlib plotting scripts.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Style presets
# ---------------------------------------------------------------------------

# SciencePlots style list — CodeGen Agent inserts this into generated scripts.
# Fallback: seaborn-v0_8-whitegrid if SciencePlots is not installed.
MATPLOTLIB_STYLES = ["science", "ieee"]
MATPLOTLIB_STYLES_FALLBACK = ["seaborn-v0_8-whitegrid"]

# Output resolution (DPI) — 300+ for publication, 150 for draft
DPI_PUBLICATION = 300
DPI_DRAFT = 150

# ---------------------------------------------------------------------------
# Font sizes (points) — width-aware to avoid oversized text in paper columns
# ---------------------------------------------------------------------------

# For single-column figures (≤3.5in) — fonts must be small to match 10pt body
FONT_SIZE_SINGLE_COL = {
    "title": 9,
    "axis_label": 8,
    "tick": 7,
    "legend": 7,
    "annotation": 7,
}

# For double-column / full-page figures (≥7.0in) — normal academic sizes
FONT_SIZE_DOUBLE_COL = {
    "title": 11,
    "axis_label": 10,
    "tick": 9,
    "legend": 9,
    "annotation": 9,
}

# Legacy alias (default to single-column, the most common case)
FONT_SIZE = FONT_SIZE_SINGLE_COL


def get_font_sizes(width_key: str = "single_column") -> dict[str, int]:
    """Return font size dict appropriate for the given figure width."""
    if width_key in ("double_column", "full_page"):
        return FONT_SIZE_DOUBLE_COL
    return FONT_SIZE_SINGLE_COL

# ---------------------------------------------------------------------------
# Figure dimensions (inches) — column-width aware
# ---------------------------------------------------------------------------

FIGURE_WIDTH = {
    "single_column": 3.5,   # IEEE / NeurIPS single column
    "double_column": 7.0,   # IEEE / NeurIPS double column
    "full_page": 7.0,       # Full width
}

DEFAULT_FIGURE_HEIGHT = 3.0  # reasonable default height

# ---------------------------------------------------------------------------
# Colorblind-safe palette (Paul Tol's "bright" scheme)
# ---------------------------------------------------------------------------

COLORS_BRIGHT = [
    "#4477AA",  # blue
    "#EE6677",  # red
    "#228833",  # green
    "#CCBB44",  # yellow
    "#66CCEE",  # cyan
    "#AA3377",  # purple
    "#BBBBBB",  # grey
]

# Extended palette for > 7 categories
COLORS_EXTENDED = COLORS_BRIGHT + [
    "#332288",  # indigo
    "#88CCEE",  # light blue
    "#44AA99",  # teal
    "#117733",  # dark green
    "#999933",  # olive
    "#CC6677",  # rose
    "#882255",  # wine
]

# ---------------------------------------------------------------------------
# Line and marker styles (for B&W printing compatibility)
# ---------------------------------------------------------------------------

LINE_STYLES = ["-", "--", "-.", ":"]
MARKER_STYLES = ["o", "s", "^", "D", "v", "P", "*", "X"]

# ---------------------------------------------------------------------------
# Output format preferences
# ---------------------------------------------------------------------------

OUTPUT_FORMAT_PRIMARY = "pdf"      # Vector — preferred for publication
OUTPUT_FORMAT_FALLBACK = "png"     # Raster — for markdown embedding
OUTPUT_FORMATS = ["pdf", "png"]    # Generate both

# ---------------------------------------------------------------------------
# Chart type constants
# ---------------------------------------------------------------------------

CHART_TYPES = {
    "bar_comparison",
    "grouped_bar",
    "training_curve",
    "loss_curve",
    "heatmap",
    "confusion_matrix",
    "scatter_plot",
    "ablation_grouped",
    "line_multi",
    "radar_chart",
    "architecture_diagram",  # Placeholder — generated via description
}

# ---------------------------------------------------------------------------
# Style snippet for injection into generated scripts
# ---------------------------------------------------------------------------

STYLE_PREAMBLE = '''
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import hashlib
import math
import textwrap

# Academic styling
try:
    plt.style.use({styles})
except Exception:
    try:
        plt.style.use({fallback})
    except Exception:
        pass  # Use default matplotlib style

# Colorblind-safe palette
COLORS = {colors}
LINE_STYLES = {line_styles}
MARKERS = {markers}

def method_color(name):
    normalized = " ".join(str(name).replace("_", " ").replace("-", " ").lower().split())
    if normalized in {{"random", "rnd", "baseline", "random baseline"}}:
        return COLORS[6 % len(COLORS)]
    digest = hashlib.sha256(normalized.encode("utf-8")).digest()
    return COLORS[digest[0] % len(COLORS)]

def assign_method_colors(labels):
    used = set()
    assigned = []
    for label in labels:
        preferred = method_color(label)
        if preferred in used:
            digest = hashlib.sha256(str(label).lower().encode("utf-8")).digest()
            start = digest[1] % len(COLORS)
            preferred = None
            for offset in range(len(COLORS)):
                candidate = COLORS[(start + offset) % len(COLORS)]
                if candidate not in used:
                    preferred = candidate
                    break
            if preferred is None:
                preferred = COLORS[len(assigned) % len(COLORS)]
        assigned.append(preferred)
        used.add(preferred)
    return assigned

def metric_display_label(metric_key):
    raw = str(metric_key or "").strip()
    low = raw.lower().replace("-", "_").replace(" ", "_")
    for suffix in ("_mean", "_median", "_value"):
        if low.endswith(suffix):
            low = low[:-len(suffix)]
            raw = raw[:-len(suffix)]
            break
    names = {{
        "primary_metric": "Performance score",
        "accuracy": "Accuracy",
        "balanced_accuracy": "Balanced accuracy",
        "f1": "F1 score",
        "f1_score": "F1 score",
        "precision": "Precision",
        "recall": "Recall",
        "roc_auc": "ROC-AUC",
        "auc": "AUC",
        "mae": "MAE",
        "mse": "MSE",
        "rmse": "RMSE",
        "r2": "R2",
        "loss": "Loss",
        "bias": "Bias",
        "variance": "Variance",
        "bias_variance": "Bias-variance score",
        "coverage": "Coverage",
        "type_i_error": "Type I error",
        "power": "Power",
    }}
    if low in names:
        return names[low]
    if "roc" in low and "auc" in low:
        return "ROC-AUC"
    if "bias" in low and "variance" in low:
        return "Bias-variance score"
    if "bias" in low:
        return "Bias"
    if "variance" in low:
        return "Variance"
    return raw.replace("_", " ").replace("-", " ").title() if raw else "Performance score"

def apply_bar_axis_baseline(ax, values, lower_bounds=None, upper_bounds=None):
    finite_values = []
    for seq in (values, lower_bounds, upper_bounds):
        if seq is None:
            continue
        for item in seq:
            try:
                value = float(item)
            except Exception:
                continue
            if math.isfinite(value):
                finite_values.append(value)
    if not finite_values:
        return
    lo = min(min(finite_values), 0.0)
    hi = max(max(finite_values), 0.0)
    span = hi - lo
    if span <= 0:
        span = max(1.0, abs(hi), abs(lo))
    pad = span * 0.10
    bottom = 0.0 if lo >= 0 else lo - pad
    top = 0.0 if hi <= 0 else hi + pad
    if top <= bottom:
        top = bottom + span
    ax.set_ylim(bottom=bottom, top=top)

def _clean_axis_label(value):
    text = str(value).replace("_", " ").replace("-", " ").strip()
    return " ".join(text.split())

def wrap_tick_label(value, width=13):
    text = _clean_axis_label(value)
    if len(text) <= width:
        return text
    wrapped = textwrap.wrap(
        text,
        width=width,
        break_long_words=False,
        break_on_hyphens=False,
    )
    return "\\n".join(wrapped) if wrapped else text

def _max_label_length(labels):
    return max((len(_clean_axis_label(label)) for label in labels), default=0)

def apply_non_overlapping_xticklabels(ax, labels, *, max_chars=13, rotation=None):
    labels = [_clean_axis_label(label) for label in labels]
    count = len(labels)
    longest = _max_label_length(labels)
    if rotation is None:
        rotation = 0 if count <= 4 and longest <= 18 else 30
    wrap_width = max_chars if rotation == 0 else max(12, min(18, max_chars + 3))
    wrapped = [wrap_tick_label(label, width=wrap_width) for label in labels]
    ha = "center" if rotation == 0 else "right"
    ax.set_xticklabels(wrapped, rotation=rotation, ha=ha, rotation_mode="anchor")
    ax.tick_params(axis="x", pad=6)
    fig = ax.figure
    current_width, current_height = fig.get_size_inches()
    target_width = max(current_width, 1.05 * count + 0.035 * sum(min(len(label), 30) for label in labels))
    max_lines = max((label.count("\\n") + 1 for label in wrapped), default=1)
    target_height = max(current_height, current_height + max(0, max_lines - 1) * 0.18)
    if target_width > current_width or target_height > current_height:
        fig.set_size_inches(target_width, target_height, forward=True)
    bottom = min(0.36, 0.12 + 0.055 * max_lines + (0.05 if rotation else 0.0))
    try:
        fig.subplots_adjust(bottom=max(fig.subplotpars.bottom, bottom))
    except Exception:
        pass

def apply_non_overlapping_yticklabels(ax, labels, *, max_chars=24):
    labels = [_clean_axis_label(label) for label in labels]
    wrapped = [wrap_tick_label(label, width=max_chars) for label in labels]
    ax.set_yticklabels(wrapped)
    ax.tick_params(axis="y", pad=4)
    fig = ax.figure
    current_width, current_height = fig.get_size_inches()
    max_lines = max((label.count("\\n") + 1 for label in wrapped), default=1)
    target_width = max(current_width, current_width + max(0, max_lines - 1) * 0.28)
    if target_width > current_width:
        fig.set_size_inches(target_width, current_height, forward=True)

def apply_publication_layout(fig, ax=None):
    try:
        if getattr(fig, "get_constrained_layout", lambda: False)():
            fig.set_constrained_layout_pads(w_pad=0.04, h_pad=0.08, hspace=0.08, wspace=0.08)
        else:
            fig.tight_layout(pad=1.1)
    except Exception:
        pass

def save_publication_figure(fig, output_path, *, dpi=300):
    apply_publication_layout(fig)
    fig.savefig(output_path, dpi=dpi, bbox_inches="tight", pad_inches=0.2)

# Publication settings
plt.rcParams.update({{
    "font.size": {font_axis},
    "axes.titlesize": {font_title},
    "axes.labelsize": {font_axis},
    "xtick.labelsize": {font_tick},
    "ytick.labelsize": {font_tick},
    "legend.fontsize": {font_legend},
    "figure.dpi": {dpi},
    "savefig.dpi": {dpi},
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.15,
}})
'''.strip()


def get_style_preamble(
    *,
    dpi: int = DPI_PUBLICATION,
    width_key: str = "single_column",
) -> str:
    """Return the style preamble string for injection into chart scripts."""
    fonts = get_font_sizes(width_key)
    return STYLE_PREAMBLE.format(
        styles=repr(MATPLOTLIB_STYLES),
        fallback=repr(MATPLOTLIB_STYLES_FALLBACK),
        colors=repr(COLORS_EXTENDED),
        line_styles=repr(LINE_STYLES),
        markers=repr(MARKER_STYLES),
        font_title=fonts["title"],
        font_axis=fonts["axis_label"],
        font_tick=fonts["tick"],
        font_legend=fonts["legend"],
        dpi=dpi,
    )
