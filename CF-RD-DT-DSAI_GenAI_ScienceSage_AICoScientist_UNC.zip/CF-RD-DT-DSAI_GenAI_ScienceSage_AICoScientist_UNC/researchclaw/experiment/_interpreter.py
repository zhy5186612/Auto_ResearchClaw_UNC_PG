"""Portable resolution of the sandbox Python interpreter.

Shared by ``ExperimentSandbox``, the pipeline dep-install helper, and the
``doctor`` health check so ``experiment.sandbox.python_path`` behaves the
same everywhere: env-var expansion, wrong-platform detection, fall back to
the current interpreter when the configured path is missing.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

_FIELD = "experiment.sandbox.python_path"
_AUTO_SENTINELS = {"", "auto", "sys.executable"}
_BARE_NAMES = {"python", "python3"}
_WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:[\\/]")

_warned: set[str] = set()


def _warn_once(raw: str, reason: str, fallback: Path) -> None:
    key = f"{raw}|{reason}"
    if key in _warned:
        return
    _warned.add(key)
    logger.warning(
        "%s=%r %s; falling back to %s", _FIELD, raw, reason, fallback
    )


def _looks_windows(raw: str) -> bool:
    return bool(_WINDOWS_DRIVE_RE.match(raw)) or "\\" in raw


def _current_interpreter() -> Path:
    exe = sys.executable
    if not exe:
        raise RuntimeError(
            "sys.executable is empty; cannot resolve a sandbox Python interpreter"
        )
    return Path(exe)


def resolve_python_path(raw: str | None) -> Path:
    """Resolve ``experiment.sandbox.python_path`` to an absolute path.

    Falls back to :data:`sys.executable` (with a one-shot warning per raw
    value) whenever the configured value is missing, unusable, or shaped
    for a different OS. Returns an absolute :class:`~pathlib.Path`; never
    calls ``.resolve()`` — venv symlinks matter (see the note in
    ``sandbox._build_command``).
    """
    fallback = _current_interpreter()

    if raw is None:
        return fallback

    value = raw.strip()
    if value.lower() in _AUTO_SENTINELS:
        return fallback

    expanded = os.path.expandvars(os.path.expanduser(value))
    if "$" in expanded or (expanded.startswith("~") and expanded == value):
        _warn_once(raw, "contains unresolved env vars", fallback)
        return fallback

    if expanded in _BARE_NAMES:
        which = shutil.which(expanded)
        if which:
            return Path(which)
        _warn_once(raw, f"{expanded!r} not found on PATH", fallback)
        return fallback

    on_windows = sys.platform == "win32"
    if not on_windows and _looks_windows(expanded):
        _warn_once(raw, f"Windows-style path on {sys.platform}", fallback)
        return fallback
    if on_windows and expanded.startswith("/") and not _WINDOWS_DRIVE_RE.match(expanded):
        _warn_once(raw, "POSIX-style path on Windows", fallback)
        return fallback

    path = Path(expanded)
    if not path.is_absolute():
        path = Path.cwd() / path

    if not path.exists():
        _warn_once(raw, f"resolved path {path} does not exist", fallback)
        return fallback

    return path


def reset_warning_cache() -> None:
    """Test-only: clear the once-per-process warning dedup set."""
    _warned.clear()
