"""Experiment result visualization.

Generates publication-quality charts from experiment run data:
- Condition comparison (grouped bar chart with CI error bars)
- Metric heatmap (condition × metric matrix)
- Metric trajectory (line chart with markers)
- Ablation delta chart (horizontal bar showing delta from baseline)
- Pipeline execution timeline
- Iteration score history

Uses Paul Tol colorblind-safe palette and academic styling.
"""

from __future__ import annotations

import json
import logging
import math
import hashlib
import textwrap
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

try:
    import matplotlib

    matplotlib.use("Agg")  # Non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    from matplotlib.patches import FancyBboxPatch
    import numpy as np

    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

# Paul Tol "bright" palette — colorblind-safe, publication-ready
_PAUL_TOL_BRIGHT = [
    "#4477AA",  # blue
    "#EE6677",  # red/pink
    "#228833",  # green
    "#CCBB44",  # yellow
    "#66CCEE",  # cyan
    "#AA3377",  # purple
    "#BBBBBB",  # grey
]

# Extended palette for many conditions (Tol muted + bright merged)
_PAUL_TOL_EXTENDED = [
    "#4477AA", "#EE6677", "#228833", "#CCBB44", "#66CCEE",
    "#AA3377", "#332288", "#88CCEE", "#44AA99", "#117733",
    "#999933", "#CC6677", "#882255", "#661100", "#6699CC",
]

_CANONICAL_METHOD_COLOR_OVERRIDES = {
    "random": _PAUL_TOL_EXTENDED[6],
    "rnd": _PAUL_TOL_EXTENDED[6],
    "baseline": _PAUL_TOL_EXTENDED[6],
    "random baseline": _PAUL_TOL_EXTENDED[6],
}

_METRIC_DISPLAY_NAMES: dict[str, str] = {
    "primary_metric": "Performance score",
    "performance": "Performance score",
    "accuracy": "Accuracy",
    "balanced_accuracy": "Balanced accuracy",
    "f1": "F1 score",
    "f1_score": "F1 score",
    "precision": "Precision",
    "recall": "Recall",
    "roc_auc": "ROC-AUC",
    "auc": "AUC",
    "mae": "MAE",
    "mse": "MSE",
    "rmse": "RMSE",
    "r2": "R2",
    "loss": "Loss",
    "bias": "Bias",
    "variance": "Variance",
    "bias_variance": "Bias-variance score",
    "coverage": "Coverage",
    "type_i_error": "Type I error",
    "power": "Power",
    "runtime_sec": "Runtime (seconds)",
}

# Metrics to exclude from comparison charts (timing, meta, non-scientific)
_EXCLUDED_METRICS: set[str] = {
    "time_budget_sec", "elapsed_sec", "elapsed_time", "execution_time",
    "wall_time", "runtime_sec", "total_time", "timeout",
    "seed", "seed_count", "n_seeds", "num_seeds",
    "success_rate", "num_conditions", "total_conditions",
    "calibration_iterations",
}

# Prefixes that indicate meta/timing metrics
_EXCLUDED_PREFIXES: tuple[str, ...] = ("time_", "runtime_", "elapsed_", "wall_")

_CLASSIFICATION_METRIC_ALIASES: dict[str, tuple[str, ...]] = {
    "accuracy": ("accuracy", "acc", "test_accuracy", "val_accuracy", "balanced_accuracy"),
    "f1": ("f1", "f1_score", "macro_f1", "weighted_f1", "test_f1"),
    "precision": ("precision", "positive_predictive_value", "ppv", "macro_precision", "test_precision"),
    "recall": ("recall", "sensitivity", "true_positive_rate", "tpr", "macro_recall", "test_recall"),
    "roc_auc": ("roc_auc", "rocauc", "auc", "auroc", "roc_auc_score", "test_roc_auc"),
}

_CLASSIFICATION_METRIC_TITLES: dict[str, str] = {
    "accuracy": "Accuracy comparison",
    "f1": "F1 comparison",
    "precision": "Precision comparison",
    "recall": "Recall comparison",
    "roc_auc": "ROC-AUC comparison",
}

_CLASSIFICATION_METRIC_FILENAMES: dict[str, str] = {
    "accuracy": "accuracy_comparison.png",
    "f1": "f1_comparison.png",
    "precision": "precision_comparison.png",
    "recall": "recall_comparison.png",
    "roc_auc": "roc_auc_comparison.png",
}

_CONTINUOUS_METRIC_ALIASES: dict[str, tuple[str, ...]] = {
    "mae": ("mae", "mean_absolute_error", "test_mae", "val_mae"),
    "mse": ("mse", "mean_squared_error", "test_mse", "val_mse"),
    "rmse": ("rmse", "root_mean_squared_error", "test_rmse", "val_rmse"),
    "r2": ("r2", "r2_score", "r_squared", "rsquared", "test_r2", "val_r2"),
}

_CONTINUOUS_METRIC_TITLES: dict[str, str] = {
    "mae": "MAE comparison",
    "mse": "MSE comparison",
    "rmse": "RMSE comparison",
    "r2": "R2 comparison",
}

_CONTINUOUS_METRIC_FILENAMES: dict[str, str] = {
    "mae": "mae_comparison.png",
    "mse": "mse_comparison.png",
    "rmse": "rmse_comparison.png",
    "r2": "r2_comparison.png",
}


def _is_excluded_metric(name: str) -> bool:
    """Return True if *name* is a timing/meta metric that shouldn't be charted."""
    low = name.lower()
    if low in _EXCLUDED_METRICS:
        return True
    return any(low.startswith(p) for p in _EXCLUDED_PREFIXES)


def _shorten_label(name: str, max_len: int = 22) -> str:
    """Shorten a metric label for chart readability."""
    if len(name) <= max_len:
        return name
    return name[: max_len - 1] + "\u2026"


def _clean_axis_label(value: Any) -> str:
    text = str(value).replace("_", " ").replace("-", " ").strip()
    return " ".join(text.split())


def _wrap_tick_label(value: Any, width: int = 13) -> str:
    text = _clean_axis_label(value)
    if len(text) <= width:
        return text
    wrapped = textwrap.wrap(
        text,
        width=width,
        break_long_words=False,
        break_on_hyphens=False,
    )
    return "\n".join(wrapped) if wrapped else text


def _apply_readable_xticklabels(
    ax: Any,
    labels: list[Any],
    *,
    max_chars: int = 13,
    rotation: int | None = None,
) -> None:
    clean_labels = [_clean_axis_label(label) for label in labels]
    count = len(clean_labels)
    longest = max((len(label) for label in clean_labels), default=0)
    if rotation is None:
        rotation = 0 if count <= 4 and longest <= 18 else 30
    wrap_width = max_chars if rotation == 0 else max(12, min(18, max_chars + 3))
    wrapped = [_wrap_tick_label(label, width=wrap_width) for label in clean_labels]
    ha = "center" if rotation == 0 else "right"
    ax.set_xticklabels(wrapped, rotation=rotation, ha=ha, rotation_mode="anchor")
    ax.tick_params(axis="x", pad=6)
    fig = ax.figure
    current_width, current_height = fig.get_size_inches()
    target_width = max(
        current_width,
        1.05 * max(count, 1) + 0.035 * sum(min(len(label), 30) for label in clean_labels),
    )
    max_lines = max((label.count("\n") + 1 for label in wrapped), default=1)
    target_height = max(current_height, current_height + max(0, max_lines - 1) * 0.18)
    if target_width > current_width or target_height > current_height:
        fig.set_size_inches(target_width, target_height, forward=True)
    try:
        fig.subplots_adjust(
            bottom=max(fig.subplotpars.bottom, min(0.36, 0.12 + 0.055 * max_lines + (0.05 if rotation else 0))),
        )
    except Exception:
        pass


def _apply_readable_yticklabels(ax: Any, labels: list[Any], *, max_chars: int = 24) -> None:
    wrapped = [_wrap_tick_label(label, width=max_chars) for label in labels]
    ax.set_yticklabels(wrapped)
    ax.tick_params(axis="y", pad=4)


def _method_color(name: str) -> str:
    """Return a deterministic color for a method or condition name."""
    normalized = " ".join(str(name).replace("_", " ").replace("-", " ").casefold().split())
    if normalized in _CANONICAL_METHOD_COLOR_OVERRIDES:
        return _CANONICAL_METHOD_COLOR_OVERRIDES[normalized]
    digest = hashlib.sha256(normalized.encode("utf-8")).digest()
    return _PAUL_TOL_EXTENDED[digest[0] % len(_PAUL_TOL_EXTENDED)]


def _assign_method_colors(names: list[Any]) -> list[str]:
    """Assign distinct colors to visible method/model labels when possible."""
    used: set[str] = set()
    assigned: list[str] = []
    for name in names:
        preferred = _method_color(str(name))
        if preferred in used:
            digest = hashlib.sha256(str(name).casefold().encode("utf-8")).digest()
            start = digest[1] % len(_PAUL_TOL_EXTENDED)
            preferred = ""
            for offset in range(len(_PAUL_TOL_EXTENDED)):
                candidate = _PAUL_TOL_EXTENDED[(start + offset) % len(_PAUL_TOL_EXTENDED)]
                if candidate not in used:
                    preferred = candidate
                    break
            if not preferred:
                preferred = _PAUL_TOL_EXTENDED[len(assigned) % len(_PAUL_TOL_EXTENDED)]
        assigned.append(preferred)
        used.add(preferred)
    return assigned


def _metric_display_label(metric_key: str | None) -> str:
    """Return a paper-facing metric label instead of raw storage keys."""
    raw = str(metric_key or "").strip()
    if not raw:
        return "Performance score"
    normalized = raw.casefold()
    for suffix in ("_mean", "_median", "_value"):
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)]
            raw = raw[: -len(suffix)]
            break
    normalized = normalized.replace("-", "_").replace(" ", "_")
    if normalized in _METRIC_DISPLAY_NAMES:
        return _METRIC_DISPLAY_NAMES[normalized]
    if "roc" in normalized and "auc" in normalized:
        return "ROC-AUC"
    if "bias" in normalized and "variance" in normalized:
        return "Bias-variance score"
    if "bias" in normalized:
        return "Bias"
    if "variance" in normalized:
        return "Variance"
    if "rmse" in normalized:
        return "RMSE"
    if normalized in {"r_squared", "rsquared"}:
        return "R2"
    return raw.replace("_", " ").replace("-", " ").title()


def _apply_bar_axis_baseline(
    ax: Any,
    values: list[float],
    *,
    lower_bounds: list[float] | None = None,
    upper_bounds: list[float] | None = None,
) -> None:
    """Ensure bar charts show the real zero baseline instead of truncating it."""
    finite_values: list[float] = []
    for seq in (values, lower_bounds, upper_bounds):
        if seq is None:
            continue
        for item in seq:
            try:
                value = float(item)
            except (TypeError, ValueError):
                continue
            if math.isfinite(value):
                finite_values.append(value)
    if not finite_values:
        return
    lo = min(finite_values)
    hi = max(finite_values)
    lo = min(lo, 0.0)
    hi = max(hi, 0.0)
    span = hi - lo
    if span <= 0:
        span = max(1.0, abs(hi), abs(lo))
    pad = span * 0.10
    bottom = 0.0 if lo >= 0 else lo - pad
    top = 0.0 if hi <= 0 else hi + pad
    if top <= bottom:
        top = bottom + span
    ax.set_ylim(bottom=bottom, top=top)


def _format_cond_name(name: str) -> str:
    """Format condition name for display: underscores → spaces, title case."""
    return name.replace("_", " ").title()


def _normalize_metric_name(name: str) -> str:
    return "".join(ch for ch in name.casefold() if ch.isalnum())


def _mean_value(value: Any) -> float | None:
    if isinstance(value, dict):
        for key in ("mean", "value", "median", "max", "min"):
            if key in value:
                return _mean_value(value[key])
        return None
    if isinstance(value, (list, tuple)):
        values: list[float] = []
        for item in value:
            parsed = _mean_value(item)
            if parsed is not None and math.isfinite(parsed):
                values.append(parsed)
        return float(sum(values) / len(values)) if values else None
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def _metric_matches(metric_name: str, aliases: tuple[str, ...]) -> bool:
    normalized = _normalize_metric_name(metric_name)
    return any(_normalize_metric_name(alias) == normalized for alias in aliases)


def _condition_metric_value(metrics: dict[str, Any], canonical_metric: str) -> float | None:
    aliases = _CLASSIFICATION_METRIC_ALIASES.get(canonical_metric, (canonical_metric,))
    for key, value in metrics.items():
        metric_name = str(key).split("/")[-1].replace("_mean", "")
        if _metric_matches(metric_name, aliases):
            parsed = _mean_value(value)
            if parsed is not None:
                return parsed
    return None


def _metrics_summary_condition_values(
    metrics_summary: dict[str, Any],
    canonical_metric: str,
) -> dict[str, float]:
    aliases = _CLASSIFICATION_METRIC_ALIASES.get(canonical_metric, (canonical_metric,))
    values: dict[str, float] = {}
    for key, value in metrics_summary.items():
        key_text = str(key)
        if "/" not in key_text:
            continue
        condition, metric_name = key_text.rsplit("/", 1)
        metric_name = metric_name.replace("_mean", "")
        if not _metric_matches(metric_name, aliases):
            continue
        parsed = _mean_value(value)
        if parsed is not None:
            values[condition] = parsed
    return values


def _ensure_dir(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _setup_academic_style() -> None:
    """Apply academic styling via rcParams."""
    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 11,
        "axes.labelsize": 12,
        "axes.titlesize": 13,
        "axes.titleweight": "bold",
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "grid.linestyle": "--",
        "axes.axisbelow": True,
    })


def _save_figure_without_title(fig: Any, output_path: Path) -> Path:
    """Save a chart with no in-image title; the paper caption carries the title."""
    for ax in getattr(fig, "axes", []):
        try:
            ax.set_title("")
        except Exception:
            pass
    path = _ensure_dir(output_path)
    fig.savefig(path, dpi=300, bbox_inches="tight", pad_inches=0.2)
    return path


# ---------------------------------------------------------------------------
# 1. Condition comparison — grouped bar with CI error bars
# ---------------------------------------------------------------------------


def plot_condition_comparison(
    condition_summaries: dict[str, dict[str, Any]],
    output_path: Path,
    *,
    metric_key: str = "primary_metric",
    title: str = "",
) -> Path | None:
    """Bar chart comparing conditions with mean +/- 95% CI error bars.

    Uses Paul Tol colorblind-safe palette with gradient shading.
    """
    if not HAS_MATPLOTLIB or not condition_summaries:
        return None

    _setup_academic_style()

    names: list[str] = []
    means: list[float] = []
    ci_low: list[float] = []
    ci_high: list[float] = []

    for cond, info in condition_summaries.items():
        m = info.get("metrics", {})
        mean_val = m.get(f"{metric_key}_mean") or m.get(metric_key)
        if mean_val is None:
            continue
        fmean = float(mean_val)
        names.append(_format_cond_name(cond))
        means.append(fmean)
        ci_low.append(float(info.get("ci95_low", fmean)))
        ci_high.append(float(info.get("ci95_high", fmean)))

    if len(names) < 2:
        logger.warning(
            "Skipping condition comparison chart with %d bar(s); result bar "
            "charts must compare at least two methods/conditions or sample-size regimes.",
            len(names),
        )
        return None

    yerr_lo = [max(0, m - lo) for m, lo in zip(means, ci_low)]
    yerr_hi = [max(0, hi - m) for m, hi in zip(means, ci_high)]

    n = len(names)
    colors = _assign_method_colors(names)

    fig, ax = plt.subplots(figsize=(max(7, n * 1.2), 5))
    x = np.arange(n)
    bars = ax.bar(
        x, means, color=colors, alpha=0.88,
        edgecolor="white", linewidth=0.8, width=0.7,
    )
    ax.errorbar(
        x, means, yerr=[yerr_lo, yerr_hi],
        fmt="none", ecolor="#333333", capsize=5, capthick=1.5, linewidth=1.5,
    )

    y_max = max(m + h for m, h in zip(means, yerr_hi)) if yerr_hi else max(means)
    y_min = min(ci_low) if ci_low else min(means)
    y_span = max(y_max - min(y_min, 0.0), 1e-9)
    offset = y_span * 0.025
    for i, m in enumerate(means):
        ax.text(
            i, m + yerr_hi[i] + offset, f"{m:.3f}",
            ha="center", va="bottom", fontsize=9, fontweight="bold", color="#333",
        )

    ax.set_xlabel("Method / Condition")
    metric_label = _metric_display_label(metric_key)
    ax.set_ylabel(metric_label)
    ax.set_title(title or f"{metric_label} Comparison (Mean \u00b1 95% CI)")
    ax.set_xticks(x)
    _apply_readable_xticklabels(ax, names)
    if n > 1:
        ax.legend(
            [bars[i] for i in range(n)],
            names,
            title="Method / Condition",
            loc="upper right",
            fontsize=8,
            title_fontsize=9,
            frameon=True,
        )
    _apply_bar_axis_baseline(ax, means, lower_bounds=ci_low, upper_bounds=ci_high)
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved condition comparison: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 2. Metric heatmap — condition × metric matrix
# ---------------------------------------------------------------------------


def plot_metric_heatmap(
    condition_summaries: dict[str, dict[str, Any]],
    output_path: Path,
    *,
    title: str = "Performance Heatmap (Per-Condition Metrics)",
    max_metrics: int = 12,
) -> Path | None:
    """Heatmap of normalized metric values across conditions.

    Shows per-condition performance normalized to [0, 1] per metric column.
    """
    if not HAS_MATPLOTLIB or not condition_summaries:
        return None

    _setup_academic_style()

    # Collect all metric keys across conditions
    all_metric_keys: set[str] = set()
    for info in condition_summaries.values():
        m = info.get("metrics", {})
        for k in m:
            if not _is_excluded_metric(k) and not k.endswith("_std"):
                all_metric_keys.add(k)

    # Filter to _mean variants or raw metrics, deduplicate
    clean_keys: list[str] = []
    for k in sorted(all_metric_keys):
        base = k.replace("_mean", "")
        if base not in [ck.replace("_mean", "") for ck in clean_keys]:
            clean_keys.append(k)

    if len(clean_keys) < 2:
        return None

    clean_keys = clean_keys[:max_metrics]
    cond_names = list(condition_summaries.keys())
    if len(cond_names) < 2:
        logger.warning(
            "Skipping metric heatmap with %d condition(s); result heatmaps "
            "must compare at least two methods/conditions or sample-size regimes.",
            len(cond_names),
        )
        return None

    # Build matrix
    data = np.zeros((len(cond_names), len(clean_keys)))
    for i, cond in enumerate(cond_names):
        m = condition_summaries[cond].get("metrics", {})
        for j, mk in enumerate(clean_keys):
            val = m.get(mk, 0)
            try:
                data[i, j] = float(val)
            except (ValueError, TypeError):
                data[i, j] = 0

    # Normalize per column (min-max)
    for j in range(data.shape[1]):
        col = data[:, j]
        lo, hi = col.min(), col.max()
        if hi > lo:
            data[:, j] = (col - lo) / (hi - lo)
        else:
            data[:, j] = 0.5

    fig, ax = plt.subplots(
        figsize=(max(6, len(clean_keys) * 1.3), max(4, len(cond_names) * 0.6))
    )
    im = ax.imshow(data, cmap="YlGnBu", aspect="auto", vmin=0, vmax=1)

    # Annotate cells
    for i in range(len(cond_names)):
        for j in range(len(clean_keys)):
            val = data[i, j]
            color = "white" if val > 0.6 else "#333"
            ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                    fontsize=8, color=color, fontweight="bold")

    ax.set_xticks(range(len(clean_keys)))
    _apply_readable_xticklabels(
        ax,
        [_metric_display_label(k) for k in clean_keys],
        max_chars=12,
        rotation=35,
    )
    ax.set_yticks(range(len(cond_names)))
    _apply_readable_yticklabels(ax, [_format_cond_name(c) for c in cond_names], max_chars=18)
    ax.set_title(title)

    cbar = fig.colorbar(im, ax=ax, shrink=0.8, label="Normalized Score")
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved metric heatmap: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 3. Ablation delta chart — horizontal bars showing improvement over baseline
# ---------------------------------------------------------------------------


def plot_ablation_deltas(
    condition_summaries: dict[str, dict[str, Any]],
    output_path: Path,
    *,
    metric_key: str = "primary_metric",
    baseline_name: str = "",
    title: str = "",
    higher_is_better: bool = True,
) -> Path | None:
    """Horizontal bar chart showing delta from baseline for each ablation.

    Bars go left (worse) or right (better) from zero.
    """
    if not HAS_MATPLOTLIB or not condition_summaries:
        return None

    _setup_academic_style()

    # Find baseline
    cond_keys = list(condition_summaries.keys())
    if baseline_name:
        base_key = baseline_name
    else:
        # Heuristic: pick "baseline", "heuristic_baseline", or first condition
        for candidate in ["baseline", "heuristic_baseline", "random_baseline"]:
            if candidate in cond_keys:
                base_key = candidate
                break
        else:
            base_key = cond_keys[0]

    base_info = condition_summaries.get(base_key, {})
    base_m = base_info.get("metrics", {})
    base_val = float(base_m.get(f"{metric_key}_mean") or base_m.get(metric_key, 0))

    if base_val == 0:
        return None

    names: list[str] = []
    deltas: list[float] = []
    for cond, info in condition_summaries.items():
        if cond == base_key:
            continue
        m = info.get("metrics", {})
        val = m.get(f"{metric_key}_mean") or m.get(metric_key)
        if val is None:
            continue
        fval = float(val)
        pct = ((fval - base_val) / abs(base_val)) * 100
        names.append(_format_cond_name(cond))
        deltas.append(pct)

    if len(names) < 2:
        logger.warning(
            "Skipping ablation delta chart with %d bar(s); ablation bar charts "
            "must compare at least two variants against the baseline.",
            len(names),
        )
        return None

    # Sort by delta
    pairs = sorted(zip(deltas, names), reverse=True)
    deltas, names = zip(*pairs)
    deltas = list(deltas)
    names = list(names)

    fig, ax = plt.subplots(figsize=(8, max(4, len(names) * 0.5)))
    y = np.arange(len(names))
    bar_colors = []
    for d in deltas:
        if higher_is_better:
            bar_colors.append("#228833" if d > 0 else "#EE6677")
        else:
            bar_colors.append("#228833" if d < 0 else "#EE6677")

    ax.barh(y, deltas, color=bar_colors, alpha=0.85, edgecolor="white", height=0.6)
    ax.axvline(x=0, color="#333", linewidth=1, linestyle="-")

    # Value labels
    for i, d in enumerate(deltas):
        ha = "left" if d >= 0 else "right"
        offset = 0.5 if d >= 0 else -0.5
        ax.text(d + offset, i, f"{d:+.1f}%", ha=ha, va="center", fontsize=9, fontweight="bold")

    ax.set_yticks(y)
    _apply_readable_yticklabels(ax, names, max_chars=24)
    ax.set_xlabel(f"\u0394 {_metric_display_label(metric_key)} vs. Baseline (%)")
    ax.set_title(title or f"Ablation Analysis (Baseline: {_format_cond_name(base_key)})")
    ax.invert_yaxis()
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved ablation deltas: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 4. Metric trajectory — line chart across refinement iterations
# ---------------------------------------------------------------------------


def plot_metric_trajectory(
    runs: list[dict[str, Any]],
    metric_key: str,
    output_path: Path,
    *,
    title: str = "",
) -> Path | None:
    """Plot metric values across runs as a styled line chart with markers."""
    if not HAS_MATPLOTLIB or not runs:
        return None

    _setup_academic_style()

    values: list[float] = []
    labels: list[str] = []
    for i, r in enumerate(runs):
        m = r.get("metrics") or r.get("key_metrics") or {}
        if isinstance(m, dict) and metric_key in m:
            try:
                values.append(float(m[metric_key]))
                labels.append(r.get("run_id", f"Iter {i + 1}"))
            except (ValueError, TypeError):
                continue

    if not values:
        return None

    fig, ax = plt.subplots(figsize=(max(6, len(values) * 1.5), 4.5))
    x = range(len(values))
    ax.plot(
        x, values, "o-", color=_PAUL_TOL_BRIGHT[0],
        linewidth=2.5, markersize=8, markerfacecolor="white",
        markeredgewidth=2, markeredgecolor=_PAUL_TOL_BRIGHT[0],
    )

    # Fill area under curve
    ax.fill_between(x, values, alpha=0.08, color=_PAUL_TOL_BRIGHT[0])

    # Value annotations
    for i, v in enumerate(values):
        ax.annotate(
            f"{v:.4f}", (i, v), textcoords="offset points",
            xytext=(0, 12), ha="center", fontsize=9, fontweight="bold",
        )

    metric_label = _metric_display_label(metric_key)
    ax.set_xlabel("Refinement Iteration")
    ax.set_ylabel(metric_label)
    ax.set_title(title or f"{metric_label} Across Iterations")
    ax.set_xticks(list(x))
    _apply_readable_xticklabels(ax, labels, max_chars=12)
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved metric trajectory: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 5. Experiment comparison — multi-metric bar chart
# ---------------------------------------------------------------------------


def plot_experiment_comparison(
    metrics_summary: dict[str, dict[str, float]],
    output_path: Path,
    *,
    title: str = "Experiment Results Comparison",
) -> Path | None:
    """Grouped bar chart comparing mean/min/max across metrics."""
    if not HAS_MATPLOTLIB or not metrics_summary:
        return None

    _setup_academic_style()

    filtered = {k: v for k, v in metrics_summary.items() if not _is_excluded_metric(k)}
    if len(filtered) < 2:
        logger.warning(
            "Skipping experiment comparison chart with %d metric bar(s); "
            "bar charts must be comparative.",
            len(filtered),
        )
        return None

    # Limit to top 12 metrics
    if len(filtered) > 12:
        top = sorted(filtered.items(), key=lambda kv: abs(kv[1].get("mean", 0)), reverse=True)[:12]
        filtered = dict(top)

    names = list(filtered.keys())
    means = [filtered[n].get("mean", 0) for n in names]
    mins = [filtered[n].get("min", 0) for n in names]
    maxs = [filtered[n].get("max", 0) for n in names]

    fig, ax = plt.subplots(figsize=(max(7, len(names) * 1.3), 5))
    x = np.arange(len(names))
    width = 0.6

    bars = ax.bar(
        x, means, width=width, color=_PAUL_TOL_BRIGHT[0], alpha=0.88,
        edgecolor="white", linewidth=0.8, label="Mean",
    )

    # Min-max range as thin lines
    for i, (lo, hi) in enumerate(zip(mins, maxs)):
        ax.plot([i, i], [lo, hi], color="#333", linewidth=2, solid_capstyle="round")
        ax.plot(i, lo, "_", color="#333", markersize=8, markeredgewidth=2)
        ax.plot(i, hi, "_", color="#333", markersize=8, markeredgewidth=2)

    ax.set_xlabel("Metric")
    ax.set_ylabel("Value")
    ax.set_title(title)
    ax.set_xticks(x)
    _apply_readable_xticklabels(ax, [_metric_display_label(n) for n in names], max_chars=12, rotation=35)
    ax.legend(loc="upper right")
    _apply_bar_axis_baseline(ax, means, lower_bounds=mins, upper_bounds=maxs)
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved experiment comparison: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 6. Pipeline execution timeline
# ---------------------------------------------------------------------------


def plot_pipeline_timeline(
    stage_results: list[dict[str, Any]],
    output_path: Path,
    *,
    title: str = "Pipeline Execution Timeline",
) -> Path | None:
    """Horizontal bar chart showing execution time per stage."""
    if not HAS_MATPLOTLIB or not stage_results:
        return None

    _setup_academic_style()

    labels: list[str] = []
    durations: list[float] = []
    colors: list[str] = []

    for r in stage_results:
        name = r.get("stage_name", r.get("stage", "?"))
        elapsed = r.get("elapsed_sec", 0)
        status = r.get("status", "done")
        labels.append(str(name))
        durations.append(float(elapsed) if elapsed else 1.0)
        colors.append("#228833" if status == "done" else "#EE6677")

    if not labels:
        return None

    fig, ax = plt.subplots(figsize=(10, max(4, len(labels) * 0.35)))
    y = range(len(labels))
    ax.barh(list(y), durations, color=colors, alpha=0.85, edgecolor="white", height=0.6)
    ax.set_yticks(list(y))
    _apply_readable_yticklabels(ax, labels, max_chars=24)
    ax.set_xlabel("Time (seconds)")
    ax.set_title(title)
    ax.invert_yaxis()
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved pipeline timeline: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 7. Iteration score history
# ---------------------------------------------------------------------------


def plot_iteration_scores(
    scores: list[float | None],
    output_path: Path,
    *,
    threshold: float = 7.0,
    title: str = "Quality Score by Iteration",
) -> Path | None:
    """Line chart of quality scores across iterations."""
    if not HAS_MATPLOTLIB or not scores:
        return None

    _setup_academic_style()

    valid = [(i + 1, s) for i, s in enumerate(scores) if s is not None]
    if not valid:
        return None

    iters, vals = zip(*valid)

    fig, ax = plt.subplots(figsize=(6, 4.5))
    ax.plot(
        iters, vals, "o-", color=_PAUL_TOL_BRIGHT[5],
        linewidth=2.5, markersize=9, markerfacecolor="white",
        markeredgewidth=2, markeredgecolor=_PAUL_TOL_BRIGHT[5],
    )
    ax.axhline(
        y=threshold, color=_PAUL_TOL_BRIGHT[1], linestyle="--",
        alpha=0.7, linewidth=1.5, label=f"Threshold ({threshold})",
    )
    ax.fill_between(iters, vals, alpha=0.06, color=_PAUL_TOL_BRIGHT[5])
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Quality Score")
    ax.set_title(title)
    ax.set_ylim(0, 10.5)
    ax.legend(loc="lower right")
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved iteration scores: %s", output_path)
    return output_path


def _extract_feature_inclusion_probabilities(summary: dict[str, Any]) -> list[tuple[str, float]]:
    candidates = [
        summary.get("feature_inclusion_probabilities"),
        summary.get("feature_inclusion_probability"),
        summary.get("feature_importance"),
        summary.get("feature_importances"),
    ]
    best_run = summary.get("best_run")
    if isinstance(best_run, dict):
        candidates.extend([
            best_run.get("feature_inclusion_probabilities"),
            best_run.get("feature_importance"),
            best_run.get("feature_importances"),
        ])

    for candidate in candidates:
        rows: list[tuple[str, float]] = []
        if isinstance(candidate, dict):
            iterable = candidate.items()
            for name, value in iterable:
                parsed = _mean_value(value)
                if parsed is not None:
                    rows.append((str(name), max(0.0, min(1.0, parsed))))
        elif isinstance(candidate, list):
            for item in candidate:
                if isinstance(item, dict):
                    name = (
                        item.get("variable")
                        or item.get("feature")
                        or item.get("name")
                        or item.get("column")
                    )
                    value = (
                        item.get("probability")
                        or item.get("inclusion_probability")
                        or item.get("importance")
                        or item.get("value")
                    )
                    parsed = _mean_value(value)
                    if name and parsed is not None:
                        rows.append((str(name), max(0.0, min(1.0, parsed))))
                elif isinstance(item, (list, tuple)) and len(item) >= 2:
                    parsed = _mean_value(item[1])
                    if parsed is not None:
                        rows.append((str(item[0]), max(0.0, min(1.0, parsed))))
        if rows:
            rows = sorted(rows, key=lambda pair: pair[1], reverse=True)
            return rows[:25]
    return []


def plot_feature_inclusion_probability(
    summary: dict[str, Any],
    output_path: Path,
    *,
    title: str = "Feature Importance: Inclusion Probability",
) -> Path | None:
    """Horizontal bar chart: x-axis inclusion probability, y-axis variables."""
    if not HAS_MATPLOTLIB:
        return None

    rows = _extract_feature_inclusion_probabilities(summary)
    if len(rows) < 2:
        logger.warning(
            "Skipping feature inclusion bar chart with %d variable(s); "
            "bar charts must contain at least two bars.",
            len(rows),
        )
        return None

    _setup_academic_style()
    variables = [row[0] for row in rows][::-1]
    probabilities = [row[1] for row in rows][::-1]

    fig, ax = plt.subplots(figsize=(8, max(4.5, len(rows) * 0.32)))
    y = np.arange(len(variables))
    ax.barh(y, probabilities, color=_PAUL_TOL_BRIGHT[0], alpha=0.88, edgecolor="white")
    ax.set_yticks(y)
    _apply_readable_yticklabels(ax, variables, max_chars=28)
    ax.set_xlabel("Probability of inclusion")
    ax.set_ylabel("Variables")
    ax.set_xlim(0, 1)
    ax.set_title(title)
    for i, value in enumerate(probabilities):
        ax.text(min(value + 0.015, 0.98), i, f"{value:.2f}", va="center", fontsize=8)
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved feature inclusion probability chart: %s", output_path)
    return output_path


def plot_metric_bar_comparison(
    values_by_condition: dict[str, float],
    output_path: Path,
    *,
    metric_label: str,
    title: str,
) -> Path | None:
    """Simple comparison bar chart for one classification metric."""
    if not HAS_MATPLOTLIB or not values_by_condition:
        return None

    _setup_academic_style()
    pairs = sorted(values_by_condition.items(), key=lambda pair: pair[0].casefold())
    if len(pairs) < 2:
        logger.warning(
            "Skipping %s chart with %d bar(s); metric bar charts must compare "
            "at least two methods/conditions or sample-size regimes.",
            title,
            len(pairs),
        )
        return None
    names = [_format_cond_name(name) for name, _ in pairs]
    values = [value for _, value in pairs]
    colors = _assign_method_colors(names)

    fig, ax = plt.subplots(figsize=(max(6.5, len(values) * 1.1), 4.8))
    x = np.arange(len(values))
    ax.bar(x, values, color=colors, alpha=0.88, edgecolor="white", linewidth=0.8)
    ax.set_xticks(x)
    _apply_readable_xticklabels(ax, names)
    ax.set_xlabel("Method / Condition")
    ax.set_ylabel(metric_label)
    ax.set_title(title)
    if len(values) > 1:
        ax.legend(
            [plt.Rectangle((0, 0), 1, 1, color=colors[i], alpha=0.88) for i in range(len(values))],
            names,
            title="Method / Condition",
            loc="upper right",
            fontsize=8,
            title_fontsize=9,
            frameon=True,
        )
    if values and all(0 <= value <= 1 for value in values):
        ax.set_ylim(0, 1.05)
    else:
        _apply_bar_axis_baseline(ax, values)
    for i, value in enumerate(values):
        ax.text(i, value + (0.02 if value >= 0 else 0), f"{value:.3f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved metric comparison chart: %s", output_path)
    return output_path


def _collect_metric_values(
    summary: dict[str, Any],
    canonical_metric: str,
    aliases_by_metric: dict[str, tuple[str, ...]],
) -> dict[str, float]:
    values: dict[str, float] = {}
    condition_summaries = summary.get("condition_summaries", {})
    if isinstance(condition_summaries, dict):
        for condition, info in condition_summaries.items():
            if not isinstance(info, dict):
                continue
            metrics = info.get("metrics", {})
            if not isinstance(metrics, dict):
                continue
            parsed = None
            for key, value in metrics.items():
                metric_name = str(key).split("/")[-1].replace("_mean", "")
                if _metric_matches(metric_name, aliases_by_metric.get(canonical_metric, (canonical_metric,))):
                    parsed = _mean_value(value)
                    break
            if parsed is not None:
                values[str(condition)] = parsed

    metrics_summary = summary.get("metrics_summary", {})
    if isinstance(metrics_summary, dict):
        for key, value in metrics_summary.items():
            key_text = str(key)
            if "/" in key_text:
                condition, metric_name = key_text.rsplit("/", 1)
                metric_name = metric_name.replace("_mean", "")
                if _metric_matches(metric_name, aliases_by_metric.get(canonical_metric, (canonical_metric,))):
                    parsed = _mean_value(value)
                    if parsed is not None:
                        values[condition] = parsed
                continue
            if _metric_matches(key_text, aliases_by_metric.get(canonical_metric, (canonical_metric,))):
                if isinstance(value, dict):
                    for condition, condition_value in value.items():
                        parsed = _mean_value(condition_value)
                        if parsed is not None:
                            values[str(condition)] = parsed

    best_run = summary.get("best_run", {})
    if not values and isinstance(best_run, dict):
        metrics = best_run.get("metrics", {})
        if isinstance(metrics, dict):
            for key, value in metrics.items():
                key_text = str(key)
                if "/" not in key_text:
                    continue
                condition, metric_name = key_text.rsplit("/", 1)
                if _metric_matches(metric_name, aliases_by_metric.get(canonical_metric, (canonical_metric,))):
                    parsed = _mean_value(value)
                    if parsed is not None:
                        values[condition] = parsed
    return values


def _collect_classification_metric_values(summary: dict[str, Any], canonical_metric: str) -> dict[str, float]:
    return _collect_metric_values(summary, canonical_metric, _CLASSIFICATION_METRIC_ALIASES)


def plot_classification_metric_comparisons(summary: dict[str, Any], output_dir: Path) -> list[Path]:
    """Generate Accuracy/F1/Precision/Recall/ROC-AUC comparison charts when logged."""
    generated: list[Path] = []
    for canonical_metric, filename in _CLASSIFICATION_METRIC_FILENAMES.items():
        values = _collect_classification_metric_values(summary, canonical_metric)
        if not values:
            continue
        metric_label = canonical_metric.replace("_", "-").upper() if canonical_metric == "roc_auc" else canonical_metric.title()
        path = plot_metric_bar_comparison(
            values,
            output_dir / filename,
            metric_label=metric_label,
            title=_CLASSIFICATION_METRIC_TITLES[canonical_metric],
        )
        if path:
            generated.append(path)
    return generated


def _collect_continuous_metric_values(summary: dict[str, Any], canonical_metric: str) -> dict[str, float]:
    return _collect_metric_values(summary, canonical_metric, _CONTINUOUS_METRIC_ALIASES)


def plot_continuous_metric_comparisons(summary: dict[str, Any], output_dir: Path) -> list[Path]:
    """Generate MAE/MSE/RMSE/R2 comparison charts when regression metrics are logged."""
    generated: list[Path] = []
    for canonical_metric, filename in _CONTINUOUS_METRIC_FILENAMES.items():
        values = _collect_continuous_metric_values(summary, canonical_metric)
        if not values:
            continue
        label = "R2" if canonical_metric == "r2" else canonical_metric.upper()
        path = plot_metric_bar_comparison(
            values,
            output_dir / filename,
            metric_label=label,
            title=_CONTINUOUS_METRIC_TITLES[canonical_metric],
        )
        if path:
            generated.append(path)
    return generated


def _load_prediction_artifacts(run_dir: Path) -> list[dict[str, Any]]:
    artifact_names = {
        "predictions.json",
        "classification_predictions.json",
        "regression_predictions.json",
        "test_predictions.json",
        "fold_predictions.json",
        "prediction_residuals.json",
        "prediction_artifacts.json",
    }
    artifacts: list[dict[str, Any]] = []
    for path in sorted(run_dir.rglob("*.json")):
        if path.name not in artifact_names:
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        entries = data if isinstance(data, list) else [data]
        for entry in entries:
            if isinstance(entry, dict):
                entry = dict(entry)
                entry.setdefault("_source_path", str(path))
                artifacts.append(entry)
    return artifacts


def _numeric_sequence(value: Any) -> list[float]:
    if not isinstance(value, list):
        return []
    result: list[float] = []
    for item in value:
        parsed = _mean_value(item)
        if parsed is None:
            return []
        result.append(parsed)
    return result


def _continuous_predictions_from_artifact(artifact: dict[str, Any]) -> tuple[list[float], list[float], list[float]] | None:
    y_true_raw = (
        artifact.get("y_true")
        or artifact.get("observed")
        or artifact.get("actual")
        or artifact.get("labels")
        or artifact.get("targets")
    )
    y_pred_raw = (
        artifact.get("y_pred")
        or artifact.get("predicted")
        or artifact.get("predictions")
        or artifact.get("forecast")
        or artifact.get("y_hat")
    )
    y_true = _numeric_sequence(y_true_raw)
    y_pred = _numeric_sequence(y_pred_raw)
    length = min(len(y_true), len(y_pred))
    if length == 0:
        return None
    y_true = y_true[:length]
    y_pred = y_pred[:length]
    residuals = [actual - predicted for actual, predicted in zip(y_true, y_pred)]
    return y_true, y_pred, residuals


def _binary_predictions_from_artifact(artifact: dict[str, Any]) -> tuple[list[int], list[int], list[float]] | None:
    y_true_raw = artifact.get("y_true") or artifact.get("labels") or artifact.get("targets")
    y_pred_raw = artifact.get("y_pred") or artifact.get("predictions") or artifact.get("predicted_labels")
    y_score_raw = artifact.get("y_score") or artifact.get("scores") or artifact.get("probabilities") or artifact.get("y_proba") or artifact.get("proba")
    y_true = [int(round(value)) for value in _numeric_sequence(y_true_raw)]
    y_pred_values = _numeric_sequence(y_pred_raw)
    y_score_values = _numeric_sequence(y_score_raw)
    if not y_true:
        return None
    if any(value not in {0, 1} for value in y_true):
        return None
    if y_pred_values:
        y_pred = [int(round(value)) for value in y_pred_values]
        if any(value not in {0, 1} for value in y_pred):
            return None
    elif y_score_values:
        y_pred = [1 if value >= 0.5 else 0 for value in y_score_values]
    else:
        return None
    if not y_score_values:
        y_score_values = [float(value) for value in y_pred]
    length = min(len(y_true), len(y_pred), len(y_score_values))
    if length == 0:
        return None
    return y_true[:length], y_pred[:length], y_score_values[:length]


def plot_confusion_matrix_from_predictions(
    artifact: dict[str, Any],
    output_path: Path,
    *,
    title: str = "Confusion Matrix",
) -> Path | None:
    parsed = _binary_predictions_from_artifact(artifact)
    if not HAS_MATPLOTLIB or parsed is None:
        return None
    y_true, y_pred, _ = parsed
    labels = sorted(set(y_true) | set(y_pred))
    if not labels:
        return None
    index = {label: pos for pos, label in enumerate(labels)}
    matrix = np.zeros((len(labels), len(labels)), dtype=int)
    for true_label, pred_label in zip(y_true, y_pred):
        matrix[index[true_label], index[pred_label]] += 1

    _setup_academic_style()
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    image = ax.imshow(matrix, cmap="Blues")
    ax.set_xticks(range(len(labels)))
    _apply_readable_xticklabels(ax, [str(label) for label in labels], max_chars=12)
    ax.set_yticks(range(len(labels)))
    _apply_readable_yticklabels(ax, [str(label) for label in labels], max_chars=14)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title(title)
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            color = "white" if matrix[i, j] > matrix.max() / 2 else "#333333"
            ax.text(j, i, str(matrix[i, j]), ha="center", va="center", color=color, fontweight="bold")
    fig.colorbar(image, ax=ax, shrink=0.8)
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved confusion matrix: %s", output_path)
    return output_path


def _roc_points(y_true: list[int], y_score: list[float]) -> tuple[list[float], list[float], float] | None:
    positives = sum(1 for value in y_true if value == 1)
    negatives = len(y_true) - positives
    if positives == 0 or negatives == 0:
        return None
    thresholds = sorted(set(y_score), reverse=True)
    thresholds = [float("inf"), *thresholds, -float("inf")]
    fprs: list[float] = []
    tprs: list[float] = []
    for threshold in thresholds:
        tp = fp = 0
        for true_label, score in zip(y_true, y_score):
            predicted_positive = score >= threshold
            if predicted_positive and true_label == 1:
                tp += 1
            elif predicted_positive and true_label == 0:
                fp += 1
        tprs.append(tp / positives)
        fprs.append(fp / negatives)
    auc = 0.0
    pairs = sorted(zip(fprs, tprs))
    for (x0, y0), (x1, y1) in zip(pairs, pairs[1:]):
        auc += (x1 - x0) * (y0 + y1) / 2
    return [pair[0] for pair in pairs], [pair[1] for pair in pairs], auc


def plot_roc_curve_from_predictions(
    artifact: dict[str, Any],
    output_path: Path,
    *,
    title: str = "ROC Curve",
) -> Path | None:
    parsed = _binary_predictions_from_artifact(artifact)
    if not HAS_MATPLOTLIB or parsed is None:
        return None
    y_true, _, y_score = parsed
    roc = _roc_points(y_true, y_score)
    if roc is None:
        return None
    fprs, tprs, auc = roc
    _setup_academic_style()
    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    ax.plot(fprs, tprs, color=_PAUL_TOL_BRIGHT[0], linewidth=2.5, label=f"ROC-AUC = {auc:.3f}")
    ax.plot([0, 1], [0, 1], "--", color="#666666", linewidth=1.2, label="Random")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate / Recall")
    ax.set_title(title)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.legend(loc="lower right")
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved ROC curve: %s", output_path)
    return output_path


def plot_predicted_vs_observed(
    artifact: dict[str, Any],
    output_path: Path,
    *,
    title: str = "Predicted vs. Observed",
) -> Path | None:
    parsed = _continuous_predictions_from_artifact(artifact)
    if not HAS_MATPLOTLIB or parsed is None:
        return None
    observed, predicted, _ = parsed
    if not observed or not predicted:
        return None
    low = min(min(observed), min(predicted))
    high = max(max(observed), max(predicted))
    if not math.isfinite(low) or not math.isfinite(high):
        return None

    _setup_academic_style()
    fig, ax = plt.subplots(figsize=(5.4, 5.0))
    ax.scatter(observed, predicted, color=_PAUL_TOL_BRIGHT[0], alpha=0.72, edgecolor="white", linewidth=0.4)
    ax.plot([low, high], [low, high], "--", color="#666666", linewidth=1.3, label="Ideal")
    ax.set_xlabel("Observed response")
    ax.set_ylabel("Predicted response")
    ax.set_title(title)
    ax.legend(loc="best")
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved predicted-vs-observed plot: %s", output_path)
    return output_path


def plot_residual_diagnostics(
    artifact: dict[str, Any],
    output_dir: Path,
    *,
    condition: str = "model",
) -> list[Path]:
    parsed = _continuous_predictions_from_artifact(artifact)
    if not HAS_MATPLOTLIB or parsed is None:
        return []
    _, predicted, residuals = parsed
    if not residuals:
        return []

    generated: list[Path] = []
    _setup_academic_style()

    fig, ax = plt.subplots(figsize=(5.8, 4.6))
    ax.scatter(predicted, residuals, color=_PAUL_TOL_BRIGHT[1], alpha=0.72, edgecolor="white", linewidth=0.4)
    ax.axhline(0, color="#666666", linestyle="--", linewidth=1.2)
    ax.set_xlabel("Predicted response")
    ax.set_ylabel("Residual (observed - predicted)")
    ax.set_title(f"Residual plot: {_format_cond_name(condition)}")
    fig.tight_layout()
    residual_path = _ensure_dir(output_dir / "residual_plot.png")
    _save_figure_without_title(fig, residual_path)
    plt.close(fig)
    generated.append(residual_path)
    logger.info("Saved residual plot: %s", residual_path)

    fig, ax = plt.subplots(figsize=(5.8, 4.4))
    ax.hist(residuals, bins=min(20, max(6, int(math.sqrt(len(residuals))))), color=_PAUL_TOL_BRIGHT[2], alpha=0.82, edgecolor="white")
    ax.axvline(0, color="#666666", linestyle="--", linewidth=1.2)
    ax.set_xlabel("Residual (observed - predicted)")
    ax.set_ylabel("Count")
    ax.set_title(f"Residual distribution: {_format_cond_name(condition)}")
    fig.tight_layout()
    residual_dist_path = _ensure_dir(output_dir / "residual_distribution.png")
    _save_figure_without_title(fig, residual_dist_path)
    plt.close(fig)
    generated.append(residual_dist_path)
    logger.info("Saved residual distribution: %s", residual_dist_path)

    return generated


def plot_kfold_boxplot(
    summary: dict[str, Any],
    output_path: Path,
    *,
    metric_key: str = "accuracy",
    title: str = "80/20 train/test k-fold cross-validation",
) -> Path | None:
    if not HAS_MATPLOTLIB:
        return None
    candidates = (
        summary.get("kfold_metrics")
        or summary.get("cv_metrics")
        or summary.get("cross_validation_metrics")
        or summary.get("fold_metrics")
    )
    if not isinstance(candidates, dict):
        return None

    series_by_condition: dict[str, list[float]] = {}
    for condition, values in candidates.items():
        metric_values: list[float] = []
        if isinstance(values, dict):
            raw = (
                values.get(metric_key)
                or values.get("accuracy")
                or values.get("roc_auc")
                or values.get("f1")
                or values.get("mae")
                or values.get("rmse")
                or values.get("mse")
                or values.get("r2")
            )
            if isinstance(raw, list):
                metric_values = [value for value in _numeric_sequence(raw) if math.isfinite(value)]
        elif isinstance(values, list):
            for item in values:
                if isinstance(item, dict):
                    parsed = _mean_value(
                        item.get(metric_key)
                        or item.get("accuracy")
                        or item.get("roc_auc")
                        or item.get("f1")
                        or item.get("mae")
                        or item.get("rmse")
                        or item.get("mse")
                        or item.get("r2")
                    )
                else:
                    parsed = _mean_value(item)
                if parsed is not None:
                    metric_values.append(parsed)
        if metric_values:
            series_by_condition[str(condition)] = metric_values

    if not series_by_condition:
        return None

    _setup_academic_style()
    names = list(series_by_condition)
    data = [series_by_condition[name] for name in names]
    fig, ax = plt.subplots(figsize=(max(6.5, len(names) * 0.8), 4.8))
    box = ax.boxplot(data, patch_artist=True, labels=[_format_cond_name(name) for name in names])
    _apply_readable_xticklabels(ax, [_format_cond_name(name) for name in names], max_chars=12)
    colors = _assign_method_colors(names)
    for patch, color in zip(box["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.75)
    ax.set_xlabel("Method / condition")
    ax.set_ylabel(_metric_display_label(metric_key))
    ax.set_title(title)
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    fig.tight_layout()
    _save_figure_without_title(fig, output_path)
    plt.close(fig)
    logger.info("Saved k-fold CV boxplot: %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# 8. All-in-one: generate all charts from run directory
# ---------------------------------------------------------------------------


def generate_all_charts(
    run_dir: Path,
    output_dir: Path | None = None,
    *,
    metric_key: str = "val_loss",
    metric_direction: str = "minimize",
) -> list[Path]:
    """Scan run_dir and generate all applicable charts.

    Returns list of generated image paths.
    """
    if not HAS_MATPLOTLIB:
        logger.warning("matplotlib not available — skipping chart generation")
        return []

    if output_dir is None:
        output_dir = run_dir / "charts"
    output_dir.mkdir(parents=True, exist_ok=True)

    generated: list[Path] = []

    # Collect experiment runs
    runs: list[dict[str, Any]] = []
    for stage_subdir in sorted(run_dir.glob("stage-*/runs")):
        for run_file in sorted(stage_subdir.glob("*.json")):
            try:
                data = json.loads(run_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    runs.append(data)
            except (json.JSONDecodeError, OSError):
                continue

    # 1. Metric trajectory
    path = plot_metric_trajectory(
        runs, metric_key, output_dir / "metric_trajectory.png"
    )
    if path:
        generated.append(path)

    # 2. Load experiment summary for condition-based charts
    # BUG-215: Also search stage-14* versioned dirs when stage-14/ is missing.
    summary_path = run_dir / "stage-14" / "experiment_summary.json"
    if not summary_path.exists():
        for _s14 in sorted(run_dir.glob("stage-14*"), reverse=True):
            _alt = _s14 / "experiment_summary.json"
            if _alt.exists():
                summary_path = _alt
                break
    if summary_path.exists():
        try:
            summary = json.loads(summary_path.read_text(encoding="utf-8"))

            cs = summary.get("condition_summaries", {})
            if cs:
                # 2a. Condition comparison (bar chart with CI)
                path = plot_condition_comparison(
                    cs, output_dir / "method_comparison.png",
                    metric_key=metric_key,
                )
                if path:
                    generated.append(path)

                # 2b. Ablation delta chart (horizontal bars)
                path = plot_ablation_deltas(
                    cs, output_dir / "ablation_analysis.png",
                    metric_key=metric_key,
                    higher_is_better=(metric_direction != "minimize"),
                )
                if path:
                    generated.append(path)

                # 2c. Metric heatmap (condition × metric)
                path = plot_metric_heatmap(
                    cs, output_dir / "metric_heatmap.png",
                )
                if path:
                    generated.append(path)

            # 2d. Prediction/classification charts requested for categorical-response models.
            generated.extend(plot_classification_metric_comparisons(summary, output_dir))
            generated.extend(plot_continuous_metric_comparisons(summary, output_dir))

            path = plot_feature_inclusion_probability(
                summary,
                output_dir / "feature_inclusion_probability.png",
            )
            if path:
                generated.append(path)

            path = plot_kfold_boxplot(
                summary,
                output_dir / "kfold_80_20_cv_boxplot.png",
                metric_key=metric_key or "accuracy",
            )
            if path:
                generated.append(path)

            # 2e. Raw metrics comparison (fallback, limited)
            ms = summary.get("metrics_summary", {})
            if ms:
                ms = {k: v for k, v in ms.items() if not _is_excluded_metric(k)}
                if ms:
                    path = plot_experiment_comparison(
                        ms, output_dir / "experiment_comparison.png"
                    )
                    if path:
                        generated.append(path)
        except (json.JSONDecodeError, OSError):
            pass

    prediction_artifacts = _load_prediction_artifacts(run_dir)
    if prediction_artifacts:
        first_artifact = prediction_artifacts[0]
        condition = str(first_artifact.get("condition") or first_artifact.get("model") or "model")
        path = plot_confusion_matrix_from_predictions(
            first_artifact,
            output_dir / "confusion_matrix.png",
            title=f"Confusion matrix: {_format_cond_name(condition)}",
        )
        if path:
            generated.append(path)
        path = plot_roc_curve_from_predictions(
            first_artifact,
            output_dir / "roc_curve.png",
            title=f"ROC curve: {_format_cond_name(condition)}",
        )
        if path:
            generated.append(path)
        path = plot_predicted_vs_observed(
            first_artifact,
            output_dir / "predicted_vs_observed.png",
            title=f"Predicted vs. observed: {_format_cond_name(condition)}",
        )
        if path:
            generated.append(path)
        generated.extend(
            plot_residual_diagnostics(
                first_artifact,
                output_dir,
                condition=condition,
            )
        )

    # 3. Iteration scores
    iter_path = run_dir / "iteration_summary.json"
    if iter_path.exists():
        try:
            iter_data = json.loads(iter_path.read_text(encoding="utf-8"))
            scores = iter_data.get("iteration_scores", [])
            threshold = iter_data.get("quality_threshold", 7.0)
            path = plot_iteration_scores(
                scores, output_dir / "iteration_scores.png", threshold=threshold
            )
            if path:
                generated.append(path)
        except (json.JSONDecodeError, OSError):
            pass

    logger.info("Generated %d chart(s) in %s", len(generated), output_dir)
    return generated
