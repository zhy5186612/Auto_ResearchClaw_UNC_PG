"""HITL Terminal UI components."""
