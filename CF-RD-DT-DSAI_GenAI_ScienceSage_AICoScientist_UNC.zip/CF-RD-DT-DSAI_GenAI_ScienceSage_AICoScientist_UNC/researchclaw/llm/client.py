"""Lightweight OpenAI-compatible LLM client — stdlib only.

Features:
  - Model fallback chain (gpt-5.2 → gpt-5.1 → gpt-4.1 → gpt-4o)
  - Auto-detect max_tokens vs max_completion_tokens per model
  - Cloudflare User-Agent bypass
  - Exponential backoff retry with jitter
  - JSON mode support
  - Streaming disabled (sync only)
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# Models that require max_completion_tokens instead of max_tokens
_NEW_PARAM_MODELS = frozenset(
    {
        "o3",
        "o3-mini",
        "o4-mini",
        "gpt-5",
        "gpt-5.1",
        "gpt-5.2",
        "gpt-5.4",
    }
)

_NO_TEMPERATURE_MODELS = frozenset(
    {
        "o3",
        "o3-mini",
        "o4-mini",
    }
)

_DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

_MAX_BACKOFF_SEC = 300  # 5-minute ceiling for retry delays
_DEFAULT_MIN_MAX_TOKENS = 16384


def _extra_headers_from_env() -> dict[str, str]:
    raw_extra_headers = os.environ.get("AZURE_CUSTOM_HEADERS", "").strip()
    if not raw_extra_headers:
        return {}
    try:
        parsed = json.loads(raw_extra_headers)
    except Exception:  # noqa: BLE001
        logger.warning("Ignoring invalid AZURE_CUSTOM_HEADERS JSON")
        return {}
    if not isinstance(parsed, dict):
        return {}
    return {str(k): str(v) for k, v in parsed.items()}


@dataclass
class LLMResponse:
    """Parsed response from the LLM API."""

    content: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    finish_reason: str = ""
    truncated: bool = False
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMConfig:
    """Configuration for the LLM client."""

    base_url: str
    api_key: str
    wire_api: str = "chat_completions"
    primary_model: str = "gpt-4o"
    fallback_models: list[str] = field(
        default_factory=lambda: ["gpt-4.1", "gpt-4o-mini"]
    )
    max_tokens: int = _DEFAULT_MIN_MAX_TOKENS
    min_max_tokens: int = _DEFAULT_MIN_MAX_TOKENS
    temperature: float = 0.7
    max_retries: int = 3
    retry_base_delay: float = 2.0
    timeout_sec: int = 300
    user_agent: str = _DEFAULT_USER_AGENT
    # MetaClaw bridge: extra headers for proxy requests
    extra_headers: dict[str, str] = field(default_factory=dict)
    # MetaClaw bridge: fallback URL if primary (proxy) is unreachable
    fallback_url: str = ""
    fallback_api_key: str = ""


class LLMClient:
    """Stateless OpenAI-compatible chat completion client."""

    def __init__(self, config: LLMConfig) -> None:
        self.config = config
        self._model_chain = [config.primary_model] + list(config.fallback_models)
        self._anthropic = None  # Will be set by from_rc_config if needed
        self._azure_access_token: str = ""
        self._azure_access_token_expiry: float = 0.0

    @staticmethod
    def _normalize_wire_api(wire_api: str) -> str:
        normalized = (wire_api or "").strip().lower().replace("-", "_")
        if normalized in ("", "chat/completions", "chat_completions"):
            return "chat_completions"
        if normalized == "responses":
            return "responses"
        return normalized

    def _endpoint_path(self) -> str:
        if self._normalize_wire_api(self.config.wire_api) == "responses":
            return "/responses"
        return "/chat/completions"

    def _endpoint_url(self, base_url: str) -> str:
        trimmed = base_url.rstrip("/")
        url = f"{trimmed}{self._endpoint_path()}"

        # Azure deployment-style endpoints need api-version query.
        if "/openai/deployments/" in trimmed and "api-version=" not in url:
            api_version = os.environ.get("OPEN_API_VERSION", "").strip()
            if api_version:
                sep = "&" if "?" in url else "?"
                url = f"{url}{sep}api-version={urllib.parse.quote(api_version, safe='')}"

        return url

    def _apply_token_floor(self, max_tokens: int | None) -> int:
        requested = max_tokens or self.config.max_tokens
        floor = max(1, self.config.min_max_tokens)
        return max(requested, floor)

    @staticmethod
    def _model_has_prefix(model: str, prefixes: set[str] | frozenset[str]) -> bool:
        model_l = (model or "").strip().lower()
        return any(model_l.startswith(prefix) for prefix in prefixes)

    @staticmethod
    def _supports_temperature(model: str) -> bool:
        return not LLMClient._model_has_prefix(model, _NO_TEMPERATURE_MODELS)

    @classmethod
    def from_rc_config(cls, rc_config: Any) -> LLMClient:
        from researchclaw.llm import PROVIDER_PRESETS

        provider = getattr(rc_config.llm, "provider", "openai")
        preset = PROVIDER_PRESETS.get(provider, {})
        preset_base_url = preset.get("base_url")

        api_key = str(
            rc_config.llm.api_key or os.environ.get(rc_config.llm.api_key_env, "") or ""
        )

        # Use preset base_url if available and config doesn't override
        base_url = rc_config.llm.base_url or preset_base_url or ""

        # Preserve original URL/key before MetaClaw bridge override
        # (needed for Anthropic adapter which should always talk directly
        # to the Anthropic API, not through the OpenAI-compatible proxy).
        original_base_url = base_url
        original_api_key = api_key

        # MetaClaw bridge: if enabled, point to proxy and set up fallback
        bridge = getattr(rc_config, "metaclaw_bridge", None)
        fallback_url = ""
        fallback_api_key = ""

        if bridge and getattr(bridge, "enabled", False):
            fallback_url = base_url
            fallback_api_key = api_key
            base_url = bridge.proxy_url
            if bridge.fallback_url:
                fallback_url = bridge.fallback_url
            if bridge.fallback_api_key:
                fallback_api_key = bridge.fallback_api_key

        # Optional: pass through custom Azure/enterprise routing headers.
        # Example env:
        #   AZURE_CUSTOM_HEADERS={"userid":"...","project-name":"..."}
        extra_headers = _extra_headers_from_env()

        config = LLMConfig(
            base_url=base_url,
            api_key=api_key,
            wire_api=getattr(rc_config.llm, "wire_api", "chat_completions"),
            primary_model=rc_config.llm.primary_model or "gpt-4o",
            fallback_models=list(rc_config.llm.fallback_models or []),
            min_max_tokens=max(
                1,
                getattr(
                    rc_config.llm,
                    "min_max_tokens",
                    _DEFAULT_MIN_MAX_TOKENS,
                ),
            ),
            extra_headers=extra_headers,
            fallback_url=fallback_url,
            fallback_api_key=fallback_api_key,
        )
        client = cls(config)

        # Detect Anthropic or Kimi-Anthropic provider — use original URL/key (not the
        # MetaClaw proxy URL which is OpenAI-compatible only).
        if provider in ("anthropic", "kimi-anthropic"):
            from .anthropic_adapter import AnthropicAdapter

            client._anthropic = AnthropicAdapter(
                original_base_url, original_api_key, config.timeout_sec
            )
        return client

    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        json_mode: bool = False,
        system: str | None = None,
        strip_thinking: bool = False,
    ) -> LLMResponse:
        """Send a chat completion request with retry and fallback.

        Args:
            messages: List of {role, content} dicts.
            model: Override model (skips fallback chain).
            max_tokens: Override max token count.
            temperature: Override temperature.
            json_mode: Request JSON response format.
            system: Prepend a system message.
            strip_thinking: If True, strip <think>…</think> reasoning
                tags from the response content.  Use this when the
                output will be written to paper/script artifacts but
                NOT for general chat calls (to avoid corrupting
                legitimate content).

        Returns:
            LLMResponse with content and metadata.
        """
        if system:
            messages = [{"role": "system", "content": system}] + messages

        models = [model] if model else self._model_chain
        max_tok = self._apply_token_floor(max_tokens)
        temp = temperature if temperature is not None else self.config.temperature

        last_error: Exception | None = None

        for m in models:
            try:
                resp = self._call_with_retry(m, messages, max_tok, temp, json_mode)
                if strip_thinking:
                    from researchclaw.utils.thinking_tags import strip_thinking_tags

                    resp = LLMResponse(
                        content=strip_thinking_tags(resp.content),
                        model=resp.model,
                        prompt_tokens=resp.prompt_tokens,
                        completion_tokens=resp.completion_tokens,
                        total_tokens=resp.total_tokens,
                        finish_reason=resp.finish_reason,
                        truncated=resp.truncated,
                        raw=resp.raw,
                    )
                return resp
            except Exception as exc:  # noqa: BLE001
                logger.warning("Model %s failed: %s. Trying next.", m, exc)
                last_error = exc

        raise RuntimeError(
            f"All models failed. Last error: {last_error}"
        ) from last_error

    def preflight(self) -> tuple[bool, str]:
        """Quick connectivity check - one minimal chat call.

        Returns (success, message).
        Distinguishes: 401 (bad key), 403 (model forbidden),
                       404 (bad endpoint), 429 (rate limited), timeout.
        """
        is_reasoning = self._model_has_prefix(
            self.config.primary_model, _NEW_PARAM_MODELS
        )
        min_tokens = 64 if is_reasoning else 1
        try:
            _ = self.chat(
                [{"role": "user", "content": "ping"}],
                max_tokens=min_tokens,
                temperature=0,
            )
            return True, f"OK - model {self.config.primary_model} responding"
        except urllib.error.HTTPError as e:
            status_map = {
                401: "Invalid API key",
                403: f"Model {self.config.primary_model} not allowed for this key",
                404: f"Endpoint not found: {self._endpoint_url(self.config.base_url)}",
                429: "Rate limited - try again in a moment",
            }
            msg = status_map.get(e.code, f"HTTP {e.code}")
            return False, msg
        except (urllib.error.URLError, OSError) as e:
            return False, f"Connection failed: {e}"
        except RuntimeError as e:
            # chat() wraps errors in RuntimeError; extract original HTTPError
            cause = e.__cause__
            if isinstance(cause, urllib.error.HTTPError):
                status_map = {
                    401: "Invalid API key",
                    403: f"Model {self.config.primary_model} not allowed for this key",
                    404: f"Endpoint not found: {self._endpoint_url(self.config.base_url)}",
                    429: "Rate limited - try again in a moment",
                }
                msg = status_map.get(cause.code, f"HTTP {cause.code}")
                return False, msg
            return False, f"All models failed: {e}"

    def _call_with_retry(
        self,
        model: str,
        messages: list[dict[str, str]],
        max_tokens: int,
        temperature: float,
        json_mode: bool,
    ) -> LLMResponse:
        """Call with exponential backoff retry."""
        for attempt in range(self.config.max_retries):
            try:
                return self._raw_call(
                    model, messages, max_tokens, temperature, json_mode
                )
            except urllib.error.HTTPError as e:
                status = e.code
                body = ""
                try:
                    body = e.read().decode()[:500]
                except Exception:  # noqa: BLE001
                    pass

                # Non-retryable errors
                if status == 403 and "not allowed to use model" in body:
                    raise  # Model not available — let fallback handle

                # 400 is normally non-retryable, but some providers
                # (Azure OpenAI) return 400 during overload / rate-limit.
                # Retry if the body hints at a transient issue.
                if status == 400:
                    _transient_400 = any(
                        kw in body.lower()
                        for kw in (
                            "rate limit",
                            "ratelimit",
                            "overloaded",
                            "temporarily",
                            "capacity",
                            "throttl",
                            "too many",
                            "retry",
                        )
                    )
                    if not _transient_400:
                        raise  # Genuine bad request — don't retry

                # Retryable: 429 (rate limit), transient 400, 500, 502, 503, 504,
                # 529 (Anthropic overloaded)
                if status in (400, 429, 500, 502, 503, 504, 529):
                    delay = min(
                        self.config.retry_base_delay * (2**attempt),
                        _MAX_BACKOFF_SEC,
                    )
                    # Add jitter
                    import random

                    delay += random.uniform(0, delay * 0.3)
                    logger.info(
                        "Retry %d/%d for %s (HTTP %d). Waiting %.1fs.",
                        attempt + 1,
                        self.config.max_retries,
                        model,
                        status,
                        delay,
                    )
                    time.sleep(delay)
                    continue

                raise  # Other HTTP errors
            except urllib.error.URLError:
                if attempt < self.config.max_retries - 1:
                    delay = min(
                        self.config.retry_base_delay * (2**attempt),
                        _MAX_BACKOFF_SEC,
                    )
                    time.sleep(delay)
                    continue
                raise
            except (TimeoutError, OSError) as exc:
                # Covers TimeoutError, ConnectionResetError, IncompleteRead, etc.
                if attempt < self.config.max_retries - 1:
                    delay = self.config.retry_base_delay * (2**attempt)
                    logger.info(
                        "Retry %d/%d for %s (%s). Waiting %.1fs.",
                        attempt + 1,
                        self.config.max_retries,
                        model,
                        type(exc).__name__,
                        delay,
                    )
                    time.sleep(delay)
                    continue
                raise

        # All retries exhausted
        raise RuntimeError(
            f"LLM call failed after {self.config.max_retries} retries for model {model}"
        )

    @staticmethod
    def _request_headers(req: urllib.request.Request) -> dict[str, str]:
        return {key: value for key, value in req.header_items()}

    def _open_json_request(
        self,
        req: urllib.request.Request,
        *,
        timeout: int,
        max_redirects: int = 3,
    ) -> dict[str, Any]:
        current_req = req
        for _ in range(max_redirects + 1):
            try:
                with urllib.request.urlopen(current_req, timeout=timeout) as resp:
                    return json.loads(resp.read())
            except urllib.error.HTTPError as exc:
                if exc.code not in (307, 308):
                    raise
                location = exc.headers.get("Location") if exc.headers else None
                if not location:
                    raise
                redirect_url = urllib.parse.urljoin(current_req.full_url, location)
                current_req = urllib.request.Request(
                    redirect_url,
                    data=current_req.data,
                    headers=self._request_headers(current_req),
                    method=current_req.get_method(),
                )
        raise RuntimeError(f"Too many redirects for request to {req.full_url}")

    def _raw_call(
        self,
        model: str,
        messages: list[dict[str, str]],
        max_tokens: int,
        temperature: float,
        json_mode: bool,
    ) -> LLMResponse:
        """Make a single API call."""

        # Use Anthropic adapter if configured
        if self._anthropic:
            data = self._anthropic.chat_completion(
                model, messages, max_tokens, temperature, json_mode
            )
        else:
            # Original OpenAI logic
            # Copy messages to avoid mutating the caller's list (important for
            # retries and model-fallback — each attempt must start from the
            # original, un-modified messages).
            msgs = [dict(m) for m in messages]

            # MiniMax API requires temperature in [0, 1.0]
            _temp = temperature
            if "api.minimax.io" in self.config.base_url:
                _temp = max(0.0, min(_temp, 1.0))

            if self._normalize_wire_api(self.config.wire_api) == "responses":
                body = self._build_responses_body(model, msgs, max_tokens, _temp)
            else:
                body = {
                    "model": model,
                    "messages": msgs,
                }
                if self._supports_temperature(model):
                    body["temperature"] = _temp

                # Use correct token parameter based on model
                if self._model_has_prefix(model, _NEW_PARAM_MODELS):
                    reasoning_min = 32768
                    body["max_completion_tokens"] = max(max_tokens, reasoning_min)
                else:
                    body["max_tokens"] = max_tokens

            if json_mode:
                # Many OpenAI-compatible providers don't support the
                # response_format parameter and return HTTP 400.
                # Fall back to system-prompt injection for known-incompatible
                # models (Claude, DeepSeek, Qwen, etc.) and the responses API.
                _no_response_format = (
                    model.lower().startswith("claude")
                    or model.lower().startswith("deepseek")
                    or model.lower().startswith("qwen")
                    or model.lower().startswith("yi-")
                    or model.lower().startswith("glm")
                    or model.lower().startswith("moonshot")
                    or self._normalize_wire_api(self.config.wire_api) == "responses"
                )
                if _no_response_format:
                    _json_hint = (
                        "You MUST respond with valid JSON only. "
                        "Do not include any text outside the JSON object."
                    )
                    # Prepend to existing system message or add as new one
                    if msgs and msgs[0]["role"] == "system":
                        msgs[0]["content"] = _json_hint + "\n\n" + msgs[0]["content"]
                    else:
                        msgs.insert(0, {"role": "system", "content": _json_hint})
                else:
                    body["response_format"] = {"type": "json_object"}

            payload = json.dumps(body).encode("utf-8")
            url = self._endpoint_url(self.config.base_url)
            auth_key = self._resolve_auth_key()

            headers = {
                "Content-Type": "application/json",
                "User-Agent": self.config.user_agent,
            }
            if auth_key:
                headers["Authorization"] = f"Bearer {auth_key}"
            # MetaClaw bridge: inject extra headers (session ID, stage info, etc.)
            headers.update(self.config.extra_headers)

            req = urllib.request.Request(url, data=payload, headers=headers)

            try:
                data = self._open_json_request(req, timeout=self.config.timeout_sec)
            except (urllib.error.URLError, OSError) as exc:
                # MetaClaw bridge: fallback to direct LLM if proxy unreachable
                if self.config.fallback_url:
                    logger.warning(
                        "Primary endpoint unreachable, falling back to %s: %s",
                        self.config.fallback_url,
                        exc,
                    )
                    fallback_url = self._endpoint_url(self.config.fallback_url)
                    fallback_key = self.config.fallback_api_key or self.config.api_key
                    fallback_headers = {
                        "Content-Type": "application/json",
                        "User-Agent": self.config.user_agent,
                    }
                    if fallback_key:
                        fallback_headers["Authorization"] = f"Bearer {fallback_key}"
                    fallback_req = urllib.request.Request(
                        fallback_url, data=payload, headers=fallback_headers
                    )
                    data = self._open_json_request(
                        fallback_req, timeout=self.config.timeout_sec
                    )
                else:
                    raise

        if not isinstance(data, dict):
            raise ValueError(
                f"Malformed API response: expected JSON object, got {type(data).__name__}: {data}"
            )

        # Handle API error responses
        if "error" in data and data["error"] is not None:
            error_info = data["error"]
            if isinstance(error_info, dict):
                error_msg = str(error_info.get("message", str(error_info)))
                error_type = str(error_info.get("type", "api_error"))
            else:
                error_msg = str(error_info)
                error_type = "api_error"
            import io

            raise urllib.error.HTTPError(
                "",
                500,
                f"{error_type}: {error_msg}",
                None,
                io.BytesIO(error_msg.encode()),
            )

        if self._normalize_wire_api(self.config.wire_api) == "responses":
            return self._parse_responses_response(data, model)
        return self._parse_chat_completions_response(data, model)

    def _resolve_auth_key(self) -> str:
        """Resolve bearer token/key for the current request.

        Priority:
        1) static configured api_key
        2) OPENAI_API_KEY env via config resolution (already copied into api_key)
        3) Azure AD client-credentials token from env vars
        """
        if self.config.api_key.strip():
            return self.config.api_key.strip()
        return self._get_azure_access_token()

    def _get_azure_access_token(self) -> str:
        """Fetch/cached Azure AD access token when AZURE_* env vars are present."""
        now = time.time()
        if self._azure_access_token and now < (self._azure_access_token_expiry - 60):
            return self._azure_access_token

        tenant = os.environ.get("AZURE_TENANT_ID", "").strip()
        client_id = os.environ.get("AZURE_CLIENT_ID", "").strip()
        client_secret = os.environ.get("AZURE_CLIENT_SECRET", "").strip()
        scope = os.environ.get("COGNITIVE_SERVICES", "").strip()
        if not (tenant and client_id and client_secret and scope):
            return ""

        token_url = (
            f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
        )
        form = urllib.parse.urlencode(
            {
                "client_id": client_id,
                "client_secret": client_secret,
                "scope": scope,
                "grant_type": "client_credentials",
            }
        ).encode("utf-8")
        req = urllib.request.Request(
            token_url,
            data=form,
            method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(req, timeout=min(self.config.timeout_sec, 30)) as resp:
            payload = json.loads(resp.read().decode("utf-8"))

        token = str(payload.get("access_token", "") or "")
        expires_in = int(payload.get("expires_in", 3600) or 3600)
        if token:
            self._azure_access_token = token
            self._azure_access_token_expiry = now + max(expires_in, 60)
        return token

    def _build_responses_body(
        self,
        model: str,
        messages: list[dict[str, str]],
        max_tokens: int,
        temperature: float,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": model,
            "input": self._messages_to_responses_input(messages),
        }
        if self._supports_temperature(model):
            body["temperature"] = temperature
        body["max_output_tokens"] = max_tokens
        return body

    def _messages_to_responses_input(
        self, messages: list[dict[str, str]]
    ) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for message in messages:
            role = str(message.get("role", "user") or "user")
            content = str(message.get("content", "") or "")
            items.append(
                {
                    "role": role,
                    "content": [{"type": "input_text", "text": content}],
                }
            )
        return items

    def _parse_chat_completions_response(
        self, data: dict[str, Any], model: str
    ) -> LLMResponse:
        if "choices" not in data or not data["choices"]:
            raise ValueError(f"Malformed API response: missing choices. Got: {data}")

        choice = data["choices"][0]
        usage = data.get("usage", {})

        message = choice.get("message", {})
        content = message.get("content") or ""

        return LLMResponse(
            content=content,
            model=data.get("model", model),
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            total_tokens=usage.get("total_tokens", 0),
            finish_reason=choice.get("finish_reason", ""),
            truncated=(choice.get("finish_reason", "") == "length"),
            raw=data,
        )

    def _parse_responses_response(
        self, data: dict[str, Any], model: str
    ) -> LLMResponse:
        output_items = data.get("output")
        if not isinstance(output_items, list) or not output_items:
            raise ValueError(
                f"Malformed responses API payload: missing output. Got: {data}"
            )

        chunks: list[str] = []
        finish_reason = str(data.get("status", "") or "")
        truncated = False

        for item in output_items:
            if not isinstance(item, dict):
                continue
            if item.get("type") != "message":
                continue
            content_items = item.get("content")
            if not isinstance(content_items, list):
                continue
            for content_item in content_items:
                if not isinstance(content_item, dict):
                    continue
                if content_item.get("type") == "output_text":
                    text = content_item.get("text")
                    if isinstance(text, str):
                        chunks.append(text)

        incomplete_details = data.get("incomplete_details")
        if isinstance(incomplete_details, dict):
            reason = incomplete_details.get("reason")
            if isinstance(reason, str) and reason:
                finish_reason = reason
                truncated = reason in ("max_output_tokens", "content_filter")

        usage = data.get("usage", {})
        prompt_tokens = 0
        completion_tokens = 0
        total_tokens = 0
        if isinstance(usage, dict):
            prompt_tokens = int(usage.get("input_tokens", 0) or 0)
            completion_tokens = int(usage.get("output_tokens", 0) or 0)
            total_tokens = int(
                usage.get("total_tokens", prompt_tokens + completion_tokens) or 0
            )

        return LLMResponse(
            content="".join(chunks),
            model=data.get("model", model),
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            finish_reason=finish_reason,
            truncated=truncated,
            raw=data,
        )


def create_client_from_yaml(yaml_path: str | None = None) -> LLMClient:
    """Create an LLMClient from the ARC config file.

    Reads base_url and api_key from config.arc.yaml's llm section.
    """
    import yaml as _yaml

    if yaml_path is None:
        yaml_path = "config.yaml"

    with open(yaml_path, encoding="utf-8") as f:
        raw = _yaml.safe_load(f)

    llm_section = raw.get("llm", {})
    api_key = str(
        os.environ.get(
            llm_section.get("api_key_env", "OPENAI_API_KEY"),
            llm_section.get("api_key", ""),
        )
        or ""
    )

    return LLMClient(
        LLMConfig(
            base_url=llm_section.get("base_url", "https://api.openai.com/v1"),
            api_key=api_key,
            wire_api=llm_section.get("wire_api", "chat_completions"),
            primary_model=llm_section.get("primary_model", "gpt-4o"),
            fallback_models=llm_section.get(
                "fallback_models", ["gpt-4.1", "gpt-4o-mini"]
            ),
            min_max_tokens=max(
                1,
                int(llm_section.get("min_max_tokens", _DEFAULT_MIN_MAX_TOKENS)),
            ),
            extra_headers=_extra_headers_from_env(),
        )
    )
