"""Experiment evidence readiness checks for Stage 14/15 handoff.

The checks in this module are intentionally deterministic.  Stage 15 may use
LLM prose for judgment, but the control-flow gate needs a stable answer to the
basic question: did Stage 14 leave comparative, quantitative evidence that can
support paper writing?
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


BOOKKEEPING_METRICS = {
    "n",
    "n_entries",
    "n_seeds",
    "num_seeds",
    "seed_count",
    "condition_count",
    "run_count",
    "sample_size",
    "sample_size_n",
    "training_size",
    "test_size",
    "validation_size",
}

REPLICATION_METRICS = {
    "n_entries",
    "n_seeds",
    "num_seeds",
    "seed_count",
    "replications",
    "replication_count",
    "n_reps",
    "n_replications",
    "monte_carlo_replications",
    "mc_replications",
}


@dataclass(frozen=True)
class EvidenceReadinessReport:
    """Structured summary of whether Stage 14 evidence can feed Stage 16."""

    sufficient_for_stage16: bool
    has_meaningful_metrics: bool
    completed_conditions: tuple[str, ...]
    condition_count: int
    min_repetitions: int
    max_repetitions: int
    comparative_metric_count: int
    all_metric_values_zero: bool
    blocking_reasons: tuple[str, ...]
    warnings: tuple[str, ...]
    summary_path: str | None = None
    table_rows: int | None = None
    chart_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "sufficient_for_stage16": self.sufficient_for_stage16,
            "has_meaningful_metrics": self.has_meaningful_metrics,
            "completed_conditions": list(self.completed_conditions),
            "condition_count": self.condition_count,
            "min_repetitions": self.min_repetitions,
            "max_repetitions": self.max_repetitions,
            "comparative_metric_count": self.comparative_metric_count,
            "all_metric_values_zero": self.all_metric_values_zero,
            "blocking_reasons": list(self.blocking_reasons),
            "warnings": list(self.warnings),
            "summary_path": self.summary_path,
            "table_rows": self.table_rows,
            "chart_count": self.chart_count,
        }


def _metric_leaf(key: object) -> str:
    leaf = str(key).split("/")[-1].strip().lower()
    return re.sub(r"[^a-z0-9]+", "_", leaf).strip("_")


def _is_finite_number(value: object) -> bool:
    if isinstance(value, bool):
        return False
    if not isinstance(value, int | float):
        return False
    return math.isfinite(float(value))


def _coerce_numeric(value: object, *, prefer_max: bool = False) -> float | None:
    if _is_finite_number(value):
        return float(value)  # type: ignore[arg-type]
    if isinstance(value, dict):
        keys = ("max", "mean", "value", "count", "min") if prefer_max else (
            "mean",
            "value",
            "max",
            "min",
            "count",
        )
        for key in keys:
            if key in value:
                numeric = _coerce_numeric(value.get(key), prefer_max=prefer_max)
                if numeric is not None:
                    return numeric
    return None


def _metric_map(payload: object, *, meaningful_only: bool = True) -> dict[str, float]:
    if not isinstance(payload, dict):
        return {}
    metrics = payload.get("metrics")
    if isinstance(metrics, dict):
        source = metrics
    else:
        source = payload

    result: dict[str, float] = {}
    for key, value in source.items():
        leaf = _metric_leaf(key)
        if meaningful_only and leaf in BOOKKEEPING_METRICS:
            continue
        numeric = _coerce_numeric(value)
        if numeric is not None:
            result[leaf] = numeric
    return result


def condition_metric_maps(summary: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Return meaningful metrics grouped by condition/method name."""

    grouped: dict[str, dict[str, float]] = {}
    cond_summaries = summary.get("condition_summaries", {})
    if isinstance(cond_summaries, dict):
        for cond_name, cond_data in cond_summaries.items():
            metrics = _metric_map(cond_data)
            if metrics:
                grouped[str(cond_name)] = metrics

    def add_keyed_metrics(container: object) -> None:
        if not isinstance(container, dict):
            return
        for key, value in container.items():
            parts = str(key).split("/")
            if len(parts) < 2:
                continue
            cond_name = parts[0]
            metric_name = _metric_leaf(parts[-1])
            if metric_name in BOOKKEEPING_METRICS:
                continue
            numeric = _coerce_numeric(value)
            if numeric is None:
                continue
            grouped.setdefault(cond_name, {})[metric_name] = numeric

    add_keyed_metrics(summary.get("metrics_summary"))
    best_run = summary.get("best_run")
    if isinstance(best_run, dict):
        add_keyed_metrics(best_run.get("metrics"))
    add_keyed_metrics(summary.get("condition_metrics"))
    return grouped


def condition_repetition_count(
    cond_name: str,
    cond_data: object,
    best_metrics: dict[str, Any] | None = None,
) -> int:
    """Return explicit Monte Carlo/seed count for a condition when present."""

    candidates: list[float] = []
    if isinstance(cond_data, dict):
        for key, value in cond_data.items():
            if _metric_leaf(key) in REPLICATION_METRICS:
                numeric = _coerce_numeric(value, prefer_max=True)
                if numeric is not None:
                    candidates.append(numeric)
        metrics = cond_data.get("metrics")
        if isinstance(metrics, dict):
            for key, value in metrics.items():
                if _metric_leaf(key) in REPLICATION_METRICS:
                    numeric = _coerce_numeric(value, prefer_max=True)
                    if numeric is not None:
                        candidates.append(numeric)

    if best_metrics:
        prefix = f"{cond_name}/"
        seed_ids: set[str] = set()
        for key in best_metrics:
            key_text = str(key)
            if not key_text.startswith(prefix):
                continue
            match = re.match(rf"{re.escape(cond_name)}/(\d+)/", key_text)
            if match:
                seed_ids.add(match.group(1))
        if seed_ids:
            candidates.append(float(len(seed_ids)))

    if candidates:
        return max(0, int(max(candidates)))
    return 1


def completed_condition_names(summary: dict[str, Any]) -> tuple[str, ...]:
    best_metrics = summary.get("best_run", {}).get("metrics", {})
    best_metrics = best_metrics if isinstance(best_metrics, dict) else {}
    metric_maps = condition_metric_maps(summary)
    if not metric_maps:
        return ()
    cond_summaries = summary.get("condition_summaries", {})
    cond_summaries = cond_summaries if isinstance(cond_summaries, dict) else {}
    completed: list[str] = []
    for cond_name, metrics in metric_maps.items():
        cond_data = cond_summaries.get(cond_name, {})
        reps = condition_repetition_count(str(cond_name), cond_data, best_metrics)
        if metrics and reps > 0:
            completed.append(str(cond_name))
    return tuple(sorted(completed))


def summary_has_meaningful_metrics(summary: dict[str, Any]) -> bool:
    if condition_metric_maps(summary):
        return True
    for key in ("metrics_summary", "condition_metrics"):
        value = summary.get(key)
        if isinstance(value, dict) and _metric_map(value):
            return True
    best_run = summary.get("best_run")
    if isinstance(best_run, dict) and _metric_map(best_run):
        return True
    return False


def _all_count_values(summary: dict[str, Any]) -> list[float]:
    values: list[float] = []
    for container in (
        summary.get("metrics_summary"),
        summary.get("condition_metrics"),
        summary.get("best_run", {}).get("metrics")
        if isinstance(summary.get("best_run"), dict)
        else None,
    ):
        if not isinstance(container, dict):
            continue
        for key, value in container.items():
            if _metric_leaf(key) in REPLICATION_METRICS:
                numeric = _coerce_numeric(value, prefer_max=True)
                if numeric is not None:
                    values.append(numeric)
    cond_summaries = summary.get("condition_summaries", {})
    if isinstance(cond_summaries, dict):
        for cond_data in cond_summaries.values():
            if isinstance(cond_data, dict):
                for key, value in cond_data.items():
                    if _metric_leaf(key) in REPLICATION_METRICS:
                        numeric = _coerce_numeric(value, prefer_max=True)
                        if numeric is not None:
                            values.append(numeric)
                metrics = cond_data.get("metrics")
                if isinstance(metrics, dict):
                    for key, value in metrics.items():
                        if _metric_leaf(key) in REPLICATION_METRICS:
                            numeric = _coerce_numeric(value, prefer_max=True)
                            if numeric is not None:
                                values.append(numeric)
    return values


def _has_sample_size_regime_gt_200(summary: dict[str, Any]) -> bool:
    coverage = summary.get("sample_size_coverage")
    if isinstance(coverage, dict):
        if coverage.get("all_planned_sample_sizes_gt_200") is True:
            return True
        planned = coverage.get("planned_sample_sizes")
        if isinstance(planned, list):
            values = [
                float(value)
                for value in planned
                if _is_finite_number(value)
            ]
            if values and min(values) > 200:
                return True

    regimes = summary.get("sample_size_regimes")
    if isinstance(regimes, list):
        values: list[float] = []
        for item in regimes:
            if isinstance(item, dict):
                for key in ("sample_size", "N", "n"):
                    value = item.get(key)
                    if _is_finite_number(value):
                        values.append(float(value))
                        break
            elif _is_finite_number(item):
                values.append(float(item))
        if values and min(values) > 200:
            return True
    return False


def _latex_data_row_count(text: str) -> int:
    rows = 0
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if "\\\\" not in line:
            continue
        lower = line.lower()
        if any(
            token in lower
            for token in (
                "\\hline",
                "\\toprule",
                "\\midrule",
                "\\bottomrule",
                "\\begin",
                "\\end",
            )
        ):
            continue
        normalized = re.sub(r"\s+", " ", lower)
        if normalized.startswith("metric &") or normalized.startswith("condition &"):
            continue
        rows += 1
    return rows


def _manifest_chart_count(manifest: object) -> int:
    if isinstance(manifest, list):
        return len(manifest)
    if isinstance(manifest, dict):
        for key in ("figures", "charts", "items"):
            value = manifest.get(key)
            if isinstance(value, list):
                return len(value)
        for key in ("figure_count", "chart_count"):
            value = _coerce_numeric(manifest.get(key))
            if value is not None:
                return int(value)
    return 0


def assess_experiment_summary(
    summary: dict[str, Any],
    *,
    summary_path: str | None = None,
    table_text: str | None = None,
    chart_manifest: object | None = None,
    topic: str = "",
) -> EvidenceReadinessReport:
    blocking: list[str] = []
    warnings: list[str] = []

    completed = completed_condition_names(summary)
    cond_summaries = summary.get("condition_summaries", {})
    metric_maps = condition_metric_maps(summary)
    condition_count = (
        len(cond_summaries)
        if isinstance(cond_summaries, dict) and cond_summaries
        else len(metric_maps)
    )
    has_metrics = summary_has_meaningful_metrics(summary)

    if not has_metrics:
        blocking.append("no meaningful quantitative metrics were recorded")
    if len(completed) < 2:
        blocking.append("fewer than two completed conditions with metrics")

    best_metrics = summary.get("best_run", {}).get("metrics", {})
    best_metrics = best_metrics if isinstance(best_metrics, dict) else {}
    repetitions: list[int] = []
    metrics_by_condition: dict[str, dict[str, float]] = {}
    cond_summaries = cond_summaries if isinstance(cond_summaries, dict) else {}
    for cond_name in completed:
        cond_data = cond_summaries.get(cond_name, {})
        repetitions.append(condition_repetition_count(cond_name, cond_data, best_metrics))
        metrics_by_condition[cond_name] = metric_maps.get(cond_name, {})

    min_repetitions = min(repetitions) if repetitions else 0
    max_repetitions = max(repetitions) if repetitions else 0

    count_values = _all_count_values(summary)
    if count_values and max(count_values) <= 0:
        blocking.append("n_entries/n_seeds are zero, so no usable replications exist")

    all_values = [
        value
        for metric_map in metrics_by_condition.values()
        for value in metric_map.values()
    ]
    all_zero = bool(all_values) and all(value == 0.0 for value in all_values)
    if all_zero:
        blocking.append("all condition metric values are zero")

    comparative_metric_count = 0
    if len(metrics_by_condition) >= 2:
        shared_metrics = set.intersection(
            *(set(metric_map) for metric_map in metrics_by_condition.values())
        )
        if not shared_metrics:
            blocking.append("completed conditions do not share a comparable metric")
        for metric_name in shared_metrics:
            values = [metric_map[metric_name] for metric_map in metrics_by_condition.values()]
            rounded = {round(value, 12) for value in values}
            if len(rounded) >= 2:
                comparative_metric_count += 1
        if shared_metrics and comparative_metric_count == 0:
            blocking.append("all shared condition metrics are identical")

    context = f"{topic}\n{json.dumps(summary, default=str)[:40000]}".lower()
    monte_carlo_requested = "monte carlo" in context or "monte-carlo" in context
    simulation_repetition_requested = "simulation" in context and bool(count_values or repetitions)
    if monte_carlo_requested or simulation_repetition_requested:
        if max_repetitions <= 1:
            blocking.append("simulation evidence has only one replication")
        elif min_repetitions <= 200:
            suffix = (
                "; planned sample-size regimes are >200"
                if _has_sample_size_regime_gt_200(summary)
                else ""
            )
            warnings.append(
                "simulation has fewer than 201 repeated observations per "
                "condition; treat precision as a limitation, not dataset "
                f"sample size{suffix}"
            )

    best_run = summary.get("best_run")
    if isinstance(best_run, dict):
        status = str(best_run.get("status") or "").strip().lower()
        if status in {"failed", "error", "crashed"}:
            warnings.append(f"best run status is {status}")
        if best_run.get("timed_out") is True:
            warnings.append("best run timed out")

    table_rows = None
    if table_text:
        table_rows = _latex_data_row_count(table_text)
        if table_rows == 1:
            blocking.append("results_table.tex has only one data row")

    chart_count = _manifest_chart_count(chart_manifest)

    return EvidenceReadinessReport(
        sufficient_for_stage16=not blocking,
        has_meaningful_metrics=has_metrics,
        completed_conditions=completed,
        condition_count=condition_count,
        min_repetitions=min_repetitions,
        max_repetitions=max_repetitions,
        comparative_metric_count=comparative_metric_count,
        all_metric_values_zero=all_zero,
        blocking_reasons=tuple(dict.fromkeys(blocking)),
        warnings=tuple(dict.fromkeys(warnings)),
        summary_path=summary_path,
        table_rows=table_rows,
        chart_count=chart_count,
    )


def _existing_progress_artifact(run_dir: Path, filename: str) -> Path | None:
    for candidate in (
        run_dir / "progress experiment" / filename,
        run_dir / filename,
    ):
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def _latest_stage14_summary(run_dir: Path) -> Path | None:
    preferred = _existing_progress_artifact(run_dir, "experiment_summary_best.json")
    if preferred is not None:
        return preferred
    direct = run_dir / "stage-14" / "experiment_summary.json"
    if direct.exists():
        return direct
    matches = sorted(
        run_dir.glob("stage-14*/experiment_summary.json"),
        key=lambda path: path.stat().st_mtime if path.exists() else 0.0,
    )
    return matches[-1] if matches else None


def assess_stage14_evidence(run_dir: Path, *, topic: str = "") -> EvidenceReadinessReport:
    summary_path = _latest_stage14_summary(run_dir)
    if summary_path is None:
        return EvidenceReadinessReport(
            sufficient_for_stage16=False,
            has_meaningful_metrics=False,
            completed_conditions=(),
            condition_count=0,
            min_repetitions=0,
            max_repetitions=0,
            comparative_metric_count=0,
            all_metric_values_zero=False,
            blocking_reasons=("no Stage 14 experiment_summary.json found",),
            warnings=(),
        )
    try:
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return EvidenceReadinessReport(
            sufficient_for_stage16=False,
            has_meaningful_metrics=False,
            completed_conditions=(),
            condition_count=0,
            min_repetitions=0,
            max_repetitions=0,
            comparative_metric_count=0,
            all_metric_values_zero=False,
            blocking_reasons=("Stage 14 experiment_summary.json is malformed",),
            warnings=(),
            summary_path=str(summary_path),
        )
    if not isinstance(summary, dict):
        summary = {}

    stage14_dir = summary_path.parent if summary_path.name == "experiment_summary.json" else run_dir / "stage-14"
    table_path = stage14_dir / "results_table.tex"
    table_text = ""
    if table_path.exists():
        table_text = table_path.read_text(encoding="utf-8", errors="replace")

    manifest: object | None = None
    manifest_path = stage14_dir / "charts" / "figure_manifest.json"
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            manifest = None

    return assess_experiment_summary(
        summary,
        summary_path=str(summary_path),
        table_text=table_text,
        chart_manifest=manifest,
        topic=topic,
    )
