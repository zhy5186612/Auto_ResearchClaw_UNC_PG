from __future__ import annotations

import json
import importlib
import logging
import math
import os
import shutil
import tempfile
import threading
import time as _time
from dataclasses import dataclass, replace
from pathlib import Path

from researchclaw.adapters import AdapterBundle
from researchclaw.config import RCConfig
from researchclaw.evolution import EvolutionStore, extract_lessons
from researchclaw.knowledge.base import write_stage_to_kb
from researchclaw.pipeline.contracts import CONTRACTS
from researchclaw.pipeline.evidence_gate import (
    assess_stage14_evidence,
    summary_has_meaningful_metrics,
)
from researchclaw.pipeline.executor import StageResult, execute_stage
from researchclaw.pipeline._helpers import (
    _contract_artifact_available,
    _existing_progress_artifact,
    _path_has_content,
    _progress_artifact_path,
    _read_prior_artifact,
    _read_progress_json,
)
from researchclaw.pipeline.stages import (
    DECISION_ROLLBACK,
    MAX_DECISION_PIVOTS,
    NEXT_STAGE,
    NONCRITICAL_STAGES,
    STAGE_SEQUENCE,
    Stage,
    StageStatus,
    recovery_rollback_stage,
)

def _env_int(name: str, default: int, *, minimum: int = 0) -> int:
    try:
        value = int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default
    return max(minimum, value)


# Keep automatic rewinds useful but bounded. The defaults are intentionally
# generous because experiment repair and paper rewrite stages may need many
# passes; operators can still cap them with the environment variables below.
MAX_AUTO_RECOVERY_ATTEMPTS_PER_STAGE = _env_int(
    "RESEARCHCLAW_MAX_AUTO_RECOVERY_PER_STAGE",
    20,
)
MAX_AUTO_RECOVERY_TOTAL_ATTEMPTS = _env_int(
    "RESEARCHCLAW_MAX_AUTO_RECOVERY_TOTAL",
    120,
)
_SOURCE_TYPE_VALUES = {"auto", "web", "paper", "patent", "slr"}


@dataclass(frozen=True)
class ResumePlan:
    from_stage: Stage | None
    rebuild_through_stage: Stage | None = None
    reason: str = "checkpoint"


def _utcnow_iso() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _should_start(stage: Stage, from_stage: Stage, started: bool) -> bool:
    if started:
        return True
    return stage == from_stage


def _build_pipeline_summary(
    *,
    run_id: str,
    results: list[StageResult],
    from_stage: Stage,
    run_dir: Path | None = None,
) -> dict[str, object]:
    summary: dict[str, object] = {
        "run_id": run_id,
        "stages_executed": len(results),
        "stages_done": sum(1 for item in results if item.status == StageStatus.DONE),
        "stages_paused": sum(
            1 for item in results if item.status == StageStatus.PAUSED
        ),
        "stages_blocked": sum(
            1 for item in results if item.status == StageStatus.BLOCKED_APPROVAL
        ),
        "stages_failed": sum(
            1 for item in results if item.status == StageStatus.FAILED
        ),
        "degraded": any(r.decision == "degraded" for r in results),
        "from_stage": int(from_stage),
        "final_stage": int(results[-1].stage) if results else int(from_stage),
        "final_status": results[-1].status.value if results else "no_stages",
        "generated": _utcnow_iso(),
        "content_metrics": _collect_content_metrics(run_dir),
    }
    return summary


def _write_pipeline_summary(run_dir: Path, summary: dict[str, object]) -> None:
    _progress_artifact_path(run_dir, "pipeline_summary.json", create=True).write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )


def _write_checkpoint(
    run_dir: Path, stage: Stage, run_id: str,
    adapters: "AdapterBundle | None" = None,
) -> None:
    """Write checkpoint atomically via temp file + rename to prevent corruption."""
    checkpoint: dict[str, object] = {
        "last_completed_stage": int(stage),
        "last_completed_name": stage.name,
        "run_id": run_id,
        "timestamp": _utcnow_iso(),
    }

    # Embed HITL session data if available
    if adapters is not None:
        hitl_session = getattr(adapters, "hitl", None)
        if hitl_session is not None:
            try:
                checkpoint["hitl"] = hitl_session.hitl_checkpoint_data()
            except Exception:
                pass
    target = _progress_artifact_path(run_dir, "checkpoint.json", create=True)
    fd, tmp_path = tempfile.mkstemp(dir=target.parent, suffix=".tmp", prefix="checkpoint_")
    os.close(fd)
    try:
        with open(tmp_path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(checkpoint, indent=2))
        Path(tmp_path).replace(target)
    except BaseException:
        Path(tmp_path).unlink(missing_ok=True)
        raise


def _config_with_latest_run_source(run_dir: Path, config: RCConfig) -> RCConfig:
    metadata = _read_progress_json(run_dir, "library_metadata.json")
    source_type = str(metadata.get("source_type") or "").strip().lower()
    if source_type not in _SOURCE_TYPE_VALUES:
        return config
    if source_type == getattr(config.research, "source_type", "auto"):
        return config
    return replace(
        config,
        research=replace(config.research, source_type=source_type),
    )


def _read_auto_recovery_history(run_dir: Path) -> list[dict[str, object]]:
    history_path = _existing_progress_artifact(run_dir, "auto_recovery_history.json")
    if history_path is None:
        return []
    try:
        data = json.loads(history_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    return data if isinstance(data, list) else []


def _count_auto_recovery_attempts(
    run_dir: Path,
    *,
    source_stage: Stage | None = None,
) -> int:
    history = _read_auto_recovery_history(run_dir)
    if source_stage is None:
        return len(history)
    return sum(
        1
        for entry in history
        if entry.get("source_stage_num") == int(source_stage)
    )


def _record_auto_recovery(
    run_dir: Path,
    *,
    source_stage: Stage,
    rollback_target: Stage,
    result: StageResult,
    attempt: int,
    total_attempts: int,
) -> None:
    history_path = (
        _existing_progress_artifact(run_dir, "auto_recovery_history.json")
        or run_dir / "auto_recovery_history.json"
    )
    history = _read_auto_recovery_history(run_dir)
    history.append(
        {
            "source_stage": source_stage.name,
            "source_stage_num": int(source_stage),
            "source_status": result.status.value,
            "rollback_target": rollback_target.name,
            "rollback_stage_num": int(rollback_target),
            "decision": result.decision,
            "error": result.error,
            "attempt": attempt,
            "total_attempts": total_attempts,
            "timestamp": _utcnow_iso(),
        }
    )
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")


def _eligible_for_auto_recovery(
    stage: Stage,
    result: StageResult,
    *,
    stop_on_gate: bool,
    skip_noncritical: bool,
) -> bool:
    if result.decision == "abort":
        return False
    if result.status == StageStatus.BLOCKED_APPROVAL:
        return False
    if result.status == StageStatus.REJECTED:
        return True
    if result.status == StageStatus.PAUSED:
        return True
    if result.status == StageStatus.FAILED:
        if skip_noncritical and stage in NONCRITICAL_STAGES:
            return False
        return True
    return False


def _auto_recovery_budget_available(run_dir: Path, source_stage: Stage) -> bool:
    stage_attempts = _count_auto_recovery_attempts(
        run_dir, source_stage=source_stage
    )
    total_attempts = _count_auto_recovery_attempts(run_dir)
    return (
        stage_attempts < MAX_AUTO_RECOVERY_ATTEMPTS_PER_STAGE
        and total_attempts < MAX_AUTO_RECOVERY_TOTAL_ATTEMPTS
    )


def _write_auto_recovery_budget_exhausted(
    run_dir: Path,
    *,
    source_stage: Stage,
    result: StageResult,
) -> None:
    payload = {
        "source_stage": source_stage.name,
        "source_stage_num": int(source_stage),
        "source_status": result.status.value,
        "decision": result.decision,
        "error": result.error,
        "stage_attempts": _count_auto_recovery_attempts(
            run_dir, source_stage=source_stage
        ),
        "stage_attempt_limit": MAX_AUTO_RECOVERY_ATTEMPTS_PER_STAGE,
        "total_attempts": _count_auto_recovery_attempts(run_dir),
        "total_attempt_limit": MAX_AUTO_RECOVERY_TOTAL_ATTEMPTS,
        "timestamp": _utcnow_iso(),
    }
    marker_path = (
        _existing_progress_artifact(run_dir, "auto_recovery_budget_exhausted.json")
        or run_dir / "auto_recovery_budget_exhausted.json"
    )
    marker_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_heartbeat(run_dir: Path, stage: Stage, run_id: str) -> None:
    """Write heartbeat file for sentinel watchdog monitoring."""
    import os

    heartbeat = {
        "pid": os.getpid(),
        "last_stage": int(stage),
        "last_stage_name": stage.name,
        "run_id": run_id,
        "timestamp": _utcnow_iso(),
    }
    _progress_artifact_path(run_dir, "heartbeat.json", create=True).write_text(
        json.dumps(heartbeat, indent=2), encoding="utf-8"
    )


def read_checkpoint(run_dir: Path) -> Stage | None:
    """Read checkpoint and return the NEXT stage to execute, or None if no checkpoint."""
    cp_path = _existing_progress_artifact(run_dir, "checkpoint.json")
    if cp_path is None:
        return None
    try:
        data = json.loads(cp_path.read_text(encoding="utf-8"))
        last_num = data.get("last_completed_stage")
        if last_num is None:
            return None
        for i, stage in enumerate(STAGE_SEQUENCE):
            if int(stage) == last_num:
                if i + 1 < len(STAGE_SEQUENCE):
                    return STAGE_SEQUENCE[i + 1]
                return None
        return None
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def _read_last_completed_stage_num(run_dir: Path) -> int:
    cp_path = _existing_progress_artifact(run_dir, "checkpoint.json")
    if cp_path is None:
        return 0
    try:
        data = json.loads(cp_path.read_text(encoding="utf-8"))
        return int(data.get("last_completed_stage") or 0)
    except (json.JSONDecodeError, OSError, TypeError, ValueError):
        return 0


def _read_stage_decision(run_dir: Path, stage: Stage) -> dict[str, object] | None:
    decision_path = run_dir / f"stage-{int(stage):02d}" / "decision.json"
    if not decision_path.exists():
        return None
    try:
        data = json.loads(decision_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    return data if isinstance(data, dict) else None


def _stage_handoff_passed(run_dir: Path, stage: Stage) -> bool:
    report_path = run_dir / f"stage-{int(stage):02d}" / "stage_handoff_report.json"
    if not report_path.exists():
        return False
    try:
        data = json.loads(report_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return False
    return str(data.get("status") or "").strip().lower() == "pass"


def _positive_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        numeric_value = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if math.isnan(numeric_value) or math.isinf(numeric_value) or numeric_value <= 0:
        return None
    return numeric_value


def _budget_payload_unlimited(payload: object) -> bool:
    if not isinstance(payload, dict):
        return False
    if payload.get("unlimited") is True or payload.get("timeout_unlimited") is True:
        return True
    for key in (
        "time_budget_sec",
        "effective_time_budget_sec",
        "timeout_sec",
        "budget_sec",
    ):
        if key not in payload:
            continue
        value = payload.get(key)
        if value is None:
            return True
        if isinstance(value, str) and value.strip().casefold() in {
            "",
            "0",
            "none",
            "null",
            "no_limit",
            "nolimit",
            "unbounded",
            "unlimited",
            "infinite",
            "inf",
        }:
            return True
        numeric_value = _positive_float(value)
        if (
            numeric_value is None
            and not isinstance(value, bool)
            and isinstance(value, (int, float))
            and float(value) == 0.0
        ):
            return True
    return False


def _stage11_required_budget_sec(run_dir: Path) -> float:
    schedule_path = run_dir / "stage-11" / "schedule.json"
    if not schedule_path.exists():
        return 0.0
    try:
        schedule = json.loads(schedule_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return 0.0
    if not isinstance(schedule, dict):
        return 0.0

    candidates: list[float] = []
    for payload in (
        schedule.get("total_gpu_budget"),
        schedule.get("budget_fit"),
        schedule.get("resource_planning_warning"),
    ):
        if not isinstance(payload, dict):
            continue
        if _budget_payload_unlimited(payload):
            return math.inf
        for key in ("time_budget_sec", "effective_time_budget_sec"):
            value = _positive_float(payload.get(key))
            if value is not None:
                candidates.append(value)
        for key in (
            "time_budget_minutes",
            "effective_time_budget_minutes",
            "estimated_minutes_total",
        ):
            value = _positive_float(payload.get(key))
            if value is not None:
                candidates.append(value * 60.0)

    task_total_minutes = 0.0
    tasks = schedule.get("tasks")
    if isinstance(tasks, list):
        for task in tasks:
            if isinstance(task, dict):
                value = _positive_float(task.get("estimated_minutes"))
                if value is not None:
                    task_total_minutes += value
    if task_total_minutes > 0:
        candidates.append(task_total_minutes * 60.0)

    return max(candidates, default=0.0)


def _stage12_recorded_budget_sec(run_dir: Path) -> float:
    candidates: list[float] = []

    def _collect_from_payload(payload: object) -> None:
        if not isinstance(payload, dict):
            return
        if _budget_payload_unlimited(payload):
            candidates.append(math.inf)
            return
        for key in ("timeout_sec", "configured_timeout_sec", "budget_sec"):
            value = _positive_float(payload.get(key))
            if value is not None:
                candidates.append(value)
        structured = payload.get("structured_results")
        if isinstance(structured, dict):
            _collect_from_payload(structured)
        config = payload.get("config")
        if isinstance(config, dict):
            value = _positive_float(config.get("total_time_budget_s"))
            if value is not None:
                candidates.append(value)

    for path in (
        run_dir / "stage-12" / "runs" / "run-1.json",
        run_dir / "stage-12" / "runs" / "results.json",
    ):
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        _collect_from_payload(payload)

    return max(candidates, default=0.0)


def _stage12_budget_stale(run_dir: Path) -> bool:
    required_sec = _stage11_required_budget_sec(run_dir)
    recorded_sec = _stage12_recorded_budget_sec(run_dir)
    return required_sec > 0 and recorded_sec > 0 and recorded_sec + 1.0 < required_sec


def _read_waiting_state(run_dir: Path) -> dict[str, object] | None:
    waiting_path = run_dir / "hitl" / "waiting.json"
    if not waiting_path.exists():
        return None
    try:
        data = json.loads(waiting_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    return data if isinstance(data, dict) else None


def _read_decision_history(run_dir: Path) -> list[dict[str, object]]:
    history_path = _existing_progress_artifact(run_dir, "decision_history.json")
    if history_path is None:
        return []
    try:
        data = json.loads(history_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    return data if isinstance(data, list) else []


def _highest_active_stage_num(run_dir: Path) -> int:
    highest = 0
    for stage_dir in run_dir.iterdir():
        if not stage_dir.is_dir():
            continue
        name = stage_dir.name
        if not name.startswith("stage-") or "_v" in name:
            continue
        try:
            stage_num = int(name.split("-", 1)[1])
        except (IndexError, ValueError):
            continue
        highest = max(highest, stage_num)
    return highest


def _pending_research_decision_rollback_plan(
    run_dir: Path,
    *,
    highest_stage_num: int | None = None,
) -> ResumePlan | None:
    """Return a rollback resume plan for an unfinished Stage 15 decision.

    Stage 15 can emit ``pivot``/``refine`` and then pause for HITL approval
    before the runner records/version-rolls back affected stages. A crash or
    detached library resume at that point must continue the rollback path,
    not blindly advance from the checkpoint to Stage 16.
    """

    decision = _read_stage_decision(run_dir, Stage.RESEARCH_DECISION)
    if not decision:
        return None
    decision_value = str(decision.get("decision") or "").strip().lower()
    rollback_target = DECISION_ROLLBACK.get(decision_value)
    if rollback_target is None:
        return None

    if highest_stage_num is None:
        highest_stage_num = _highest_active_stage_num(run_dir)
    if highest_stage_num > int(Stage.RESEARCH_DECISION):
        return None

    history = _read_decision_history(run_dir)
    pivot_count = len(history)
    latest_attempt = pivot_count
    if history:
        try:
            latest_attempt = int(history[-1].get("attempt") or latest_attempt)
        except (TypeError, ValueError):
            latest_attempt = pivot_count

    rollback_dir = run_dir / f"stage-{int(rollback_target):02d}"
    version_dir = run_dir / f"stage-{int(rollback_target):02d}_v{latest_attempt}"
    rollback_not_started = latest_attempt <= 0 or not version_dir.exists()
    rollback_not_recreated = not rollback_dir.exists()

    if pivot_count >= MAX_DECISION_PIVOTS and not (
        rollback_not_started or rollback_not_recreated
    ):
        return ResumePlan(
            from_stage=NEXT_STAGE.get(Stage.RESEARCH_DECISION),
            reason="decision-budget-exhausted",
        )

    return ResumePlan(
        from_stage=rollback_target,
        rebuild_through_stage=Stage.RESEARCH_DECISION,
        reason=f"pending-decision-{decision_value}",
    )


def build_resume_plan(run_dir: Path) -> ResumePlan:
    """Resolve the safest stage to resume from for an existing run.

    Uses the regular checkpoint when the run stopped cleanly between stages.
    If the latest persisted stage is failed/paused/rejected or appears partially
    written without a final decision, rewind to the configured recovery stage and
    rebuild the affected slice before continuing.
    """
    checkpoint_stage = read_checkpoint(run_dir)
    last_completed_num = _read_last_completed_stage_num(run_dir)
    highest_stage_num = _highest_active_stage_num(run_dir)
    waiting_state = _read_waiting_state(run_dir)

    if waiting_state is not None:
        try:
            waiting_stage = Stage(int(waiting_state.get("stage") or 0))
        except ValueError:
            waiting_stage = None
        waiting_reason = str(waiting_state.get("reason") or "").strip().lower()
        if waiting_stage is not None:
            if waiting_reason in {
                "post_stage",
                "gate_approval",
                "quality_below_threshold",
                "confidence_low",
            }:
                if waiting_stage == Stage.RESEARCH_DECISION:
                    decision_plan = _pending_research_decision_rollback_plan(
                        run_dir,
                        highest_stage_num=highest_stage_num,
                    )
                    if decision_plan is not None:
                        return ResumePlan(
                            from_stage=decision_plan.from_stage,
                            rebuild_through_stage=decision_plan.rebuild_through_stage,
                            reason=f"waiting-{waiting_reason}-{decision_plan.reason}",
                        )
                return ResumePlan(
                    from_stage=NEXT_STAGE.get(waiting_stage),
                    reason=f"waiting-{waiting_reason}",
                )
            if waiting_reason == "pre_stage":
                return ResumePlan(
                    from_stage=waiting_stage,
                    reason="waiting-pre_stage",
                )
            if waiting_reason in {"cost_budget_exceeded", "error_occurred"}:
                rollback_target = recovery_rollback_stage(waiting_stage)
                return ResumePlan(
                    from_stage=rollback_target,
                    rebuild_through_stage=waiting_stage,
                    reason=f"recover-{waiting_reason}",
                )
            return ResumePlan(
                from_stage=waiting_stage,
                reason=f"waiting-{waiting_reason or 'resume'}",
            )

    latest_stage: Stage | None = None
    latest_decision: dict[str, object] | None = None
    if highest_stage_num > 0:
        try:
            latest_stage = Stage(highest_stage_num)
            latest_decision = _read_stage_decision(run_dir, latest_stage)
        except ValueError:
            latest_stage = None

    if latest_stage is not None and latest_decision is not None:
        status = str(latest_decision.get("status") or "").strip().lower()
        if latest_stage == Stage.RESEARCH_DECISION and status == StageStatus.DONE.value:
            decision_plan = _pending_research_decision_rollback_plan(
                run_dir,
                highest_stage_num=highest_stage_num,
            )
            if decision_plan is not None:
                return decision_plan
        if status in {
            StageStatus.FAILED.value,
            StageStatus.PAUSED.value,
            StageStatus.REJECTED.value,
        }:
            decision = str(latest_decision.get("decision") or "").strip().lower()
            if decision == "experiment_repair":
                rollback_target = (
                    Stage.PAPER_DRAFT
                    if latest_stage == Stage.PAPER_DRAFT
                    else Stage.ITERATIVE_REFINE
                )
            else:
                rollback_target = recovery_rollback_stage(latest_stage)
            return ResumePlan(
                from_stage=rollback_target,
                rebuild_through_stage=latest_stage,
                reason=f"recover-{status}",
            )

    if _stage12_budget_stale(run_dir):
        return ResumePlan(
            from_stage=Stage.EXPERIMENT_RUN,
            reason="stage12-stale-budget",
        )

    if latest_stage is not None and highest_stage_num > last_completed_num:
        interrupted_stage = latest_stage
        interrupted_status = str((latest_decision or {}).get("status") or "").strip().lower()
        if interrupted_status == StageStatus.DONE.value and _stage_handoff_passed(
            run_dir,
            interrupted_stage,
        ):
            return ResumePlan(
                from_stage=NEXT_STAGE.get(interrupted_stage),
                reason="checkpoint-stale-handoff-pass",
            )
        if interrupted_status not in {
            StageStatus.DONE.value,
            StageStatus.BLOCKED_APPROVAL.value,
        }:
            rollback_target = recovery_rollback_stage(interrupted_stage)
            return ResumePlan(
                from_stage=rollback_target,
                rebuild_through_stage=interrupted_stage,
                reason="recover-interrupted",
            )

    return ResumePlan(from_stage=checkpoint_stage, reason="checkpoint")


def _next_resume_rebuild_attempt(
    run_dir: Path,
    rollback_target: Stage,
    rebuild_through_stage: Stage,
) -> int:
    max_attempt = 0
    for stage_num in range(int(rollback_target), int(rebuild_through_stage) + 1):
        pattern = f"stage-{stage_num:02d}_v*"
        for version_dir in run_dir.glob(pattern):
            suffix = version_dir.name.rsplit("_v", 1)[-1]
            try:
                max_attempt = max(max_attempt, int(suffix))
            except ValueError:
                continue
    return max_attempt + 1


def apply_resume_plan(run_dir: Path, plan: ResumePlan) -> None:
    """Prepare a run directory for resuming from a recovery-aware resume plan."""
    if plan.from_stage is None or plan.rebuild_through_stage is None:
        return
    attempt = _next_resume_rebuild_attempt(
        run_dir,
        plan.from_stage,
        plan.rebuild_through_stage,
    )
    _version_rollback_stages(
        run_dir,
        plan.from_stage,
        attempt,
        end_stage=plan.rebuild_through_stage,
    )


def resume_from_checkpoint(
    run_dir: Path, default_stage: Stage = Stage.TOPIC_INIT
) -> Stage:
    """Resolve the stage to resume from using checkpoint metadata."""
    next_stage = read_checkpoint(run_dir)
    return next_stage if next_stage is not None else default_stage


def _collect_content_metrics(run_dir: Path | None) -> dict[str, object]:
    """Collect content authenticity metrics from stage outputs."""
    metrics: dict[str, object] = {
        "template_ratio": None,
        "citation_verify_score": None,
        "total_citations": None,
        "verified_citations": None,
        "degraded_sources": [],
    }
    if run_dir is None:
        return metrics

    draft_path = run_dir / "stage-17" / "paper_draft.md"
    if draft_path.exists():
        try:
            quality_module = importlib.import_module("researchclaw.quality")
            compute_template_ratio = quality_module.compute_template_ratio
            text = draft_path.read_text(encoding="utf-8")
            metrics["template_ratio"] = round(compute_template_ratio(text), 4)
        except (
            AttributeError,
            ModuleNotFoundError,
            UnicodeDecodeError,
            OSError,
            ValueError,
            TypeError,
        ):
            pass

    verify_path = run_dir / "stage-23" / "verification_report.json"
    if verify_path.exists():
        try:
            vdata = json.loads(verify_path.read_text(encoding="utf-8"))
            if isinstance(vdata, dict):
                summary = vdata.get("summary", vdata)
                total = summary.get("total", 0) if isinstance(summary, dict) else None
                verified = summary.get("verified", 0) if isinstance(summary, dict) else None
                if isinstance(total, int | float) and isinstance(verified, int | float):
                    total_num = int(total)
                    verified_num = int(verified)
                    metrics["total_citations"] = total_num
                    metrics["verified_citations"] = verified_num
                    if total_num > 0:
                        metrics["citation_verify_score"] = round(
                            verified_num / total_num, 4
                        )
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            pass

    return metrics


logger = logging.getLogger(__name__)


def _json_load_file(path: Path) -> dict[str, object]:
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (json.JSONDecodeError, OSError):
        return {}
    return data if isinstance(data, dict) else {}


def _has_numeric_value(value: object) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int | float):
        return math.isfinite(float(value))
    if isinstance(value, dict):
        return any(_has_numeric_value(v) for v in value.values())
    if isinstance(value, list):
        return any(_has_numeric_value(v) for v in value)
    return False


def _experiment_summary_has_metrics(data: dict[str, object]) -> bool:
    if summary_has_meaningful_metrics(data):
        return True
    for container_key in ("structured_results", "results"):
        structured = data.get(container_key)
        if not isinstance(structured, dict):
            continue
        runs = structured.get("runs")
        if isinstance(runs, dict):
            for run_data in runs.values():
                if not isinstance(run_data, dict):
                    continue
                metrics = run_data.get("metrics")
                if isinstance(metrics, dict) and metrics and _has_numeric_value(metrics):
                    return True
        if _has_numeric_value(structured.get("metrics")):
            return True
    return False


def _refinement_log_has_metrics(data: dict[str, object]) -> bool:
    if _has_numeric_value(data.get("best_metric")):
        return True
    iterations = data.get("iterations")
    if not isinstance(iterations, list):
        return False
    for iteration in iterations:
        if not isinstance(iteration, dict):
            continue
        if _has_numeric_value(iteration.get("metric")):
            return True
        metrics = iteration.get("metrics")
        if isinstance(metrics, dict) and metrics and _has_numeric_value(metrics):
            return True
        sandbox = iteration.get("sandbox")
        if isinstance(sandbox, dict):
            sandbox_metrics = sandbox.get("metrics")
            if (
                isinstance(sandbox_metrics, dict)
                and sandbox_metrics
                and _has_numeric_value(sandbox_metrics)
            ):
                return True
    return False


def _latest_stage_artifact(run_dir: Path, pattern: str) -> Path | None:
    matches = sorted(run_dir.glob(pattern), key=lambda p: p.stat().st_mtime if p.exists() else 0)
    return matches[-1] if matches else None


def _best_experiment_summary_path(run_dir: Path) -> Path | None:
    path = _existing_progress_artifact(run_dir, "experiment_summary_best.json")
    if path is not None:
        return path
    direct = run_dir / "stage-14" / "experiment_summary.json"
    if direct.exists():
        return direct
    return _latest_stage_artifact(run_dir, "stage-14*/experiment_summary.json")


def _stage_handoff_issue(
    issues: list[dict[str, object]],
    *,
    severity: str,
    code: str,
    message: str,
    repair_hint: str,
) -> None:
    issues.append(
        {
            "severity": severity,
            "code": code,
            "message": message,
            "repair_hint": repair_hint,
        }
    )


def _audit_stage_semantics(
    run_dir: Path,
    stage: Stage,
    config: RCConfig,
    issues: list[dict[str, object]],
) -> None:
    stage_dir = run_dir / f"stage-{int(stage):02d}"

    if stage == Stage.CODE_GENERATION:
        exp_dir = stage_dir / "experiment"
        py_files = list(exp_dir.rglob("*.py")) if exp_dir.is_dir() else []
        main_py = exp_dir / "main.py"
        if not py_files or not main_py.exists():
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="code_generation_no_entrypoint",
                message="Stage 10 did not leave a runnable experiment/main.py file.",
                repair_hint="Regenerate or repair Stage 10 code before resource planning and execution.",
            )
        warning_path = stage_dir / "code_quality_warning.md"
        if warning_path.exists():
            _stage_handoff_issue(
                issues,
                severity="warning",
                code="code_generation_quality_warning",
                message="Stage 10 proceeded with unresolved quality warnings.",
                repair_hint="Use code_quality_warning.md as repair context if Stage 12/13 execution degrades.",
            )

    if stage in (Stage.EXPERIMENT_RUN, Stage.ITERATIVE_REFINE):
        runs_dir = stage_dir / "runs"
        run_files = list(runs_dir.glob("*.json")) if runs_dir.is_dir() else []
        has_metrics = False
        for run_file in run_files:
            data = _json_load_file(run_file)
            if _experiment_summary_has_metrics(data):
                has_metrics = True
                break
            metrics = data.get("metrics")
            if isinstance(metrics, dict) and metrics and _has_numeric_value(metrics):
                has_metrics = True
                break
        if not has_metrics and stage == Stage.ITERATIVE_REFINE:
            refinement_log = _json_load_file(stage_dir / "refinement_log.json")
            has_metrics = _refinement_log_has_metrics(refinement_log)
        if not has_metrics:
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="experiment_run_no_metrics",
                message=f"{stage.name} did not produce usable experiment metrics for the next stage.",
                repair_hint="Repair code generation/execution so Stage 14 can build tables and figures from real metrics.",
            )

    if stage == Stage.RESULT_ANALYSIS:
        summary_path = _best_experiment_summary_path(run_dir)
        summary = _json_load_file(summary_path) if summary_path is not None else {}
        has_metrics = _experiment_summary_has_metrics(summary)
        evidence_report = assess_stage14_evidence(
            run_dir,
            topic=getattr(config.research, "topic", ""),
        )
        if not summary_path or not summary:
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="analysis_missing_experiment_summary",
                message="Stage 14 did not produce a usable experiment_summary.json.",
                repair_hint="Run experiment diagnosis/repair before Stage 15 decision.",
            )
        elif not has_metrics:
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="analysis_empty_metrics",
                message="Stage 14 experiment summary has no usable metrics.",
                repair_hint="Repair Stage 12/13 execution so Stage 14 can produce metrics_summary and condition summaries.",
            )
        elif not evidence_report.sufficient_for_stage16:
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="analysis_evidence_not_comparative",
                message=(
                    "Stage 14 evidence is not sufficient for Stage 16: "
                    + "; ".join(evidence_report.blocking_reasons)
                ),
                repair_hint=(
                    "Repair Stage 12/13 so Stage 14 has at least two completed "
                    "conditions, non-identical comparative metrics, and valid "
                    "replication counts before Stage 15."
                ),
            )

        table_path = stage_dir / "results_table.tex"
        if table_path.exists():
            table_text = table_path.read_text(encoding="utf-8", errors="replace")
            if "No experiment data available" in table_text:
                _stage_handoff_issue(
                    issues,
                    severity="critical",
                    code="analysis_empty_results_table",
                    message="Stage 14 results_table.tex reports no experiment data.",
                    repair_hint="Regenerate Stage 14 only after Stage 12/13 produce metrics for every method/condition.",
                )

        analysis_path = stage_dir / "analysis.md"
        if analysis_path.exists():
            analysis_text = analysis_path.read_text(encoding="utf-8", errors="replace")
            if "RC_FAILED_RUN_DIAGNOSTIC" in analysis_text or "Failed-Run Diagnostic" in analysis_text:
                _stage_handoff_issue(
                    issues,
                    severity="critical" if not has_metrics else "warning",
                    code="analysis_failed_run_diagnostic",
                    message="Stage 14 analysis contains failed-run diagnostic content.",
                    repair_hint="Bypass irrelevant diagnostics only when metrics are usable; otherwise repair execution first.",
                )

    if stage == Stage.RESEARCH_DECISION:
        decision_path = stage_dir / "decision_structured.json"
        decision = str(_json_load_file(decision_path).get("decision", "")).lower()
        if decision not in {"proceed", "pivot", "refine", "experiment_repair"}:
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="decision_invalid",
                message="Stage 15 did not produce a valid structured decision.",
                repair_hint="Regenerate Stage 15 decision from the promoted Stage 14 analysis and experiment summary.",
            )

    if stage in (Stage.PAPER_OUTLINE, Stage.PAPER_DRAFT, Stage.PAPER_REVISION):
        artifact_name = {
            Stage.PAPER_OUTLINE: "outline.md",
            Stage.PAPER_DRAFT: "paper_draft.md",
            Stage.PAPER_REVISION: "paper_revised.md",
        }[stage]
        paper_path = stage_dir / artifact_name
        if paper_path.exists():
            text = paper_path.read_text(encoding="utf-8", errors="replace")
            if "RC_FAILED_RUN_DIAGNOSTIC" in text or "Failed-Run Diagnostic" in text:
                _stage_handoff_issue(
                    issues,
                    severity="critical",
                    code="paper_contains_failed_run_diagnostic",
                    message=f"{artifact_name} contains failed-run diagnostic text.",
                    repair_hint="Repair experiment outputs before writing/revising the paper so diagnostic scaffolding is not published.",
                )
            if len(text.strip()) < 1500:
                _stage_handoff_issue(
                    issues,
                    severity="warning",
                    code="paper_artifact_too_short",
                    message=f"{artifact_name} is unusually short for this stage.",
                    repair_hint="Regenerate the writing stage if downstream quality gate rejects the paper.",
                )

    if stage == Stage.CITATION_VERIFY:
        pdf_candidates = [
            stage_dir / "paper_final_verified.pdf",
            stage_dir / "paper_final.pdf",
            stage_dir / "paper.pdf",
            run_dir / "stage-22" / "paper_final_verified.pdf",
            run_dir / "stage-22" / "paper_final.pdf",
            run_dir / "stage-22" / "paper.pdf",
            run_dir / "deliverables" / "paper.pdf",
            _progress_artifact_path(run_dir, "paper_final_verified.pdf"),
            _progress_artifact_path(run_dir, "paper.pdf"),
        ]
        if not any(path.exists() and path.stat().st_size > 0 for path in pdf_candidates):
            _stage_handoff_issue(
                issues,
                severity="critical",
                code="final_pdf_missing",
                message="Final verified PDF was not produced.",
                repair_hint="Repair Stage 22/23 export so paper_final_verified.pdf is available for the UI.",
            )


def _run_stage_handoff_audit(
    run_dir: Path,
    *,
    stage: Stage,
    result: StageResult,
    config: RCConfig,
) -> tuple[bool, tuple[str, ...]]:
    if result.status != StageStatus.DONE:
        return True, ()

    stage_dir = run_dir / f"stage-{int(stage):02d}"
    current_contract = CONTRACTS.get(stage)
    next_stage = NEXT_STAGE.get(stage)
    next_contract = CONTRACTS.get(next_stage) if next_stage is not None else None
    issues: list[dict[str, object]] = []

    if current_contract is not None:
        for output_file in current_contract.output_files:
            if not _contract_artifact_available(run_dir, stage, output_file):
                _stage_handoff_issue(
                    issues,
                    severity="critical",
                    code="missing_current_output",
                    message=f"Required current-stage output is missing or empty: {output_file}",
                    repair_hint=f"Repair {stage.name} before downstream stages consume this output.",
                )

    if next_stage is not None and next_contract is not None:
        for input_file in next_contract.input_files:
            if not _contract_artifact_available(
                run_dir, stage, input_file, allow_prior=True
            ):
                _stage_handoff_issue(
                    issues,
                    severity="critical",
                    code="missing_next_input",
                    message=(
                        f"Next stage {next_stage.name} requires missing input: "
                        f"{input_file}"
                    ),
                    repair_hint=(
                        f"Repair {stage.name} or the upstream producer before "
                        f"starting {next_stage.name}."
                    ),
                )

    _audit_stage_semantics(run_dir, stage, config, issues)

    critical = [issue for issue in issues if issue.get("severity") == "critical"]
    report = {
        "stage": stage.name,
        "stage_num": int(stage),
        "status": "repair_required" if critical else "pass_with_warnings" if issues else "pass",
        "next_stage": next_stage.name if next_stage is not None else None,
        "current_outputs": list(current_contract.output_files) if current_contract else [],
        "next_inputs": list(next_contract.input_files) if next_contract else [],
        "issues": issues,
        "generated": _utcnow_iso(),
    }
    report_path = stage_dir / "stage_handoff_report.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    artifacts = ("stage_handoff_report.json",)
    if critical:
        prompt_lines = [
            "# Stage Handoff Repair Required",
            "",
            f"Current stage: {int(stage):02d} {stage.name}",
            f"Next stage: {next_stage.name if next_stage is not None else 'none'}",
            "",
            "The current stage cannot safely hand off to the next stage.",
            "Repair the current or upstream artifact before proceeding.",
            "",
            "## Issues",
        ]
        prompt_lines.extend(
            f"- [{issue.get('code')}] {issue.get('message')} Repair: {issue.get('repair_hint')}"
            for issue in critical
        )
        prompt_lines.extend(
            [
                "",
                "## Current Stage Contract",
                f"Outputs required: {', '.join(report['current_outputs']) or 'none'}",
                "",
                "## Next Stage Contract",
                f"Inputs required: {', '.join(report['next_inputs']) or 'none'}",
            ]
        )
        (stage_dir / "handoff_repair_prompt.md").write_text(
            "\n".join(prompt_lines),
            encoding="utf-8",
        )
        artifacts = artifacts + ("handoff_repair_prompt.md",)

    return not critical, artifacts


def _handoff_recovery_stage(stage: Stage, run_dir: Path) -> Stage:
    report = _json_load_file(
        run_dir / f"stage-{int(stage):02d}" / "stage_handoff_report.json"
    )
    issue_codes = {
        str(issue.get("code"))
        for issue in report.get("issues", [])
        if isinstance(issue, dict)
    }
    experiment_issue = any(
        code
        in {
            "experiment_run_no_metrics",
            "analysis_missing_experiment_summary",
            "analysis_empty_metrics",
            "analysis_empty_results_table",
            "analysis_failed_run_diagnostic",
            "paper_contains_failed_run_diagnostic",
        }
        for code in issue_codes
    )
    if experiment_issue:
        return Stage.ITERATIVE_REFINE
    if stage == Stage.CODE_GENERATION:
        return Stage.CODE_GENERATION
    if stage in (Stage.EXPERIMENT_RUN, Stage.ITERATIVE_REFINE):
        return Stage.CODE_GENERATION
    if stage == Stage.RESULT_ANALYSIS:
        return Stage.ITERATIVE_REFINE
    if stage == Stage.RESEARCH_DECISION:
        return Stage.RESULT_ANALYSIS
    if stage in {
        Stage.PAPER_OUTLINE,
        Stage.PAPER_DRAFT,
        Stage.PEER_REVIEW,
        Stage.PAPER_REVISION,
        Stage.QUALITY_GATE,
    }:
        return Stage.PAPER_OUTLINE
    if stage in {Stage.EXPORT_PUBLISH, Stage.CITATION_VERIFY}:
        return Stage.EXPORT_PUBLISH
    return recovery_rollback_stage(stage)


def _run_experiment_diagnosis(run_dir: Path, config: RCConfig, run_id: str) -> None:
    """Run experiment diagnosis after Stage 14 and save reports.

    Produces:
    - ``run_dir/experiment_diagnosis.json`` — structured diagnosis + quality assessment
    - ``run_dir/repair_prompt.txt`` — repair instructions (if quality is insufficient)
    """
    try:
        from researchclaw.pipeline.experiment_diagnosis import (
            diagnose_experiment,
            assess_experiment_quality,
        )

        # Find the most recent stage-14 experiment_summary.json
        summary_path = None
        for candidate in sorted(run_dir.glob("stage-14*/experiment_summary.json")):
            summary_path = candidate
        if not summary_path or not summary_path.exists():
            return

        summary = json.loads(summary_path.read_text(encoding="utf-8"))

        # Collect stdout/stderr from experiment runs
        # Look in stage-12 (EXPERIMENT_RUN) and stage-13 (ITERATIVE_REFINE), not stage-14
        stdout, stderr = "", ""
        runs_dir = None
        for _candidate_runs in sorted(run_dir.glob("stage-1[23]*/runs"), reverse=True):
            if _candidate_runs.is_dir():
                runs_dir = _candidate_runs
                break
        if runs_dir is None:
            runs_dir = summary_path.parent / "runs"
        if runs_dir.is_dir():
            for run_file in sorted(runs_dir.glob("*.json"))[:5]:
                try:
                    run_data = json.loads(run_file.read_text(encoding="utf-8"))
                    if isinstance(run_data, dict):
                        stdout += run_data.get("stdout", "") + "\n"
                        stderr += run_data.get("stderr", "") + "\n"
                except (json.JSONDecodeError, OSError):
                    continue

        # Load experiment plan from stage-09
        plan = None
        for candidate in sorted(run_dir.glob("stage-09*/exp_plan.yaml")):
            try:
                import yaml as _yaml_diag
                plan = _yaml_diag.safe_load(candidate.read_text(encoding="utf-8"))
            except Exception:
                pass
        if plan is None:
            for candidate in sorted(run_dir.glob("stage-09*/experiment_design.json")):
                try:
                    plan = json.loads(candidate.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    pass

        # Load refinement log if available
        ref_log = None
        for candidate in sorted(run_dir.glob("stage-13*/refinement_log.json")):
            try:
                ref_log = json.loads(candidate.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        # Run diagnosis
        diag = diagnose_experiment(
            experiment_summary=summary,
            experiment_plan=plan,
            refinement_log=ref_log,
            stdout=stdout.strip(),
            stderr=stderr.strip(),
        )

        # Run quality assessment
        qa = assess_experiment_quality(summary, ref_log)

        # Save diagnosis report
        diag_report = {
            "diagnosis": diag.to_dict(),
            "quality_assessment": {
                "mode": qa.mode.value,
                "sufficient": qa.sufficient,
                "repair_possible": qa.repair_possible,
                "deficiency_types": [d.type.value for d in qa.deficiencies],
            },
            "repair_needed": not qa.sufficient,
            "generated": _utcnow_iso(),
        }
        _progress_artifact_path(run_dir, "experiment_diagnosis.json", create=True).write_text(
            json.dumps(diag_report, indent=2), encoding="utf-8"
        )

        if not qa.sufficient:
            # Generate repair prompt for the REFINE loop
            from researchclaw.pipeline.experiment_repair import build_repair_prompt

            code: dict[str, str] = {}
            # Try refined code first, then stage-10 experiment dir, then raw stage-10
            for _glob_pat in (
                "stage-13*/experiment_final/*.py",
                "stage-10*/experiment/*.py",
                "stage-10*/*.py",
            ):
                for candidate in sorted(run_dir.glob(_glob_pat)):
                    try:
                        code[candidate.name] = candidate.read_text(encoding="utf-8")
                    except (OSError, UnicodeDecodeError):
                        pass
                if code:
                    break

            repair_prompt = build_repair_prompt(
                diag, code, time_budget_sec=config.experiment.time_budget_sec
            )
            _progress_artifact_path(run_dir, "repair_prompt.txt", create=True).write_text(
                repair_prompt, encoding="utf-8"
            )
            logger.info(
                "[%s] Experiment diagnosis: mode=%s, deficiencies=%d - repair prompt saved",
                run_id, qa.mode.value, len(diag.deficiencies),
            )
            print(
                f"[{run_id}] Experiment diagnosis: {qa.mode.value} "
                f"({len(diag.deficiencies)} issues found, repair needed)"
            )
        else:
            logger.info(
                "[%s] Experiment diagnosis: mode=%s, sufficient=True - quality OK",
                run_id, qa.mode.value,
            )
            print(f"[{run_id}] Experiment diagnosis: {qa.mode.value} - quality OK")

    except Exception as exc:
        logger.warning("Experiment diagnosis failed: %s", exc)


def _run_experiment_repair(run_dir: Path, config: RCConfig, run_id: str) -> None:
    """Execute the experiment repair loop when diagnosis finds quality issues.

    Calls the repair loop from ``experiment_repair.py`` which:
    1. Loads experiment code and diagnosis
    2. Gets fixes from LLM or OpenCode
    3. Re-runs experiment in sandbox
    4. Re-assesses quality
    5. Repeats up to max_cycles
    """
    try:
        from researchclaw.pipeline.experiment_repair import run_repair_loop

        repair_result = run_repair_loop(
            run_dir=run_dir,
            config=config,
            run_id=run_id,
        )

        # Save repair result
        _progress_artifact_path(run_dir, "experiment_repair_result.json", create=True).write_text(
            json.dumps(repair_result.to_dict(), indent=2), encoding="utf-8"
        )

        # BUG-186: Promote best experiment summary to stage-14/ so
        # downstream stages (sanitizer, paper_verifier) see it.
        # BUG-198: Only promote if the repair summary is RICHER than
        # the existing stage-14 summary.  The repair loop can produce
        # empty summaries (metrics: {}, 0 conditions) which would
        # overwrite enriched data from the analysis stage.
        if repair_result.best_experiment_summary:
            from researchclaw.pipeline.experiment_repair import (
                _summary_quality_score,
            )

            best_path = run_dir / "stage-14" / "experiment_summary.json"
            existing_score = 0.0
            if best_path.exists():
                try:
                    existing = json.loads(
                        best_path.read_text(encoding="utf-8")
                    )
                    existing_score = _summary_quality_score(existing)
                except (json.JSONDecodeError, OSError):
                    pass

            repair_score = _summary_quality_score(
                repair_result.best_experiment_summary
            )

            if repair_score > existing_score:
                best_path.write_text(
                    json.dumps(
                        repair_result.best_experiment_summary, indent=2
                    ),
                    encoding="utf-8",
                )
                logger.info(
                    "[%s] Promoted repair results to stage-14 "
                    "(score %.1f > %.1f, success=%s)",
                    run_id, repair_score, existing_score,
                    repair_result.success,
                )
            else:
                logger.info(
                    "[%s] Kept existing stage-14 summary (score %.1f >= "
                    "repair score %.1f)",
                    run_id, existing_score, repair_score,
                )

        if repair_result.success:
            # Re-run diagnosis with updated results
            _run_experiment_diagnosis(run_dir, config, run_id)
        else:
            logger.info(
                "[%s] Repair loop completed without reaching full_paper quality "
                "(best mode: %s, %d cycles)",
                run_id, repair_result.final_mode.value, repair_result.total_cycles,
            )

    except Exception as exc:
        logger.warning("[%s] Experiment repair failed: %s", run_id, exc)
        print(f"[{run_id}] Experiment repair failed: {exc}")


def execute_pipeline(
    *,
    run_dir: Path,
    run_id: str,
    config: RCConfig,
    adapters: AdapterBundle,
    from_stage: Stage = Stage.TOPIC_INIT,
    auto_approve_gates: bool = False,
    stop_on_gate: bool = False,
    skip_noncritical: bool = False,
    kb_root: Path | None = None,
    cancel_event: "threading.Event | None" = None,
) -> list[StageResult]:
    """Execute pipeline stages sequentially from `from_stage` and write summary."""

    results: list[StageResult] = []
    started = False
    total_stages = len(STAGE_SEQUENCE)

    # ── Integration hooks: EventLog, ExperimentMemory, CostTracker ──
    event_log = None
    try:
        from researchclaw.pipeline.event_log import EventLog, EventType, create_event
        event_log = EventLog(log_dir=run_dir)
        event_log.append(create_event(
            EventType.PIPELINE_START, run_id=run_id,
            stages=total_stages, from_stage=int(from_stage),
        ))
    except Exception:
        logger.debug("Event log initialisation skipped")

    exp_memory = None
    try:
        from researchclaw.memory.experiment_memory import ExperimentMemory
        _mem_dir = run_dir / "experiment_memory"
        _mem_dir.mkdir(parents=True, exist_ok=True)
        exp_memory = ExperimentMemory(store_dir=str(_mem_dir))
    except Exception:
        logger.debug("Experiment memory initialisation skipped")

    cost_budget = getattr(config.experiment.cli_agent, "max_budget_usd", 0.0) or 0.0

    for stage in STAGE_SEQUENCE:
        started = _should_start(stage, from_stage, started)
        if not started:
            continue

        # ── Check for cancellation before each stage ──
        if cancel_event is not None and cancel_event.is_set():
            logger.info("[%s] Pipeline cancelled before stage %s", run_id, stage.name)
            print(f"[{run_id}] Pipeline cancelled by user.")
            break

        stage_num = int(stage)
        prefix = f"[{run_id}] Stage {stage_num:02d}/{total_stages}"
        config = _config_with_latest_run_source(run_dir, config)
        _write_heartbeat(run_dir, stage, run_id)
        print(f"{prefix} {stage.name} -- running...")

        # ── Event log: stage start ──
        if event_log:
            try:
                event_log.append(create_event(
                    EventType.STAGE_START, run_id=run_id, stage=stage.name,
                ))
            except Exception:
                pass

        # ── Cost budget check ──
        if cost_budget > 0:
            try:
                from researchclaw.cost_tracker import get_global_tracker
                if not get_global_tracker().check_budget(cost_budget):
                    logger.warning(
                        "Cost budget $%.2f exceeded - continuing in recovery mode",
                        cost_budget,
                    )
                    print(
                        f"{prefix} BUDGET EXCEEDED ($%.2f) - continuing" % cost_budget
                    )
            except Exception:
                pass

        # BUG-218: Ensure the best stage-14 experiment data is promoted
        # BEFORE paper writing begins.  Without this, the recursive REFINE
        # path writes the paper using the latest (potentially worse)
        # iteration's data, because the post-recursion promotion at line
        # ~547 runs only after the recursive call—i.e. after the paper
        # has already been written.
        if stage == Stage.PAPER_OUTLINE:
            try:
                _promote_best_stage14(run_dir, config)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Failed to promote best stage-14 before paper writing: %s",
                    exc,
                )

        t0 = _time.monotonic()

        result = execute_stage(
            stage,
            run_dir=run_dir,
            run_id=run_id,
            config=config,
            adapters=adapters,
            auto_approve_gates=auto_approve_gates,
        )
        elapsed = _time.monotonic() - t0

        # ── Event log: stage end ──
        if event_log:
            try:
                etype = EventType.STAGE_END if result.status == StageStatus.DONE else EventType.STAGE_FAIL
                event_log.append(create_event(
                    etype, run_id=run_id, stage=stage.name,
                    status=result.status.value, elapsed_sec=round(elapsed, 1),
                    error=result.error,
                ))
            except Exception:
                pass

        # ── ExperimentSpec: generate after design, validate after analysis ──
        if stage == Stage.EXPERIMENT_DESIGN and result.status == StageStatus.DONE:
            try:
                from researchclaw.pipeline.experiment_spec import ExperimentSpec, MetricDef, generate_spec
                spec_text = generate_spec(config.research.topic, "")
                spec_path = run_dir / f"stage-{int(stage):02d}" / "experiment_spec.md"
                spec_path.write_text(spec_text, encoding="utf-8")
                logger.info("Experiment spec generated: %s", spec_path)
            except Exception:
                logger.debug("Experiment spec generation skipped")

        if stage == Stage.RESULT_ANALYSIS and result.status == StageStatus.DONE:
            try:
                from researchclaw.pipeline.experiment_spec import parse_spec, validate_results_against_spec
                spec_path = run_dir / "stage-09" / "experiment_spec.md"
                if spec_path.exists():
                    spec = parse_spec(spec_path.read_text(encoding="utf-8"))
                    results_path = run_dir / "results.json"
                    exp_results = {}
                    if results_path.exists():
                        exp_results = json.loads(results_path.read_text(encoding="utf-8"))
                    violations = validate_results_against_spec(spec, exp_results)
                    if violations:
                        logger.warning("Spec violations: %s", violations)
                        (run_dir / f"stage-{int(stage):02d}" / "spec_violations.json").write_text(
                            json.dumps(violations, indent=2), encoding="utf-8"
                        )
            except Exception:
                logger.debug("Experiment spec validation skipped")

        # ── Pitfall detection after code generation / experiment run ──
        if stage in (Stage.CODE_GENERATION, Stage.EXPERIMENT_RUN) and result.status == StageStatus.DONE:
            try:
                from researchclaw.pipeline.pitfall_detector import PitfallDetector
                detector = PitfallDetector()
                code_path = run_dir / f"stage-{int(stage):02d}"
                code_files = list(code_path.rglob("*.py"))
                code_text = "\n".join(f.read_text(errors="ignore") for f in code_files[:5])
                pitfalls = detector.detect_all(code=code_text, results={}, experiment_config={})
                if pitfalls:
                    critical = [p for p in pitfalls if p.severity == "critical"]
                    if critical:
                        logger.warning("CRITICAL pitfalls detected: %s", [p.description for p in critical])
                    pitfall_report = [{"type": p.type.value, "severity": p.severity, "description": p.description} for p in pitfalls]
                    (run_dir / f"stage-{int(stage):02d}" / "pitfall_report.json").write_text(
                        json.dumps(pitfall_report, indent=2), encoding="utf-8"
                    )
            except Exception:
                logger.debug("Pitfall detection skipped")

        # ── Experiment memory: record outcome after experiment stages ──
        if stage in (Stage.EXPERIMENT_RUN, Stage.ITERATIVE_REFINE) and result.status == StageStatus.DONE and exp_memory:
            try:
                from researchclaw.memory.experiment_memory import ExperimentOutcome
                import time as _time_mod
                results_path = run_dir / "results.json"
                metric_val = 0.0
                if results_path.exists():
                    rdata = json.loads(results_path.read_text(encoding="utf-8"))
                    metric_val = rdata.get(config.experiment.metric_key, 0.0)
                exp_memory.record_outcome(ExperimentOutcome(
                    run_id=run_id, stage=stage.name,
                    hypothesis=config.research.topic, config={},
                    metric_name=config.experiment.metric_key,
                    metric_value=float(metric_val) if metric_val else 0.0,
                    baseline_value=0.0, improvement=0.0,
                    success=result.status == StageStatus.DONE,
                    failure_mode=result.error,
                    packages_used=[], hyperparameters={},
                    timestamp=_time_mod.time(), duration_sec=elapsed,
                ))
            except Exception:
                logger.debug("Experiment memory recording skipped")

        # --- Experiment diagnosis + repair before Stage 14 handoff audit ---
        if (
            stage == Stage.RESULT_ANALYSIS
            and result.status == StageStatus.DONE
            and config.experiment.repair.enabled
        ):
            _run_experiment_diagnosis(run_dir, config, run_id)

            _diag_path = _existing_progress_artifact(run_dir, "experiment_diagnosis.json")
            if _diag_path is not None:
                try:
                    _diag_data = json.loads(_diag_path.read_text(encoding="utf-8"))
                    if _diag_data.get("repair_needed"):
                        _run_experiment_repair(run_dir, config, run_id)
                except (json.JSONDecodeError, OSError):
                    pass

        # --- Stage handoff audit: validate current output against next input ---
        if result.status == StageStatus.DONE:
            handoff_ok, handoff_artifacts = _run_stage_handoff_audit(
                run_dir,
                stage=stage,
                result=result,
                config=config,
            )
            if handoff_artifacts:
                result = replace(
                    result,
                    artifacts=tuple(
                        dict.fromkeys((*result.artifacts, *handoff_artifacts))
                    ),
                )
            if not handoff_ok:
                audit_error = (
                    f"Stage handoff audit failed for {stage.name}; "
                    "repair required before starting the next stage"
                )
                logger.warning("[%s] %s", run_id, audit_error)
                result = replace(
                    result,
                    status=StageStatus.FAILED,
                    error=audit_error,
                    decision="handoff_repair",
                )

        if result.status == StageStatus.BLOCKED_APPROVAL and not stop_on_gate:
            logger.warning(
                "[%s] Auto-continuing unresolved approval gate %s because stop_on_gate=False",
                run_id,
                stage.name,
            )
            result = replace(
                result,
                status=StageStatus.DONE,
                error=None,
                decision="proceed",
            )

        if result.status == StageStatus.DONE:
            arts = ", ".join(result.artifacts) if result.artifacts else "none"
            if result.decision == "degraded":
                print(
                    f"{prefix} {stage.name} -- DEGRADED ({elapsed:.1f}s) "
                    f"-- continuing with sanitization -> {arts}"
                )
            else:
                print(f"{prefix} {stage.name} -- done ({elapsed:.1f}s) -> {arts}")
        elif result.status == StageStatus.FAILED:
            err = result.error or "unknown error"
            print(f"{prefix} {stage.name} -- FAILED ({elapsed:.1f}s) -- {err}")
        elif result.status == StageStatus.BLOCKED_APPROVAL:
            print(f"{prefix} {stage.name} -- blocked (awaiting approval)")
        elif result.status == StageStatus.PAUSED:
            err = result.error or "paused"
            print(f"{prefix} {stage.name} -- PAUSED ({elapsed:.1f}s) -- {err}")
        results.append(result)

        if kb_root is not None and result.status == StageStatus.DONE:
            try:
                stage_dir = run_dir / f"stage-{int(stage):02d}"
                write_stage_to_kb(
                    kb_root,
                    stage_id=int(stage),
                    stage_name=stage.name.lower(),
                    run_id=run_id,
                    artifacts=list(result.artifacts),
                    stage_dir=stage_dir,
                    backend=config.knowledge_base.backend,
                    topic=config.research.topic,
                )
            except Exception:  # noqa: BLE001
                pass

        if result.status == StageStatus.DONE:
            _write_checkpoint(run_dir, stage, run_id, adapters=adapters)

        # --- Heartbeat for sentinel watchdog ---
        if result.status == StageStatus.DONE:
            _write_heartbeat(run_dir, stage, run_id)

        # --- PIVOT/REFINE decision handling ---
        if (
            stage == Stage.RESEARCH_DECISION
            and result.status == StageStatus.DONE
            and result.decision in DECISION_ROLLBACK
        ):
            pivot_count = _read_pivot_count(run_dir)
            # R6-4: Skip REFINE if experiment metrics are empty for consecutive cycles
            if pivot_count > 0 and _consecutive_empty_metrics(run_dir, pivot_count):
                logger.warning(
                    "Consecutive REFINE cycles produced empty metrics - forcing PROCEED"
                )
                print(
                    f"[{run_id}] Consecutive empty metrics across REFINE cycles - forcing PROCEED"
                )
                # BUG-211: Promote best stage-14 before proceeding with
                # empty data — an earlier iteration may have real metrics.
                _promote_best_stage14(run_dir, config)
            elif pivot_count < MAX_DECISION_PIVOTS:
                rollback_target = DECISION_ROLLBACK[result.decision]
                _record_decision_history(
                    run_dir, result.decision, rollback_target, pivot_count + 1
                )
                logger.info(
                    "Decision %s: rolling back to %s (attempt %d/%d)",
                    result.decision.upper(),
                    rollback_target.name,
                    pivot_count + 1,
                    MAX_DECISION_PIVOTS,
                )
                print(
                    f"[{run_id}] Decision: {result.decision.upper()} -> "
                    f"rollback to {rollback_target.name} "
                    f"(attempt {pivot_count + 1}/{MAX_DECISION_PIVOTS})"
                )
                # Version existing stage directories before overwriting
                _version_rollback_stages(
                    run_dir, rollback_target, pivot_count + 1
                )
                # Recurse from rollback target
                pivot_results = execute_pipeline(
                    run_dir=run_dir,
                    run_id=run_id,
                    config=config,
                    adapters=adapters,
                    from_stage=rollback_target,
                    auto_approve_gates=auto_approve_gates,
                    stop_on_gate=stop_on_gate,
                    skip_noncritical=skip_noncritical,
                    kb_root=kb_root,
                    cancel_event=cancel_event,
                )
                results.extend(pivot_results)
                # BUG-211: Promote best stage-14 after REFINE completes so
                # downstream stages use the best data, not just the latest.
                _promote_best_stage14(run_dir, config)
                break  # Exit current loop; recursive call handles the rest
            else:
                # Quality gate: check if experiment results are actually usable
                _quality_ok, _quality_msg = _check_experiment_quality(
                    run_dir, pivot_count
                )
                if not _quality_ok:
                    logger.warning(
                        "Max pivot attempts (%d) reached - forcing PROCEED "
                        "with quality warning: %s",
                        MAX_DECISION_PIVOTS,
                        _quality_msg,
                    )
                    print(
                        f"[{run_id}] QUALITY WARNING: {_quality_msg}"
                    )
                    # Write quality warning to run directory
                    _qw_path = run_dir / "quality_warning.txt"
                    _qw_path.write_text(
                        f"Max pivots ({MAX_DECISION_PIVOTS}) reached.\n"
                        f"Quality gate failed: {_quality_msg}\n"
                        f"Paper will be written but may have significant issues.\n",
                        encoding="utf-8",
                    )
                else:
                    logger.warning(
                        "Max pivot attempts (%d) reached - forcing PROCEED",
                        MAX_DECISION_PIVOTS,
                    )
                print(
                    f"[{run_id}] Max pivot attempts reached - forcing PROCEED"
                )

                # Prevent downstream control flow from treating this as yet
                # another rollback request after the pivot budget is exhausted.
                result = replace(result, decision="proceed")

                # BUG-205: After forced PROCEED, promote the BEST stage-14
                # experiment summary across all REFINE iterations.
                _promote_best_stage14(run_dir, config)

        # --- HITL: Handle abort decision ---
        if result.decision == "abort":
            logger.info("[%s] Pipeline aborted by user at stage %s", run_id, stage.name)
            print(f"[{run_id}] Pipeline aborted by user at {stage.name}")
            break

        if _eligible_for_auto_recovery(
            stage,
            result,
            stop_on_gate=stop_on_gate,
            skip_noncritical=skip_noncritical,
        ):
            if _auto_recovery_budget_available(run_dir, stage):
                if result.decision == "experiment_repair":
                    rollback_target = (
                        Stage.PAPER_DRAFT
                        if stage == Stage.PAPER_DRAFT
                        else Stage.ITERATIVE_REFINE
                    )
                elif result.decision == "handoff_repair":
                    rollback_target = _handoff_recovery_stage(stage, run_dir)
                else:
                    rollback_target = recovery_rollback_stage(stage)
                stage_attempt = _count_auto_recovery_attempts(
                    run_dir, source_stage=stage
                ) + 1
                total_attempts = _count_auto_recovery_attempts(run_dir) + 1
                _record_auto_recovery(
                    run_dir,
                    source_stage=stage,
                    rollback_target=rollback_target,
                    result=result,
                    attempt=stage_attempt,
                    total_attempts=total_attempts,
                )
                logger.warning(
                    "[%s] Auto-recovery: %s %s -> rollback to %s "
                    "(attempt %d/%d, total %d/%d)",
                    run_id,
                    stage.name,
                    result.status.value,
                    rollback_target.name,
                    stage_attempt,
                    MAX_AUTO_RECOVERY_ATTEMPTS_PER_STAGE,
                    total_attempts,
                    MAX_AUTO_RECOVERY_TOTAL_ATTEMPTS,
                )
                print(
                    f"[{run_id}] Auto-recovery: {stage.name} {result.status.value} "
                    f"-> rollback to {rollback_target.name} "
                    f"(attempt {stage_attempt}/{MAX_AUTO_RECOVERY_ATTEMPTS_PER_STAGE})"
                )
                _version_rollback_stages(
                    run_dir,
                    rollback_target,
                    stage_attempt,
                    end_stage=Stage.CITATION_VERIFY,
                )
                recovery_results = execute_pipeline(
                    run_dir=run_dir,
                    run_id=run_id,
                    config=config,
                    adapters=adapters,
                    from_stage=rollback_target,
                    auto_approve_gates=auto_approve_gates,
                    stop_on_gate=stop_on_gate,
                    skip_noncritical=skip_noncritical,
                    kb_root=kb_root,
                    cancel_event=cancel_event,
                )
                results.extend(recovery_results)
                break

            logger.error(
                "[%s] Auto-recovery budget exhausted for %s (%s)",
                run_id,
                stage.name,
                result.status.value,
            )
            _write_auto_recovery_budget_exhausted(
                run_dir,
                source_stage=stage,
                result=result,
            )
            print(
                f"[{run_id}] Auto-recovery budget exhausted at {stage.name} "
                f"after {MAX_AUTO_RECOVERY_ATTEMPTS_PER_STAGE} attempts"
            )

        if result.status == StageStatus.FAILED:
            if skip_noncritical and stage in NONCRITICAL_STAGES:
                logger.warning("Noncritical stage %s failed - skipping", stage.name)
            else:
                break

        if result.status == StageStatus.PAUSED:
            logger.warning(
                "[%s] Pipeline paused at %s: %s",
                run_id,
                stage.name,
                result.error or result.decision,
            )
            break

        # --- HITL: Handle rejected stage (from HITL review) ---
        if result.status == StageStatus.REJECTED:
            logger.info(
                "[%s] Stage %s rejected by reviewer - pipeline stopped",
                run_id, stage.name,
            )
            print(f"[{run_id}] Stage {stage.name} rejected -- pipeline stopped")
            break

        if result.status == StageStatus.BLOCKED_APPROVAL:
            if not stop_on_gate:
                logger.warning(
                    "[%s] Pipeline stopped at unresolved approval gate %s",
                    run_id,
                    stage.name,
                )
            break

    summary = _build_pipeline_summary(
        run_id=run_id,
        results=results,
        from_stage=from_stage,
        run_dir=run_dir,
    )
    _write_pipeline_summary(run_dir, summary)

    # ── Event log: pipeline end ──
    if event_log:
        try:
            done_count = sum(1 for r in results if r.status == StageStatus.DONE)
            failed_count = sum(1 for r in results if r.status == StageStatus.FAILED)
            event_log.append(create_event(
                EventType.PIPELINE_END, run_id=run_id,
                stages_done=done_count, stages_failed=failed_count,
            ))
        except Exception:
            pass

    # --- Evolution: extract and store lessons ---
    lessons: list[object] = []
    try:
        lessons = extract_lessons(results, run_id=run_id, run_dir=run_dir)
        if lessons:
            store = EvolutionStore(run_dir / "evolution")
            store.append_many(lessons)
            logger.info("Extracted %d lessons from pipeline run", len(lessons))
    except Exception:  # noqa: BLE001
        logger.warning("Evolution lesson extraction failed (non-blocking)")

    # --- MetaClaw bridge: convert high-severity lessons to skills ---
    try:
        _metaclaw_post_pipeline(config, results, lessons, run_id, run_dir)
    except Exception:  # noqa: BLE001
        logger.warning("MetaClaw post-pipeline hook failed (non-blocking)")

    # --- Package deliverables into a single folder ---
    try:
        deliverables_dir = _package_deliverables(run_dir, run_id, config)
        if deliverables_dir is not None:
            print(f"[{run_id}] Deliverables packaged -> {deliverables_dir}")
    except Exception:  # noqa: BLE001
        logger.warning("Deliverables packaging failed (non-blocking)")

    # --- HITL: Finalize session state ---
    try:
        hitl_session = getattr(adapters, "hitl", None)
        if hitl_session is not None:
            has_abort = any(
                r.decision == "abort" for r in results
            )
            has_failure = any(
                r.status == StageStatus.FAILED for r in results
            )
            if has_abort:
                hitl_session.abort()
            elif has_failure:
                hitl_session.abort()
            else:
                hitl_session.complete()
    except Exception:  # noqa: BLE001
        logger.debug("HITL session finalization failed (non-blocking)")

    return results


def _package_deliverables(
    run_dir: Path,
    run_id: str,
    config: RCConfig,
) -> Path | None:
    """Collect all final user-facing deliverables into a single ``deliverables/`` folder.

    Returns the deliverables directory path, or None if nothing was packaged.

    Packaged artifacts (best-available version selected automatically):
    - paper_final.md          — Final paper (Markdown)
    - paper.tex               — Conference-ready LaTeX
    - references.bib          — BibTeX bibliography
    - code/                   — Experiment code package
    - verification_report.json — Citation verification report (if available)
    """
    dest = run_dir / "deliverables"
    dest.mkdir(parents=True, exist_ok=True)

    packaged: list[str] = []

    # --- 1. Final paper (Markdown) ---
    # Prefer verified version (stage 23) over base version (stage 22)
    paper_md = None
    for candidate in [
        run_dir / "stage-23" / "paper_final_verified.md",
        run_dir / "stage-22" / "paper_final.md",
    ]:
        if candidate.exists() and candidate.stat().st_size > 0:
            paper_md = candidate
            break
    if paper_md is not None:
        shutil.copy2(paper_md, dest / "paper_final.md")
        packaged.append("paper_final.md")

    # --- 2. LaTeX paper ---
    # BUG-183: Stage 22's paper.tex has been sanitized (fabricated numbers
    # replaced with ---).  Regenerating from Markdown would undo this because
    # the Markdown was never sanitized.  Prefer Stage-22 paper.tex when a
    # sanitization report exists.  Only regenerate from verified Markdown if
    # no sanitization was performed (i.e., the run was clean).
    tex_regenerated = False
    _sanitization_report = run_dir / "stage-22" / "sanitization_report.json"
    _was_sanitized = _sanitization_report.exists()
    verified_md = run_dir / "stage-23" / "paper_final_verified.md"
    if (
        not _was_sanitized
        and paper_md is not None
        and paper_md == verified_md
        and verified_md.exists()
        and verified_md.stat().st_size > 0
    ):
        try:
            from researchclaw.templates import get_template, markdown_to_latex
            from researchclaw.pipeline.executor import _extract_paper_title

            tpl = get_template(config.export.target_conference)
            v_text = verified_md.read_text(encoding="utf-8")
            tex_content = markdown_to_latex(
                v_text,
                tpl,
                title=_extract_paper_title(v_text),
                authors=config.export.authors,
                bib_file=config.export.bib_file,
            )
            # IMP-17: Quality check — ensure regenerated LaTeX has
            # proper structure (abstract, multiple sections)
            _has_abstract = (
                "\\begin{abstract}" in tex_content
                and tex_content.split("\\begin{abstract}")[1]
                .split("\\end{abstract}")[0]
                .strip()
            )
            _section_count = tex_content.count("\\section{")
            if _has_abstract and _section_count >= 3:
                (dest / "paper.tex").write_text(tex_content, encoding="utf-8")
                packaged.append("paper.tex")
                tex_regenerated = True
                logger.info(
                    "Deliverables: regenerated paper.tex from verified markdown"
                )
            else:
                logger.warning(
                    "Regenerated paper.tex has poor structure "
                    "(abstract=%s, sections=%d) — using Stage 22 version",
                    bool(_has_abstract),
                    _section_count,
                )
        except Exception:  # noqa: BLE001
            logger.debug("paper.tex regeneration from verified md failed")
    elif _was_sanitized:
        logger.info(
            "Deliverables: using Stage 22 paper.tex (sanitized) — "
            "skipping markdown regeneration to preserve sanitization"
        )

    if not tex_regenerated:
        tex_src = run_dir / "stage-22" / "paper.tex"
        if tex_src.exists() and tex_src.stat().st_size > 0:
            shutil.copy2(tex_src, dest / "paper.tex")
            packaged.append("paper.tex")

    # --- 3. References (BibTeX) ---
    # Prefer verified bib (stage 23) over base bib (stage 22)
    bib_src = None
    for candidate in [
        run_dir / "stage-23" / "references_verified.bib",
        run_dir / "stage-22" / "references.bib",
    ]:
        if candidate.exists() and candidate.stat().st_size > 0:
            bib_src = candidate
            break
    if bib_src is not None:
        shutil.copy2(bib_src, dest / "references.bib")
        packaged.append("references.bib")

    # --- 4. Experiment code package ---
    code_src = run_dir / "stage-22" / "code"
    if code_src.is_dir():
        code_dest = dest / "code"
        if code_dest.exists():
            shutil.rmtree(code_dest)
        shutil.copytree(code_src, code_dest)
        packaged.append("code/")

    # --- 5. Verification report (optional) ---
    verify_src = run_dir / "stage-23" / "verification_report.json"
    if verify_src.exists() and verify_src.stat().st_size > 0:
        shutil.copy2(verify_src, dest / "verification_report.json")
        packaged.append("verification_report.json")

    # --- 5b. Sanitization report (degraded mode) ---
    san_src = run_dir / "stage-22" / "sanitization_report.json"
    if san_src.exists() and san_src.stat().st_size > 0:
        shutil.copy2(san_src, dest / "sanitization_report.json")
        packaged.append("sanitization_report.json")

    # --- 6. Charts (optional) ---
    charts_src = run_dir / "stage-22" / "charts"
    if charts_src.is_dir() and any(charts_src.iterdir()):
        charts_dest = dest / "charts"
        if charts_dest.exists():
            shutil.rmtree(charts_dest)
        shutil.copytree(charts_src, charts_dest)
        packaged.append("charts/")

    # --- 7. Conference style files (.sty, .bst) ---
    try:
        from researchclaw.templates import get_template

        tpl = get_template(config.export.target_conference)
        style_files = tpl.get_style_files()
        for sf in style_files:
            shutil.copy2(sf, dest / sf.name)
            packaged.append(sf.name)
        if style_files:
            logger.info(
                "Deliverables: bundled %d style files for %s",
                len(style_files),
                tpl.display_name,
            )
    except Exception:  # noqa: BLE001
        logger.debug("Style file bundling skipped (template lookup failed)")

    # --- 8. Verify & repair cite key coverage (IMP-12 + IMP-14) ---
    tex_path = dest / "paper.tex"
    bib_path = dest / "references.bib"
    if tex_path.exists() and bib_path.exists():
        try:
            tex_text = tex_path.read_text(encoding="utf-8")
            bib_text = bib_path.read_text(encoding="utf-8")
            import re as _re

            # IMP-15: Deduplicate .bib entries
            _seen_bib_keys: set[str] = set()
            _deduped_entries: list[str] = []
            for _bm in _re.finditer(
                r"(@\w+\{([^,]+),.*?\n\})", bib_text, _re.DOTALL
            ):
                _bkey = _bm.group(2).strip()
                if _bkey not in _seen_bib_keys:
                    _seen_bib_keys.add(_bkey)
                    _deduped_entries.append(_bm.group(1))
            if len(_deduped_entries) < len(
                list(_re.finditer(r"@\w+\{", bib_text))
            ):
                bib_text = "\n\n".join(_deduped_entries) + "\n"
                bib_path.write_text(bib_text, encoding="utf-8")
                logger.info(
                    "Deliverables: deduplicated .bib → %d entries",
                    len(_deduped_entries),
                )

            # Collect all cite keys from \cite{key1, key2}
            all_cite_keys: set[str] = set()
            for cm in _re.finditer(r"\\cite\{([^}]+)\}", tex_text):
                all_cite_keys.update(k.strip() for k in cm.group(1).split(","))
            bib_keys = set(_re.findall(r"@\w+\{([^,]+),", bib_text))
            missing = all_cite_keys - bib_keys

            # IMP-14: Strip orphaned \cite{key} from paper.tex
            if missing:
                logger.warning(
                    "Deliverables: stripping %d orphaned cite keys from "
                    "paper.tex: %s",
                    len(missing),
                    sorted(missing)[:10],
                )

                def _filter_cite(m: _re.Match[str]) -> str:
                    keys = [k.strip() for k in m.group(1).split(",")]
                    kept = [k for k in keys if k not in missing]
                    if not kept:
                        return ""
                    return "\\cite{" + ", ".join(kept) + "}"

                tex_text = _re.sub(r"\\cite\{([^}]+)\}", _filter_cite, tex_text)
                # Clean up whitespace artifacts: double spaces, space before period
                tex_text = _re.sub(r"  +", " ", tex_text)
                tex_text = _re.sub(r" ([.,;:)])", r"\1", tex_text)
                tex_path.write_text(tex_text, encoding="utf-8")
                logger.info(
                    "Deliverables: paper.tex repaired — all remaining cite "
                    "keys verified"
                )
            else:
                logger.info(
                    "Deliverables: all %d cite keys verified in references.bib",
                    len(all_cite_keys),
                )
        except Exception:  # noqa: BLE001
            logger.debug("Cite key verification/repair skipped")

    # --- 9. IMP-18: Compile LaTeX to verify paper.tex ---
    if tex_path.exists() and bib_path.exists():
        try:
            from researchclaw.templates.compiler import compile_latex

            compile_result = compile_latex(tex_path, max_attempts=3, timeout=120)
            if compile_result.success:
                logger.info("IMP-18: paper.tex compiles successfully")
                # Keep the generated PDF
                pdf_path = dest / tex_path.stem
                pdf_file = dest / (tex_path.stem + ".pdf")
                if pdf_file.exists():
                    packaged.append(f"{tex_path.stem}.pdf")
            else:
                logger.warning(
                    "IMP-18: paper.tex compilation failed after %d attempts: %s",
                    compile_result.attempts,
                    compile_result.errors[:3],
                )
            if compile_result.fixes_applied:
                logger.info(
                    "IMP-18: Applied %d auto-fixes: %s",
                    len(compile_result.fixes_applied),
                    compile_result.fixes_applied,
                )
        except Exception:  # noqa: BLE001
            logger.debug("IMP-18: LaTeX compilation skipped (non-blocking)")

    if not packaged:
        # Nothing to package — remove empty dir
        dest.rmdir()
        return None

    # --- Write manifest ---
    manifest = {
        "run_id": run_id,
        "target_conference": config.export.target_conference,
        "files": packaged,
        "generated": _utcnow_iso(),
        "notes": {
            "paper_final.md": "Final paper in Markdown format",
            "paper.tex": f"Conference-ready LaTeX ({config.export.target_conference})",
            "references.bib": "BibTeX bibliography (verified citations only)",
            "code/": "Experiment source code with requirements.txt",
            "verification_report.json": "Citation integrity & relevance verification",
            "charts/": "Result visualizations",
        },
    }
    (dest / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )

    logger.info(
        "Deliverables packaged: %s (%d items)",
        dest,
        len(packaged),
    )
    return dest


def _version_rollback_stages(
    run_dir: Path,
    rollback_target: Stage,
    attempt: int,
    *,
    end_stage: Stage = Stage.RESEARCH_DECISION,
) -> None:
    """Rename stage directories that will be overwritten by a PIVOT/REFINE.

    For example, if rolling back to Stage 8 (attempt 2), renames:
      stage-08/ → stage-08_v1/
      stage-09/ → stage-09_v1/
      ... up to the current rollback boundary.
    """
    import shutil

    def _remove_readonly(func: object, path: str, _exc_info: object) -> None:
        try:
            os.chmod(path, 0o700)
            func(path)  # type: ignore[misc]
        except OSError:
            pass

    def _clear_stage_dir_contents(stage_dir: Path) -> list[str]:
        errors: list[str] = []
        for child in list(stage_dir.iterdir()):
            try:
                if child.is_dir():
                    shutil.rmtree(child, onerror=_remove_readonly)
                else:
                    child.unlink()
            except OSError as exc:
                errors.append(f"{child.name}: {exc}")
        return errors

    def _append_versioning_warning(payload: dict[str, object]) -> None:
        warning_path = run_dir / "rollback_versioning_warnings.jsonl"
        try:
            with warning_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(payload, ensure_ascii=True) + "\n")
        except OSError:
            logger.warning("Failed to write rollback versioning warning")

    rollback_num = int(rollback_target)
    rerun_end = max(rollback_num, int(end_stage))

    for stage_num in range(rollback_num, rerun_end + 1):
        stage_dir = run_dir / f"stage-{stage_num:02d}"
        if stage_dir.exists():
            version_index = max(1, int(attempt))
            version_dir = run_dir / f"stage-{stage_num:02d}_v{version_index}"
            while version_dir.exists():
                version_index += 1
                version_dir = run_dir / f"stage-{stage_num:02d}_v{version_index}"
            try:
                stage_dir.rename(version_dir)
                logger.debug(
                    "Versioned %s -> %s", stage_dir.name, version_dir.name
                )
            except OSError as exc:
                logger.warning(
                    "Could not rename %s to %s during rollback versioning: %s. "
                    "Using copy-and-clear fallback.",
                    stage_dir.name,
                    version_dir.name,
                    exc,
                )
                copied = False
                copy_error = ""
                clear_errors: list[str] = []
                try:
                    shutil.copytree(stage_dir, version_dir)
                    copied = True
                    clear_errors = _clear_stage_dir_contents(stage_dir)
                except OSError as copy_exc:
                    copy_error = str(copy_exc)
                    logger.warning(
                        "Could not copy %s to %s during rollback fallback: %s",
                        stage_dir.name,
                        version_dir.name,
                        copy_exc,
                    )

                _append_versioning_warning(
                    {
                        "stage": stage_dir.name,
                        "archive": version_dir.name,
                        "attempt": attempt,
                        "rename_error": str(exc),
                        "copy_error": copy_error,
                        "copied": copied,
                        "clear_errors": clear_errors,
                        "timestamp": _utcnow_iso(),
                    }
                )


def _consecutive_empty_metrics(run_dir: Path, pivot_count: int) -> bool:
    """R6-4: Check if the current and previous REFINE cycles both produced empty metrics."""
    # Check the most recent experiment_summary.json (stage-14) and its versioned predecessor.
    # BUG-215: When stage-14/ doesn't exist (renamed to stage-14_v{N} without
    # promotion), fall back to the latest versioned directory as "current".
    current = run_dir / "stage-14" / "experiment_summary.json"
    if not current.exists():
        # Try the latest versioned directory
        for _v in range(pivot_count + 1, 0, -1):
            alt = run_dir / f"stage-14_v{_v}" / "experiment_summary.json"
            if alt.exists():
                current = alt
                break
    prev = run_dir / f"stage-14_v{pivot_count}" / "experiment_summary.json"
    for path in (current, prev):
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            # Check all possible metric locations
            has_metrics = False
            ms = data.get("metrics_summary", {})
            if isinstance(ms, dict) and ms:
                has_metrics = True
            br = data.get("best_run", {})
            if isinstance(br, dict) and br.get("metrics"):
                has_metrics = True
            if has_metrics:
                return False  # At least one cycle had real metrics
        except (json.JSONDecodeError, OSError, AttributeError):
            return False
    return True  # Both cycles had empty metrics


def _promote_best_stage14(run_dir: Path, config: RCConfig) -> None:
    """BUG-205: After forced PROCEED, promote the best stage-14 experiment.

    Scans all ``stage-14*`` directories, scores them by primary metric,
    and copies the best experiment_summary.json into ``stage-14/`` if the
    current ``stage-14/`` is not already the best.
    """
    import shutil

    metric_key = config.experiment.metric_key or "primary_metric"
    metric_dir = config.experiment.metric_direction or "maximize"

    candidates: list[tuple[float, Path]] = []
    for d in sorted(run_dir.glob("stage-14*")):
        summary_path = d / "experiment_summary.json"
        if not summary_path.exists():
            continue
        try:
            data = json.loads(summary_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        ms = data.get("metrics_summary", {})
        pm_val: float | None = None
        # BUG-DA8-03: Exact match first, then substring fallback
        # (avoids "accuracy" matching "balanced_accuracy")
        if metric_key in ms:
            _v = ms[metric_key]
            try:
                pm_val = float(_v["mean"] if isinstance(_v, dict) else _v)
            except (TypeError, ValueError, KeyError):
                pass
        if pm_val is None:
            for k, v in ms.items():
                if metric_key in k:
                    try:
                        pm_val = float(v["mean"] if isinstance(v, dict) else v)
                    except (TypeError, ValueError, KeyError):
                        pass
                    break
        if pm_val is not None:
            if math.isnan(pm_val):
                continue
            candidates.append((pm_val, d))

    if not candidates:
        return  # nothing to promote

    current_dir = run_dir / "stage-14"

    # Sort: best first
    candidates.sort(key=lambda x: x[0], reverse=(metric_dir == "maximize"))

    # BUG-226: Detect degenerate near-zero metrics (broken normalization or
    # collapsed training).  When minimising, a value >1000x smaller than the
    # second-best almost certainly comes from a degenerate iteration.
    if metric_dir == "minimize" and len(candidates) > 1:
        _bv, _bd = candidates[0]
        _sv = candidates[1][0]
        if 0 < _bv < _sv * 1e-3:
            logger.warning(
                "BUG-226: Degenerate best value %.6g is >1000× smaller than "
                "second-best %.6g — skipping degenerate iteration %s",
                _bv, _sv, _bd.name,
            )
            candidates.pop(0)

    best_val, best_dir = candidates[0]

    # BUG-223: Always write canonical best summary at run root BEFORE any
    # early return, so downstream consumers (Stage 17, Stage 20, Stage 22,
    # VerifiedRegistry) always find experiment_summary_best.json.
    _best_src = best_dir / "experiment_summary.json"
    if _best_src.exists():
        try:
            shutil.copy2(_best_src, _progress_artifact_path(run_dir, "experiment_summary_best.json", create=True))
            logger.info(
                "BUG-223: Wrote experiment_summary_best.json from %s (%.4f)",
                best_dir.name, best_val,
            )
        except OSError as exc:
            logger.warning(
                "Failed to write experiment_summary_best.json from %s: %s",
                best_dir.name,
                exc,
            )
        # BUG-225: Also copy analysis.md from the best iteration so Stage 17
        # doesn't read stale analysis from a degenerate non-versioned stage-14.
        _best_analysis = best_dir / "analysis.md"
        if _best_analysis.exists():
            try:
                shutil.copy2(_best_analysis, _progress_artifact_path(run_dir, "analysis_best.md", create=True))
            except OSError as exc:
                logger.warning(
                    "Failed to write analysis_best.md from %s: %s",
                    best_dir.name,
                    exc,
                )

    if best_dir == current_dir:
        logger.info("BUG-205: stage-14/ already has the best result (%.4f)", best_val)
        return

    # Promote: copy best summary into stage-14/
    current_summary = current_dir / "experiment_summary.json"
    best_summary = best_dir / "experiment_summary.json"
    # BUG-213: Also promote when stage-14/ is missing or empty
    if best_summary.exists():
        current_dir.mkdir(parents=True, exist_ok=True)
        logger.warning(
            "BUG-205: Promoting %s (%.4f) over stage-14/",
            best_dir.name, best_val,
        )
        try:
            shutil.copy2(best_summary, current_summary)
        except OSError as exc:
            logger.warning(
                "Failed to promote experiment_summary.json from %s: %s",
                best_dir.name,
                exc,
            )
        # Also copy charts, analysis, and figure plans if they exist
        for fname in [
            "analysis.md",
            "results_table.tex",
            "figure_plan.json",           # BUG-213: must travel with metrics
            "figure_plan_final.json",     # BUG-213: ditto
        ]:
            src = best_dir / fname
            if src.exists():
                try:
                    shutil.copy2(src, current_dir / fname)
                except OSError as exc:
                    logger.warning(
                        "Failed to promote %s from %s: %s",
                        fname,
                        best_dir.name,
                        exc,
                    )
        # Copy charts directory
        best_charts = best_dir / "charts"
        current_charts = current_dir / "charts"
        if best_charts.is_dir():
            try:
                shutil.copytree(best_charts, current_charts, dirs_exist_ok=True)
            except OSError as exc:
                logger.warning(
                    "Failed to promote charts from %s: %s",
                    best_dir.name,
                    exc,
                )


def _check_experiment_quality(
    run_dir: Path, pivot_count: int
) -> tuple[bool, str]:
    """Quality gate before forced PROCEED.

    Returns (ok, message). ok=False means experiment results have critical
    quality issues and the forced-PROCEED paper will likely be poor.
    """
    evidence_report = assess_stage14_evidence(run_dir)
    if not evidence_report.sufficient_for_stage16:
        reasons = "; ".join(evidence_report.blocking_reasons)
        return False, reasons or "Stage 14 evidence is not sufficient for paper writing"

    # BUG-DA8-18: Check experiment_summary_best.json first (repair-promoted)
    summary_path = _existing_progress_artifact(run_dir, "experiment_summary_best.json")
    if summary_path is None:
        summary_path = run_dir / "stage-14" / "experiment_summary.json"
    if not summary_path.exists():
        for v in range(pivot_count, 0, -1):
            alt = run_dir / f"stage-14_v{v}" / "experiment_summary.json"
            if alt.exists():
                summary_path = alt
                break

    if not summary_path.exists():
        return False, "No experiment_summary.json found — no metrics produced"

    try:
        data = json.loads(summary_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return False, "experiment_summary.json is malformed"

    # Check 1: Are all metrics zero?
    ms = data.get("metrics_summary", {})
    if isinstance(ms, dict):
        values: list[float] = []
        for k, v in ms.items():
            if isinstance(v, (int, float)):
                values.append(float(v))
            # BUG-212: metrics_summary values are often dicts {min,max,mean,count}
            elif isinstance(v, dict) and "mean" in v:
                _mv = v["mean"]
                if isinstance(_mv, (int, float)):
                    values.append(float(_mv))
        if values and all(v == 0.0 for v in values):
            return False, "All experiment metrics are zero — experiments likely failed"

    # Check 2: Zero variance across conditions (R13-1)
    # Look for ablation_warnings or condition comparison data
    ablation_warnings = data.get("ablation_warnings", [])
    # BUG-212: Key is "condition_summaries", not "conditions"
    conditions = data.get(
        "condition_summaries", data.get("condition_metrics", {})
    )
    if isinstance(conditions, dict) and len(conditions) >= 2:
        primary_values: list[float] = []
        for cond_name, cond_data in conditions.items():
            if isinstance(cond_data, dict):
                # BUG-212: Primary metric lives inside cond_data["metrics"]
                _metrics = cond_data.get("metrics", cond_data)
                pm = _metrics.get(
                    "primary_metric",
                    _metrics.get("primary_metric_mean"),
                )
                if isinstance(pm, (int, float)):
                    primary_values.append(float(pm))
        if (
            len(primary_values) >= 2
            and len(set(primary_values)) == 1
            and evidence_report.comparative_metric_count == 0
        ):
            return False, (
                f"All {len(primary_values)} conditions have identical primary_metric "
                f"({primary_values[0]}) — condition implementations are likely broken"
            )

    # Check 3: Too many ablation warnings
    if (
        isinstance(ablation_warnings, list)
        and len(ablation_warnings) >= 3
        and evidence_report.comparative_metric_count == 0
    ):
        return False, (
            f"{len(ablation_warnings)} ablation warnings — most conditions "
            f"produce identical results"
        )

    # Check 4: Analysis quality score (if available)
    quality = data.get("analysis_quality", data.get("quality_score"))
    if isinstance(quality, (int, float)) and quality < 3.0:
        return False, f"Analysis quality score {quality}/10 — below minimum threshold"

    return True, "Quality checks passed"


def _read_pivot_count(run_dir: Path) -> int:
    """Read how many PIVOT/REFINE decisions have been made so far."""
    history_path = _existing_progress_artifact(run_dir, "decision_history.json")
    if history_path is None:
        return 0
    try:
        data = json.loads(history_path.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return len(data)
    except (json.JSONDecodeError, OSError):
        pass
    return 0


def _record_decision_history(
    run_dir: Path, decision: str, rollback_target: Stage, attempt: int
) -> None:
    """Append a decision event to the history log."""
    history_path = (
        _existing_progress_artifact(run_dir, "decision_history.json")
        or run_dir / "decision_history.json"
    )
    history = _read_decision_history(run_dir)
    history.append({
        "decision": decision,
        "rollback_target": rollback_target.name,
        "rollback_stage_num": int(rollback_target),
        "attempt": attempt,
        "timestamp": _utcnow_iso(),
    })
    history_path.write_text(
        json.dumps(history, indent=2), encoding="utf-8"
    )



def _read_quality_score(run_dir: Path) -> float | None:
    """Extract quality score from the most recent quality_report.json."""
    report_path = _existing_progress_artifact(run_dir, "quality_report.json")
    if report_path is None:
        return None
    try:
        data = json.loads(report_path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            # Try common keys: score_1_to_10, score, quality_score
            for key in ("score_1_to_10", "score", "quality_score", "overall_score"):
                if key in data:
                    return float(data[key])
    except (json.JSONDecodeError, ValueError, TypeError):
        pass
    return None


def _write_iteration_context(
    run_dir: Path, iteration: int, reviews: str, quality_score: float | None
) -> None:
    """Write iteration feedback file so next round can read it."""
    ctx = {
        "iteration": iteration,
        "quality_score": quality_score,
        "reviews_excerpt": reviews[:3000] if reviews else "",
        "generated": _utcnow_iso(),
    }
    _progress_artifact_path(run_dir, "iteration_context.json", create=True).write_text(
        json.dumps(ctx, indent=2), encoding="utf-8"
    )


def execute_iterative_pipeline(
    *,
    run_dir: Path,
    run_id: str,
    config: RCConfig,
    adapters: AdapterBundle,
    auto_approve_gates: bool = False,
    kb_root: Path | None = None,
    max_iterations: int = 3,
    quality_threshold: float = 7.0,
    convergence_rounds: int = 2,
) -> dict[str, object]:
    """Run the full pipeline with iterative quality improvement.

    After the first full pass (stages 1-22), if the quality gate score is below
    *quality_threshold*, re-run stages 16-22 (paper writing + finalization) with
    review feedback injected.  Stop when:
      - Score >= quality_threshold, OR
      - Score hasn't improved for *convergence_rounds* consecutive iterations, OR
      - *max_iterations* reached.

    Returns a summary dict with iteration history.
    """
    iteration_scores: list[float | None] = []
    all_results: list[list[StageResult]] = []

    # --- First full pass ---
    logger.info("Iteration 1/%d: running full pipeline (stages 1-22)", max_iterations)
    results = execute_pipeline(
        run_dir=run_dir,
        run_id=f"{run_id}-iter1",
        config=config,
        adapters=adapters,
        auto_approve_gates=auto_approve_gates,
        kb_root=kb_root,
    )
    all_results.append(results)
    score = _read_quality_score(run_dir)
    iteration_scores.append(score)
    logger.info("Iteration 1 score: %s", score)

    # --- Iterative improvement ---
    for iteration in range(2, max_iterations + 1):
        # Check if we've met quality threshold
        if score is not None and score >= quality_threshold:
            logger.info(
                "Quality threshold %.1f met (score=%.1f). Stopping.",
                quality_threshold,
                score,
            )
            break

        # Check convergence (score hasn't improved)
        if len(iteration_scores) >= convergence_rounds:
            recent = iteration_scores[-convergence_rounds:]
            if all(s is not None for s in recent):
                recent_scores = [float(s) for s in recent if s is not None]
                if max(recent_scores) - min(recent_scores) < 0.5:
                    logger.info(
                        "Convergence detected: scores %s unchanged for %d rounds. Stopping.",
                        recent,
                        convergence_rounds,
                    )
                    break

        # Write iteration context with feedback from reviews
        reviews_text = ""
        reviews_path = run_dir / "stage-18" / "reviews.md"
        if reviews_path.exists():
            reviews_text = reviews_path.read_text(encoding="utf-8")
        _write_iteration_context(run_dir, iteration, reviews_text, score)

        # Re-run from PAPER_OUTLINE (stage 16) through EXPORT_PUBLISH (stage 22)
        logger.info(
            "Iteration %d/%d: re-running stages 16-22 with feedback",
            iteration,
            max_iterations,
        )
        results = execute_pipeline(
            run_dir=run_dir,
            run_id=f"{run_id}-iter{iteration}",
            config=config,
            adapters=adapters,
            from_stage=Stage.PAPER_OUTLINE,
            auto_approve_gates=auto_approve_gates,
            kb_root=kb_root,
        )
        all_results.append(results)
        score = _read_quality_score(run_dir)
        iteration_scores.append(score)
        logger.info("Iteration %d score: %s", iteration, score)

    # --- Build iterative summary ---
    converged = False
    if len(iteration_scores) >= convergence_rounds:
        recent_window = iteration_scores[-convergence_rounds:]
        if all(s is not None for s in recent_window):
            recent_scores = [float(s) for s in recent_window if s is not None]
            converged = max(recent_scores) - min(recent_scores) < 0.5

    summary: dict[str, object] = {
        "run_id": run_id,
        "total_iterations": len(iteration_scores),
        "iteration_scores": iteration_scores,
        "quality_threshold": quality_threshold,
        "converged": converged,
        "final_score": iteration_scores[-1] if iteration_scores else None,
        "met_threshold": score is not None and score >= quality_threshold,
        "stages_per_iteration": [len(r) for r in all_results],
        "generated": _utcnow_iso(),
    }
    _progress_artifact_path(run_dir, "iteration_summary.json", create=True).write_text(
        json.dumps(summary, indent=2, default=str), encoding="utf-8"
    )

    # --- Package deliverables into a single folder ---
    try:
        deliverables_dir = _package_deliverables(run_dir, run_id, config)
        if deliverables_dir is not None:
            print(f"[{run_id}] Deliverables packaged -> {deliverables_dir}")
    except Exception:  # noqa: BLE001
        logger.warning("Deliverables packaging failed (non-blocking)")

    return summary


def _metaclaw_post_pipeline(
    config: RCConfig,
    results: list[StageResult],
    lessons: list[object],
    run_id: str,
    run_dir: Path,
) -> None:
    """MetaClaw bridge: post-pipeline hook.

    1. Convert high-severity lessons into MetaClaw skills.
    2. Record skill effectiveness feedback.
    3. Signal session end to MetaClaw proxy.
    """
    bridge = getattr(config, "metaclaw_bridge", None)
    if not bridge or not getattr(bridge, "enabled", False):
        return

    from researchclaw.llm.client import LLMClient

    # 1. Lesson-to-skill conversion
    l2s = getattr(bridge, "lesson_to_skill", None)
    if l2s and getattr(l2s, "enabled", False) and lessons:
        try:
            from researchclaw.metaclaw_bridge.lesson_to_skill import (
                convert_lessons_to_skills,
            )

            min_sev = getattr(l2s, "min_severity", "warning")
            llm = LLMClient.from_rc_config(config)
            new_skills = convert_lessons_to_skills(
                lessons,
                llm,
                getattr(bridge, "skills_dir", "~/.metaclaw/skills"),
                min_severity=min_sev,
                max_skills=getattr(l2s, "max_skills_per_run", 3),
            )
            if new_skills:
                logger.info(
                    "MetaClaw: generated %d new skills from lessons: %s",
                    len(new_skills),
                    new_skills,
                )
        except Exception:  # noqa: BLE001
            logger.warning("MetaClaw lesson-to-skill conversion failed", exc_info=True)

    # 2. Skill effectiveness feedback
    try:
        from researchclaw.metaclaw_bridge.skill_feedback import (
            SkillFeedbackStore,
            record_stage_skills,
        )
        from researchclaw.metaclaw_bridge.stage_skill_map import get_stage_config

        feedback_store = SkillFeedbackStore(run_dir / "evolution" / "skill_effectiveness.jsonl")
        for result in results:
            stage_num = int(getattr(result, "stage", 0))
            stage_name = {
                1: "topic_init", 2: "problem_decompose", 3: "search_strategy",
                4: "literature_collect", 5: "literature_screen", 6: "knowledge_extract",
                7: "synthesis", 8: "hypothesis_gen", 9: "experiment_design",
                10: "code_generation", 11: "resource_planning", 12: "experiment_run",
                13: "iterative_refine", 14: "result_analysis", 15: "research_decision",
                16: "paper_outline", 17: "paper_draft", 18: "peer_review",
                19: "paper_revision", 20: "quality_gate", 21: "knowledge_archive",
                22: "export_publish", 23: "citation_verify",
            }.get(stage_num, "")
            if not stage_name:
                continue

            stage_config = get_stage_config(stage_name)
            active_skills = stage_config.get("skills", [])
            status = str(getattr(result, "status", ""))
            success = "done" in status.lower()

            if active_skills:
                record_stage_skills(
                    feedback_store,
                    stage_name,
                    run_id,
                    success,
                    active_skills,
                )
    except Exception:  # noqa: BLE001
        logger.warning("MetaClaw skill feedback recording failed")

    # 3. Signal session end (fire-and-forget)
    try:
        from researchclaw.metaclaw_bridge.session import MetaClawSession
        import json as _json
        import urllib.request as _urllib_req

        session = MetaClawSession(run_id)
        end_headers = session.end()
        # Send a minimal request to signal session end
        proxy_url = getattr(bridge, "proxy_url", "http://localhost:30000")
        url = f"{proxy_url.rstrip('/')}/v1/chat/completions"
        body = _json.dumps({
            "model": "session-end",
            "messages": [{"role": "user", "content": "session complete"}],
            "max_tokens": 1,
        }).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        headers.update(end_headers)
        req = _urllib_req.Request(url, data=body, headers=headers)
        try:
            _urllib_req.urlopen(req, timeout=5)
        except Exception:  # noqa: BLE001
            pass  # Best-effort signal
    except Exception:  # noqa: BLE001
        pass
