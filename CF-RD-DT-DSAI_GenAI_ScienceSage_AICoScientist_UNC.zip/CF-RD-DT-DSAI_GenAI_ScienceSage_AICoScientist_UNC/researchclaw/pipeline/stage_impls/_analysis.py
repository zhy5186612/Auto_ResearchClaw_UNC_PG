"""Stages 14-15: Result analysis and research decision."""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

from researchclaw.adapters import AdapterBundle
from researchclaw.config import RCConfig
from researchclaw.llm.client import LLMClient
from researchclaw.pipeline._domain import _detect_domain, _is_ml_domain
from researchclaw.pipeline.experiment_diagnosis import (
    is_topic_sensitive_diagnostic_bypass,
)
from researchclaw.pipeline.evidence_gate import (
    assess_experiment_summary,
    assess_stage14_evidence,
)
from researchclaw.pipeline._helpers import (
    StageResult,
    _build_context_preamble,
    _chat_with_prompt,
    _collect_experiment_results,
    _collect_json_context,
    _get_evolution_overlay,
    _latex_escape,
    _multi_perspective_generate,
    _existing_progress_artifact,
    _read_best_analysis,
    _read_prior_artifact,
    _safe_json_loads,
    _synthesize_perspectives,
    _utcnow_iso,
)
from researchclaw.pipeline.stages import Stage, StageStatus
from researchclaw.prompts import PromptManager

logger = logging.getLogger(__name__)


def _read_decision_history_count(run_dir: Path) -> int:
    history_path = _existing_progress_artifact(run_dir, "decision_history.json")
    if history_path is None:
        return 0
    try:
        data = json.loads(history_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return 0
    return len(data) if isinstance(data, list) else 0


def _has_usable_experiment_output(run_dir: Path) -> bool:
    summary_path = _existing_progress_artifact(run_dir, "experiment_summary_best.json")
    if summary_path is None:
        summary_path = _existing_progress_artifact(run_dir, "experiment_summary.json")
    if summary_path is None:
        return False
    try:
        data = json.loads(summary_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return False
    if not isinstance(data, dict):
        return False
    return assess_experiment_summary(data).sufficient_for_stage16


def _extract_refinement_condition_series(
    stdout: str,
    metric_key: str,
) -> dict[str, list[float]]:
    """Recover repeated per-condition metric observations from Stage 13 stdout."""

    if not stdout:
        return {}
    metric_pattern = re.escape(metric_key or "primary_metric")
    patterns = [
        re.compile(
            rf"\bcondition=(?P<condition>[^\s,;]+)\s+"
            rf"(?P<metric>{metric_pattern}|primary_metric)\s*:\s*"
            rf"(?P<value>[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)"
        ),
        re.compile(
            rf"\bcondition\s*[:=]\s*(?P<condition>[^\s,;]+).*?"
            rf"\b(?P<metric>{metric_pattern}|primary_metric)\s*[:=]\s*"
            rf"(?P<value>[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)",
            re.IGNORECASE,
        ),
    ]
    series: dict[str, list[float]] = {}
    for pattern in patterns:
        for match in pattern.finditer(stdout):
            condition = match.group("condition").strip()
            try:
                value = float(match.group("value"))
            except (TypeError, ValueError):
                continue
            series.setdefault(condition, []).append(value)
        if series:
            break
    return {condition: values for condition, values in series.items() if values}


def _series_summary_stats(values: list[float]) -> dict[str, float | int]:
    import statistics as _stats_mod

    count = len(values)
    mean = _stats_mod.mean(values)
    std = _stats_mod.stdev(values) if count > 1 else 0.0
    return {
        "min": round(min(values), 6),
        "max": round(max(values), 6),
        "mean": round(mean, 6),
        "std": round(std, 6),
        "mcse": round(std / (count ** 0.5), 6) if count > 1 else 0.0,
        "count": count,
    }


def _load_experiment_plan_metadata(run_dir: Path) -> dict[str, Any]:
    """Extract paper-critical metadata from the experiment plan when available."""
    exp_plan_text = _read_prior_artifact(run_dir, "exp_plan.yaml") or ""
    if not exp_plan_text:
        return {}
    try:
        import yaml as _yaml

        exp_plan = _yaml.safe_load(exp_plan_text) or {}
    except Exception:
        logger.debug("Stage 14: Failed to parse exp_plan.yaml", exc_info=True)
        return {}
    if not isinstance(exp_plan, dict):
        return {}

    metadata: dict[str, Any] = {}
    for key in (
        "datasets",
        "dataset_details",
        "sample_size_regimes",
        "preprocessing",
        "metric_definitions",
        "required_figures",
        "prediction_artifacts",
        "study_mode_reporting_requirements",
        "evaluation_protocol",
        "conditions",
        "baselines",
        "proposed_methods",
        "ablations",
        "ablation_requirements",
        "model_definitions",
        "input_intent",
        "method",
        "implementation_details",
        "canonical_results_schema",
        "experiment_contract",
        "simulation_factors",
        "tuning_parameters",
        "model_reporting_requirements",
        "code_generation_requirements",
        "required_tables",
        "presentation_requirements",
    ):
        value = exp_plan.get(key)
        if value:
            metadata[key] = value
    return metadata


def _load_json_artifact_by_name(run_dir: Path, filenames: tuple[str, ...]) -> Any:
    for filename in filenames:
        for candidate in sorted(run_dir.rglob(filename), reverse=True):
            if not candidate.is_file():
                continue
            try:
                return json.loads(candidate.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
    return None


def _positive_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, float):
        return int(value) if value > 0 and value == value and value != float("inf") else None
    if isinstance(value, str):
        match = re.search(r"\b(?:N|n|sample_size|training_size|test_size)\s*(?:>=|=|:)?\s*(\d+)\b", value)
        if match:
            return _positive_int(int(match.group(1)))
        if value.strip().isdigit():
            return _positive_int(int(value.strip()))
    return None


def _first_positive_int(container: dict[str, Any], keys: tuple[str, ...]) -> int | None:
    for key in keys:
        if key in container:
            parsed = _positive_int(container.get(key))
            if parsed is not None:
                return parsed
    return None


def _build_sample_size_coverage_summary(
    plan_metadata: dict[str, Any],
    exp_data: dict[str, Any],
    *,
    scalar_refinement_fallback: bool = False,
    observed_text: str = "",
) -> dict[str, Any]:
    regimes = plan_metadata.get("sample_size_regimes")
    planned_regimes: list[dict[str, Any]] = []
    planned_sample_sizes: list[int] = []
    if isinstance(regimes, list):
        for idx, regime in enumerate(regimes):
            if isinstance(regime, dict):
                n_value = _first_positive_int(
                    regime,
                    ("N", "n", "sample_size", "training_size", "train_size", "test_size"),
                )
                reps = _first_positive_int(
                    regime,
                    (
                        "mc_replications",
                        "replications",
                        "n_replications",
                        "repeats",
                        "n_repeats",
                        "n_seeds",
                    ),
                )
                entry: dict[str, Any] = {
                    "name": regime.get("name", f"regime_{idx + 1}"),
                }
                if n_value is not None:
                    entry["N"] = n_value
                    planned_sample_sizes.append(n_value)
                if reps is not None:
                    entry["planned_replications"] = reps
                planned_regimes.append(entry)
            else:
                n_value = _positive_int(regime)
                if n_value is not None:
                    planned_sample_sizes.append(n_value)
                    planned_regimes.append({"name": f"regime_{idx + 1}", "N": n_value})

    if not planned_sample_sizes:
        dataset_details = plan_metadata.get("dataset_details")
        if isinstance(dataset_details, list):
            for detail in dataset_details:
                if not isinstance(detail, dict):
                    continue
                for key in ("sample_size", "training_size", "test_size"):
                    n_value = _positive_int(detail.get(key))
                    if n_value is not None:
                        planned_sample_sizes.append(n_value)

    metric_observation_counts: dict[str, int] = {}
    metrics_summary = exp_data.get("metrics_summary")
    if isinstance(metrics_summary, dict):
        for metric_name, stats in metrics_summary.items():
            if isinstance(stats, dict):
                count = _positive_int(stats.get("count"))
                if count is not None:
                    metric_observation_counts[str(metric_name)] = count

    unique_sizes = sorted(set(planned_sample_sizes))
    coverage: dict[str, Any] = {
        "metrics_summary_count_semantics": (
            "metric observations/runs aggregated for each metric; not dataset sample size"
        ),
        "planned_sample_sizes": unique_sizes,
        "planned_regimes": planned_regimes,
        "metric_observation_counts": metric_observation_counts,
        "source": "experiment_plan_and_metrics_summary",
    }
    if unique_sizes:
        coverage["min_planned_sample_size"] = min(unique_sizes)
        coverage["all_planned_sample_sizes_gt_200"] = all(size > 200 for size in unique_sizes)
    if metric_observation_counts:
        coverage["max_metric_observations_per_metric"] = max(metric_observation_counts.values())
        coverage["min_metric_observations_per_metric"] = min(metric_observation_counts.values())
    if observed_text:
        observed_sizes: set[int] = set()
        observed_rows = 0
        observed_tables = 0
        in_sample_table = False
        for line in observed_text.splitlines():
            if re.search(r"\bdataset\b.*\bN\b.*\bK_over_N\b", line):
                in_sample_table = True
                observed_tables += 1
                continue
            if in_sample_table and not line.strip():
                in_sample_table = False
                continue
            if in_sample_table:
                for token in line.split()[:6]:
                    n_value = _positive_int(token)
                    if n_value is not None and n_value > 200:
                        observed_sizes.add(n_value)
                        observed_rows += 1
                        break
        for match in re.finditer(r"\bsample_size\s*[=:]\s*(\d+)\b", observed_text):
            n_value = _positive_int(match.group(1))
            if n_value is not None:
                observed_sizes.add(n_value)
        if observed_sizes:
            coverage["observed_sample_sizes_from_refinement_stdout"] = sorted(observed_sizes)
        if observed_rows:
            coverage["observed_sample_table_rows_from_refinement_stdout"] = observed_rows
        if observed_tables:
            coverage["observed_sample_tables_from_refinement_stdout"] = observed_tables
    if scalar_refinement_fallback:
        coverage["scalar_refinement_fallback"] = True
        coverage["fallback_note"] = (
            "Stage 14 used scalar metrics from Stage 13 refinement_log.json. "
            "Those scalar counts must not be interpreted as simulation sample sizes."
        )
    return coverage


def _execute_result_analysis(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    _plan_metadata = _load_experiment_plan_metadata(run_dir)

    # --- Collect experiment data ---
    exp_data = _collect_experiment_results(
        run_dir,
        metric_key=config.experiment.metric_key,
        metric_direction=config.experiment.metric_direction,
    )
    runs_dir = _read_prior_artifact(run_dir, "runs/") or ""
    context = ""
    if runs_dir:
        context = _collect_json_context(Path(runs_dir), max_files=30)

    # --- R13-1: Merge Stage 13 (ITERATIVE_REFINE) results if available ---
    # Stage 13 stores richer per-condition metrics in refinement_log.json
    # that _collect_experiment_results() misses (it only scans runs/ dirs).
    _scalar_refinement_fallback = False
    _refinement_condition_series: dict[str, list[float]] = {}
    _refinement_stdout_text = ""
    _refine_log_text = _read_prior_artifact(run_dir, "refinement_log.json")
    if _refine_log_text:
        try:
            _refine_data = json.loads(_refine_log_text)
            _best_iter = None
            _best_ver = _refine_data.get("best_version", "")

            def _get_best_sandbox(it: dict) -> dict:
                """BUG-181: Metrics may be in sandbox or sandbox_after_fix."""
                sbx = it.get("sandbox", {})
                if sbx.get("metrics"):
                    return sbx
                sbx_fix = it.get("sandbox_after_fix", {})
                if sbx_fix.get("metrics"):
                    return sbx_fix
                return sbx

            for _it in _refine_data.get("iterations", []):
                _sbx = _get_best_sandbox(_it)
                _it_metrics = _sbx.get("metrics", {})
                if _it.get("version_dir", "") == _best_ver and _it_metrics:
                    _best_iter = _it
                    break
            # If no version match, take the first iteration with metrics
            if _best_iter is None:
                for _it in _refine_data.get("iterations", []):
                    _sbx = _get_best_sandbox(_it)
                    if _sbx.get("metrics"):
                        _best_iter = _it
                        break
            if _best_iter is not None:
                _sbx = _get_best_sandbox(_best_iter)
                _refine_metrics = _sbx.get("metrics", {})
                # BUG-165 fix: Prefer Stage 13 refinement data when it is
                # actually better.  The old `or True` unconditionally
                # replaced existing data, causing catastrophic regressions
                # (BUG-205: v1=78.93% destroyed by v3=8.65%).
                _refine_is_better = not exp_data["metrics_summary"]
                if not _refine_is_better and _refine_metrics:
                    # Compare primary_metric values to decide
                    _mkey = config.experiment.metric_key or "primary_metric"
                    _mdir = config.experiment.metric_direction or "maximize"
                    _existing_pm: float | None = None
                    _refine_pm: float | None = None
                    # BUG-214: Use exact match first, then substring fallback
                    # to avoid "accuracy" matching "balanced_accuracy".
                    _ms_items = list((exp_data.get("metrics_summary") or {}).items())
                    for _k, _v in _ms_items:
                        if _k == _mkey:
                            try:
                                _existing_pm = float(_v["mean"] if isinstance(_v, dict) else _v)
                            except (TypeError, ValueError, KeyError):
                                pass
                            break
                    else:
                        for _k, _v in _ms_items:
                            if _mkey in _k:
                                try:
                                    _existing_pm = float(_v["mean"] if isinstance(_v, dict) else _v)
                                except (TypeError, ValueError, KeyError):
                                    pass
                                break
                    _refine_items = list(_refine_metrics.items())
                    for _k, _v in _refine_items:
                        if _k == _mkey:
                            try:
                                _refine_pm = float(_v)
                            except (TypeError, ValueError):
                                pass
                            break
                    else:
                        for _k, _v in _refine_items:
                            if _mkey in _k:
                                try:
                                    _refine_pm = float(_v)
                                except (TypeError, ValueError):
                                    pass
                                break
                    if _existing_pm is None:
                        _refine_is_better = True  # no existing data
                    elif _refine_pm is not None:
                        if _mdir == "maximize":
                            _refine_is_better = _refine_pm > _existing_pm
                        else:
                            _refine_is_better = _refine_pm < _existing_pm
                    logger.info(
                        "Stage 14: Refine metric comparison: existing=%s, refine=%s, "
                        "direction=%s → refine_is_better=%s",
                        _existing_pm, _refine_pm, _mdir, _refine_is_better,
                    )
                _existing_metric_count = len(exp_data.get("metrics_summary") or {})
                _refine_metric_count = len(_refine_metrics) if isinstance(_refine_metrics, dict) else 0
                _allow_refine_replacement = (
                    _refine_is_better
                    and _refine_metric_count > 0
                    and (
                        _existing_metric_count == 0
                        or _refine_metric_count >= _existing_metric_count
                    )
                )
                if _refine_is_better and not _allow_refine_replacement:
                    logger.info(
                        "Stage 14: Keeping existing metric summary because refinement_log "
                        "would reduce coverage (%d existing metrics vs %d refinement metrics).",
                        _existing_metric_count,
                        _refine_metric_count,
                )
                if _refine_metrics and _allow_refine_replacement:
                    # Refinement has richer data — rebuild metrics_summary from it.
                    # Prefer repeated condition observations printed by the
                    # sandbox over one scalar aggregate per condition.
                    _refinement_stdout_text = str(_sbx.get("stdout") or "")
                    _refinement_condition_series = _extract_refinement_condition_series(
                        _refinement_stdout_text,
                        config.experiment.metric_key or "primary_metric",
                    )
                    _new_summary: dict[str, dict[str, float | None]] = {}
                    if _refinement_condition_series:
                        _metric_name = config.experiment.metric_key or "primary_metric"
                        for _cond, _values in sorted(_refinement_condition_series.items()):
                            _new_summary[f"{_cond}/{_metric_name}"] = _series_summary_stats(_values)
                    else:
                        for _mk, _mv in _refine_metrics.items():
                            try:
                                _fv = float(_mv)
                                _new_summary[_mk] = {
                                    "min": round(_fv, 6),
                                    "max": round(_fv, 6),
                                    "mean": round(_fv, 6),
                                    "count": 1,
                                }
                            except (ValueError, TypeError):
                                pass
                    if _new_summary:
                        _scalar_refinement_fallback = not bool(_refinement_condition_series)
                        exp_data["metrics_summary"] = _new_summary
                        _best_metrics_payload = {
                            k: (v.get("mean") if isinstance(v, dict) else v)
                            for k, v in _new_summary.items()
                        }
                        if not _refinement_condition_series:
                            _best_metrics_payload = {
                                k: v for k, v in _refine_metrics.items()
                            }
                        # Also update best_run with refinement data
                        exp_data["best_run"] = {
                            "run_id": "iterative-refine-best",
                            "task_id": "sandbox-main",
                            "status": "completed",
                            "metrics": _best_metrics_payload,
                            "elapsed_sec": _sbx.get("elapsed_sec", 0),
                            "stdout": "",  # omit for brevity
                            "stderr": _sbx.get("stderr", ""),
                            "timed_out": _sbx.get("timed_out", False),
                        }
                        # Rebuild latex table only when there are at least two rows.
                        if len(_new_summary) >= 2:
                            _ltx = [
                                r"\begin{table}[h]", r"\centering",
                                r"\caption{Experiment Results (Best Refinement Iteration)}",
                                r"\begin{tabular}{lrrrr}", r"\hline",
                                r"Metric & Min & Max & Mean & Metric Obs. \\", r"\hline",
                            ]
                            for _col in sorted(_new_summary.keys()):
                                _s = _new_summary[_col]
                                _ltx.append(
                                    f"{_latex_escape(_col)} & {_s['min']:.4f} & {_s['max']:.4f} "
                                    f"& {_s['mean']:.4f} & {_s['count']} \\\\"
                                )
                            _ltx.extend([r"\hline", r"\end{tabular}", r"\end{table}"])
                            exp_data["latex_table"] = "\n".join(_ltx)
                        else:
                            exp_data["latex_table"] = ""
                        # Count unique conditions (keys without 'seed' and not ending in _mean/_std)
                        if _refinement_condition_series:
                            _conditions = set(_refinement_condition_series.keys())
                        else:
                            _conditions = {
                                k for k in _refine_metrics
                                if "seed" not in k and not k.endswith("_std")
                            }
                        exp_data["runs"] = [exp_data["best_run"]]
                        # Store condition count for accurate reporting
                        exp_data["best_run"]["condition_count"] = len(_conditions)
                        if not context:
                            context = json.dumps(
                                {"refinement_best_metrics": _refine_metrics},
                                indent=2, default=str,
                            )
                        _bm_val = _refine_data.get("best_metric")
                        logger.info(
                            "R13-1: Merged %d metrics from refinement_log "
                            "(best_metric=%.4f, repeated_condition_series=%s)",
                            len(_refine_metrics),
                            float(_bm_val) if isinstance(_bm_val, (int, float)) else 0.0,
                            bool(_refinement_condition_series),
                        )
        except (json.JSONDecodeError, OSError, KeyError):
            logger.warning("R13-1: Failed to parse refinement_log.json, using Stage 12 data")

    # --- R19-2: Extract PAIRED comparisons from refinement stdout ---
    from researchclaw.experiment.sandbox import extract_paired_comparisons as _extract_paired

    _all_paired: list[dict[str, object]] = []
    # First: from _collect_experiment_results (Stage 12 runs/)
    if exp_data.get("paired_comparisons"):
        _all_paired.extend(exp_data["paired_comparisons"])
    # Second: from refinement_log iterations (Stage 13)
    if _refine_log_text:
        try:
            _rl = json.loads(_refine_log_text)
            for _it in _rl.get("iterations", []):
                for _sbx_key in ("sandbox", "sandbox_after_fix"):
                    _sbx_stdout = (_it.get(_sbx_key) or {}).get("stdout", "")
                    if _sbx_stdout:
                        _all_paired.extend(_extract_paired(_sbx_stdout))
        except (json.JSONDecodeError, OSError):
            pass

    # --- R19-3: Build structured condition_summaries from metrics ---
    _condition_summaries: dict[str, dict[str, Any]] = {}
    _ms = exp_data.get("metrics_summary", {})
    _best_metrics = {}
    if exp_data.get("best_run") and isinstance(exp_data["best_run"], dict):
        _best_metrics = exp_data["best_run"].get("metrics", {})

    # Group metrics by condition prefix (e.g., "ppo/primary_metric" → condition "ppo")
    for _mk, _mv in _best_metrics.items():
        parts = _mk.split("/")
        if len(parts) >= 2:
            cond = parts[0]
            metric_name = parts[-1]
            if cond not in _condition_summaries:
                _condition_summaries[cond] = {"metrics": {}}
            try:
                _condition_summaries[cond]["metrics"][metric_name] = float(_mv)
            except (ValueError, TypeError):
                pass

    # BUG-09 fix: If no condition summaries were built (metrics don't use
    # condition/metric format), try to extract from metrics_summary or
    # structured_results so FigureAgent has data to work with.
    if not _condition_summaries and _ms:
        # Try to parse condition data from metrics_summary keys
        for _mk, _mv in _ms.items():
            parts = _mk.split("/")
            if len(parts) >= 2:
                cond = parts[0]
                metric_name = parts[-1]
                if cond not in _condition_summaries:
                    _condition_summaries[cond] = {"metrics": {}}
                try:
                    # BUG-182: metrics_summary values are dicts {min,max,mean,count},
                    # not plain floats. Extract the mean value.
                    if isinstance(_mv, dict):
                        _val = float(_mv["mean"]) if "mean" in _mv else None
                    else:
                        _val = float(_mv)
                    if _val is not None:
                        _condition_summaries[cond]["metrics"][metric_name] = _val
                except (ValueError, TypeError, KeyError):
                    pass
    if not _condition_summaries:
        # Last resort: build from structured_results condition keys
        _sr = exp_data.get("structured_results", {})
        if isinstance(_sr, dict):
            for _sk, _sv in _sr.items():
                if isinstance(_sv, dict) and _sk not in ("metadata", "config"):
                    _condition_summaries[_sk] = {"metrics": {}}
                    for _smk, _smv in _sv.items():
                        try:
                            _condition_summaries[_sk]["metrics"][_smk] = float(_smv)
                        except (ValueError, TypeError):
                            pass

    # R33: Build per-seed data structure (needed for CIs and paired tests below)
    _seed_data: dict[str, dict[int, float]] = {}  # {condition: {seed: value}}
    for _mk, _mv in _best_metrics.items():
        parts = _mk.split("/")
        # Pattern: condition/regime/seed_id/primary_metric
        if len(parts) >= 4 and parts[-1] == config.experiment.metric_key:
            cond = parts[0]
            try:
                seed_id = int(parts[2])
                val = float(_mv)
                _seed_data.setdefault(cond, {})[seed_id] = val
            except (ValueError, TypeError):
                pass

    # Enrich condition summaries with seed counts, success rates, and CIs
    for _ck, _cv in _condition_summaries.items():
        if _ck in _refinement_condition_series:
            _vals = _refinement_condition_series[_ck]
            _stats = _series_summary_stats(_vals)
            _metric_name = config.experiment.metric_key or "primary_metric"
            _cv.setdefault("metrics", {})
            if isinstance(_cv["metrics"], dict):
                _cv["metrics"][_metric_name] = _stats["mean"]
                _cv["metrics"][f"{_metric_name}_std"] = _stats["std"]
                _cv["metrics"][f"{_metric_name}_mcse"] = _stats["mcse"]
            _cv["n_entries"] = _stats["count"]
            _cv["n_seeds"] = _stats["count"]
            _cv["metric_observations"] = _stats["count"]
        # Look for success_rate in metrics
        sr_key = f"{_ck}/success_rate"
        if sr_key in _best_metrics:
            try:
                _cv["success_rate"] = float(_best_metrics[sr_key])
            except (ValueError, TypeError):
                pass
        # Count seed-level entries to estimate n_seeds
        _seed_count = 0
        for _mk in _best_metrics:
            if _mk.startswith(f"{_ck}/") and "seed" in _mk.lower():
                _seed_count += 1
        if _seed_count > 0:
            _cv["n_seed_metrics"] = _seed_count

        # R33: Compute mean ± std and bootstrap 95% CI from per-seed data
        if _ck in _seed_data and len(_seed_data[_ck]) >= 3:
            _vals = list(_seed_data[_ck].values())
            import statistics as _stats_mod
            _mean = _stats_mod.mean(_vals)
            _std = _stats_mod.stdev(_vals)
            _cv["metrics"][f"{config.experiment.metric_key}_mean"] = round(_mean, 6)
            _cv["metrics"][f"{config.experiment.metric_key}_std"] = round(_std, 6)
            _cv["n_seeds"] = len(_vals)
            # Bootstrap 95% CI (use local RNG to avoid corrupting global state)
            import random as _rng_mod
            _rng_local = _rng_mod.Random(42)
            _boot_means = []
            for _ in range(1000):
                _sample = [_rng_local.choice(_vals) for _ in range(len(_vals))]
                _boot_means.append(_stats_mod.mean(_sample))
            _boot_means.sort()
            _ci_low = round(_boot_means[int(0.025 * len(_boot_means))], 6)
            _ci_high = round(_boot_means[int(0.975 * len(_boot_means))], 6)
            # IMP-16: Sanity check — CI must contain the mean
            if _ci_low > _mean or _ci_high < _mean:
                logger.warning(
                    "Bootstrap CI [%.4f, %.4f] does not contain mean %.4f "
                    "for condition %s — replacing CI with mean ± 1.96*SE",
                    _ci_low, _ci_high, _mean, _ck,
                )
                _se = _std / (len(_vals) ** 0.5)
                _ci_low = round(_mean - 1.96 * _se, 6)
                _ci_high = round(_mean + 1.96 * _se, 6)
            _cv["ci95_low"] = _ci_low
            _cv["ci95_high"] = _ci_high

    # Count totals
    _total_conditions = len(_condition_summaries) if _condition_summaries else None
    _total_metrics = len(_best_metrics) if _best_metrics else None
    _metric_defs_for_bypass = _plan_metadata.get("metric_definitions")
    _ablation_bypass_context: dict[str, Any] = {
        "condition_summaries": _condition_summaries,
        "metrics_summary": exp_data.get("metrics_summary", {}),
        "best_run": exp_data.get("best_run", {}),
        "datasets": _plan_metadata.get("datasets"),
        "dataset_details": _plan_metadata.get("dataset_details"),
        "metric_definitions": _metric_defs_for_bypass,
        "model_definitions": _plan_metadata.get("model_definitions"),
        "conditions": _plan_metadata.get("conditions"),
        "baselines": _plan_metadata.get("baselines"),
        "proposed_methods": _plan_metadata.get("proposed_methods"),
        "total_metric_keys": _total_metrics,
    }
    if isinstance(_metric_defs_for_bypass, list):
        _ablation_bypass_context["planned_metric_count"] = len(_metric_defs_for_bypass)
    _bypass_topic_sensitive_ablation = is_topic_sensitive_diagnostic_bypass(
        _ablation_bypass_context
    )

    # --- R33: Pipeline-level paired computation as fallback ---
    # If the experiment code's PAIRED lines are sparse or suspicious (e.g.,
    # all identical t-stats), compute fresh paired tests from per-seed data.
    # (_seed_data was built above before condition summary enrichment)
    if len(_seed_data) >= 2:
        # Find common seeds across conditions
        _all_seeds_sets = [set(v.keys()) for v in _seed_data.values()]
        _common_seeds = set.intersection(*_all_seeds_sets) if _all_seeds_sets else set()

        if len(_common_seeds) >= 3:
            _cond_names_sorted = sorted(_seed_data.keys())
            _pipeline_paired: list[dict[str, object]] = []
            # Compare each condition against the first baseline (alphabetically)
            _baseline_cond = _cond_names_sorted[0]
            for _other_cond in _cond_names_sorted[1:]:
                _diffs = []
                for _sid in sorted(_common_seeds):
                    _diffs.append(
                        _seed_data[_other_cond][_sid] - _seed_data[_baseline_cond][_sid]
                    )
                if _diffs:
                    import statistics
                    _n = len(_diffs)
                    _mean_d = statistics.mean(_diffs)
                    _std_d = statistics.stdev(_diffs) if _n > 1 else 0.0
                    _t = (_mean_d / (_std_d / (_n ** 0.5))) if _std_d > 0 else 0.0
                    _df = _n - 1
                    # Two-tailed p-value using t-distribution
                    import math
                    try:
                        from scipy.stats import t as _t_dist
                        _p = float(2 * _t_dist.sf(abs(_t), _df))
                    except ImportError:
                        _p = 2 * (1 - 0.5 * (1 + math.erf(abs(_t) / (2 ** 0.5))))
                        if _df < 30:
                            _p = min(1.0, _p * (1 + 2.5 / max(_df, 1)))
                    _pipeline_paired.append({
                        "method": _other_cond,
                        "baseline": _baseline_cond,
                        "mean_diff": round(_mean_d, 6),
                        "std_diff": round(_std_d, 6),
                        "t_stat": round(_t, 4),
                        "p_value": round(_p, 6),
                        "n_seeds": _n,
                        "source": "pipeline_computed",
                    })

            # Use pipeline-computed if experiment code's are suspicious
            _exp_t_stats = {round(p.get("t_stat", 0), 4) for p in _all_paired}
            _all_identical = len(_exp_t_stats) <= 1 and len(_all_paired) > 1
            if _pipeline_paired and (_all_identical or len(_all_paired) < len(_pipeline_paired)):
                logger.info(
                    "R33: Using %d pipeline-computed paired tests (experiment code had %d, identical=%s)",
                    len(_pipeline_paired), len(_all_paired), _all_identical,
                )
                _all_paired = _pipeline_paired

    # --- P8: Detect identical conditions (broken ablations) ---
    _ablation_warnings: list[str] = []
    if _condition_summaries and len(_condition_summaries) >= 2:
        _cond_names = sorted(_condition_summaries.keys())
        for _i in range(len(_cond_names)):
            for _j in range(_i + 1, len(_cond_names)):
                _c1, _c2 = _cond_names[_i], _cond_names[_j]
                _s1_raw = _condition_summaries[_c1]
                _s2_raw = _condition_summaries[_c2]
                # BUG-133 fix: compare inner metrics dicts, not top-level keys
                _s1_m = _s1_raw.get("metrics", {}) if isinstance(_s1_raw, dict) else {}
                _s2_m = _s2_raw.get("metrics", {}) if isinstance(_s2_raw, dict) else {}
                if not isinstance(_s1_m, dict):
                    _s1_m = {}
                if not isinstance(_s2_m, dict):
                    _s2_m = {}
                _shared_keys = set(_s1_m.keys()) & set(_s2_m.keys())
                if not _shared_keys:
                    continue
                _all_equal = True
                for _sk in _shared_keys:
                    _v1 = _s1_m[_sk]
                    _v2 = _s2_m[_sk]
                    if _v1 != _v2:
                        _all_equal = False
                        break
                if _all_equal and _shared_keys:
                    if _bypass_topic_sensitive_ablation:
                        logger.info(
                            "P8: Bypassing identical-condition ablation warning "
                            "for topic-sensitive low-information metrics: %s vs %s",
                            _c1,
                            _c2,
                        )
                        continue
                    _warn = (
                        f"ABLATION FAILURE: Conditions '{_c1}' and '{_c2}' produce "
                        f"identical outputs across all {len(_shared_keys)} metrics. "
                        f"The ablation is invalid — the differentiating parameter "
                        f"is likely not used in the code."
                    )
                    _ablation_warnings.append(_warn)
                    logger.warning("P8: %s", _warn)
                elif _shared_keys:
                    # R5-BUG-03: Also flag near-identical conditions (< 1% relative diff)
                    _near_identical = True
                    for _sk in _shared_keys:
                        _v1 = _s1_m[_sk]
                        _v2 = _s2_m[_sk]
                        try:
                            _v1f, _v2f = float(_v1), float(_v2)
                            _denom = max(abs(_v1f), abs(_v2f), 1e-12)
                            if abs(_v1f - _v2f) / _denom > 0.01:
                                _near_identical = False
                                break
                        except (TypeError, ValueError):
                            _near_identical = False
                            break
                    if _near_identical:
                        if _bypass_topic_sensitive_ablation:
                            logger.info(
                                "P8: Bypassing near-identical ablation warning "
                                "for topic-sensitive low-information metrics: %s vs %s",
                                _c1,
                                _c2,
                            )
                            continue
                        _warn = (
                            f"ABLATION WARNING: Conditions '{_c1}' and '{_c2}' produce "
                            f"near-identical outputs (<1% relative difference) across "
                            f"all {len(_shared_keys)} metrics. The ablation may be trivial."
                        )
                        _ablation_warnings.append(_warn)
                        logger.warning("P8: %s", _warn)

    # --- Evidence coverage checks: prioritize comparative breadth over seed count ---
    _evidence_coverage_warnings: list[str] = []
    _dataset_details = (
        _load_json_artifact_by_name(run_dir, ("dataset_details.json", "datasets.json"))
        or _plan_metadata.get("dataset_details")
    )
    _sample_size_regimes = (
        _load_json_artifact_by_name(run_dir, ("sample_size_regimes.json", "sample_sizes.json"))
        or _plan_metadata.get("sample_size_regimes")
    )
    _metric_definitions = (
        _load_json_artifact_by_name(run_dir, ("metric_definitions.json", "metrics_definitions.json"))
        or _plan_metadata.get("metric_definitions")
    )
    _preprocessing_plan = _plan_metadata.get("preprocessing")
    _dataset_count = len(_dataset_details) if isinstance(_dataset_details, list) else 0
    _regime_count = len(_sample_size_regimes) if isinstance(_sample_size_regimes, list) else 0

    if _dataset_count == 0:
        _warn = "DATASET DETAIL GAP: experiment plan lacks structured dataset_details metadata"
        _evidence_coverage_warnings.append(_warn)
        logger.warning("Stage 14: %s", _warn)
    if _dataset_count < 2 and _regime_count < 2:
        _warn = (
            "EVIDENCE BREADTH GAP: experiment evidence appears limited to a single dataset/regime; "
            "prefer multiple datasets or explicit sample-size regimes"
        )
        _evidence_coverage_warnings.append(_warn)
        logger.warning("Stage 14: %s", _warn)
    if not _metric_definitions:
        _warn = "METRIC DEFINITION GAP: experiment plan lacks structured metric_definitions"
        _evidence_coverage_warnings.append(_warn)
        logger.warning("Stage 14: %s", _warn)
    elif isinstance(_metric_definitions, list):
        if len(_metric_definitions) < 3:
            _warn = (
                f"METRIC BREADTH GAP: only {len(_metric_definitions)} metrics are defined in the experiment plan; comparative studies should usually report a broader literature-backed metric suite unless the benchmark standard clearly uses fewer"
            )
            _evidence_coverage_warnings.append(_warn)
            logger.warning("Stage 14: %s", _warn)
        for _metric_def in _metric_definitions:
            if not isinstance(_metric_def, dict):
                continue
            _metric_name = str(_metric_def.get("name") or "primary_metric")
            _literature_basis = str(_metric_def.get("literature_basis") or "").strip()
            _citation_keys = _metric_def.get("citation_keys")
            _has_citation_keys = bool(_citation_keys) and not (
                isinstance(_citation_keys, list) and all(not str(item).strip() for item in _citation_keys)
            )
            _is_novel = bool(_metric_def.get("is_novel"))
            _proof_or_validation = str(_metric_def.get("proof_or_validation") or "").strip()
            if not _is_novel and (not _literature_basis or not _has_citation_keys):
                _warn = (
                    f"METRIC PROVENANCE GAP: metric '{_metric_name}' is not linked to the literature or benchmark protocol that justifies using it"
                )
                _evidence_coverage_warnings.append(_warn)
                logger.warning("Stage 14: %s", _warn)
            if _is_novel and (not _literature_basis or not _proof_or_validation):
                _warn = (
                    f"NOVEL METRIC GAP: metric '{_metric_name}' is marked novel but lacks a clear insufficiency rationale or proof/validation plan"
                )
                _evidence_coverage_warnings.append(_warn)
                logger.warning("Stage 14: %s", _warn)
    if not _preprocessing_plan:
        _warn = "PREPROCESSING GAP: experiment plan does not specify preprocessing steps"
        _evidence_coverage_warnings.append(_warn)
        logger.warning("Stage 14: %s", _warn)

    _coverage_metadata = dict(_plan_metadata)
    if _sample_size_regimes:
        _coverage_metadata["sample_size_regimes"] = _sample_size_regimes
    _sample_size_coverage = _build_sample_size_coverage_summary(
        _coverage_metadata,
        exp_data,
        scalar_refinement_fallback=_scalar_refinement_fallback,
        observed_text=_refinement_stdout_text,
    )
    _metric_obs_max = _sample_size_coverage.get("max_metric_observations_per_metric")
    _planned_sample_sizes = _sample_size_coverage.get("planned_sample_sizes")
    if _scalar_refinement_fallback and _metric_obs_max == 1:
        _planned_desc = (
            ", ".join(str(v) for v in _planned_sample_sizes)
            if isinstance(_planned_sample_sizes, list) and _planned_sample_sizes
            else "not available"
        )
        _warn = (
            "SCALAR METRIC COVERAGE GAP: Stage 14 is using one scalar metric "
            "observation per metric from Stage 13 refinement fallback. "
            f"Planned sample sizes are {_planned_desc}; metrics_summary.count is "
            "metric observations, not dataset sample size."
        )
        if _warn not in _evidence_coverage_warnings:
            _evidence_coverage_warnings.append(_warn)
        logger.warning("Stage 14: %s", _warn)

    # --- Write structured experiment summary ---
    summary_payload = {
        "metrics_summary": exp_data["metrics_summary"],
        "metrics_summary_count_semantics": (
            "metric observations/runs aggregated for each metric; not dataset sample size"
        ),
        "sample_size_coverage": _sample_size_coverage,
        "total_runs": len(exp_data["runs"]),
        "best_run": exp_data["best_run"],
        "latex_table": exp_data["latex_table"],
        "generated": _utcnow_iso(),
    }
    if _plan_metadata:
        summary_payload.update(_plan_metadata)
    if _sample_size_regimes and "sample_size_regimes" not in summary_payload:
        summary_payload["sample_size_regimes"] = _sample_size_regimes
    if _dataset_details:
        summary_payload["dataset_details"] = _dataset_details
    if _metric_definitions:
        summary_payload["metric_definitions"] = _metric_definitions
    _model_defs_artifact = _load_json_artifact_by_name(
        run_dir,
        ("model_definitions.json", "models.json"),
    )
    if _model_defs_artifact:
        summary_payload["model_definitions"] = _model_defs_artifact
    _software_versions = _load_json_artifact_by_name(
        run_dir,
        ("software_versions.json", "environment.json", "runtime_environment.json"),
    )
    if _software_versions:
        summary_payload["software_versions"] = _software_versions
    _runtime_by_condition = _load_json_artifact_by_name(
        run_dir,
        ("runtime_by_condition.json", "condition_runtime.json", "runtime_metrics.json"),
    )
    if _runtime_by_condition:
        summary_payload["runtime_by_condition"] = _runtime_by_condition
    if _evidence_coverage_warnings:
        summary_payload["evidence_coverage_warnings"] = _evidence_coverage_warnings
    # R13-1: Detect zero-variance across conditions (all conditions identical primary metric)
    if _condition_summaries and len(_condition_summaries) >= 2:
        _primary_vals = []
        for _cs in _condition_summaries.values():
            if isinstance(_cs, dict):
                # Try 'metrics' dict first (actual structure), then 'primary_metric' fallback
                _metrics = _cs.get("metrics", {})
                if isinstance(_metrics, dict) and _metrics:
                    _pv_candidate = next(iter(_metrics.values()), None)
                    if isinstance(_pv_candidate, dict):
                        _pv_candidate = _pv_candidate.get("mean")
                    if isinstance(_pv_candidate, (int, float)):
                        _primary_vals.append(_pv_candidate)
                        continue
                _pm = _cs.get("primary_metric", {})
                _pv = _pm.get("mean") if isinstance(_pm, dict) else _pm
                if isinstance(_pv, (int, float)):
                    _primary_vals.append(_pv)
        if len(_primary_vals) >= 2 and len(set(_primary_vals)) == 1:
            if _bypass_topic_sensitive_ablation:
                logger.info(
                    "R13-1: Bypassing zero-variance warning for "
                    "topic-sensitive low-information primary_metric summary"
                )
            else:
                _zv_warn = (
                    f"ZERO VARIANCE: All {len(_primary_vals)} conditions have "
                    f"identical primary_metric ({_primary_vals[0]}). "
                    f"Experiment condition wiring is likely broken."
                )
                _ablation_warnings.append(_zv_warn)
                logger.warning("R13-1: %s", _zv_warn)

    if _ablation_warnings:
        summary_payload["ablation_warnings"] = _ablation_warnings
    if _all_paired:
        summary_payload["paired_comparisons"] = _all_paired
    if _condition_summaries:
        summary_payload["condition_summaries"] = _condition_summaries
        summary_payload["condition_metrics"] = _condition_summaries  # alias for quality gate
        summary_payload["total_conditions"] = _total_conditions
    if _refinement_condition_series:
        summary_payload["refinement_observation_counts"] = {
            _cond: len(_values)
            for _cond, _values in sorted(_refinement_condition_series.items())
        }
    if _total_metrics:
        summary_payload["total_metric_keys"] = _total_metrics
    if isinstance(_metric_definitions, list):
        summary_payload["planned_metric_count"] = len(_metric_definitions)
        if _total_metrics and _total_metrics < len(_metric_definitions):
            _warn = (
                f"METRIC EXECUTION GAP: run produced only {_total_metrics} metric keys but the experiment plan defined {len(_metric_definitions)} literature-backed metrics"
            )
            _evidence_coverage_warnings.append(_warn)
            logger.warning("Stage 14: %s", _warn)
            summary_payload["evidence_coverage_warnings"] = _evidence_coverage_warnings
    (stage_dir / "experiment_summary.json").write_text(
        json.dumps(summary_payload, indent=2, default=str), encoding="utf-8"
    )
    if exp_data["latex_table"]:
        (stage_dir / "results_table.tex").write_text(
            exp_data["latex_table"], encoding="utf-8"
        )

    # --- Build data-augmented prompt ---
    preamble = _build_context_preamble(
        config, run_dir, include_goal=True, include_hypotheses=True, include_exp_plan=True
    )
    data_context = ""
    if exp_data["metrics_summary"]:
        lines = [
            "\n## Quantitative Results",
            (
                "Note: metrics_summary.count is the number of scalar metric "
                "observations/runs aggregated for that metric; it is not the "
                "dataset sample size. Use metric_observations when referring "
                "to this count."
            ),
        ]
        for mk, mv in exp_data["metrics_summary"].items():
            if isinstance(mv, dict):
                lines.append(
                    f"- {mk}: mean={mv.get('mean', '?')}, min={mv.get('min', '?')}, "
                    f"max={mv.get('max', '?')}, "
                    f"metric_observations={mv.get('count', '?')}"
                )
        data_context = "\n".join(lines)

    if _sample_size_coverage:
        coverage_text = json.dumps(_sample_size_coverage, indent=2, default=str)
        if len(coverage_text) > 3000:
            coverage_text = coverage_text[:3000] + "\n... (truncated)"
        data_context += (
            f"\n\n## Sample Size and Replication Coverage\n"
            f"```json\n{coverage_text}\n```"
        )

    # Append structured results if available
    if exp_data.get("structured_results"):
        structured_text = json.dumps(
            exp_data["structured_results"], indent=2, default=str
        )
        # Truncate to avoid blowing up context
        if len(structured_text) > 6000:
            structured_text = structured_text[:6000] + "\n... (truncated)"
        data_context += (
            f"\n\n## Structured Experiment Results (from results.json)\n"
            f"```json\n{structured_text}\n```"
        )

    # P8: Inject ablation warnings into data context
    if _ablation_warnings:
        data_context += "\n\nCRITICAL ABLATION WARNINGS:\n"
        for _aw in _ablation_warnings:
            data_context += f"- {_aw}\n"
        data_context += (
            "\nYou MUST address these in your analysis. Identical conditions "
            "mean the ablation design is broken and the comparison is meaningless.\n"
        )

    if llm is not None:
        _pm = prompts or PromptManager()
        from researchclaw.prompts import DEBATE_ROLES_ANALYSIS  # noqa: PLC0415

        # --- Multi-perspective debate ---
        perspectives_dir = stage_dir / "perspectives"
        variables = {
            "preamble": preamble,
            "data_context": data_context,
            "context": context,
        }
        perspectives = _multi_perspective_generate(
            llm, DEBATE_ROLES_ANALYSIS, variables, perspectives_dir
        )
        # --- Synthesize into unified analysis ---
        analysis = _synthesize_perspectives(
            llm, perspectives, "analysis_synthesize", _pm
        )
    else:
        # Template with real data if available
        ms = exp_data["metrics_summary"]
        metrics_block = ""
        if ms:
            for mk, mv in ms.items():
                if isinstance(mv, dict):
                    metrics_block += (
                        f"- **{mk}**: mean={mv.get('mean')}, "
                        f"min={mv.get('min')}, max={mv.get('max')}, "
                        f"metric_observations={mv.get('count')}\n"
                    )
        else:
            metrics_block = f"- Primary metric key: `{config.experiment.metric_key}`\n- No quantitative data yet.\n"

        analysis = f"""# Result Analysis

## Metrics Summary
`metric_observations` is the number of scalar metric observations/runs aggregated for the metric, not dataset sample size.

{metrics_block}
## Sample Size and Replication Coverage
```json
{json.dumps(_sample_size_coverage, indent=2, default=str)}
```

## Comparative Findings
- Proposed approach results from {len(exp_data["runs"])} run(s) collected.

## Statistical Checks
- Report confidence intervals, explicit metric definitions, and per-dataset or per-regime comparisons when available.

## Limitations
- Focus limitations on genuine scope constraints without letting them dominate the narrative.

## Conclusion
- Proceed to decision stage with moderate confidence.

Generated: {_utcnow_iso()}
"""
    (stage_dir / "analysis.md").write_text(analysis, encoding="utf-8")

    artifacts = ["analysis.md", "experiment_summary.json"]
    if (stage_dir / "results_table.tex").exists():
        artifacts.append("results_table.tex")

    # IMP-6 + FA: Generate charts early (Stage 14) so paper draft can reference them
    # Try FigureAgent first (multi-agent intelligent charts), fall back to visualize.py
    _has_quantitative_results = bool(
        exp_data.get("metrics_summary")
        or _condition_summaries
        or _best_metrics
    )
    _figure_plan_saved = False
    if not _has_quantitative_results:
        logger.warning(
            "Stage 14: Skipping chart generation because no quantitative "
            "experiment metrics were collected."
        )
    if _has_quantitative_results and config.experiment.figure_agent.enabled and llm is not None:
        try:
            from researchclaw.agents.figure_agent import FigureOrchestrator
            from researchclaw.agents.figure_agent.orchestrator import FigureAgentConfig as _FACfg

            _fa_cfg = _FACfg(
                enabled=True,
                min_figures=config.experiment.figure_agent.min_figures,
                max_figures=config.experiment.figure_agent.max_figures,
                max_iterations=config.experiment.figure_agent.max_iterations,
                render_timeout_sec=config.experiment.figure_agent.render_timeout_sec,
                use_docker=config.experiment.figure_agent.use_docker,
                docker_image=config.experiment.figure_agent.docker_image,
                output_format=config.experiment.figure_agent.output_format,
                gemini_api_key=config.experiment.figure_agent.gemini_api_key,
                gemini_model=config.experiment.figure_agent.gemini_model,
                nano_banana_enabled=config.experiment.figure_agent.nano_banana_enabled,
                strict_mode=config.experiment.figure_agent.strict_mode,
                dpi=config.experiment.figure_agent.dpi,
            )
            _fa = FigureOrchestrator(llm, _fa_cfg, stage_dir=stage_dir)

            # Build conditions list from condition_summaries
            _fa_conditions = list(_condition_summaries.keys()) if _condition_summaries else []

            # BUG-09 fix: pass best_run metrics as fallback data if
            # structured_results is empty, so Planner has some data to chart
            _fa_exp_results = exp_data.get("structured_results", {})
            if not _fa_exp_results and _best_metrics:
                _fa_exp_results = {"best_run_metrics": _best_metrics}

            # Read paper draft for Decision Agent analysis
            _paper_draft = (
                _read_prior_artifact(run_dir, "paper_draft.md")
                or _read_prior_artifact(run_dir, "outline.md")
                or ""
            )

            _fa_plan = _fa.orchestrate({
                "experiment_results": _fa_exp_results,
                "condition_summaries": _condition_summaries,
                "metrics_summary": exp_data.get("metrics_summary", {}),
                "metric_key": config.experiment.metric_key,
                "conditions": _fa_conditions,
                "topic": _read_prior_artifact(run_dir, "topic.md") or config.research.topic,
                "hypothesis": _read_prior_artifact(run_dir, "hypotheses.md") or "",
                "paper_draft": _paper_draft,
                "output_dir": str(stage_dir / "charts"),
            })

            if _fa_plan.figure_count > 0:
                # Save figure plan for Stage 17 to read
                (stage_dir / "figure_plan.json").write_text(
                    json.dumps(_fa_plan.to_dict(), indent=2, default=str),
                    encoding="utf-8",
                )
                _figure_plan_saved = True
                for _cf_name in _fa_plan.get_chart_files():
                    artifacts.append(f"charts/{_cf_name}")
                logger.info(
                    "Stage 14: FigureAgent generated %d charts (%d passed review, %.1fs)",
                    _fa_plan.figure_count,
                    _fa_plan.passed_count,
                    _fa_plan.elapsed_sec,
                )
            else:
                logger.warning("Stage 14: FigureAgent produced no charts, falling back")
        except Exception as _fa_exc:
            logger.warning("Stage 14: FigureAgent failed (%s), falling back to visualize.py", _fa_exc)

    # Fallback: legacy visualize.py chart generation
    if _has_quantitative_results and not _figure_plan_saved:
        try:
            from researchclaw.experiment.visualize import (
                generate_all_charts as _gen_charts_early,
            )

            _charts_dir = stage_dir / "charts"
            _early_charts = _gen_charts_early(
                run_dir,
                _charts_dir,
                metric_key=config.experiment.metric_key,
            )
            if _early_charts:
                for _cp in _early_charts:
                    artifacts.append(f"charts/{_cp.name}")
                logger.info(
                    "Stage 14: Generated %d early charts (legacy) for paper embedding",
                    len(_early_charts),
                )
        except Exception as _chart_exc:
            logger.warning("Stage 14: Early chart generation failed: %s", _chart_exc)

    return StageResult(
        stage=Stage.RESULT_ANALYSIS,
        status=StageStatus.DONE,
        artifacts=tuple(artifacts),
        evidence_refs=tuple(f"stage-14/{a}" for a in artifacts),
    )


def _parse_decision(text: str) -> str:
    """Extract PROCEED/PIVOT/REFINE from decision text.

    Looks for the first standalone keyword on its own line after a
    ``## Decision`` heading.  Falls back to a keyword scan of the first
    few lines after the heading, but only matches the keyword itself
    (not mentions inside explanatory prose like "PIVOT is not warranted").
    Returns lowercase ``"proceed"`` / ``"pivot"`` / ``"refine"``.
    Defaults to ``"proceed"`` if nothing matches.
    """
    import re as _re

    text_upper = text.upper()
    # Look in the first occurrence after "## Decision" heading
    decision_section = ""
    for keyword in ("## DECISION", "## Decision", "## decision"):
        if keyword.upper() in text_upper:
            idx = text_upper.index(keyword.upper())
            decision_section = text[idx : idx + 200]
            break
    search_text = decision_section or text[:500]

    # First try: look for a line that is just the keyword (possibly with
    # whitespace / markdown bold / trailing punctuation).
    for line in search_text.splitlines():
        stripped = line.strip().strip("*").strip("#").strip()
        if stripped.upper() in ("PROCEED", "PIVOT", "REFINE"):
            return stripped.lower()

    # Fallback: regex for standalone word boundaries so that
    # "PIVOT is not warranted" does NOT match as a decision.
    for kw in ("PIVOT", "REFINE", "PROCEED"):
        # Only match if the keyword appears as the FIRST keyword-class token
        # on its own (not embedded in a sentence saying "not PIVOT").
        pattern = _re.compile(
            r"(?:^|##\s*Decision\s*\n\s*)" + kw, _re.IGNORECASE | _re.MULTILINE
        )
        if pattern.search(search_text):
            return kw.lower()

    # Last resort: position-based — prefer whichever keyword appears LAST
    # (the final conclusion after deliberation is more reliable than early mentions)
    # BUG-DA8-08: Old code always returned "refine" when both keywords present
    search_upper = search_text.upper()
    last_refine = search_upper.rfind("REFINE")
    last_pivot = search_upper.rfind("PIVOT")
    if last_refine >= 0 and (last_pivot < 0 or last_refine > last_pivot):
        return "refine"
    if last_pivot >= 0 and (last_refine < 0 or last_pivot > last_refine):
        return "pivot"
    return "proceed"


def _execute_research_decision(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    analysis = _read_best_analysis(run_dir) or ""
    _evidence_report = assess_stage14_evidence(
        run_dir,
        topic=getattr(config.research, "topic", ""),
    )
    _evidence_hint = (
        "\n\n## STAGE 14 EVIDENCE READINESS (deterministic control-flow gate)\n"
        f"- Sufficient for Stage 16: {'yes' if _evidence_report.sufficient_for_stage16 else 'no'}\n"
        f"- Completed comparative conditions: {len(_evidence_report.completed_conditions)} "
        f"({', '.join(_evidence_report.completed_conditions) or 'none'})\n"
        f"- Repetitions per completed condition: min={_evidence_report.min_repetitions}, "
        f"max={_evidence_report.max_repetitions}\n"
        f"- Comparative metric count: {_evidence_report.comparative_metric_count}\n"
        f"- Result-table data rows: {_evidence_report.table_rows if _evidence_report.table_rows is not None else 'not generated'}\n"
        f"- Figure manifest count: {_evidence_report.chart_count}\n"
    )
    if _evidence_report.blocking_reasons:
        _evidence_hint += (
            "- Blocking reasons: "
            + "; ".join(_evidence_report.blocking_reasons)
            + "\n"
        )
    if _evidence_report.warnings:
        _evidence_hint += (
            "- Warnings: " + "; ".join(_evidence_report.warnings) + "\n"
        )

    # P6: Detect degenerate REFINE cycles — inject warning if metrics stagnate
    _degenerate_hint = ""
    _refine_log = _read_prior_artifact(run_dir, "refinement_log.json")
    if _refine_log:
        try:
            _rl = json.loads(_refine_log)
            _iters = _rl.get("iterations", [])
            _metrics = [it.get("metric") for it in _iters if isinstance(it, dict)]
            _valid = [m for m in _metrics if m is not None]
            _all_saturated = _valid and all(m <= 0.001 or m >= 0.999 for m in _valid)
            _all_identical = len(set(_valid)) <= 1 and len(_valid) >= 2
            if _all_saturated or _all_identical:
                _degenerate_hint = (
                    "\n\nSYSTEM WARNING — DEGENERATE REFINE CYCLE DETECTED:\n"
                    f"Metrics across {len(_valid)} iterations: {_valid}\n"
                    "All iterations produce identical/saturated results. Further REFINE "
                    "cycles CANNOT fix this — the underlying benchmark design is too "
                    "easy/hard. You SHOULD choose PROCEED with a quality caveat rather "
                    "than REFINE again.\n"
                )
                logger.warning("P6: Degenerate refine cycle detected, injecting PROCEED hint")
        except (json.JSONDecodeError, OSError):
            pass

    # Phase 2: Inject experiment diagnosis into decision prompt
    _diagnosis_hint = ""
    _diag_path = _existing_progress_artifact(run_dir, "experiment_diagnosis.json")
    if _diag_path is not None:
        try:
            _diag_data = json.loads(_diag_path.read_text(encoding="utf-8"))
            _qa = _diag_data.get("quality_assessment", {})
            _mode = _qa.get("mode", "unknown")
            _sufficient = _qa.get("sufficient", False)
            _deficiency_types = _qa.get("deficiency_types", [])
            if not _sufficient:
                _diagnosis_hint = (
                    "\n\n## EXPERIMENT DIAGNOSIS (from automated analysis)\n"
                    f"Quality mode: {_mode}\n"
                    f"Sufficient for full paper: NO\n"
                    f"Issues found: {', '.join(_deficiency_types)}\n\n"
                    "IMPORTANT: The experiment has significant issues. "
                    "If REFINE is chosen, a structured repair prompt is available "
                    "at repair_prompt.txt with specific fixes for identified issues.\n"
                    "If the same issues persist after 2+ REFINE cycles, choose PROCEED "
                    "with appropriate quality caveats.\n"
                )
                logger.info(
                    "Stage 15: Injected experiment diagnosis — mode=%s, issues=%s",
                    _mode, _deficiency_types,
                )
        except (json.JSONDecodeError, OSError):
            pass

    # Improvement C: Check ablation quality — if >50% trivial, push REFINE
    _ablation_refine_hint = ""
    _exp_summary_hint = ""
    # BUG-DA8-16: Prefer experiment_summary_best.json (promoted best) over
    # alphabetically-last stage-14* (which could be a stale versioned dir)
    _exp_sum_path = _existing_progress_artifact(run_dir, "experiment_summary_best.json")
    if _exp_sum_path is None or not _exp_sum_path.is_file():
        _exp_sum_path = None
        for _s14 in sorted(run_dir.glob("stage-14*/experiment_summary.json"), reverse=True):
            _exp_sum_path = _s14
            break
    if _exp_sum_path and _exp_sum_path.is_file():
        try:
            from researchclaw.pipeline.stage_impls._paper_writing import _check_ablation_effectiveness
            _abl_exp = json.loads(_exp_sum_path.read_text(encoding="utf-8"))
            _metrics_summary = _abl_exp.get("metrics_summary", {})
            _total_conditions = _abl_exp.get("total_conditions")
            _total_metric_keys = _abl_exp.get("total_metric_keys")
            _best_metrics = {}
            _best_run = _abl_exp.get("best_run", {})
            if isinstance(_best_run, dict):
                _best_metrics = _best_run.get("metrics", {})
            _metric_preview: list[str] = []
            if isinstance(_best_metrics, dict):
                for _metric_name, _metric_value in list(_best_metrics.items())[:12]:
                    _metric_preview.append(f"- {_metric_name}: {_metric_value}")
            elif isinstance(_metrics_summary, dict):
                for _metric_name, _metric_stats in list(_metrics_summary.items())[:12]:
                    if isinstance(_metric_stats, dict):
                        _metric_preview.append(
                            f"- {_metric_name}: mean={_metric_stats.get('mean')}, n={_metric_stats.get('count')}"
                        )
            _exp_summary_hint = (
                "\n\n## EXPERIMENT SUMMARY SNAPSHOT (ground truth for this decision)\n"
                f"- Total conditions: {_total_conditions}\n"
                f"- Total metric keys: {_total_metric_keys}\n"
                f"- Metrics summary present: {'yes' if bool(_metrics_summary) else 'no'}\n"
            )
            _exp_summary_hint += _evidence_hint
            if _metric_preview:
                _exp_summary_hint += "Key reported metrics:\n" + "\n".join(_metric_preview) + "\n"
            _abl_warnings = _check_ablation_effectiveness(_abl_exp, threshold=0.02)
            if _abl_warnings:
                _trivial_count = sum(1 for w in _abl_warnings if "ineffective" in w.lower() or "trivial" in w.lower())
                _total_abl = max(1, len(_abl_warnings))
                if _trivial_count / _total_abl > 0.5:
                    _ablation_refine_hint = (
                        "\n\n## ABLATION QUALITY ASSESSMENT (CRITICAL)\n"
                        f"STRONG RECOMMENDATION: Choose REFINE.\n"
                        f"{_trivial_count}/{_total_abl} ablations show <2% difference from baseline "
                        f"(trivially similar). This means the ablation design is broken.\n"
                        "Warnings:\n" + "\n".join(f"- {w}" for w in _abl_warnings) + "\n"
                    )
                    logger.warning("C: %d/%d ablations trivial → recommending REFINE", _trivial_count, _total_abl)
        except Exception:  # noqa: BLE001
            pass

    if llm is not None:
        _pm = prompts or PromptManager()
        _overlay = _get_evolution_overlay(run_dir, "research_decision")
        sp = _pm.for_stage("research_decision", evolution_overlay=_overlay, analysis=analysis)
        _user = (
            sp.user
            + _exp_summary_hint
            + ("" if _exp_summary_hint else _evidence_hint)
            + _degenerate_hint
            + _diagnosis_hint
            + _ablation_refine_hint
            + "\nIf the analysis prose and experiment summary snapshot disagree, trust the experiment summary snapshot over stale narrative text.\n"
        )
        resp = _chat_with_prompt(llm, sp.system, _user)
        decision_md = resp.content
    else:
        decision_md = f"""# Research Decision

## Decision
PROCEED

## Justification
Current evidence suggests measurable progress with actionable limitations.

## Next Actions
- Build detailed paper outline
- Expand ablation and uncertainty analysis in writing

Generated: {_utcnow_iso()}
"""
    (stage_dir / "decision.md").write_text(decision_md, encoding="utf-8")

    # --- Extract structured decision ---
    decision = _parse_decision(decision_md)
    decision_override = ""
    if decision == "refine" and _evidence_report.sufficient_for_stage16:
        decision_override = (
            "REFINE overridden to PROCEED because the deterministic Stage 14 "
            "evidence readiness gate found comparative multi-condition metrics "
            "sufficient for Stage 16. Further experiment changes should be "
            "reported as limitations instead of causing another Stage 13-15 loop."
        )
        logger.warning("Stage 15: %s", decision_override)
        decision = "proceed"
        (stage_dir / "decision_override.md").write_text(
            "# Research Decision Override\n\n"
            f"{decision_override}\n\n"
            "The original decision text is preserved in `decision.md`.",
            encoding="utf-8",
        )
    if (
        decision == "refine"
        and _read_decision_history_count(run_dir) >= 1
        and _has_usable_experiment_output(run_dir)
        and "minimum criteria" in decision_md.lower()
    ):
        decision_override = (
            "REFINE overridden to PROCEED after a prior repair rollback because "
            "usable experiment metrics are available and another REFINE would "
            "repeat the same minimum-criteria loop."
        )
        logger.warning("Stage 15: %s", decision_override)
        decision = "proceed"
        (stage_dir / "decision_override.md").write_text(
            "# Research Decision Override\n\n"
            f"{decision_override}\n\n"
            "The original decision text is preserved in `decision.md`.",
            encoding="utf-8",
        )

    # T3.1: Validate decision quality — check for minimum experiment rigor
    _quality_warnings: list[str] = []
    _dec_lower = decision_md.lower()
    if "baseline" not in _dec_lower and "control" not in _dec_lower:
        _quality_warnings.append("Decision text does not mention baselines")
    if "dataset" not in _dec_lower and "regime" not in _dec_lower and "sample size" not in _dec_lower:
        _quality_warnings.append("Decision text does not mention dataset breadth or sample-size coverage")
    if "metric" not in _dec_lower and "accuracy" not in _dec_lower and "loss" not in _dec_lower:
        _quality_warnings.append("Decision text does not mention evaluation metrics")
    if _quality_warnings:
        logger.warning("T3.1: Decision quality warnings: %s", _quality_warnings)

    decision_payload = {
        "decision": decision,
        "raw_text_excerpt": decision_md[:500],
        "quality_warnings": _quality_warnings,
        "override": decision_override,
        "evidence_readiness": _evidence_report.to_dict(),
        "generated": _utcnow_iso(),
    }
    (stage_dir / "decision_structured.json").write_text(
        json.dumps(decision_payload, indent=2), encoding="utf-8"
    )
    (stage_dir / "decision_evidence_report.json").write_text(
        json.dumps(_evidence_report.to_dict(), indent=2),
        encoding="utf-8",
    )
    logger.info("Research decision: %s", decision)

    return StageResult(
        stage=Stage.RESEARCH_DECISION,
        status=StageStatus.DONE,
        artifacts=tuple(
            a for a in (
                "decision.md",
                "decision_structured.json",
                "decision_evidence_report.json",
                "decision_override.md" if decision_override else "",
            )
            if a
        ),
        evidence_refs=("stage-15/decision.md",),
        decision=decision,
    )
