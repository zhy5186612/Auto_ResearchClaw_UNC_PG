"""Stage 10: Code generation."""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any

from researchclaw.adapters import AdapterBundle
from researchclaw.config import RCConfig
from researchclaw.experiment.validator import (
    CodeValidation,
    format_issues_for_llm,
    validate_code,
)
from researchclaw.llm.client import LLMClient
from researchclaw.pipeline._domain import _detect_domain
from researchclaw.pipeline._helpers import (
    StageResult,
    _chat_with_prompt,
    _ensure_sandbox_deps,
    _extract_code_block,
    _extract_multi_file_blocks,
    _extract_yaml_block,
    _get_evolution_overlay,
    _load_hardware_profile,
    _read_prior_artifact,
    _safe_json_loads,
    _utcnow_iso,
)
from researchclaw.pipeline.stages import Stage, StageStatus
from researchclaw.prompts import PromptManager

logger = logging.getLogger(__name__)

# Improvement G: Continuous-action environments that are incompatible with DQN
_CONTINUOUS_ENVS = {
    "pendulum", "halfcheetah", "hopper", "walker2d", "ant", "humanoid",
    "swimmer", "reacher", "invertedpendulum", "inverteddoublependulum",
    "mountaincarcontinuous", "lunarlander-continuous",
}


def _detect_codegen_input_intent(topic: str, exp_plan: str = "") -> dict[str, str]:
    """Infer user intent once, then use it for codegen guidance."""
    def normalize_intent(intent: Any) -> dict[str, str] | None:
        if not isinstance(intent, dict):
            return None
        target_type = str(intent.get("target_type") or "").casefold()
        model_suite = str(intent.get("model_suite") or "").casefold()
        modality = str(intent.get("modality") or "").casefold()
        task_family = str(intent.get("task_family") or "").casefold()
        if target_type not in {"classification", "regression", "ambiguous_predictive"}:
            return None
        if modality not in {"tabular_or_structured", "unstructured_or_deep"}:
            modality = "tabular_or_structured"
        if not model_suite:
            if target_type == "classification" and modality == "tabular_or_structured":
                model_suite = "tabular_classification"
            elif target_type == "regression" and modality == "tabular_or_structured":
                model_suite = "tabular_regression"
            elif target_type == "ambiguous_predictive" and modality == "tabular_or_structured":
                model_suite = "ambiguous_tabular_predictive"
            else:
                model_suite = "domain_specific_or_generic"
        if task_family != "predictive":
            task_family = "predictive"
        return {
            "task_family": task_family,
            "target_type": target_type,
            "modality": modality,
            "model_suite": model_suite,
        }

    try:
        parsed_plan = json.loads(exp_plan) if exp_plan.strip() else None
    except json.JSONDecodeError:
        parsed_plan = None
    if isinstance(parsed_plan, dict):
        parsed_intent = normalize_intent(parsed_plan.get("input_intent"))
        if parsed_intent:
            return parsed_intent

    explicit_target = re.search(r'"target_type"\s*:\s*"([^"]+)"', exp_plan, re.IGNORECASE)
    explicit_suite = re.search(r'"model_suite"\s*:\s*"([^"]+)"', exp_plan, re.IGNORECASE)
    explicit_modality = re.search(r'"modality"\s*:\s*"([^"]+)"', exp_plan, re.IGNORECASE)
    explicit_intent = normalize_intent(
        {
            "task_family": "predictive",
            "target_type": explicit_target.group(1) if explicit_target else "",
            "model_suite": explicit_suite.group(1) if explicit_suite else "",
            "modality": explicit_modality.group(1) if explicit_modality else "",
        }
    )
    if explicit_intent:
        return explicit_intent

    combined = f"{topic}\n{exp_plan}".casefold()

    def has_any(tokens: tuple[str, ...]) -> bool:
        return any(token in combined for token in tokens)

    predictive = has_any((
        "predict", "prediction", "classify", "classification", "classifier",
        "regression", "forecast", "forecasting", "estimate", "estimation",
        "diagnose", "diagnosis", "presence", "detect", "detection",
        "model", "screen", "identify",
    ))
    categorical = has_any((
        "classification", "classifier", "classify", "categorical",
        "diagnosis", "diagnostic", "presence", "absence", "binary", "label",
        "detect", "detection", "fraud", "default", "churn", "mortality",
        "readmission", "disease", "cancer", "conversion", "click",
        "purchase", "failure", "approval", "attrition", "dropout", "spam",
        "pass/fail", "risk",
    ))
    continuous = has_any((
        "regression", "continuous", "numeric", "real-valued", "real valued",
        "score", "forecast", "forecasting", "value", "rate", "price", "cost",
        "demand", "sales", "revenue", "income", "load", "usage",
        "consumption", "quantity", "volume", "duration", "time to",
        "length of stay", "count", "severity", "concentration",
        "temperature", "pressure",
    ))
    unstructured_or_deep = has_any((
        "image", "images", "vision", "cnn", "convolution", "resnet", "vit",
        "transformer", "bert", "gpt", "text", "nlp", "language", "token",
        "speech", "audio", "deep learning", "neural network",
        "neural networks",
    ))
    classical = has_any((
        "classical", "classic", "traditional model", "traditional models",
        "classical model", "classical models", "comparative study",
        "compare classical",
    ))

    if categorical and continuous:
        if has_any((
            "risk", "default", "fraud", "churn", "mortality",
            "readmission", "presence", "diagnosis", "detection",
            "disease", "cancer", "conversion", "click", "purchase",
            "failure", "approval", "attrition", "dropout", "spam",
            "pass/fail",
        )):
            target_type = "classification"
        else:
            target_type = "ambiguous_predictive"
    elif categorical:
        target_type = "classification"
    elif continuous:
        target_type = "regression"
    elif predictive:
        target_type = "ambiguous_predictive"
    else:
        target_type = "unknown"

    if target_type == "classification" and not unstructured_or_deep:
        model_suite = "classical_classification" if classical else "tabular_classification"
    elif target_type == "regression" and not unstructured_or_deep:
        model_suite = "tabular_regression"
    elif target_type == "ambiguous_predictive" and not unstructured_or_deep:
        model_suite = "ambiguous_tabular_predictive"
    else:
        model_suite = "domain_specific_or_generic"

    return {
        "task_family": "predictive" if predictive else "unknown",
        "target_type": target_type,
        "modality": "unstructured_or_deep" if unstructured_or_deep else "tabular_or_structured",
        "model_suite": model_suite,
    }


def _check_rl_compatibility(code: str) -> list[str]:
    """Detect DQN + continuous-action environment mismatches.

    Returns a list of error strings if incompatible combinations are found.
    """
    errors: list[str] = []
    code_lower = code.lower()
    has_dqn = "dqn" in code_lower
    if not has_dqn:
        return errors

    for env_name in _CONTINUOUS_ENVS:
        if env_name in code_lower:
            errors.append(
                f"RL COMPATIBILITY ERROR: DQN is used with continuous-action "
                f"environment '{env_name}'. DQN only works with DISCRETE action "
                f"spaces. Use SAC, TD3, or PPO instead."
            )
    return errors


_STAGE10_BLOCKING_MARKERS = (
    "UnboundLocalError",
    "unregistered",
    "does not exist",
    "empty or trivial subclass",
    "does NOT override",
    "Import-usage mismatch",
    "NameError",
    "undefined function",
    "was removed",
    "ptp()",
    "copy-paste",
    "identical method signatures",
    "identical AST",
    "NOT a real ablation",
    "shadows stdlib/pip",
    "hardcoded metric",
    "Trivial computation detected",
)


def _is_stage10_blocking_warning(warning: str) -> bool:
    return any(marker in warning for marker in _STAGE10_BLOCKING_MARKERS)


def _write_experiment_files(exp_dir: Path, files: dict[str, str]) -> None:
    """Write the current file set and remove stale Python artifacts."""

    exp_dir.mkdir(parents=True, exist_ok=True)
    root = exp_dir.resolve()
    current_python = {
        Path(fname).as_posix()
        for fname in files
        if fname.endswith(".py")
    }
    for existing in exp_dir.rglob("*.py"):
        rel = existing.relative_to(exp_dir).as_posix()
        if rel not in current_python:
            existing.unlink()

    for fname, code in files.items():
        target = (exp_dir / fname).resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Unsafe generated filename: {fname}") from exc
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(code, encoding="utf-8")


def _prune_unreachable_python_files(files: dict[str, str]) -> tuple[dict[str, str], list[str]]:
    """Drop stale Python files not reachable from the experiment entry point."""

    python_files = {fname for fname in files if fname.endswith(".py")}
    if not python_files:
        return files, []

    entry = "main.py" if "main.py" in python_files else ""
    if not entry:
        for fname in sorted(python_files):
            code = files.get(fname, "")
            if 'if __name__' in code and '__main__' in code:
                entry = fname
                break
    if not entry:
        return files, []

    import ast

    module_to_file: dict[str, str] = {}
    for fname in python_files:
        module_path = Path(fname).with_suffix("").as_posix().replace("/", ".")
        module_to_file[module_path] = fname
        module_to_file[Path(fname).stem] = fname
    reachable: set[str] = set()
    stack = [entry]

    while stack:
        fname = stack.pop()
        if fname in reachable:
            continue
        reachable.add(fname)
        try:
            tree = ast.parse(files.get(fname, ""))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    target = module_to_file.get(alias.name)
                    if target is None:
                        module_name = alias.name.split(".", 1)[0]
                        target = module_to_file.get(module_name)
                    if target and target not in reachable:
                        stack.append(target)
            elif isinstance(node, ast.ImportFrom) and node.module:
                target = module_to_file.get(node.module)
                if target is None:
                    module_name = node.module.split(".", 1)[0]
                    target = module_to_file.get(module_name)
                if target and target not in reachable:
                    stack.append(target)

    pruned = sorted(python_files - reachable)
    if not pruned:
        return files, []
    cleaned = {
        fname: code
        for fname, code in files.items()
        if not fname.endswith(".py") or fname in reachable
    }
    return cleaned, pruned


def _collect_stage10_quality_warnings(files: dict[str, str]) -> list[str]:
    from researchclaw.experiment.validator import (
        check_code_complexity,
        deep_validate_files,
    )

    warnings: list[str] = []
    main_code = files.get("main.py", "")
    if main_code:
        for warning in check_code_complexity(main_code):
            warnings.append(f"[main.py] {warning}")
    warnings.extend(deep_validate_files(files))
    return sorted(dict.fromkeys(warnings))


def _execute_code_generation(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    exp_plan = _read_prior_artifact(run_dir, "exp_plan.yaml") or ""
    metric = config.experiment.metric_key
    max_repair = 5  # BUG-14: Increased from 3 to give more chances for critical bugs
    files: dict[str, str] = {}
    validation_log: list[str] = []

    # --- Detect available packages for sandbox ---
    _pm = prompts or PromptManager()

    # --- Hardware-aware package hint ---
    hw_profile = _load_hardware_profile(run_dir)
    if config.experiment.mode in ("sandbox", "docker"):
        if config.experiment.mode == "docker":
            pkg_prefix = "docker mode"
            _net_policy = config.experiment.docker.network_policy
            _base_pkgs = (
                ", torchvision, torchaudio, matplotlib, seaborn, scipy, "
                "tqdm, torchdiffeq, gymnasium, networkx, PyYAML, Pillow, "
                "transformers, datasets, accelerate, peft, bitsandbytes, "
                "timm, einops, torchmetrics, h5py"
            )
            if _net_policy == "none":
                pkg_extras = _base_pkgs + " (ONLY pre-installed packages — NO pip install available)"
            elif _net_policy in ("setup_only", "pip_only"):
                pkg_extras = _base_pkgs + ", and additional pip-installable packages via requirements.txt"
            else:
                pkg_extras = _base_pkgs + ", and additional pip-installable packages (auto-detected from imports)"
        else:
            pkg_prefix = "sandbox mode"
            pkg_extras = ""
        if hw_profile and hw_profile.get("has_gpu"):
            gpu_type = hw_profile.get("gpu_type", "cuda")
            gpu_name = hw_profile.get("gpu_name", "GPU")
            tier = hw_profile.get("tier", "limited")
            if tier == "high":
                device_hint = f"torch.device('{gpu_type}')"
                pkg_hint = (
                    f"\nAVAILABLE PACKAGES ({pkg_prefix}): Python stdlib, numpy, torch, sklearn, scipy, pandas{pkg_extras}.\n"
                    f"GPU: {gpu_name} ({gpu_type}). You MAY use PyTorch with GPU acceleration.\n"
                    f"Use `device = {device_hint}` for tensor operations.\n"
                )
            else:  # limited (low VRAM NVIDIA or MPS)
                device_hint = f"torch.device('{gpu_type}')"
                pkg_hint = (
                    f"\nAVAILABLE PACKAGES ({pkg_prefix}): Python stdlib, numpy, torch, sklearn, scipy, pandas{pkg_extras}.\n"
                    f"GPU: {gpu_name} ({gpu_type}) — LIMITED performance.\n"
                    f"Use `device = {device_hint}` but design LIGHTWEIGHT experiments:\n"
                    f"- Small models (<1M parameters)\n"
                    f"- Few epochs (<=20)\n"
                    f"- Small datasets (<=10K samples)\n"
                    f"- Avoid large batch sizes\n"
                )
        else:
            pkg_hint = _pm.block("pkg_hint_sandbox")
    else:
        pkg_hint = ""

    # --- Compute budget hint ---
    time_budget_sec = config.experiment.time_budget_sec
    if time_budget_sec <= 0:
        compute_budget = (
            "\n## Compute Budget Constraint\n"
            "- No ResearchClaw wall-clock timeout is configured for this experiment.\n"
            "- Run the full experimental plan needed for defensible results; use "
            "guards only for numerical divergence or unrecoverable failures.\n"
        )
    else:
        try:
            compute_budget = _pm.block("compute_budget").replace(
                "{time_budget_sec}", str(time_budget_sec)
            )
        except Exception:  # noqa: BLE001
            compute_budget = (
                f"\n## Compute Budget Constraint\n"
                f"- Total execution time limit: {time_budget_sec} seconds\n"
                f"- Design experiments that complete within this budget\n"
                f"- Implement a time guard: stop gracefully at 80% of budget\n"
            )

    # --- Dataset guidance + setup script + HP reporting (docker/sandbox modes) ---
    extra_guidance = ""
    _net_policy = getattr(getattr(config, "docker", None), "network_policy", "setup_only")
    if config.experiment.mode in ("sandbox", "docker"):
        _net_policy = (
            config.experiment.docker.network_policy
            if config.experiment.mode == "docker"
            else "none"  # sandbox mode has no network
        )
        if _net_policy == "none":
            # Network disabled: inject strict offline-only guidance
            try:
                extra_guidance += _pm.block("network_disabled_guidance")
            except Exception:  # noqa: BLE001
                pass
        elif _net_policy == "full":
            try:
                extra_guidance += _pm.block("dataset_guidance")
                extra_guidance += _pm.block("network_full_guidance")
            except Exception:  # noqa: BLE001
                pass
        else:
            # setup_only or pip_only — existing behavior
            try:
                extra_guidance += _pm.block("dataset_guidance")
            except Exception:  # noqa: BLE001
                pass
            if config.experiment.mode == "docker":
                try:
                    extra_guidance += _pm.block("setup_script_guidance")
                except Exception:  # noqa: BLE001
                    pass
        try:
            extra_guidance += _pm.block("hp_reporting")
        except Exception:  # noqa: BLE001
            pass
        # I-06: Multi-seed enforcement for all experiments
        try:
            extra_guidance += _pm.block("multi_seed_enforcement")
        except Exception:  # noqa: BLE001
            pass

    # --- BA: Inject BenchmarkAgent plan from Stage 9 ---
    _bp_path = None
    for _s9_dir in sorted(run_dir.glob("stage-09*"), reverse=True):
        _candidate = _s9_dir / "benchmark_plan.json"
        if _candidate.exists():
            _bp_path = _candidate
            break
    if _bp_path is not None:
        try:
            import json as _json_bp
            _bp_data = _json_bp.loads(_bp_path.read_text(encoding="utf-8"))
            # Reconstruct the prompt block
            from researchclaw.agents.benchmark_agent.orchestrator import BenchmarkPlan
            _bp = BenchmarkPlan(
                selected_benchmarks=_bp_data.get("selected_benchmarks", []),
                selected_baselines=_bp_data.get("selected_baselines", []),
                data_loader_code=_bp_data.get("data_loader_code", ""),
                baseline_code=_bp_data.get("baseline_code", ""),
                experiment_notes=_bp_data.get("experiment_notes", ""),
            )
            _bp_block = _bp.to_prompt_block()
            if _bp_block:
                extra_guidance += (
                    "\n\n## BenchmarkAgent Selections (USE THESE)\n"
                    "The following datasets, baselines, and code snippets were "
                    "automatically selected and validated by the BenchmarkAgent. "
                    "You MUST use these selections in your experiment code.\n\n"
                    + _bp_block
                )
                logger.info(
                    "BA: Injected benchmark plan (%d benchmarks, %d baselines)",
                    len(_bp.selected_benchmarks), len(_bp.selected_baselines),
                )
        except Exception as _bp_exc:
            logger.debug("BA: Failed to load benchmark plan: %s", _bp_exc)

    # --- P2.2+P2.3: LLM training topic detection and guidance ---
    _llm_keywords = (
        "language model", "llm", "fine-tun", "lora", "qlora", "peft",
        "instruction tun", "rlhf", "dpo", "sft", "alignment",
        "transformer train", "causal lm", "chat model", "qwen", "llama",
        "mistral", "phi-", "gemma", "pretraining", "tokeniz",
    )
    topic_lower = config.research.topic.lower()
    is_llm_topic = any(kw in topic_lower for kw in _llm_keywords)

    # --- I-08: RL topic detection and step guidance ---
    _rl_keywords = (
        "reinforcement learning", "policy gradient", "ppo", "sac", "td3",
        "ddpg", "dqn", "a2c", "a3c", "mujoco", "locomotion", "continuous control",
        "reward shaping", "exploration", "multi-agent rl", "marl", "curriculum rl",
        "imitation learning", "inverse rl", "offline rl", "model-based rl",
        "actor-critic", "reinforce", "gym", "gymnasium",
    )
    is_rl_topic = any(kw in topic_lower for kw in _rl_keywords)
    if is_rl_topic:
        try:
            extra_guidance += _pm.block("rl_step_guidance")
        except Exception:  # noqa: BLE001
            pass

    # --- F-01: Framework API doc injection (auto-detected) ---
    try:
        from researchclaw.data import detect_frameworks, load_framework_docs
        _hypothesis_text = _read_prior_artifact(run_dir, "hypotheses.md") or ""
        _fw_ids = detect_frameworks(
            config.research.topic, _hypothesis_text, exp_plan or ""
        )
        if _fw_ids:
            _fw_docs = load_framework_docs(_fw_ids, max_chars=8000)
            if _fw_docs:
                extra_guidance += _fw_docs
                logger.info("F-01: Injected framework docs for: %s", _fw_ids)
    except Exception:  # noqa: BLE001
        logger.debug("F-01: Framework doc injection skipped", exc_info=True)

    if is_llm_topic and config.experiment.mode == "docker":
        try:
            extra_guidance += _pm.block("llm_training_guidance")
        except Exception:  # noqa: BLE001
            pass
        try:
            extra_guidance += _pm.block("llm_eval_guidance")
        except Exception:  # noqa: BLE001
            pass
        # P2.3: Warn if time budget is too short for LLM training
        if 0 < time_budget_sec < 3600:
            extra_guidance += (
                "\n## COMPUTE BUDGET WARNING\n"
                f"Current time_budget_sec={time_budget_sec} is likely TOO SHORT "
                f"for LLM fine-tuning. Typical LoRA training needs 1-4 hours. "
                f"Design a LIGHTWEIGHT experiment:\n"
                f"- Use a small dataset (<=5000 samples)\n"
                f"- Train for 1-3 epochs only\n"
                f"- Use small batch size (1-2) with gradient accumulation\n"
                f"- Use 4-bit quantization (QLoRA) to minimize memory\n"
                f"- Limit max_seq_length to 512-1024\n"
                f"- If possible, use a smaller model (<=7B parameters)\n"
            )

    # --- Domain-specific guidance injection for non-ML domains ---
    try:
        from researchclaw.domains.detector import detect_domain as _dd_s10, is_ml_domain as _is_ml_s10
        _dp = _dd_s10(topic=config.research.topic)
        if not _is_ml_s10(_dp):
            from researchclaw.domains.prompt_adapter import get_adapter as _ga
            _adapter = _ga(_dp)
            _blocks = _adapter.get_code_generation_blocks({})
            if _blocks.compute_budget:
                compute_budget = _blocks.compute_budget
            if _blocks.dataset_guidance:
                extra_guidance = _blocks.dataset_guidance + "\n" + extra_guidance
            if _blocks.code_generation_hints:
                extra_guidance += "\n" + _blocks.code_generation_hints
            if _blocks.output_format_guidance:
                extra_guidance += "\n" + _blocks.output_format_guidance
            logger.info("Injected domain-specific guidance for %s", _dp.domain_id)
    except Exception:  # noqa: BLE001
        logger.debug("Domain guidance injection skipped", exc_info=True)

    # BUG-R6-01: Add explicit implementation constraints to prevent LLM
    # from substituting unrelated DL models for lightweight algorithms.
    extra_guidance += (
        "\n\nIMPLEMENTATION CONSTRAINTS (MUST FOLLOW):\n"
        "- Implement EXACTLY the algorithm/method described in the topic.\n"
        "- Do NOT replace the stated method with a deep-learning proxy "
        "(e.g. ResNet, BERT, GPT, Gymnasium+SB3) unless the topic "
        "EXPLICITLY requires deep learning.\n"
        "- Prefer lightweight CPU-friendly libraries (numpy, scipy, "
        "sklearn, pandas) unless deep learning is inherent to the topic.\n"
        "- The experiment MUST be self-contained and runnable without GPU.\n"
    )

    # --- Code generation: Beast Mode → CodeAgent → Legacy single-shot ---
    input_intent = _detect_codegen_input_intent(config.research.topic, exp_plan or "")
    predictive_topic = input_intent["task_family"] == "predictive"
    categorical_topic = input_intent["target_type"] == "classification"
    continuous_topic = input_intent["target_type"] == "regression"
    classical_classification_topic = input_intent["model_suite"] == "classical_classification"
    tabular_classification_topic = input_intent["model_suite"] in {
        "classical_classification",
        "tabular_classification",
    }
    tabular_regression_topic = input_intent["model_suite"] == "tabular_regression"
    ambiguous_tabular_predictive_topic = (
        input_intent["model_suite"] == "ambiguous_tabular_predictive"
    )

    extra_guidance += (
        "\n\nMODEL REPORTING OUTPUTS (MUST FOLLOW WHEN MODELS/ESTIMATORS ARE IMPLEMENTED):\n"
        "- Save `model_definitions.json` as records with: model_name, mathematical_form, response_or_target, assumptions, objective_or_loss, hyperparameters, tuning_grid_or_search_space, selected_hyperparameters, diagnostics, and interpretation.\n"
        "- Print `MODEL_DEF: <model_name> | form=<equation_or_decision_rule> | assumptions=<assumptions> | objective=<loss_or_likelihood> | tuning=<grid_or_selected_values> | interpretation=<meaning>` for every model, baseline, and proposed method.\n"
        "- Save `dataset_details.json` with one record per dataset containing: name, task, sample_size, training_size, validation_size if used, test_size, feature_count, target, split, preprocessing, and rationale.\n"
        "- Save `metric_definitions.json` with one record per reported metric containing: name, role, direction, units, formula, interpretation, literature_basis, citation_keys, is_novel, novelty_justification, and proof_or_validation.\n"
        "- Save `software_versions.json` with Python version, platform, and key library versions used by the experiment.\n"
        "- Save `runtime_by_condition.json` with one finite runtime value per executed condition/model.\n"
        "- Do not invent renamed framework labels; use clear model names that map to the implemented code and final paper tables.\n"
        "- If `canonical_results_schema` appears in the experiment plan, implement it exactly.\n"
        "- Always write `results.json` with either:\n"
        "  (a) `cells`: a list of records with condition/method, role, sample_size or dataset/regime, tuning_setting, seed or replication count, and a `metrics` dict; or\n"
        "  (b) `conditions`: a dict keyed by condition name with metric values.\n"
        "- If `experiment_contract` appears in the experiment plan, treat it as mandatory: run at least two comparable conditions, all planned sample-size regimes when feasible, and the tuning/ablation settings required by the plan.\n"
        "- Results tables and figure data must be comparative: never write a result table with one row or figure data with one bar/point unless the corresponding condition failed and the failure is recorded in `results.json`.\n"
        "- For Monte Carlo estimator studies, every estimator x sample_size x simulation/tuning regime must produce at least one `cells` record with metrics including bias, variance, rmse, coverage/inference diagnostics when applicable, first-stage/instrument-strength diagnostics when applicable, and runtime_sec.\n"
        "- Print comparable metric lines as `condition=<condition> sample_size=<n> tuning=<setting> <metric>: <value>` so Stage 14 can recover condition series from stdout if JSON parsing fails.\n"
        "\n\nABLATION OUTPUTS (MUST FOLLOW WHEN ABLATIONS ARE FEASIBLE):\n"
        "- Include a sample-size ablation with small, medium, and full-data regimes when possible; each sample-size level must use an explicit sample_size > 200 unless the source dataset is smaller and that limitation is documented.\n"
        "- Include a tuning ablation that compares default/untuned settings with at least two tuned hyperparameter configurations or search budgets.\n"
        "- Save `ablation_results.json` with ablation_name, factor, level, condition/model, sample_size, tuning_setting, metrics, and interpretation fields.\n"
        "- Avoid cosmetic ablations; each ablation must change sample size, tuning/search budget, model component, or preprocessing in a scientifically interpretable way.\n"
    )

    if predictive_topic and continuous_topic and not categorical_topic:
        extra_guidance += (
            "\n\nPREDICTIVE CONTINUOUS-RESPONSE OUTPUTS (MUST FOLLOW WHEN APPLICABLE):\n"
            "- If the task predicts a continuous/numeric response, compute and print MAE, MSE, RMSE, and R2 for every condition, using the exact metric keys `mae`, `mse`, `rmse`, and `r2`.\n"
            "- Save `predictions.json` with fields: condition, fold, y_true, y_pred, and optional prediction_interval or uncertainty fields.\n"
            "- Save `prediction_residuals.json` with fields: condition, fold, observed, predicted, residual, and absolute_error.\n"
            "- Use an 80/20 train/test split inside each fold/repetition when feasible, and save `kfold_metrics.json` with per-fold MAE, MSE, RMSE, and R2 values.\n"
            "- For predictive models with interpretable coefficients, tree importances, permutation importances, or selected features, compute feature inclusion probability per variable across folds/seeds and save `feature_inclusion_probabilities.json` as records with `variable` and `probability` fields.\n"
            "- Also print metric definition lines for every continuous-response metric: `METRIC_DEF: <metric> | direction=<higher/lower> | formula=<formula> | interpretation=<meaning>`.\n"
        )

    if predictive_topic and categorical_topic:
        extra_guidance += (
            "\n\nPREDICTIVE CATEGORICAL-RESPONSE OUTPUTS (MUST FOLLOW WHEN APPLICABLE):\n"
            "- If the task predicts a categorical/binary response, compute and print Accuracy, Precision, Recall, F1, and ROC_AUC for every condition, using the exact metric keys `accuracy`, `precision`, `recall`, `f1`, and `roc_auc`.\n"
            "- Save `predictions.json` with fields: condition, fold, y_true, y_pred, y_score or probabilities. These arrays are required for confusion-matrix and ROC-curve figures.\n"
            "- Use an 80/20 train/test split inside each fold/repetition when feasible, and save `kfold_metrics.json` with per-fold metric values so a k-fold boxplot can be rendered.\n"
            "- For predictive models with interpretable coefficients, tree importances, permutation importances, or selected features, compute feature inclusion probability per variable across folds/seeds and save `feature_inclusion_probabilities.json` as records with `variable` and `probability` fields.\n"
            "- Also print metric definition lines for every classification metric: `METRIC_DEF: <metric> | direction=<higher/lower> | formula=<formula> | interpretation=<meaning>`.\n"
        )

    if classical_classification_topic:
        extra_guidance += (
            "\n\nCLASSICAL TABULAR CLASSIFICATION OUTPUTS (MUST FOLLOW FOR THIS TOPIC):\n"
            "- Implement concrete classical classifiers from the experiment plan: LogisticRegression, LinearDiscriminantAnalysis, GaussianNaiveBayes, KNearestNeighbors, SupportVectorMachineRBF, RandomForestClassifier, and GradientBoostingClassifier when listed.\n"
            "- Do not replace classifier names with generic labels such as `Reference Protocol`, `Topic Informed Protocol`, `condition_0`, or `method_variant`.\n"
            "- Use one shared preprocessing/splitting/evaluation pipeline for all classifiers so the comparison is fair.\n"
            "- Compute Accuracy, Precision, Recall/Sensitivity, Specificity, F1, ROC_AUC, PR_AUC, BrierScore, runtime_sec, and success_rate for every classifier.\n"
            "- Keep tuning bounded: run a default setting first for every classifier and checkpoint `results.json`; only then run moderate/expanded grids if time remains.\n"
            "- For breast-cancer prediction, use sklearn.datasets.load_breast_cancer when sklearn is available; otherwise generate deterministic tabular binary data with n > 200 and named features.\n"
        )

    if tabular_classification_topic and not classical_classification_topic:
        extra_guidance += (
            "\n\nTABULAR CLASSIFICATION MODEL OUTPUTS (MUST FOLLOW WHEN APPLICABLE):\n"
            "- Implement the concrete classifiers named in the experiment plan, commonly including LogisticRegression, GaussianNaiveBayes, KNearestNeighbors, SupportVectorMachineRBF, RandomForestClassifier, and GradientBoostingClassifier.\n"
            "- Do not replace classifier names with generic labels such as `Reference Protocol`, `Topic Informed Protocol`, `condition_0`, or `method_variant`.\n"
            "- Use one shared preprocessing/splitting/evaluation pipeline for all classifiers.\n"
            "- Compute Accuracy, Precision, Recall, F1, ROC_AUC, PR_AUC when possible, BrierScore when probabilities are available, runtime_sec, and success_rate for every classifier.\n"
            "- Run default settings for every classifier first and checkpoint `results.json`; only then run moderate/expanded tuning if time remains.\n"
        )

    if tabular_regression_topic:
        extra_guidance += (
            "\n\nTABULAR REGRESSION MODEL OUTPUTS (MUST FOLLOW WHEN APPLICABLE):\n"
            "- Implement the concrete regressors named in the experiment plan, commonly including LinearRegression, RidgeRegression, LassoRegression, ElasticNetRegression, KNearestNeighborsRegressor, SupportVectorRegressionRBF, RandomForestRegressor, and GradientBoostingRegressor.\n"
            "- Do not replace regressor names with generic labels such as `Reference Protocol`, `Topic Informed Protocol`, `condition_0`, or `method_variant`.\n"
            "- Use one shared preprocessing/splitting/evaluation pipeline for all regressors.\n"
            "- Compute MAE, MSE, RMSE, R2, MedianAbsoluteError, ExplainedVariance, runtime_sec, and success_rate for every regressor.\n"
            "- Run default settings for every regressor first and checkpoint `results.json`; only then run moderate/expanded tuning if time remains.\n"
        )

    if ambiguous_tabular_predictive_topic:
        extra_guidance += (
            "\n\nTARGET-TYPE RESOLUTION OUTPUTS (MUST FOLLOW FOR AMBIGUOUS PREDICTIVE TOPICS):\n"
            "- Before running models, resolve whether the target is categorical or continuous from the experiment plan, loaded data, or generated synthetic target.\n"
            "- If the target is categorical, execute only the classification candidate suite and compute classification metrics.\n"
            "- If the target is continuous, execute only the regression candidate suite and compute regression metrics.\n"
            "- If no application data exists and the topic remains ambiguous, generate two explicitly labeled benchmark tracks: `target_type=classification` and `target_type=regression`, then keep results separate.\n"
            "- Write `results.json` metadata with `selected_target_type`, `target_resolution_reason`, and `skipped_incompatible_suite`.\n"
            "- Do not replace candidate model names with generic protocol labels.\n"
        )

    _code_agent_active = False
    _beast_mode_used = False
    _code_max_tokens = 8192

    # ── Beast Mode: OpenCode external agent (optional) ─────────────────
    _oc_cfg = config.experiment.opencode
    if _oc_cfg.enabled:
        from researchclaw.pipeline.opencode_bridge import (
            OpenCodeBridge,
            OpenCodeResult,
            count_historical_failures,
            score_complexity,
        )

        _hist_failures = count_historical_failures(run_dir)
        _cplx = score_complexity(
            exp_plan=exp_plan,
            topic=config.research.topic,
            historical_failures=_hist_failures,
            threshold=_oc_cfg.complexity_threshold,
        )

        # Persist complexity analysis
        (stage_dir / "complexity_analysis.json").write_text(
            json.dumps(
                {
                    "score": _cplx.score,
                    "signals": _cplx.signals,
                    "recommendation": _cplx.recommendation,
                    "reason": _cplx.reason,
                    "threshold": _oc_cfg.complexity_threshold,
                    "historical_failures": _hist_failures,
                },
                indent=2,
            ),
            encoding="utf-8",
        )

        if _cplx.recommendation == "beast_mode":
            _proceed = _oc_cfg.auto
            if not _proceed:
                # Non-auto mode: check for HITL adapter
                if adapters.hitl is not None:
                    try:
                        _proceed = adapters.hitl.confirm(
                            f"Beast Mode: complexity={_cplx.score:.2f} "
                            f"(threshold={_oc_cfg.complexity_threshold}). "
                            f"Route to OpenCode?"
                        )
                    except Exception:  # noqa: BLE001
                        logger.info(
                            "Beast mode: HITL adapter unavailable, skipping "
                            "(set opencode.auto=true for non-interactive runs)"
                        )
                else:
                    logger.info(
                        "Beast mode: no HITL adapter, skipping "
                        "(set opencode.auto=true for non-interactive runs)"
                    )

            if _proceed:
                _oc_model = _oc_cfg.model or config.llm.primary_model
                _bridge = OpenCodeBridge(
                    model=_oc_model,
                    llm_base_url=config.llm.base_url,
                    api_key_env=config.llm.api_key_env,
                    llm_provider=config.llm.provider,
                    timeout_sec=_oc_cfg.timeout_sec,
                    max_retries=_oc_cfg.max_retries,
                    workspace_cleanup=_oc_cfg.workspace_cleanup,
                )

                logger.info(
                    "Beast mode: ENGAGED (complexity=%.2f, model=%s)",
                    _cplx.score,
                    _oc_model,
                )

                _oc_result: OpenCodeResult = _bridge.generate(
                    stage_dir=stage_dir,
                    topic=config.research.topic,
                    exp_plan=exp_plan,
                    metric=metric,
                    pkg_hint=pkg_hint + "\n" + compute_budget,
                    extra_guidance=extra_guidance,
                    time_budget_sec=config.experiment.time_budget_sec,
                )

                # Persist beast mode log
                (stage_dir / "beast_mode_log.json").write_text(
                    json.dumps(
                        {
                            "success": _oc_result.success,
                            "elapsed_sec": _oc_result.elapsed_sec,
                            "files": list(_oc_result.files.keys()),
                            "error": _oc_result.error,
                            "complexity_score": _cplx.score,
                            "model": _oc_model,
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )

                if _oc_result.success and _oc_result.files:
                    files = _oc_result.files
                    _beast_mode_used = True
                    _code_agent_active = True  # skip legacy path
                    logger.info(
                        "Beast mode: SUCCESS — %d files in %.1fs",
                        len(files),
                        _oc_result.elapsed_sec,
                    )
                else:
                    logger.warning(
                        "Beast mode: FAILED (%s) — falling back to CodeAgent",
                        _oc_result.error or "unknown error",
                    )
        else:
            logger.info(
                "Beast mode: complexity=%.2f (threshold=%.2f), not triggered",
                _cplx.score,
                _oc_cfg.complexity_threshold,
            )

    if not _beast_mode_used and config.experiment.code_agent.enabled and llm is not None:
        # ── F-02: Advanced Code Agent path ────────────────────────────────
        from researchclaw.pipeline.code_agent import CodeAgent as _CodeAgent

        _ca_cfg = config.experiment.code_agent
        # Ensure we have a proper config object
        if not hasattr(_ca_cfg, "enabled"):
            from researchclaw.pipeline.code_agent import (
                CodeAgentConfig as _CAConfig,
            )
            _ca_cfg = _CAConfig()

        # Sandbox factory (only for sandbox/docker modes)
        _sandbox_factory = None
        if config.experiment.mode in ("sandbox", "docker"):
            from researchclaw.experiment.factory import (
                create_sandbox as _csb,
            )
            _sandbox_factory = _csb

        if any(
            config.llm.primary_model.startswith(p)
            for p in ("gpt-5", "o3", "o4")
        ):
            _code_max_tokens = 16384

        # ── Domain detection + Code Search for non-ML domains ──────────
        _domain_profile = None
        _code_search_result = None
        try:
            from researchclaw.domains.detector import detect_domain as _dd
            from researchclaw.domains.detector import is_ml_domain as _is_ml
            _domain_profile = _dd(topic=config.research.topic)
            logger.info(
                "CodeAgent: domain=%s (%s)",
                _domain_profile.display_name,
                _domain_profile.domain_id,
            )
            # Run code search for non-ML domains (ML has enough built-in knowledge)
            if not _is_ml(_domain_profile):
                try:
                    # GitHub code search endpoint requires authentication.
                    # Skip proactively when token is missing to avoid noisy 401 logs.
                    if os.environ.get("GITHUB_TOKEN", "").strip():
                        from researchclaw.agents.code_searcher import CodeSearchAgent
                        _cs_agent = CodeSearchAgent(llm=llm)
                        _code_search_result = _cs_agent.search(
                            topic=config.research.topic,
                            domain=_domain_profile,
                        )
                        if _code_search_result and _code_search_result.patterns.has_content:
                            logger.info(
                                "Code search: %d patterns, %d repos found",
                                len(_code_search_result.patterns.api_patterns),
                                len(_code_search_result.repos_found),
                            )
                    else:
                        logger.info(
                            "Code search skipped (GITHUB_TOKEN not set)"
                        )
                except Exception:  # noqa: BLE001
                    logger.debug("Code search unavailable", exc_info=True)
        except Exception:  # noqa: BLE001
            logger.debug("Domain detection unavailable", exc_info=True)

        _agent = _CodeAgent(
            llm=llm,
            prompts=_pm,
            config=_ca_cfg,
            stage_dir=stage_dir,
            sandbox_factory=_sandbox_factory,
            experiment_config=config.experiment,
            domain_profile=_domain_profile,
            code_search_result=_code_search_result,
        )
        _agent_result = None
        try:
            _agent_result = _agent.generate(
                topic=config.research.topic,
                exp_plan=exp_plan,
                metric=metric,
                pkg_hint=pkg_hint + "\n" + compute_budget + "\n" + extra_guidance,
                max_tokens=_code_max_tokens,
            )
        except Exception as exc:  # noqa: BLE001
            (stage_dir / "code_agent_log.json").write_text(
                json.dumps(
                    {
                        "log": list(getattr(_agent, "_log", [])),
                        "llm_calls": getattr(_agent, "_calls", 0),
                        "sandbox_runs": getattr(_agent, "_runs", 0),
                        "error": str(exc),
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            logger.warning(
                "CodeAgent failed unexpectedly (%s) — falling back to "
                "Stage 10 graceful fallback generation",
                exc,
            )
        if _agent_result is not None:
            files = _agent_result.files
            _code_agent_active = True

            # Write agent artifacts
            (stage_dir / "code_agent_log.json").write_text(
                json.dumps(
                    {
                        "log": _agent_result.validation_log,
                        "llm_calls": _agent_result.total_llm_calls,
                        "sandbox_runs": _agent_result.total_sandbox_runs,
                        "best_score": _agent_result.best_score,
                        "tree_nodes_explored": _agent_result.tree_nodes_explored,
                        "review_rounds": _agent_result.review_rounds,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            if _agent_result.architecture_spec:
                (stage_dir / "architecture_spec.yaml").write_text(
                    _agent_result.architecture_spec, encoding="utf-8",
                )
            logger.info(
                "CodeAgent: %d LLM calls, %d sandbox runs, score=%.2f",
                _agent_result.total_llm_calls,
                _agent_result.total_sandbox_runs,
                _agent_result.best_score,
            )
    elif not _beast_mode_used and llm is not None:
        # ── Legacy single-shot generation ─────────────────────────────────
        topic = config.research.topic
        _md = config.experiment.metric_direction
        _md_hint = (
            f"`{_md}` — use direction={'lower' if _md == 'minimize' else 'higher'} "
            f"in METRIC_DEF. You MUST NOT use the opposite direction."
        )
        _overlay = _get_evolution_overlay(run_dir, "code_generation")
        sp = _pm.for_stage(
            "code_generation",
            evolution_overlay=_overlay,
            topic=topic,
            metric=metric,
            pkg_hint=pkg_hint + "\n" + compute_budget + "\n" + extra_guidance,
            exp_plan=exp_plan,
            metric_direction_hint=_md_hint,
        )
        # R13-3: Use higher max_tokens for reasoning models (they consume tokens
        # for internal chain-of-thought). Retry once with even higher limit on empty.
        _code_max_tokens = sp.max_tokens or 8192
        if any(config.llm.primary_model.startswith(p) for p in ("gpt-5", "o3", "o4")):
            _code_max_tokens = max(_code_max_tokens, 16384)

        resp = _chat_with_prompt(
            llm,
            sp.system,
            sp.user,
            json_mode=sp.json_mode,
            max_tokens=_code_max_tokens,
        )
        files = _extract_multi_file_blocks(resp.content)
        if not files and not resp.content.strip():
            # Empty response — retry with higher token limit
            logger.warning(
                "R13-3: Empty LLM response for code_generation (len=%d, "
                "finish_reason=%s, tokens=%d). Retrying with 32768 tokens.",
                len(resp.content),
                resp.finish_reason,
                resp.total_tokens,
            )
            resp = _chat_with_prompt(
                llm,
                sp.system,
                sp.user,
                json_mode=sp.json_mode,
                max_tokens=32768,
            )
            files = _extract_multi_file_blocks(resp.content)
        if not files:
            logger.warning(
                "R13-2: _extract_multi_file_blocks returned empty. "
                "LLM response length=%d, first 300 chars: %s",
                len(resp.content),
                resp.content[:300],
            )

    # --- Fallback: generic numerical experiment ---
    if not files:
        files = {
            "main.py": (
                "import numpy as np\n"
                "\n"
                "np.random.seed(42)\n"
                "\n"
                "# Fallback experiment: parameter sweep on a synthetic objective\n"
                "# This runs when LLM code generation fails to produce valid code.\n"
                "dim = 10\n"
                "n_conditions = 3\n"
                "results = {}\n"
                "\n"
                "for cond_idx in range(n_conditions):\n"
                "    cond_name = f'condition_{cond_idx}'\n"
                "    scores = []\n"
                "    for seed in range(3):\n"
                "        rng = np.random.RandomState(seed + cond_idx * 100)\n"
                "        x = rng.randn(dim)\n"
                "        score = float(1.0 / (1.0 + np.sum(x ** 2)))\n"
                "        scores.append(score)\n"
                "    mean_score = float(np.mean(scores))\n"
                "    results[cond_name] = mean_score\n"
                f"    print(f'condition={{cond_name}} {metric}: {{mean_score:.6f}}')\n"
                "\n"
                "best = max(results, key=results.get)\n"
                f"print(f'{metric}: {{results[best]:.6f}}')\n"
            )
        }

    # --- Validate each file + auto-repair loop ---
    all_valid = True
    attempt = 0
    for fname, code in list(files.items()):
        # Skip non-Python files (requirements.txt, setup.py, etc.)
        if not fname.endswith(".py"):
            continue
        validation = validate_code(code)
        repair_attempt = 0
        while not validation.ok and llm is not None and repair_attempt < max_repair:
            repair_attempt += 1
            attempt += 1
            # Only send errors to the LLM — warnings don't block validation
            # and confuse the LLM into over-correcting (e.g. removing runtime imports)
            errors_only = type(validation)(
                issues=[i for i in validation.issues if i.severity == "error"]
            )
            issues_text = format_issues_for_llm(errors_only)
            validation_log.append(
                f"File {fname} attempt {repair_attempt}: {validation.summary()}"
            )
            logger.info(
                "Code validation failed for %s (attempt %d/%d): %s",
                fname,
                repair_attempt,
                max_repair,
                validation.summary(),
            )
            all_files_ctx = "\n\n".join(
                f"```filename:{f}\n{c}\n```" for f, c in files.items()
            )
            rp = _pm.sub_prompt(
                "code_repair",
                fname=fname,
                issues_text=issues_text,
                all_files_ctx=all_files_ctx,
            )
            resp = _chat_with_prompt(llm, rp.system, rp.user)
            _repaired = _extract_code_block(resp.content)
            if _repaired.strip():
                files[fname] = _repaired
            else:
                logger.warning("Repair attempt returned empty code, keeping original")
            validation = validate_code(files[fname])
        if not validation.ok:
            all_valid = False
            # BUG-14: Log remaining issues prominently
            logger.warning(
                "Code validation FAILED for %s after %d repair attempts: %s",
                fname, max_repair, validation.summary(),
            )

    # Improvement G: RL algorithm-environment compatibility check
    for fname, code in list(files.items()):
        if not fname.endswith(".py"):
            continue
        _rl_errors = _check_rl_compatibility(code)
        if _rl_errors:
            for _rl_err in _rl_errors:
                logger.error("Stage 10: %s (in %s)", _rl_err, fname)
                validation_log.append(f"RL_COMPAT: {fname}: {_rl_err}")
            all_valid = False

    # Record critical validation failures after repair attempts, but do not
    # stop the pipeline. Later execution/diagnosis stages still get the best
    # repaired artifact and can continue the repair chain.
    if not all_valid:
        _has_critical = False
        for fname, code in files.items():
            _v = validate_code(code)
            if not _v.ok:
                for issue in _v.issues:
                    if issue.severity == "error" and issue.category in (
                        "syntax", "import",
                    ):
                        _has_critical = True
        if _has_critical:
            logger.warning(
                "Stage 10: CRITICAL validation issues remain after %d repair "
                "attempts. Proceeding with best repaired code.", max_repair,
            )
            (stage_dir / "validation_report.md").write_text(
                "# Code Validation Report\n\n"
                f"**Status**: WARNING — critical issues remain after {max_repair} repairs; proceeding with best repaired code\n\n"
                + "\n".join(f"- {e}" for e in validation_log),
                encoding="utf-8",
            )

    files, _pruned_files = _prune_unreachable_python_files(files)
    if _pruned_files:
        logger.info(
            "Stage 10: pruned stale unreachable Python file(s): %s",
            ", ".join(_pruned_files),
        )

    # --- BUG-184: Cross-import validation — warn if a .py file imports a
    # local module that doesn't exist in the files dict.  This catches the
    # case where Beast Mode/CodeAgent produced an intermediate file that
    # got lost during repair iterations.
    _known_modules = {
        f.replace(".py", "") for f in files if f.endswith(".py")
    }
    _stdlib_and_common = {
        "os", "sys", "json", "math", "time", "copy", "re", "random",
        "pathlib", "argparse", "logging", "collections", "functools",
        "itertools", "abc", "typing", "dataclasses", "enum", "io",
        "csv", "pickle", "glob", "shutil", "subprocess", "datetime",
        "numpy", "np", "torch", "torchvision", "gymnasium", "gym",
        "sklearn", "scipy", "pandas", "matplotlib", "PIL", "tqdm",
        "einops", "timm", "transformers", "datasets", "peft",
        "stable_baselines3",
    }
    for fname, code in list(files.items()):
        if not fname.endswith(".py"):
            continue
        for _m in re.findall(
            r"^(?:from|import)\s+([a-zA-Z_][a-zA-Z0-9_]*)",
            code, re.MULTILINE,
        ):
            if (_m not in _known_modules
                    and _m not in _stdlib_and_common
                    and not _m.startswith("_")):
                logger.warning(
                    "BUG-184: %s imports '%s' which is not in generated "
                    "files — experiment may crash on import",
                    fname, _m,
                )

    # --- Write experiment directory ---
    exp_dir = stage_dir / "experiment"
    _write_experiment_files(exp_dir, files)

    # --- Write validation report ---
    if validation_log or not all_valid:
        report_lines = ["# Code Validation Report\n"]
        if all_valid:
            report_lines.append(f"**Status**: PASSED after {attempt} total repair(s)\n")
        else:
            report_lines.append(
                f"**Status**: WARNING after {attempt} total repair attempt(s); "
                "proceeding with best repaired code\n"
            )
        for entry in validation_log:
            report_lines.append(f"- {entry}")
        (stage_dir / "validation_report.md").write_text(
            "\n".join(report_lines), encoding="utf-8"
        )

    # --- R10-Fix6: Code complexity and quality check ---
    from researchclaw.experiment.validator import (
        auto_fix_unbound_locals,
    )

    # --- BUG-3 fix: Programmatic auto-fix for UnboundLocalError patterns ---
    _total_ub_fixes = 0
    for fname, code in list(files.items()):
        if fname.endswith(".py"):
            fixed_code, n_fixes = auto_fix_unbound_locals(code)
            if n_fixes > 0:
                files[fname] = fixed_code
                _total_ub_fixes += n_fixes
                logger.info(
                    "Stage 10: auto-fixed %d UnboundLocalError risk(s) in %s",
                    n_fixes, fname,
                )
    if _total_ub_fixes:
        logger.info(
            "Stage 10: auto-fixed %d total UnboundLocalError risks", _total_ub_fixes
        )
        _write_experiment_files(exp_dir, files)

    quality_warnings = _collect_stage10_quality_warnings(files)
    for w in quality_warnings:
        logger.warning("Stage 10 code quality: %s", w)

    # --- P1.2: If critical deep issues found, attempt one repair cycle ---
    critical_deep = [
        w for w in quality_warnings
        if _is_stage10_blocking_warning(w)
    ]
    if critical_deep and llm is not None:
        logger.info(
            "Stage 10: %d critical code issues found — triggering repair cycle",
            len(critical_deep),
        )
        repair_issues = "\n".join(f"- {w}" for w in critical_deep)
        all_code_ctx = "\n\n".join(
            f"```filename:{f}\n{c}\n```" for f, c in files.items()
        )
        repair_prompt = (
            f"CRITICAL CODE QUALITY ISSUES FOUND:\n{repair_issues}\n\n"
            f"Fix ALL these issues in the code below. Return the complete "
            f"corrected files using ```filename:xxx.py format.\n\n"
            f"RULES:\n"
            f"- nn.Linear/nn.Conv must be created in __init__(), not forward()\n"
            f"- Variables used after if/else must be defined before the branch\n"
            f"- Use scipy.special.erf, not np.erf\n"
            f"- Ablation/variant classes must have genuinely different logic\n"
            f"- Every class must have a real implementation, not just `pass`\n"
            f"- Ablation classes MUST override the parent method that implements "
            f"the component being ablated (e.g., if ablating attention, override "
            f"the attention method with a simpler alternative like mean pooling)\n"
            f"- IMPORT CONSISTENCY: if you write `from X import Y`, call `Y()` "
            f"directly — NOT `X.Y()`. Mixing styles causes NameError.\n"
            f"- NumPy 2.0: ndarray.ptp() was removed — use arr.max()-arr.min()\n"
            f"- NumPy 2.0: np.bool/np.int/np.float removed — use builtins\n"
            f"- Pretrained models (EfficientNet, ResNet, ViT) expect 224×224 input "
            f"— add `transforms.Resize(224)` when using CIFAR (32×32) or similar\n"
            f"- Copy-paste ablation: if two classes have identical bodies, REWRITE "
            f"the ablation to genuinely remove/reduce a component (e.g., zero out "
            f"attention weights, halve hidden dimensions, remove a loss term)\n"
            f"- KD: teacher must be frozen, add projection layers if teacher_dim != "
            f"student_dim, use temperature T=4 for soft targets\n"
            f"- FILENAME COLLISIONS: If a file like config.py shadows a pip/stdlib "
            f"package, rename it (e.g., config.py → experiment_config.py) and update "
            f"ALL imports referencing it\n\n"
            f"Current code:\n{all_code_ctx}\n"
        )
        try:
            repair_resp = _chat_with_prompt(
                llm,
                _pm.system("code_generation"),
                repair_prompt,
                max_tokens=_code_max_tokens,
            )
            repaired = _extract_multi_file_blocks(repair_resp.content)
            if repaired and "main.py" in repaired:
                files = repaired
                files, _pruned_after_repair = _prune_unreachable_python_files(files)
                if _pruned_after_repair:
                    logger.info(
                        "Stage 10: pruned stale file(s) after deep repair: %s",
                        ", ".join(_pruned_after_repair),
                    )
                _write_experiment_files(exp_dir, files)
                # Re-check after repair
                warnings_after = _collect_stage10_quality_warnings(files)
                critical_after = [
                    w for w in warnings_after
                    if _is_stage10_blocking_warning(w)
                ]
                fixed = max(0, len(critical_deep) - len(critical_after))
                logger.info(
                    "Stage 10: Deep repair fixed %d/%d critical issues",
                    fixed, len(critical_deep),
                )
        except Exception as exc:
            logger.debug("Deep repair failed: %s", exc)

    # --- P1.4: LLM Code Review (Stage 10.5) ---
    # Skip when CodeAgent is active — Phase 4 review already covers this.
    if llm is not None and not _code_agent_active:
        all_code_review = "\n\n".join(
            f"# --- {fname} ---\n{code}" for fname, code in files.items()
        )
        if len(all_code_review) > 12000:
            all_code_review = all_code_review[:12000] + "\n... [truncated]"
        review_prompt = (
            f"You are a senior researcher reviewing experiment code for a "
            f"research submission.\n\n"
            f"TOPIC: {config.research.topic}\n"
            f"EXPERIMENT PLAN:\n{exp_plan[:3000]}\n\n"
            f"CODE:\n```python\n{all_code_review}\n```\n\n"
            f"Review the code and return JSON with this EXACT structure:\n"
            f'{{"score": <1-10>, "issues": ['
            f'{{"severity": "critical|major|minor", '
            f'"description": "...", "fix": "..."}}], '
            f'"verdict": "pass|needs_fix"}}\n\n'
            f"Check specifically:\n"
            f"1. Does each algorithm/method have a DISTINCT implementation? "
            f"(Not just renamed copies)\n"
            f"2. Are ablation conditions genuinely different from the main method?\n"
            f"3. Are loss functions / training loops mathematically correct?\n"
            f"4. Will the code actually run without errors? Check variable scoping, "
            f"API usage, tensor shape compatibility.\n"
            f"5. Is the code complex enough for a research paper? (Not trivial)\n"
            f"6. Are experimental conditions fairly compared (same seeds, data)?\n"
            f"7. If using pretrained models (EfficientNet, ResNet, ViT), are input "
            f"images resized to the model's expected size (e.g., 224x224)? CIFAR "
            f"images are 32x32 and MUST be resized for pretrained models.\n"
            f"8. Are imports consistent? `from X import Y` must use `Y()`, not `X.Y()`.\n"
        )
        try:
            review_resp = llm.chat(
                [{"role": "user", "content": review_prompt}],
                system="You are a meticulous ML code reviewer. Be strict.",
                max_tokens=2048,
            )
            # Extract JSON from LLM response (may be wrapped in markdown fences)
            _review_text = review_resp.content if hasattr(review_resp, "content") else str(review_resp)
            # Strip markdown JSON fences if present
            _review_text = _review_text.strip()
            if _review_text.startswith("```"):
                _lines = _review_text.splitlines()
                _start = 1 if _lines[0].strip().startswith("```") else 0
                _end = len(_lines) - 1 if _lines[-1].strip() == "```" else len(_lines)
                _review_text = "\n".join(_lines[_start:_end])
            review_data = _safe_json_loads(_review_text, {})
            if isinstance(review_data, dict):
                review_score = review_data.get("score", 0)
                review_verdict = review_data.get("verdict", "unknown")
                review_issues = review_data.get("issues", [])

                # Write review report
                review_report = {
                    "score": review_score,
                    "verdict": review_verdict,
                    "issues": review_issues,
                    "timestamp": _utcnow_iso(),
                }
                (stage_dir / "code_review.json").write_text(
                    json.dumps(review_report, indent=2), encoding="utf-8"
                )

                # If critical issues found and score low, attempt fix
                critical_issues = [
                    i for i in review_issues
                    if isinstance(i, dict)
                    and i.get("severity") == "critical"
                ]
                if critical_issues and review_score <= 4:
                    logger.warning(
                        "Stage 10 code review: score=%d, %d critical issues — "
                        "attempting fix",
                        review_score, len(critical_issues),
                    )
                    fix_descriptions = "\n".join(
                        f"- [{i.get('severity', '?')}] {i.get('description', '?')}: "
                        f"{i.get('fix', 'no fix suggested')}"
                        for i in critical_issues
                    )
                    fix_prompt = (
                        f"Code review found {len(critical_issues)} CRITICAL issues "
                        f"(score: {review_score}/10):\n{fix_descriptions}\n\n"
                        f"Fix ALL critical issues. Return complete corrected files "
                        f"using ```filename:xxx.py format.\n\n"
                        f"Current code:\n"
                        + "\n\n".join(
                            f"```filename:{f}\n{c}\n```" for f, c in files.items()
                        )
                    )
                    try:
                        fix_resp = _chat_with_prompt(
                            llm,
                            _pm.system("code_generation"),
                            fix_prompt,
                            max_tokens=_code_max_tokens,
                        )
                        fixed_files = _extract_multi_file_blocks(fix_resp.content)
                        if fixed_files and "main.py" in fixed_files:
                            files = fixed_files
                            files, _pruned_after_review = _prune_unreachable_python_files(files)
                            if _pruned_after_review:
                                logger.info(
                                    "Stage 10: pruned stale file(s) after review fix: %s",
                                    ", ".join(_pruned_after_review),
                                )
                            _write_experiment_files(exp_dir, files)
                            logger.info(
                                "Stage 10: Code fixed after review "
                                "(was %d/10, %d critical issues)",
                                review_score, len(critical_issues),
                            )
                    except Exception as exc:
                        logger.debug("Review-fix failed: %s", exc)
        except Exception as exc:
            logger.debug("Code review failed: %s", exc)

    # --- FIX-3: Topic-experiment alignment check ---
    # BUG-171: Previous 8000-char truncation caused false-positive misalignment
    # for multi-file experiments (30-90K chars). LLM saw "[truncated]" and
    # concluded code was incomplete. Fix: build a structured summary that
    # includes file inventory + full main.py + per-file function/class headers.
    alignment_ok = True
    alignment_note = ""
    if llm is not None:
        # Build structured code summary for alignment check
        _file_inventory = []
        for _fn, _cd in files.items():
            _lines = _cd.count("\n") + 1
            _file_inventory.append(f"  {_fn}: {_lines} lines, {len(_cd)} chars")
        _inventory_block = "FILES GENERATED:\n" + "\n".join(_file_inventory)

        # BUG-179: Beast Mode may use a different entry point (e.g.
        # run_experiment.py).  Detect the actual entry point by scanning
        # for ``if __name__ == "__main__"`` in all files, preferring main.py.
        _entry_file = "main.py"
        if "main.py" not in files or not files.get("main.py", "").strip():
            for _fn, _cd in files.items():
                if 'if __name__' in _cd and '__main__' in _cd:
                    _entry_file = _fn
                    break
        elif files.get("main.py", ""):
            # main.py exists but may be a stub — if another file has the
            # real orchestration (more lines + __main__ guard), prefer it
            _main_lines = files["main.py"].count("\n")
            for _fn, _cd in files.items():
                if _fn == "main.py":
                    continue
                if ('if __name__' in _cd and '__main__' in _cd
                        and _cd.count("\n") > _main_lines * 1.5):
                    _entry_file = _fn
                    break

        _main_code = files.get(_entry_file, files.get("main.py", ""))
        _main_block = f"# --- {_entry_file} (FULL — entry point) ---\n{_main_code}"
        # Cap main.py at 12000 chars to stay within token budget
        if len(_main_block) > 12000:
            _main_block = _main_block[:12000] + "\n... [main.py truncated at 12000 chars]"

        # For other files, include imports + function/class signatures
        _other_summaries = []
        for _fn, _cd in files.items():
            if _fn == _entry_file:
                continue
            _sig_lines = []
            for _line in _cd.split("\n"):
                _stripped = _line.strip()
                if (_stripped.startswith("def ") or _stripped.startswith("class ")
                        or _stripped.startswith("async def ")
                        # BUG-209: Include import lines — they reveal which
                        # techniques/libraries are used (e.g. CosineAnnealingLR)
                        or _stripped.startswith("import ")
                        or _stripped.startswith("from ")):
                    _sig_lines.append(_line)
            if _sig_lines:
                _other_summaries.append(
                    f"# --- {_fn} (imports + signatures) ---\n"
                    + "\n".join(_sig_lines)
                )
            else:
                # Small file — include first 800 chars
                _preview = _cd[:800]
                if len(_cd) > 800:
                    _preview += f"\n... [{len(_cd) - 800} more chars]"
                _other_summaries.append(f"# --- {_fn} (preview) ---\n{_preview}")
        _other_block = "\n\n".join(_other_summaries)
        # Cap other summaries
        if len(_other_block) > 6000:
            _other_block = _other_block[:6000] + "\n... [other files truncated]"

        all_code_for_check = (
            f"{_inventory_block}\n\n{_main_block}\n\n{_other_block}"
        )
        align_prompt = (
            f"Research topic: {config.research.topic}\n\n"
            f"Experiment code:\n```python\n{all_code_for_check}\n```\n\n"
            "TASK: Evaluate whether this experiment code actually tests the "
            "stated research topic. Answer with JSON:\n"
            '{"aligned": true/false, "reason": "...", "suggestions": "..."}\n\n'
            "IMPORTANT: The code spans MULTIPLE files. The file inventory above "
            "shows ALL generated files. Only main.py is shown in full; other "
            "files show function/class signatures. Do NOT mark as misaligned "
            "just because helper files are summarized — they contain full "
            "implementations.\n\n"
            "Check specifically:\n"
            "- Does main.py orchestrate an experiment matching the topic?\n"
            "- Do the helper file signatures indicate relevant models/methods?\n"
            "- If the topic mentions a specific technique, is there evidence of "
            "its implementation (function names, class names, imports)?\n"
            "- Are the experimental conditions meaningfully different from each other?\n"
        )
        try:
            align_resp = llm.chat(
                [{"role": "user", "content": align_prompt}],
                system="You are a scientific code reviewer checking topic-experiment alignment.",
                max_tokens=1024,
            )
            align_data = _safe_json_loads(align_resp.content, {})
            if isinstance(align_data, dict) and not align_data.get("aligned", True):
                alignment_ok = False
                alignment_note = align_data.get("reason", "Misaligned")
                suggestions = align_data.get("suggestions", "")
                logger.warning(
                    "Stage 10: Topic-experiment MISALIGNMENT detected: %s",
                    alignment_note,
                )
                # BUG-R6-01: Allow up to 2 regeneration attempts with re-check.
                _max_regen = 2
                for _regen_attempt in range(1, _max_regen + 1):
                    logger.info(
                        "Stage 10: Alignment regen attempt %d/%d",
                        _regen_attempt, _max_regen,
                    )
                    regen_prompt = (
                        f"The experiment code you previously generated does NOT align "
                        f"with the research topic.\n\n"
                        f"TOPIC: {config.research.topic}\n"
                        f"MISALIGNMENT: {alignment_note}\n"
                        f"SUGGESTIONS: {suggestions}\n\n"
                        f"REGENERATE the experiment code to DIRECTLY test the stated "
                        f"topic. The code MUST implement the core technique described "
                        f"in the topic, not a generic proxy.\n\n"
                        f"CRITICAL CONSTRAINTS:\n"
                        f"- You MUST implement the EXACT algorithm/method from the topic.\n"
                        f"- Do NOT substitute a deep-learning proxy (ResNet, BERT, etc.) "
                        f"when the topic describes a tabular, bandit, or game-theoretic method.\n"
                        f"- Use ONLY lightweight CPU-friendly libraries (numpy, scipy, "
                        f"sklearn) unless the topic EXPLICITLY requires deep learning.\n"
                        f"- The experiment must be self-contained and runnable without GPU.\n\n"
                        f"{pkg_hint}\n{compute_budget}\n"
                        f"PLAN:\n{exp_plan}\n\n"
                        f"Return multiple files using ```filename:xxx.py format."
                    )
                    regen_resp = _chat_with_prompt(
                        llm,
                        system=_pm.system("code_generation"),
                        user=regen_prompt,
                        max_tokens=_code_max_tokens,
                    )
                    regen_files = _extract_multi_file_blocks(regen_resp.content)
                    if not regen_files or "main.py" not in regen_files:
                        logger.warning(
                            "Stage 10: Regen attempt %d produced no main.py",
                            _regen_attempt,
                        )
                        continue
                    files = regen_files
                    files, _pruned_after_regen = _prune_unreachable_python_files(files)
                    if _pruned_after_regen:
                        logger.info(
                            "Stage 10: pruned stale file(s) after alignment regen: %s",
                            ", ".join(_pruned_after_regen),
                        )
                    _write_experiment_files(exp_dir, files)
                    # Re-check alignment on regenerated code (BUG-171 fix)
                    _rc_inv = []
                    for _fn, _cd in files.items():
                        _rc_inv.append(f"  {_fn}: {_cd.count(chr(10))+1} lines")
                    _rc_main = files.get("main.py", "")
                    if len(_rc_main) > 12000:
                        _rc_main = _rc_main[:12000] + "\n... [truncated]"
                    _rc_sigs = []
                    for _fn, _cd in files.items():
                        if _fn == "main.py":
                            continue
                        # BUG-209: Include imports alongside signatures
                        _slines = [l for l in _cd.split("\n")
                                   if l.strip().startswith((
                                       "def ", "class ", "async def ",
                                       "import ", "from ",
                                   ))]
                        if _slines:
                            _rc_sigs.append(f"# {_fn} imports+signatures:\n" + "\n".join(_slines))
                    recheck_code = (
                        "FILES:\n" + "\n".join(_rc_inv) + "\n\n"
                        f"# main.py (FULL):\n{_rc_main}\n\n"
                        + "\n".join(_rc_sigs)
                    )
                    recheck_resp = llm.chat(
                        [{"role": "user", "content": (
                            f"Research topic: {config.research.topic}\n\n"
                            f"Experiment code:\n```python\n{recheck_code}\n```\n\n"
                            "TASK: Evaluate whether this experiment code actually tests "
                            "the stated research topic. Only main.py is shown in full; "
                            "other files show signatures only. Answer with JSON:\n"
                            '{"aligned": true/false, "reason": "...", "suggestions": "..."}\n'
                        )}],
                        system="You are a scientific code reviewer checking topic-experiment alignment.",
                        max_tokens=1024,
                    )
                    recheck_data = _safe_json_loads(recheck_resp.content, {})
                    if isinstance(recheck_data, dict) and recheck_data.get("aligned", False):
                        alignment_ok = True
                        alignment_note = f"Regenerated after alignment check (attempt {_regen_attempt})"
                        logger.info(
                            "Stage 10: Code aligned after regen attempt %d",
                            _regen_attempt,
                        )
                        break
                    else:
                        alignment_note = recheck_data.get("reason", alignment_note)
                        suggestions = recheck_data.get("suggestions", suggestions)
                        logger.warning(
                            "Stage 10: Regen attempt %d still misaligned: %s",
                            _regen_attempt, alignment_note,
                        )
        except Exception as exc:
            logger.debug("Alignment check failed: %s", exc)

    # --- FIX-7: Ablation distinctness check ---
    main_code = files.get("main.py", "")
    if llm is not None and main_code and "condition" in main_code.lower():
        try:
            ablation_prompt = (
                f"Examine this experiment code:\n```python\n{main_code[:6000]}\n```\n\n"
                "Check if any experimental conditions (methods/ablations) have "
                "IDENTICAL configurations (same hyperparameters, same code paths). "
                "Answer JSON: "
                '{"has_duplicates": true/false, "details": "which conditions are identical"}'
            )
            abl_resp = llm.chat(
                [{"role": "user", "content": ablation_prompt}],
                system="You are a code reviewer checking experimental conditions.",
                max_tokens=512,
            )
            abl_data = _safe_json_loads(abl_resp.content, {})
            if isinstance(abl_data, dict) and abl_data.get("has_duplicates"):
                logger.warning(
                    "Stage 10: Duplicate ablation conditions detected: %s",
                    abl_data.get("details", ""),
                )
                (stage_dir / "ablation_warning.json").write_text(
                    json.dumps(abl_data, indent=2), encoding="utf-8"
                )
                # --- Attempt ablation repair ---
                all_code_ctx = "\n\n".join(
                    f"```filename:{f}\n{c}\n```" for f, c in files.items()
                )
                dup_details = abl_data.get("details", "unknown")
                abl_repair_prompt = (
                    f"ABLATION REPAIR REQUIRED — duplicate conditions detected:\n"
                    f"{dup_details}\n\n"
                    f"Rewrite the ablation/variant conditions so each one is "
                    f"GENUINELY DIFFERENT. Concrete strategies:\n"
                    f"- 'no_<component>': REMOVE the component entirely "
                    f"(e.g., replace attention with mean pooling, remove a loss term)\n"
                    f"- 'reduced_capacity': HALVE hidden dimensions or layers\n"
                    f"- Different conditions MUST produce different outputs on the "
                    f"same input. Add a startup assertion that runs one forward pass "
                    f"per condition on identical input and prints:\n"
                    f"  ABLATION_CHECK: <cond1> vs <cond2> outputs_differ=True\n\n"
                    f"Return ALL files using ```filename:xxx.py format.\n\n"
                    f"Current code:\n{all_code_ctx}\n"
                )
                try:
                    abl_repair_resp = _chat_with_prompt(
                        llm,
                        _pm.system("code_generation"),
                        abl_repair_prompt,
                        max_tokens=_code_max_tokens,
                    )
                    repaired_files = _extract_multi_file_blocks(
                        abl_repair_resp.content
                    )
                    if repaired_files and "main.py" in repaired_files:
                        files = repaired_files
                        files, _pruned_after_ablation = _prune_unreachable_python_files(files)
                        if _pruned_after_ablation:
                            logger.info(
                                "Stage 10: pruned stale file(s) after ablation repair: %s",
                                ", ".join(_pruned_after_ablation),
                            )
                        _write_experiment_files(exp_dir, files)
                        logger.info(
                            "Stage 10: Ablation repair applied — "
                            "rewrote duplicate conditions"
                        )
                except Exception as exc:
                    logger.debug("Ablation repair failed: %s", exc)
        except Exception as exc:
            logger.debug("Ablation validation skipped: %s", exc)

    files, _final_pruned = _prune_unreachable_python_files(files)
    if _final_pruned:
        logger.info(
            "Stage 10: pruned stale file(s) before final quality gate: %s",
            ", ".join(_final_pruned),
        )
    _write_experiment_files(exp_dir, files)

    final_quality_warnings = _collect_stage10_quality_warnings(files)
    final_blocking_warnings = [
        w for w in final_quality_warnings
        if _is_stage10_blocking_warning(w)
    ]
    quality_path = stage_dir / "code_complexity.json"
    if final_quality_warnings:
        quality_path.write_text(
            json.dumps(
                {
                    "code_complexity_warnings": final_quality_warnings,
                    "blocking_warnings": final_blocking_warnings,
                    "timestamp": _utcnow_iso(),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    elif quality_path.exists():
        quality_path.unlink()

    # --- Write spec ---
    file_list = ", ".join(f"`{f}`" for f in sorted(files.keys()))
    main_validation = validate_code(files.get("main.py", ""))
    _align_status = "ALIGNED" if alignment_ok else f"MISALIGNED: {alignment_note}"
    spec = f"""# Experiment Specification

## Topic
{config.research.topic}

## Project Structure
Multi-file experiment project with {len(files)} file(s): {file_list}

## Entry Point
`main.py` \u2014 executed directly via sandbox

## Outputs
- `main.py` emits metric lines in `name: value` format
- Primary metric key: `{metric}`

## Topic-Experiment Alignment
{_align_status}

## Constraints
- Time budget per run: {config.experiment.time_budget_sec}s
- Max iterations: {config.experiment.max_iterations}
- Self-contained execution (no external data, no network)
- Validated: {main_validation.summary()}

## Generated
{_utcnow_iso()}
"""
    (stage_dir / "experiment_spec.md").write_text(spec, encoding="utf-8")

    artifacts = ["experiment/", "experiment_spec.md"]
    if (stage_dir / "validation_report.md").exists():
        artifacts.append("validation_report.md")
    if quality_path.exists():
        artifacts.append("code_complexity.json")

    if final_blocking_warnings:
        logger.warning(
            "Stage 10: Final quality gate found %d unresolved issue(s); "
            "proceeding with best repaired code for downstream repair.",
            len(final_blocking_warnings),
        )
        (stage_dir / "code_quality_warning.md").write_text(
            "# Stage 10 Code Quality Warning\n\n"
            "Stage 10 proceeded with the best repaired code after cleanup. "
            "Downstream execution and diagnosis stages should use these findings "
            "as repair signals instead of restarting an indefinite loop.\n\n"
            + "\n".join(f"- {w}" for w in final_blocking_warnings),
            encoding="utf-8",
        )
        artifacts.append("code_quality_warning.md")

    if not alignment_ok:
        logger.warning(
            "Stage 10: Persistent topic-experiment misalignment after all "
            "regen attempts. Proceeding with warning. Reason: %s",
            alignment_note,
        )
        (stage_dir / "alignment_warning.md").write_text(
            "# Stage 10 Alignment Warning\n\n"
            "Stage 10 proceeded after regeneration attempts could not fully "
            "resolve topic-experiment alignment.\n\n"
            f"Reason: {alignment_note}\n",
            encoding="utf-8",
        )
        artifacts.append("alignment_warning.md")

    return StageResult(
        stage=Stage.CODE_GENERATION,
        status=StageStatus.DONE,
        artifacts=tuple(artifacts),
        evidence_refs=tuple(f"stage-10/{a}" for a in artifacts),
    )
