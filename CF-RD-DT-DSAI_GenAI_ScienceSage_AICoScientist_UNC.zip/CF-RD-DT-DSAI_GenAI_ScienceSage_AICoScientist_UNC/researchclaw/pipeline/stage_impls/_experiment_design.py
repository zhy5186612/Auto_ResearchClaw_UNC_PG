﻿"""Stage 9: Experiment design."""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

import yaml

from researchclaw.adapters import AdapterBundle
from researchclaw.config import RCConfig
from researchclaw.llm.client import LLMClient
from researchclaw.pipeline._helpers import (
    StageResult,
    _build_context_preamble,
    _chat_with_prompt,
    _extract_yaml_block,
    _get_evolution_overlay,
    _load_hardware_profile,
    _read_prior_artifact,
    _safe_json_loads,
    _utcnow_iso,
)
from researchclaw.pipeline.stages import Stage, StageStatus
from researchclaw.prompts import PromptManager

logger = logging.getLogger(__name__)

_MIN_EXPERIMENT_SAMPLE_SIZE = 201
_DEFAULT_SAMPLE_SIZE_REGIMES: list[dict[str, Any]] = [
    {"name": "small_subset", "sample_size": 256},
    {"name": "medium_subset", "sample_size": 512},
    {"name": "full_dataset", "sample_size": 1024},
]
_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "based",
    "by",
    "for",
    "from",
    "in",
    "into",
    "is",
    "of",
    "on",
    "or",
    "study",
    "the",
    "to",
    "using",
    "with",
}


def _normalize_metric_definitions(
    metric_definitions: Any,
    metrics: Any,
    config: RCConfig,
) -> list[dict[str, Any]]:
    """Ensure metric definitions carry provenance and novelty metadata."""
    normalized: list[dict[str, Any]] = []
    raw_items: list[Any] = []
    if isinstance(metric_definitions, list):
        raw_items.extend(metric_definitions)
    if isinstance(metrics, dict):
        existing_names = {
            str(item.get("name") if isinstance(item, dict) else item)
            for item in raw_items
            if isinstance(item, (dict, str))
        }
        for metric_name, metric_spec in metrics.items():
            metric_name_str = str(metric_name)
            if metric_name_str in existing_names:
                continue
            if isinstance(metric_spec, dict):
                entry = dict(metric_spec)
                entry.setdefault("name", metric_name_str)
                raw_items.append(entry)
            else:
                raw_items.append({"name": metric_name_str})
            existing_names.add(metric_name_str)
    if isinstance(metrics, list):
        existing_names = {
            str(item.get("name") if isinstance(item, dict) else item)
            for item in raw_items
            if isinstance(item, (dict, str))
        }
        for metric_name in metrics:
            metric_name_str = str(metric_name)
            if metric_name_str not in existing_names:
                raw_items.append({"name": metric_name_str})
                existing_names.add(metric_name_str)

    for item in raw_items:
        if isinstance(item, str):
            entry: dict[str, Any] = {"name": item}
        elif isinstance(item, dict):
            entry = dict(item)
        else:
            continue
        entry.setdefault("name", config.experiment.metric_key)
        entry.setdefault("direction", config.experiment.metric_direction)
        entry.setdefault("units", "specify units or scale")
        entry.setdefault("formula", "specify mathematical formula")
        entry.setdefault(
            "interpretation",
            "explain what higher/lower values mean scientifically",
        )
        entry.setdefault(
            "literature_basis",
            "cite the benchmark paper, evaluation guideline, or domain literature that justifies this metric for the task",
        )
        entry.setdefault(
            "citation_keys",
            ["add cite keys or canonical paper names supporting this metric choice"],
        )
        entry.setdefault("is_novel", False)
        entry.setdefault(
            "novelty_justification",
            "state 'not novel' for established metrics; otherwise explain why standard metrics are insufficient",
        )
        entry.setdefault(
            "proof_or_validation",
            "if novel, provide theoretical properties or empirical validation against standard metrics; otherwise cite the literature basis",
        )
        entry.setdefault(
            "role",
            "state whether this metric captures primary effectiveness, calibration, robustness, efficiency, safety, fairness, or another literature-backed dimension",
        )
        normalized.append(entry)

    if not normalized:
        normalized = [{
            "name": config.experiment.metric_key,
            "direction": config.experiment.metric_direction,
            "units": "specify units or scale",
            "formula": "specify mathematical formula",
            "interpretation": "explain what higher/lower values mean scientifically",
            "literature_basis": "cite the benchmark paper, evaluation guideline, or domain literature that justifies this metric for the task",
            "citation_keys": ["add cite keys or canonical paper names supporting this metric choice"],
            "is_novel": False,
            "novelty_justification": "state 'not novel' for established metrics; otherwise explain why standard metrics are insufficient",
            "proof_or_validation": "if novel, provide theoretical properties or empirical validation against standard metrics; otherwise cite the literature basis",
            "role": "state whether this metric captures primary effectiveness, calibration, robustness, efficiency, safety, fairness, or another literature-backed dimension",
        }]
    return normalized


_CATEGORICAL_PREDICTION_METRICS: list[dict[str, Any]] = [
    {
        "name": "Accuracy",
        "role": "classification effectiveness",
        "direction": "maximize",
        "units": "fraction or percentage",
        "formula": "Accuracy = (TP + TN) / (TP + TN + FP + FN).",
        "interpretation": "Higher values mean a larger fraction of examples are classified correctly.",
        "literature_basis": "Standard metric for categorical-response prediction when class balance is acceptable.",
        "citation_keys": ["standard_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.accuracy_score or an equivalent confusion-matrix calculation.",
    },
    {
        "name": "Precision",
        "role": "positive-prediction reliability",
        "direction": "maximize",
        "units": "fraction or percentage",
        "formula": "Precision = TP / (TP + FP).",
        "interpretation": "Higher values mean fewer false positives among predicted positive cases.",
        "literature_basis": "Standard categorical-response metric, especially when false positives matter.",
        "citation_keys": ["standard_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.precision_score with the stated averaging rule.",
    },
    {
        "name": "Recall",
        "role": "positive-case sensitivity",
        "direction": "maximize",
        "units": "fraction or percentage",
        "formula": "Recall = TP / (TP + FN).",
        "interpretation": "Higher values mean fewer false negatives among true positive cases.",
        "literature_basis": "Standard categorical-response metric, especially when missed positives are costly.",
        "citation_keys": ["standard_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.recall_score with the stated averaging rule.",
    },
    {
        "name": "F1",
        "role": "precision-recall balance",
        "direction": "maximize",
        "units": "harmonic mean on [0,1]",
        "formula": "F1 = 2 * Precision * Recall / (Precision + Recall).",
        "interpretation": "Higher values indicate better balance between false positives and false negatives.",
        "literature_basis": "Standard summary for categorical prediction under class imbalance.",
        "citation_keys": ["standard_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.f1_score with the stated averaging rule.",
    },
    {
        "name": "ROC_AUC",
        "role": "ranking/discrimination",
        "direction": "maximize",
        "units": "area under ROC curve on [0,1]",
        "formula": "ROC-AUC = integral_0^1 TPR(FPR) dFPR, where TPR=TP/(TP+FN) and FPR=FP/(FP+TN).",
        "interpretation": "Higher values mean better ranking of positive cases above negative cases across thresholds.",
        "literature_basis": "Standard discrimination metric for probabilistic binary or one-vs-rest categorical prediction.",
        "citation_keys": ["hanley1982auc"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.roc_auc_score and report binary or macro/micro averaging.",
    },
]


_CONTINUOUS_PREDICTION_METRICS: list[dict[str, Any]] = [
    {
        "name": "MAE",
        "role": "absolute prediction error",
        "direction": "minimize",
        "units": "same units as the continuous response",
        "formula": "MAE = (1/n) * sum_i |y_i - yhat_i|.",
        "interpretation": "Lower values mean predictions are closer to observed responses on average.",
        "literature_basis": "Standard regression metric for continuous-response prediction.",
        "citation_keys": ["standard_regression_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.mean_absolute_error or an equivalent direct calculation.",
    },
    {
        "name": "MSE",
        "role": "squared prediction error",
        "direction": "minimize",
        "units": "squared units of the continuous response",
        "formula": "MSE = (1/n) * sum_i (y_i - yhat_i)^2.",
        "interpretation": "Lower values mean smaller average squared errors, with larger errors penalized more strongly.",
        "literature_basis": "Standard regression metric for continuous-response prediction.",
        "citation_keys": ["standard_regression_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.mean_squared_error or an equivalent direct calculation.",
    },
    {
        "name": "RMSE",
        "role": "root squared prediction error",
        "direction": "minimize",
        "units": "same units as the continuous response",
        "formula": "RMSE = sqrt((1/n) * sum_i (y_i - yhat_i)^2).",
        "interpretation": "Lower values mean smaller typical prediction errors in the response scale.",
        "literature_basis": "Standard regression metric for continuous-response prediction.",
        "citation_keys": ["standard_regression_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against the square root of mean squared error.",
    },
    {
        "name": "R2",
        "role": "explained variance",
        "direction": "maximize",
        "units": "unitless proportion",
        "formula": "R2 = 1 - sum_i (y_i - yhat_i)^2 / sum_i (y_i - ybar)^2.",
        "interpretation": "Higher values mean the model explains more variation relative to predicting the sample mean.",
        "literature_basis": "Standard goodness-of-fit metric for continuous-response prediction.",
        "citation_keys": ["standard_regression_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.r2_score or an equivalent direct calculation.",
    },
]

_REGRESSION_EXTRA_METRICS: list[dict[str, Any]] = [
    {
        "name": "MedianAbsoluteError",
        "role": "robust absolute prediction error",
        "direction": "minimize",
        "units": "same units as the continuous response",
        "formula": "Median absolute error = median_i |y_i - yhat_i|.",
        "interpretation": "Lower values mean smaller typical error while reducing sensitivity to outliers.",
        "literature_basis": "Standard robust regression metric for continuous-response prediction.",
        "citation_keys": ["standard_regression_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against a direct median absolute error calculation.",
    },
    {
        "name": "ExplainedVariance",
        "role": "variance explained by predictions",
        "direction": "maximize",
        "units": "unitless proportion",
        "formula": "Explained variance = 1 - Var(y - yhat) / Var(y).",
        "interpretation": "Higher values mean predictions explain more response variation.",
        "literature_basis": "Standard regression goodness-of-fit metric.",
        "citation_keys": ["standard_regression_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against an equivalent direct variance calculation.",
    },
]

_CLASSICAL_CLASSIFICATION_METRICS: list[dict[str, Any]] = [
    {
        "name": "Sensitivity",
        "role": "positive-class detection",
        "direction": "maximize",
        "units": "fraction or percentage",
        "formula": "Sensitivity = TP / (TP + FN).",
        "interpretation": "Higher values mean fewer missed positive cases.",
        "literature_basis": "Standard diagnostic-classification metric for medical prediction tasks.",
        "citation_keys": ["standard_diagnostic_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate from the confusion matrix; equivalent to recall for the positive class.",
    },
    {
        "name": "Specificity",
        "role": "negative-class detection",
        "direction": "maximize",
        "units": "fraction or percentage",
        "formula": "Specificity = TN / (TN + FP).",
        "interpretation": "Higher values mean fewer false positive cancer predictions among true negative cases.",
        "literature_basis": "Standard diagnostic-classification metric for clinical screening and diagnosis studies.",
        "citation_keys": ["standard_diagnostic_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate from the confusion matrix.",
    },
    {
        "name": "BalancedAccuracy",
        "role": "class-imbalance robust accuracy",
        "direction": "maximize",
        "units": "fraction or percentage",
        "formula": "Balanced accuracy = (Sensitivity + Specificity) / 2.",
        "interpretation": "Higher values mean better average performance across positive and negative classes.",
        "literature_basis": "Standard classification metric when class balance may affect raw accuracy.",
        "citation_keys": ["standard_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute directly from sensitivity and specificity.",
    },
    {
        "name": "PR_AUC",
        "role": "precision-recall ranking",
        "direction": "maximize",
        "units": "area under precision-recall curve on [0,1]",
        "formula": "PR-AUC = integral Precision(Recall) dRecall over classification thresholds.",
        "interpretation": "Higher values mean better positive-class ranking under class imbalance.",
        "literature_basis": "Common metric for binary classification when positive-class detection is central.",
        "citation_keys": ["standard_classification_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against average_precision_score or trapezoidal PR curve integration.",
    },
    {
        "name": "BrierScore",
        "role": "probability calibration and squared prediction error",
        "direction": "minimize",
        "units": "squared probability error",
        "formula": "Brier score = (1/n) * sum_i (p_i - y_i)^2.",
        "interpretation": "Lower values mean better calibrated probabilistic cancer-risk predictions.",
        "literature_basis": "Standard probabilistic classification and calibration metric.",
        "citation_keys": ["brier1950verification", "standard_calibration_metrics"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Validate against sklearn.metrics.brier_score_loss or a direct calculation.",
    },
]

_CLASSICAL_CLASSIFIER_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "LogisticRegression",
        "mathematical_form": "P(y=1|x)=sigmoid(beta0 + x^T beta).",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["linear log-odds in predictors", "independent observations", "regularization controls overfitting"],
        "objective_or_loss": "penalized binary log-loss.",
        "hyperparameters_and_tuning": "penalty in {l2, l1}; C regularization grid; class_weight optional.",
        "tuning_grid_or_search_space": "C in {0.01, 0.1, 1, 10}; penalty l2 and l1 when solver supports it.",
        "selected_hyperparameters": "report C, penalty, solver, and class_weight.",
        "diagnostics": ["coefficients", "convergence", "calibration", "ROC_AUC", "BrierScore"],
        "interpretation": "Transparent linear baseline; coefficients indicate direction and strength of feature associations.",
    },
    {
        "name": "LinearDiscriminantAnalysis",
        "mathematical_form": "Gaussian class-conditional model with shared covariance and linear discriminant score.",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["approximately Gaussian predictors within class", "shared covariance across classes"],
        "objective_or_loss": "maximum-likelihood discriminant classification.",
        "hyperparameters_and_tuning": "solver and optional shrinkage.",
        "tuning_grid_or_search_space": "solver in {svd, lsqr}; shrinkage in {none, auto} when supported.",
        "selected_hyperparameters": "report solver and shrinkage.",
        "diagnostics": ["class means", "covariance stability", "ROC_AUC", "Specificity", "Sensitivity"],
        "interpretation": "Classical linear generative classifier for tabular diagnostic data.",
    },
    {
        "name": "GaussianNaiveBayes",
        "mathematical_form": "P(y|x) proportional to P(y) prod_j Normal(x_j | mu_{yj}, sigma^2_{yj}).",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["conditional feature independence within class", "Gaussian feature distributions"],
        "objective_or_loss": "maximum-likelihood class-conditional density estimation.",
        "hyperparameters_and_tuning": "var_smoothing grid.",
        "tuning_grid_or_search_space": "var_smoothing in {1e-9, 1e-8, 1e-7}.",
        "selected_hyperparameters": "report var_smoothing.",
        "diagnostics": ["class priors", "feature likelihood stability", "ROC_AUC", "BrierScore"],
        "interpretation": "Fast probabilistic classical baseline with strong independence assumptions.",
    },
    {
        "name": "KNearestNeighbors",
        "mathematical_form": "Class probability is the fraction of positive labels among the k nearest training points.",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["local smoothness in scaled feature space", "distance metric is meaningful after preprocessing"],
        "objective_or_loss": "nonparametric neighbor vote using a distance metric.",
        "hyperparameters_and_tuning": "k, weights, and distance metric.",
        "tuning_grid_or_search_space": "k in {3, 5, 11, 21}; weights in {uniform, distance}.",
        "selected_hyperparameters": "report k, weights, and metric.",
        "diagnostics": ["neighbor count sensitivity", "scaling sensitivity", "ROC_AUC", "runtime_sec"],
        "interpretation": "Instance-based classical comparator that tests local feature-space separability.",
    },
    {
        "name": "SupportVectorMachineRBF",
        "mathematical_form": "Maximum-margin classifier with RBF kernel K(x,x')=exp(-gamma||x-x'||^2).",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["classes separable in nonlinear kernel space", "features are scaled"],
        "objective_or_loss": "soft-margin hinge loss with kernel regularization.",
        "hyperparameters_and_tuning": "C and gamma grid; probability calibration when probabilities are required.",
        "tuning_grid_or_search_space": "C in {0.1, 1, 10}; gamma in {scale, 0.01, 0.1}.",
        "selected_hyperparameters": "report C, gamma, kernel, and calibration method.",
        "diagnostics": ["support vector count", "ROC_AUC", "PR_AUC", "runtime_sec"],
        "interpretation": "Classical nonlinear margin-based classifier.",
    },
    {
        "name": "RandomForestClassifier",
        "mathematical_form": "Ensemble of bootstrapped decision trees with feature subsampling; probabilities average tree votes.",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["tree splits capture nonlinear interactions", "ensemble averaging reduces variance"],
        "objective_or_loss": "greedy impurity reduction averaged across trees.",
        "hyperparameters_and_tuning": "n_estimators, max_depth, min_samples_leaf, max_features.",
        "tuning_grid_or_search_space": "n_estimators in {100, 300}; max_depth in {none, 4, 8}; min_samples_leaf in {1, 3}.",
        "selected_hyperparameters": "report tree count, depth, leaf size, and max_features.",
        "diagnostics": ["feature importance", "out-of-bag score if used", "ROC_AUC", "BrierScore"],
        "interpretation": "Classical bagged-tree ensemble for nonlinear tabular classification.",
    },
    {
        "name": "GradientBoostingClassifier",
        "mathematical_form": "Additive ensemble of shallow trees fitted sequentially to reduce classification loss.",
        "response_or_target": "binary cancer presence label",
        "assumptions": ["boosted trees capture nonlinear additive/interacting effects", "learning rate and depth control overfitting"],
        "objective_or_loss": "stagewise minimization of binomial deviance/log-loss.",
        "hyperparameters_and_tuning": "n_estimators, learning_rate, max_depth, subsample.",
        "tuning_grid_or_search_space": "n_estimators in {100, 300}; learning_rate in {0.03, 0.1}; max_depth in {2, 3}.",
        "selected_hyperparameters": "report boosting rounds, learning rate, depth, and early-stopping rule when used.",
        "diagnostics": ["staged validation curve", "feature importance", "ROC_AUC", "PR_AUC", "runtime_sec"],
        "interpretation": "Classical boosted-tree comparator for strong tabular predictive performance.",
    },
]

_REGRESSION_MODEL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "LinearRegression",
        "mathematical_form": "y = beta0 + x^T beta + epsilon fitted by ordinary least squares.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["linear conditional mean", "independent observations", "finite-variance errors"],
        "objective_or_loss": "minimize sum of squared residuals.",
        "hyperparameters_and_tuning": "no primary hyperparameters; preprocessing and feature set are fixed across models.",
        "tuning_grid_or_search_space": "none beyond shared preprocessing choices.",
        "selected_hyperparameters": "report intercept handling and preprocessing.",
        "diagnostics": ["coefficients", "residual_plot", "MAE", "RMSE", "R2"],
        "interpretation": "Transparent linear reference model for continuous prediction.",
    },
    {
        "name": "RidgeRegression",
        "mathematical_form": "min_beta sum_i (y_i - x_i^T beta)^2 + alpha ||beta||_2^2.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["linear conditional mean", "regularization stabilizes correlated predictors"],
        "objective_or_loss": "L2-penalized squared error.",
        "hyperparameters_and_tuning": "alpha regularization strength.",
        "tuning_grid_or_search_space": "alpha in {0.01, 0.1, 1, 10, 100}.",
        "selected_hyperparameters": "report selected alpha.",
        "diagnostics": ["coefficient shrinkage", "MAE", "RMSE", "R2"],
        "interpretation": "Regularized linear baseline robust to multicollinearity.",
    },
    {
        "name": "LassoRegression",
        "mathematical_form": "min_beta sum_i (y_i - x_i^T beta)^2 + alpha ||beta||_1.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["sparse or approximately sparse linear signal", "scaled predictors"],
        "objective_or_loss": "L1-penalized squared error.",
        "hyperparameters_and_tuning": "alpha regularization strength.",
        "tuning_grid_or_search_space": "alpha in {0.001, 0.01, 0.1, 1}.",
        "selected_hyperparameters": "report selected alpha and number of nonzero coefficients.",
        "diagnostics": ["feature selection count", "MAE", "RMSE", "R2"],
        "interpretation": "Sparse linear model useful when variable selection matters.",
    },
    {
        "name": "ElasticNetRegression",
        "mathematical_form": "min_beta squared error + alpha[(1-l1_ratio)||beta||_2^2/2 + l1_ratio||beta||_1].",
        "response_or_target": "continuous numeric response",
        "assumptions": ["linear signal with correlated feature groups", "scaled predictors"],
        "objective_or_loss": "combined L1/L2-penalized squared error.",
        "hyperparameters_and_tuning": "alpha and l1_ratio.",
        "tuning_grid_or_search_space": "alpha in {0.001, 0.01, 0.1, 1}; l1_ratio in {0.2, 0.5, 0.8}.",
        "selected_hyperparameters": "report selected alpha and l1_ratio.",
        "diagnostics": ["coefficient sparsity", "MAE", "RMSE", "R2"],
        "interpretation": "Regularized linear model balancing shrinkage and feature selection.",
    },
    {
        "name": "KNearestNeighborsRegressor",
        "mathematical_form": "Prediction is the average response among the k nearest training points.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["local smoothness in scaled feature space", "distance metric is meaningful"],
        "objective_or_loss": "nonparametric local averaging.",
        "hyperparameters_and_tuning": "n_neighbors, weights, and distance metric.",
        "tuning_grid_or_search_space": "n_neighbors in {3, 5, 11, 21}; weights in {uniform, distance}.",
        "selected_hyperparameters": "report k and weights.",
        "diagnostics": ["neighbor count sensitivity", "MAE", "RMSE", "runtime_sec"],
        "interpretation": "Instance-based nonlinear comparator for tabular regression.",
    },
    {
        "name": "SupportVectorRegressionRBF",
        "mathematical_form": "Epsilon-insensitive support-vector regression with RBF kernel.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["features are scaled", "nonlinear smooth function can be represented by kernel expansion"],
        "objective_or_loss": "epsilon-insensitive loss with margin regularization.",
        "hyperparameters_and_tuning": "C, epsilon, and gamma.",
        "tuning_grid_or_search_space": "C in {0.1, 1, 10}; epsilon in {0.01, 0.1}; gamma in {scale, 0.01, 0.1}.",
        "selected_hyperparameters": "report C, epsilon, gamma, and support vector count.",
        "diagnostics": ["support vector count", "MAE", "RMSE", "runtime_sec"],
        "interpretation": "Classical kernel regressor for smooth nonlinear relationships.",
    },
    {
        "name": "RandomForestRegressor",
        "mathematical_form": "Average prediction from bootstrapped decision trees with feature subsampling.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["tree splits capture nonlinear interactions", "ensemble averaging reduces variance"],
        "objective_or_loss": "greedy squared-error impurity reduction averaged across trees.",
        "hyperparameters_and_tuning": "n_estimators, max_depth, min_samples_leaf, max_features.",
        "tuning_grid_or_search_space": "n_estimators in {100, 300}; max_depth in {none, 4, 8}; min_samples_leaf in {1, 3}.",
        "selected_hyperparameters": "report tree count, depth, leaf size, and max_features.",
        "diagnostics": ["feature importance", "MAE", "RMSE", "R2", "runtime_sec"],
        "interpretation": "Bagged-tree ensemble for nonlinear tabular regression.",
    },
    {
        "name": "GradientBoostingRegressor",
        "mathematical_form": "Additive ensemble of shallow trees fitted sequentially to reduce squared or absolute loss.",
        "response_or_target": "continuous numeric response",
        "assumptions": ["boosted trees capture nonlinear additive/interacting effects", "learning rate and depth control overfitting"],
        "objective_or_loss": "stagewise minimization of regression loss.",
        "hyperparameters_and_tuning": "n_estimators, learning_rate, max_depth, subsample.",
        "tuning_grid_or_search_space": "n_estimators in {100, 300}; learning_rate in {0.03, 0.1}; max_depth in {2, 3}.",
        "selected_hyperparameters": "report boosting rounds, learning rate, depth, and early-stopping rule when used.",
        "diagnostics": ["staged validation curve", "feature importance", "MAE", "RMSE", "R2", "runtime_sec"],
        "interpretation": "Boosted-tree comparator for strong tabular regression performance.",
    },
]


_IV_MONTE_CARLO_METRICS: list[dict[str, Any]] = [
    {
        "name": "bias",
        "role": "estimator bias",
        "direction": "minimize",
        "units": "coefficient units",
        "formula": "bias(\\hat\\beta) = mean_r(\\hat\\beta_r - \\beta_0).",
        "interpretation": "Lower absolute bias means the estimator is centered closer to the true structural parameter.",
        "literature_basis": "Standard Monte Carlo criterion for IV estimator finite-sample performance.",
        "citation_keys": ["staiger1997instrumental", "stock2002survey", "angrist2009mostly"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute directly across Monte Carlo replications with known true beta.",
    },
    {
        "name": "variance",
        "role": "estimator dispersion",
        "direction": "minimize",
        "units": "squared coefficient units",
        "formula": "variance(\\hat\\beta) = Var_r(\\hat\\beta_r).",
        "interpretation": "Lower variance means the estimator is more stable across repeated samples.",
        "literature_basis": "Standard Monte Carlo criterion for bias-variance trade-off analysis.",
        "citation_keys": ["stock2002survey", "davidson2004econometric"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute sample variance across Monte Carlo replications.",
    },
    {
        "name": "rmse",
        "role": "combined bias-variance error",
        "direction": "minimize",
        "units": "coefficient units",
        "formula": "RMSE = sqrt(mean_r((\\hat\\beta_r - \\beta_0)^2)).",
        "interpretation": "Lower RMSE means a better finite-sample bias-variance trade-off.",
        "literature_basis": "Standard Monte Carlo summary combining squared bias and variance.",
        "citation_keys": ["stock2002survey", "davidson2004econometric"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute directly from estimation errors across replications.",
    },
    {
        "name": "coverage_rate",
        "role": "inference calibration",
        "direction": "target_0.95",
        "units": "fraction",
        "formula": "coverage = mean_r(1{\\beta_0 in CI_r}).",
        "interpretation": "Values closer to 0.95 indicate better nominal 95% confidence interval calibration.",
        "literature_basis": "Standard finite-sample inference diagnostic for IV estimators.",
        "citation_keys": ["staiger1997instrumental", "stock2002survey"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute indicator coverage across Monte Carlo replications.",
    },
    {
        "name": "rejection_rate_5pct",
        "role": "size control",
        "direction": "target_0.05",
        "units": "fraction",
        "formula": "size = mean_r(1{p_r < 0.05}) under the null.",
        "interpretation": "Values closer to 0.05 indicate better test-size control.",
        "literature_basis": "Standard weak-instrument inference diagnostic.",
        "citation_keys": ["stock2002survey", "moreira2003conditional"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute empirical rejection frequency under a known null DGP.",
    },
    {
        "name": "first_stage_f_stat",
        "role": "instrument-strength diagnostic",
        "direction": "maximize",
        "units": "F statistic",
        "formula": "First-stage F statistic for excluded instruments in the first-stage regression.",
        "interpretation": "Higher values indicate stronger instruments; values near or below 10 indicate weak-instrument risk.",
        "literature_basis": "Canonical diagnostic for weak instruments.",
        "citation_keys": ["staiger1997instrumental", "stock2002survey"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Compute from the first-stage regression for every DGP/replication regime.",
    },
    {
        "name": "runtime_sec",
        "role": "computational efficiency",
        "direction": "minimize",
        "units": "seconds",
        "formula": "Wall-clock runtime per estimator-condition cell.",
        "interpretation": "Lower values indicate cheaper estimation at the same design size.",
        "literature_basis": "Standard reproducibility and computational-cost reporting practice.",
        "citation_keys": ["reproducibility_runtime_reporting"],
        "is_novel": False,
        "novelty_justification": "not novel",
        "proof_or_validation": "Measure elapsed wall-clock time around each estimator run.",
    },
]


_IV_ESTIMATOR_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "NaiveOLS",
        "mathematical_form": "OLS regression y = beta*x + error, ignoring endogeneity.",
        "response_or_target": "structural coefficient beta",
        "assumptions": ["exogeneity of x is violated in the weak-IV DGP; included as a biased benchmark"],
        "objective_or_loss": "minimize squared residuals in the structural equation.",
        "hyperparameters_and_tuning": "no tuning; closed-form least squares.",
        "tuning_grid_or_search_space": "none",
        "selected_hyperparameters": "none",
        "diagnostics": ["bias", "variance", "rmse"],
        "interpretation": "Shows the endogeneity bias that IV estimators are meant to address.",
    },
    {
        "name": "TwoStageLeastSquares",
        "mathematical_form": "First regress x on instruments z and controls, then regress y on fitted x_hat.",
        "response_or_target": "structural coefficient beta",
        "assumptions": ["instrument relevance", "instrument exogeneity", "exclusion restriction"],
        "objective_or_loss": "linear IV moment conditions E[z*(y - beta*x)] = 0.",
        "hyperparameters_and_tuning": "instrument set and optional ridge regularization for numerical stability.",
        "tuning_grid_or_search_space": "instrument_strength in target first-stage F values; optional ridge in {0, 1e-8, 1e-6}.",
        "selected_hyperparameters": "report selected ridge and achieved first-stage F.",
        "diagnostics": ["first_stage_f_stat", "bias", "variance", "rmse", "coverage_rate"],
        "interpretation": "Canonical IV estimator; can have high variance and finite-sample bias under weak instruments.",
    },
    {
        "name": "LIML",
        "mathematical_form": "Limited-information maximum likelihood / k-class IV estimator.",
        "response_or_target": "structural coefficient beta",
        "assumptions": ["same IV validity assumptions as 2SLS", "linear simultaneous-equations structure"],
        "objective_or_loss": "k-class likelihood criterion using the smallest characteristic root.",
        "hyperparameters_and_tuning": "no manual tuning beyond instrument set.",
        "tuning_grid_or_search_space": "instrument_strength regimes and sample-size regimes.",
        "selected_hyperparameters": "report k-class estimate implied by the LIML root.",
        "diagnostics": ["bias", "variance", "rmse", "coverage_rate"],
        "interpretation": "Often less biased than 2SLS with many/weak instruments, with different variance behavior.",
    },
    {
        "name": "FullerLIML",
        "mathematical_form": "Fuller modified LIML estimator with alpha adjustment.",
        "response_or_target": "structural coefficient beta",
        "assumptions": ["same IV validity assumptions as LIML"],
        "objective_or_loss": "bias-adjusted k-class criterion.",
        "hyperparameters_and_tuning": "Fuller alpha in {1, 4}.",
        "tuning_grid_or_search_space": "alpha values {1, 4}; instrument strength and sample size regimes.",
        "selected_hyperparameters": "report alpha and resulting estimate.",
        "diagnostics": ["bias", "variance", "rmse", "coverage_rate"],
        "interpretation": "Bias-reduced LIML variant commonly used in weak-instrument Monte Carlo comparisons.",
    },
    {
        "name": "JIVE",
        "mathematical_form": "Jackknife IV estimator using leave-one-out fitted first-stage values.",
        "response_or_target": "structural coefficient beta",
        "assumptions": ["valid instruments", "leave-one-out first-stage prediction reduces own-observation bias"],
        "objective_or_loss": "IV moment criterion with jackknife fitted endogenous regressor.",
        "hyperparameters_and_tuning": "instrument set; optional ridge stabilization for leave-one-out first stage.",
        "tuning_grid_or_search_space": "ridge in {0, 1e-8, 1e-6}; instrument strength regimes.",
        "selected_hyperparameters": "report ridge and numerical stability diagnostics.",
        "diagnostics": ["bias", "variance", "rmse", "coverage_rate"],
        "interpretation": "Designed to reduce finite-sample bias relative to conventional 2SLS.",
    },
]


def _combined_plan_topic_text(config: RCConfig, plan: dict[str, Any]) -> str:
    text_parts = [config.research.topic.casefold()]
    for key in ("objectives", "datasets", "baselines", "proposed_methods", "metrics", "metric_definitions"):
        value = plan.get(key)
        if isinstance(value, list):
            text_parts.extend(str(item).casefold() for item in value)
        elif value is not None:
            text_parts.append(str(value).casefold())
    return " ".join(text_parts)


def _detect_input_intent(config: RCConfig, plan: dict[str, Any]) -> dict[str, Any]:
    """Infer the user's experiment intent before selecting models/metrics."""
    combined = _combined_plan_topic_text(config, plan)

    signals: list[str] = []
    def _has_any(tokens: tuple[str, ...]) -> bool:
        found = [token for token in tokens if token in combined]
        signals.extend(found)
        return bool(found)

    task_predictive = _has_any((
        "predict",
        "prediction",
        "classify",
        "classification",
        "classifier",
        "regression",
        "forecast",
        "forecasting",
        "estimate",
        "estimation",
        "diagnose",
        "diagnosis",
        "detect",
        "detection",
        "model",
        "screen",
        "identify",
    ))
    categorical = _has_any((
        "class",
        "categorical",
        "binary",
        "label",
        "presence",
        "absence",
        "diagnosis",
        "diagnostic",
        "detection",
        "detect",
        "fraud",
        "default",
        "churn",
        "mortality",
        "readmission",
        "disease",
        "cancer",
        "conversion",
        "click",
        "purchase",
        "failure",
        "approval",
        "attrition",
        "dropout",
        "spam",
        "pass/fail",
        "risk",
    ))
    continuous = _has_any((
        "continuous",
        "regression",
        "numeric",
        "real-valued",
        "real valued",
        "score",
        "amount",
        "value",
        "rate",
        "forecast",
        "forecasting",
        "price",
        "cost",
        "demand",
        "sales",
        "revenue",
        "income",
        "load",
        "usage",
        "consumption",
        "quantity",
        "volume",
        "duration",
        "time to",
        "length of stay",
        "count",
        "severity",
        "concentration",
        "temperature",
        "pressure",
    ))
    unstructured = _has_any((
        "image",
        "images",
        "vision",
        "cnn",
        "convolution",
        "resnet",
        "vit",
        "transformer",
        "bert",
        "gpt",
        "text",
        "nlp",
        "language",
        "token",
        "speech",
        "audio",
        "deep learning",
        "neural network",
        "neural networks",
    ))
    classical = _has_any((
        "classical",
        "classic",
        "traditional model",
        "traditional models",
        "classical model",
        "classical models",
        "comparative study",
        "compare classical",
    ))

    if categorical and continuous:
        # Common phrasing such as "risk score" or "default rate" can include
        # continuous words while still asking for binary classification.
        if any(
            token in combined
            for token in (
                "risk",
                "default",
                "fraud",
                "churn",
                "mortality",
                "readmission",
                "presence",
                "diagnosis",
                "detection",
                "disease",
                "cancer",
                "conversion",
                "click",
                "purchase",
                "failure",
                "approval",
                "attrition",
                "dropout",
                "spam",
                "pass/fail",
            )
        ):
            target_type = "classification"
        else:
            target_type = "ambiguous_predictive"
    elif categorical:
        target_type = "classification"
    elif continuous:
        target_type = "regression"
    elif task_predictive:
        target_type = "ambiguous_predictive"
    else:
        target_type = "unknown"

    modality = "unstructured_or_deep" if unstructured else "tabular_or_structured"
    if target_type == "classification" and modality == "tabular_or_structured":
        suite = "classical_classification" if classical else "tabular_classification"
    elif target_type == "regression" and modality == "tabular_or_structured":
        suite = "tabular_regression"
    elif target_type == "ambiguous_predictive" and modality == "tabular_or_structured":
        suite = "ambiguous_tabular_predictive"
    else:
        suite = "domain_specific_or_generic"
    return {
        "task_family": "predictive" if task_predictive else "unknown",
        "target_type": target_type,
        "modality": modality,
        "model_suite": suite,
        "signals": sorted(set(signals)),
    }


def _get_input_intent(config: RCConfig, plan: dict[str, Any]) -> dict[str, Any]:
    intent = plan.get("input_intent")
    if isinstance(intent, dict) and intent.get("target_type") and intent.get("model_suite"):
        return intent
    intent = _detect_input_intent(config, plan)
    plan["input_intent"] = intent
    return intent


def _looks_like_predictive_categorical_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["target_type"] == "classification"


def _looks_like_classical_classification_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["model_suite"] == "classical_classification"


def _looks_like_unstructured_or_deep_prediction_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["modality"] == "unstructured_or_deep"


def _looks_like_tabular_classification_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["model_suite"] in {
        "classical_classification",
        "tabular_classification",
    }


def _looks_like_predictive_continuous_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["target_type"] == "regression"


def _looks_like_tabular_regression_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["model_suite"] == "tabular_regression"


def _looks_like_ambiguous_tabular_predictive_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    return _get_input_intent(config, plan)["model_suite"] == "ambiguous_tabular_predictive"


def _looks_like_weak_iv_monte_carlo_task(config: RCConfig, plan: dict[str, Any]) -> bool:
    combined = _combined_plan_topic_text(config, plan)
    return any(
        token in combined
        for token in (
            "weak instrument",
            "weak-instrument",
            "weak-intrument",
            "instrumental variable",
            "instrumental variables",
            "iv estimator",
            "iv estimators",
            "2sls",
            "two-stage least squares",
            "liml",
            "fuller liml",
            "jive",
            "jackknife iv",
            "first-stage f",
            "bias variance",
            "bias-variance",
            "monte carlo",
        )
    )


def _append_unique_strings(existing: Any, additions: list[str]) -> list[str]:
    normalized = existing if isinstance(existing, list) else []
    output = [str(item) for item in normalized if str(item).strip()]
    seen = {item.casefold() for item in output}
    for addition in additions:
        if addition.casefold() not in seen:
            output.append(addition)
            seen.add(addition.casefold())
    return output


def _item_name(item: Any) -> str:
    if isinstance(item, dict):
        for key in ("name", "model_name", "method", "condition", "id"):
            value = item.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""
    return str(item).strip()


def _is_generic_model_name(name: str) -> bool:
    normalized = re.sub(r"[^a-z0-9]+", "_", name.casefold()).strip("_")
    if not normalized:
        return True
    generic_tokens = (
        "baseline",
        "baseline_1",
        "baseline_2",
        "proposed",
        "proposed_method",
        "method_variant",
        "condition",
        "protocol",
        "topic_informed",
        "reference",
        "primary_dataset",
    )
    return any(token in normalized for token in generic_tokens)


def _needs_predictive_model_suite(plan: dict[str, Any]) -> bool:
    names: list[str] = []
    for key in ("baselines", "proposed_methods", "model_definitions"):
        for item in _normalize_named_sequence(plan.get(key)):
            name = _item_name(item)
            if name:
                names.append(name)
    concrete_names = [name for name in names if not _is_generic_model_name(name)]
    return len({name.casefold() for name in concrete_names}) < 2


def _normalize_named_sequence(value: Any) -> list[Any]:
    if isinstance(value, dict):
        return [
            dict(item, name=str(name)) if isinstance(item, dict) else {"name": str(name), "description": str(item)}
            for name, item in value.items()
        ]
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def _append_named_dicts(existing: Any, additions: list[dict[str, Any]]) -> list[Any]:
    output = list(_normalize_named_sequence(existing))
    seen = {_item_name(item).casefold() for item in output if _item_name(item)}
    for addition in additions:
        name = _item_name(addition)
        if name and name.casefold() not in seen:
            output.append(dict(addition))
            seen.add(name.casefold())
    return output


def _append_metric_definitions(plan: dict[str, Any], metric_definitions: list[dict[str, Any]]) -> None:
    existing_metric_names = {
        str(metric_def.get("name") or "").casefold().replace("-", "_")
        for metric_def in plan["metric_definitions"]
        if isinstance(metric_def, dict)
    }
    for metric_def in metric_definitions:
        metric_key = str(metric_def["name"]).casefold().replace("-", "_")
        if metric_key not in existing_metric_names:
            plan["metric_definitions"].append(dict(metric_def))
            existing_metric_names.add(metric_key)


def _coerce_sample_size(value: Any, fallback: int) -> int:
    match = re.search(r"\d+", str(value))
    sample_size = int(match.group()) if match else fallback
    return max(sample_size, _MIN_EXPERIMENT_SAMPLE_SIZE)


def _normalize_sample_size_regimes(regimes: Any) -> list[dict[str, Any]]:
    if isinstance(regimes, dict):
        raw_regimes = [
            {"name": name, "sample_size": sample_size}
            for name, sample_size in regimes.items()
        ]
    else:
        raw_regimes = regimes if isinstance(regimes, list) and regimes else []
    if not raw_regimes:
        return [dict(regime) for regime in _DEFAULT_SAMPLE_SIZE_REGIMES]

    normalized: list[dict[str, Any]] = []
    for idx, item in enumerate(raw_regimes):
        default = _DEFAULT_SAMPLE_SIZE_REGIMES[min(idx, len(_DEFAULT_SAMPLE_SIZE_REGIMES) - 1)]
        fallback_size = int(default["sample_size"])
        if isinstance(item, dict):
            entry = dict(item)
            entry.setdefault("name", default["name"])
            entry["sample_size"] = _coerce_sample_size(
                entry.get("sample_size") or entry.get("n") or entry.get("size"),
                fallback_size,
            )
        else:
            entry = {
                "name": str(item) if str(item).strip() else str(default["name"]),
                "sample_size": _coerce_sample_size(item, fallback_size),
            }
        normalized.append(entry)

    while len(normalized) < len(_DEFAULT_SAMPLE_SIZE_REGIMES):
        normalized.append(dict(_DEFAULT_SAMPLE_SIZE_REGIMES[len(normalized)]))
    return normalized


def _topic_descriptor(config: RCConfig) -> str:
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9]+", str(config.research.topic or "research topic"))
    selected = [
        token
        for token in tokens
        if token.casefold() not in _STOPWORDS and len(token) > 2
    ][:4]
    if not selected:
        selected = ["Research", "Topic"]
    return " ".join(token[:1].upper() + token[1:] for token in selected)


def _metric_name(metric: Any) -> str:
    if isinstance(metric, dict):
        value = metric.get("name") or metric.get("metric") or metric.get("id")
        return str(value).strip() if value is not None else ""
    return str(metric).strip()


def _append_condition_records(
    records: list[dict[str, Any]],
    items: Any,
    role: str,
) -> None:
    seen = {str(item.get("name") or "").casefold() for item in records if item.get("name")}
    for item in _normalize_named_sequence(items):
        name = _item_name(item)
        if not name:
            continue
        key = name.casefold()
        if key in seen:
            continue
        if isinstance(item, dict):
            record = dict(item)
        else:
            record = {"name": name}
        record.setdefault("name", name)
        record.setdefault("role", role)
        records.append(record)
        seen.add(key)


def _universal_metric_definitions(config: RCConfig) -> list[dict[str, Any]]:
    primary_key = str(getattr(config.experiment, "metric_key", "primary_metric") or "primary_metric")
    primary_direction = str(getattr(config.experiment, "metric_direction", "minimize") or "minimize")
    primary_better = "lower" if primary_direction == "minimize" else "higher"
    return [
        {
            "name": primary_key,
            "role": "primary effectiveness endpoint",
            "direction": primary_direction,
            "units": "task-specific units defined by the experiment",
            "formula": "Compute the task-specific primary endpoint from raw outputs exactly as specified in the experiment plan.",
            "interpretation": f"{primary_better.capitalize()} values indicate better primary task performance.",
            "literature_basis": "Primary endpoint selected from the task-specific benchmark or evaluation literature.",
            "citation_keys": ["task_specific_primary_metric"],
            "is_novel": False,
            "novelty_justification": "not novel unless explicitly justified by the task literature",
            "proof_or_validation": "Validate by comparing the implementation against a direct reference calculation on a small deterministic example.",
        },
        {
            "name": "effect_size",
            "role": "comparative magnitude of improvement",
            "direction": "maximize",
            "units": "standardized or signed difference",
            "formula": "Effect size = signed difference between proposed and reference condition on the primary metric, oriented so positive favors the proposed condition.",
            "interpretation": "Larger positive values indicate a more practically meaningful improvement over the reference condition.",
            "literature_basis": "Standard comparative reporting practice for empirical studies.",
            "citation_keys": ["standard_effect_size_reporting"],
            "is_novel": False,
            "novelty_justification": "not novel",
            "proof_or_validation": "Compute from per-condition primary metric values and verify sign convention.",
        },
        {
            "name": "robustness_score",
            "role": "stability across regimes",
            "direction": "maximize",
            "units": "fraction or normalized score on [0,1]",
            "formula": "Robustness score = fraction of datasets, regimes, seeds, or perturbation levels where the condition remains within the pre-specified acceptable performance band.",
            "interpretation": "Higher values mean conclusions are less sensitive to dataset, sample size, tuning, or simulation-regime changes.",
            "literature_basis": "Sensitivity and robustness analyses are standard for comparative empirical claims.",
            "citation_keys": ["standard_robustness_analysis"],
            "is_novel": False,
            "novelty_justification": "not novel",
            "proof_or_validation": "Derive from the same cells used for the main comparison and report the threshold used.",
        },
        {
            "name": "runtime_sec",
            "role": "computational efficiency",
            "direction": "minimize",
            "units": "seconds",
            "formula": "Runtime is measured wall-clock seconds for each condition/regime execution.",
            "interpretation": "Lower values indicate less computational cost for the same experimental regime.",
            "literature_basis": "Runtime is a standard operational metric for reproducible computational studies.",
            "citation_keys": ["standard_runtime_reporting"],
            "is_novel": False,
            "novelty_justification": "not novel",
            "proof_or_validation": "Measure with a monotonic timer around each condition and save runtime_by_condition.json.",
        },
        {
            "name": "success_rate",
            "role": "execution reliability",
            "direction": "maximize",
            "units": "fraction on [0,1]",
            "formula": "Success rate = completed runs divided by attempted runs for each condition.",
            "interpretation": "Higher values indicate fewer crashes, numerical failures, or invalid outputs.",
            "literature_basis": "Reliability reporting prevents survivorship bias in computational experiments.",
            "citation_keys": ["standard_reliability_reporting"],
            "is_novel": False,
            "novelty_justification": "not novel",
            "proof_or_validation": "Count failed and completed cells explicitly in results.json.",
        },
    ]


def _enforce_universal_experiment_contract(plan: dict[str, Any], config: RCConfig) -> dict[str, Any]:
    """Repair a thin plan into a minimum comparative experiment contract.

    This is intentionally domain-agnostic. Domain-specific enrichers can add
    stronger content, but every topic must still leave Stage 9 with comparable
    conditions, nontrivial sample-size/tuning axes, defined metrics, and a
    machine-readable results schema for Stage 10 and Stage 14.
    """
    descriptor = _topic_descriptor(config)
    repairs: list[str] = []

    plan["sample_size_regimes"] = _normalize_sample_size_regimes(plan.get("sample_size_regimes"))
    if len(plan["sample_size_regimes"]) < 3:
        repairs.append("added sample-size regimes")
    for idx, regime in enumerate(plan["sample_size_regimes"]):
        if not isinstance(regime, dict):
            continue
        default = _DEFAULT_SAMPLE_SIZE_REGIMES[min(idx, len(_DEFAULT_SAMPLE_SIZE_REGIMES) - 1)]
        regime.setdefault("name", default["name"])
        regime["sample_size"] = _coerce_sample_size(
            regime.get("sample_size") or regime.get("n") or regime.get("size"),
            int(default["sample_size"]),
        )

    baselines = _append_named_dicts(plan.get("baselines"), [])
    proposed = _append_named_dicts(plan.get("proposed_methods"), [])
    if not baselines:
        baselines = _append_named_dicts(
            baselines,
            [
                {
                    "name": f"Reference {descriptor} Protocol",
                    "description": "transparent reference implementation representing the simplest defensible comparator for the topic",
                }
            ],
        )
    if not proposed:
        proposed = _append_named_dicts(
            proposed,
            [
                {
                    "name": f"Topic Informed {descriptor} Protocol",
                    "description": "topic-aligned method or configuration that directly tests the main hypothesis",
                }
            ],
        )
    comparable_names = [_item_name(item) for item in baselines + proposed if _item_name(item)]
    if len(set(name.casefold() for name in comparable_names)) < 2:
        proposed = _append_named_dicts(
            proposed,
            [
                {
                    "name": f"Enhanced {descriptor} Protocol",
                    "description": "second topic-aligned condition added to preserve comparative validity",
                }
            ],
        )
        repairs.append("added second comparable condition")
    plan["baselines"] = baselines
    plan["proposed_methods"] = proposed

    ablations = _append_named_dicts(
        plan.get("ablations"),
        [
            {
                "name": "sample_size_ablation",
                "factor": "sample_size",
                "levels": [dict(regime) for regime in plan["sample_size_regimes"]],
                "purpose": "verify that conclusions are not an artifact of one sample size",
            },
            {
                "name": "tuning_ablation",
                "factor": "tuning_setting",
                "levels": ["default", "moderate_search", "expanded_search"],
                "purpose": "separate method effects from tuning/search-budget effects",
            },
        ],
    )
    for ablation in ablations:
        if not isinstance(ablation, dict):
            continue
        name = str(ablation.get("name", "")).casefold()
        if name == "sample_size_ablation":
            ablation["factor"] = "sample_size"
            ablation["levels"] = [dict(regime) for regime in plan["sample_size_regimes"]]
        elif name == "tuning_ablation":
            ablation.setdefault("factor", "tuning_setting")
            ablation.setdefault("levels", ["default", "moderate_search", "expanded_search"])
    plan["ablations"] = ablations

    model_definitions = _append_named_dicts(plan.get("model_definitions"), [])
    existing_models = {_item_name(item).casefold() for item in model_definitions if _item_name(item)}
    for item in plan["baselines"] + plan["proposed_methods"]:
        name = _item_name(item)
        if not name or name.casefold() in existing_models:
            continue
        model_definitions.append({
            "name": name,
            "mathematical_form": "state the model, estimator, algorithm, simulation rule, or decision procedure in equations or precise pseudocode",
            "response_or_target": "state the measured endpoint, output, or estimand",
            "assumptions": [
                "state data-generating, independence, measurement, identifiability, and numerical assumptions relevant to the topic",
                "state when the condition is expected to fail",
            ],
            "objective_or_loss": "state the optimization objective, likelihood, risk, utility, simulation criterion, or evaluation rule",
            "hyperparameters_and_tuning": "state default values plus the tuning/search grid used in tuning_ablation",
            "tuning_grid_or_search_space": "default, moderate_search, and expanded_search settings aligned to the topic",
            "selected_hyperparameters": "record selected values in model_definitions.json at runtime",
            "diagnostics": ["primary_metric", "effect_size", "robustness_score", "runtime_sec", "success_rate"],
            "interpretation": "state how outputs, coefficients, decisions, or trajectories support or reject the hypothesis",
        })
        existing_models.add(name.casefold())
    plan["model_definitions"] = model_definitions

    dataset_names: list[str] = []
    for item in _normalize_named_sequence(plan.get("datasets")):
        name = _item_name(item)
        if name:
            dataset_names.append(name)
    if not dataset_names:
        dataset_names = [f"Synthetic {descriptor} Benchmark"]
        repairs.append("added benchmark dataset placeholder")
    plan["datasets"] = list(dict.fromkeys(dataset_names))

    dataset_details = plan.get("dataset_details")
    if not isinstance(dataset_details, list):
        dataset_details = []
    existing_dataset_names = {
        str(item.get("name")).casefold()
        for item in dataset_details
        if isinstance(item, dict) and item.get("name")
    }
    for dataset_name in plan["datasets"]:
        if dataset_name.casefold() in existing_dataset_names:
            continue
        n = int(plan["sample_size_regimes"][-1]["sample_size"])
        dataset_details.append({
            "name": dataset_name,
            "task": f"evaluate {descriptor} conditions under a controlled, comparable protocol",
            "sample_size": n,
            "training_size": "state train size if training is used; otherwise not applicable",
            "validation_size": "state validation size if tuning/model selection is used; otherwise not applicable",
            "test_size": "state held-out/test/evaluation size or number of simulation replications",
            "feature_count": "state feature/input/state dimensionality when applicable",
            "target": "state response, endpoint, estimand, or measured outcome",
            "split": "same split, seeds, and regimes for all comparable conditions",
            "preprocessing": ["topic-appropriate normalization, filtering, encoding, or simulation initialization"],
            "rationale": "ensures every condition is evaluated on the same task and regimes",
        })
        existing_dataset_names.add(dataset_name.casefold())
    plan["dataset_details"] = dataset_details

    plan["metric_definitions"] = _normalize_metric_definitions(
        plan.get("metric_definitions"),
        plan.get("metrics"),
        config,
    )
    _append_metric_definitions(plan, _universal_metric_definitions(config))
    metric_names = [_metric_name(metric) for metric in plan["metric_definitions"] if _metric_name(metric)]
    plan["metrics"] = list(dict.fromkeys(metric_names))

    plan["required_figures"] = _append_unique_strings(
        plan.get("required_figures"),
        [
            "condition_metric_comparison",
            "metric_by_sample_size",
            "ablation_sensitivity_comparison",
            "runtime_comparison",
        ],
    )
    plan["required_tables"] = _append_unique_strings(
        plan.get("required_tables"),
        [
            "condition_metric_comparison_table",
            "sample_size_regime_results_table",
            "ablation_results_table",
            "model_and_tuning_summary_table",
        ],
    )
    plan["presentation_requirements"] = _append_unique_strings(
        plan.get("presentation_requirements"),
        [
            "Every results figure must compare at least two conditions, sample sizes, regimes, or tuning settings; do not create single-bar figures.",
            "Every results table must contain at least two rows representing methods, sample sizes, regimes, or tuning settings; do not create one-row result tables.",
            "Tables and figures must use the same condition names as results.json and model_definitions.json.",
        ],
    )

    if not isinstance(plan.get("simulation_factors"), dict):
        plan["simulation_factors"] = {}
    plan["simulation_factors"].setdefault(
        "regime_difficulty",
        ["low_or_clean", "medium", "high_or_noisy"],
    )
    plan["simulation_factors"].setdefault(
        "sample_size",
        [int(regime["sample_size"]) for regime in plan["sample_size_regimes"]],
    )

    if not isinstance(plan.get("tuning_parameters"), dict):
        plan["tuning_parameters"] = {}
    plan["tuning_parameters"].setdefault(
        "all_conditions",
        {
            "tuning_setting": ["default", "moderate_search", "expanded_search"],
            "rule": "choose topic-appropriate hyperparameters or protocol settings and record selected values per condition",
        },
    )

    condition_records: list[dict[str, Any]] = []
    _append_condition_records(condition_records, plan["baselines"], "reference")
    _append_condition_records(condition_records, plan["proposed_methods"], "proposed")
    _append_condition_records(condition_records, plan["ablations"], "variant")
    plan["conditions"] = condition_records

    metric_keys = list(dict.fromkeys(plan["metrics"]))
    plan["canonical_results_schema"] = {
        "required": True,
        "format": "results.json must contain a `cells` list",
        "cell_fields": [
            "condition",
            "role",
            "dataset",
            "sample_size",
            "regime",
            "tuning_setting",
            "seed_or_replication",
            "metrics",
        ],
        "metric_keys": metric_keys,
        "minimum_cells": "at least one cell for each comparable condition x sample_size regime, plus tuning/ablation cells when feasible",
        "notes": (
            "Stage 10 must write comparable cells; Stage 14 tables and figures "
            "must be built from at least two cells/conditions and must never "
            "collapse to a single scalar unless the run explicitly failed."
        ),
    }
    plan["experiment_contract"] = {
        "version": "universal_comparative_v1",
        "required_minimums": {
            "comparable_conditions": 2,
            "sample_size_regimes": 3,
            "metrics": 3,
            "result_cells": "condition x sample_size/regime/tuning grid",
        },
        "validation_status": "repaired" if repairs else "valid",
        "repairs": repairs,
    }
    return plan


def _enrich_experiment_plan(
    plan: dict[str, Any],
    config: RCConfig,
    benchmark_datasets: list[str] | None = None,
) -> dict[str, Any]:
    """Add paper-critical structure when the LLM emits a thin experiment plan."""
    benchmark_datasets = benchmark_datasets or []
    domain_id = ""
    try:
        from researchclaw.domains.detector import detect_domain as _detect_domain_adv

        domain_profile = _detect_domain_adv(topic=config.research.topic)
        domain_id = getattr(domain_profile, "domain_id", "") or ""
    except Exception:  # noqa: BLE001
        domain_profile = None

    if not (
        isinstance(plan.get("input_intent"), dict)
        and plan["input_intent"].get("target_type")
        and plan["input_intent"].get("model_suite")
    ):
        plan["input_intent"] = _detect_input_intent(config, plan)

    datasets = plan.get("datasets", [])
    if isinstance(datasets, dict):
        dataset_names = [str(name) for name in datasets.keys()]
    elif isinstance(datasets, list):
        dataset_names = [str(item) for item in datasets]
    else:
        dataset_names = []

    for dataset_name in benchmark_datasets:
        if dataset_name not in dataset_names:
            dataset_names.append(dataset_name)
        if len(dataset_names) >= 3:
            break
    if dataset_names:
        plan["datasets"] = dataset_names

    dataset_details = plan.get("dataset_details")
    if not isinstance(dataset_details, list):
        dataset_details = []
    existing_names = {
        str(item.get("name"))
        for item in dataset_details
        if isinstance(item, dict) and item.get("name")
    }
    for dataset_name in dataset_names:
        if dataset_name in existing_names:
            continue
        dataset_details.append({
            "name": dataset_name,
            "task": "specify task",
            "sample_size": "specify sample size; use >200 for simulation/generated data when feasible",
            "training_size": "specify training sample size",
            "validation_size": "specify validation sample size or state not used",
            "test_size": "specify held-out test sample size",
            "feature_count": "specify feature/input dimensionality",
            "target": "specify target variable or label",
            "split": "specify train/validation/test split",
            "preprocessing": [
                "specify normalization or scaling",
                "specify missing-value handling / encoding / feature engineering",
            ],
            "rationale": "explain why this dataset is appropriate for the topic",
        })
    plan["dataset_details"] = dataset_details

    plan["sample_size_regimes"] = _normalize_sample_size_regimes(
        plan.get("sample_size_regimes")
    )
    if "preprocessing" not in plan:
        plan["preprocessing"] = [
            "state exact normalization or standardization",
            "state missing-value handling",
            "state categorical encoding or tokenization",
            "state feature engineering or augmentation",
        ]
    study_mode = str(getattr(config.experiment, "study_mode", "simulation") or "simulation").strip().lower()
    plan["study_mode"] = study_mode
    plan["study_mode_reporting_requirements"] = _append_unique_strings(
        plan.get("study_mode_reporting_requirements"),
        [
            "Report total sample size plus explicit training, validation when used, and test sizes for every simulation/application dataset.",
            "Simulation and sample-size ablation regimes must use explicit sample sizes greater than 200 whenever data can be generated or subsampled.",
            "For simulation-only studies, ablations must vary sample size, simulation setup parameters, and model tuning/search settings.",
            "For application-only studies, ablations must focus on model tuning/search settings and scientifically meaningful preprocessing/model variants.",
            "For studies with both simulation and application data, keep simulation and application ablation tracks separate and label their sample/split sizes separately.",
        ],
    )
    plan["model_reporting_requirements"] = _append_unique_strings(
        plan.get("model_reporting_requirements"),
        [
            "For every model or estimator, define the mathematical form, response/target, link or decision rule, objective/loss, and all symbols.",
            "For every model or estimator, state assumptions including distributional, independence, linearity/smoothness, feature, calibration, and identifiability assumptions when relevant.",
            "For every model or estimator, report hyperparameters, tuning/search space, selected values, and practical interpretation of fitted parameters or outputs.",
        ],
    )
    if (
        domain_profile is not None
        and domain_id.startswith("economics_")
        and getattr(domain_profile, "standard_baselines", None)
        and not plan.get("baselines")
    ):
        plan["baselines"] = [
            {"name": baseline, "description": "domain-standard economics baseline"}
            for baseline in domain_profile.standard_baselines
        ]

    if _looks_like_weak_iv_monte_carlo_task(config, plan):
        plan["domain_id"] = "economics_empirical"
        plan["experiment_type"] = "monte_carlo_estimator_comparison"
        plan["objectives"] = _append_unique_strings(
            plan.get("objectives"),
            [
                "Compare weak-instrument IV estimators in a Monte Carlo design with known true structural coefficient.",
                "Estimate finite-sample bias, variance, RMSE, coverage, rejection size, first-stage strength, and runtime across estimators.",
                "Evaluate how sample size, instrument strength, and tuning choices change the bias-variance trade-off.",
            ],
        )
        plan["datasets"] = _append_unique_strings(
            plan.get("datasets"),
            ["Synthetic weak-instrument IV DGP"],
        )
        plan["baselines"] = _append_named_dicts(
            plan.get("baselines"),
            [
                {"name": "NaiveOLS", "description": "endogeneity-biased non-IV reference estimator"},
                {"name": "TwoStageLeastSquares", "description": "canonical 2SLS IV estimator"},
            ],
        )
        plan["proposed_methods"] = _append_named_dicts(
            plan.get("proposed_methods"),
            [
                {"name": "LIML", "description": "limited-information maximum likelihood IV estimator"},
                {"name": "FullerLIML", "description": "Fuller bias-adjusted LIML estimator"},
                {"name": "JIVE", "description": "jackknife IV finite-sample bias-reduction estimator"},
            ],
        )
        enriched_regimes: list[dict[str, Any]] = []
        default_reps = 250
        for idx, regime in enumerate(plan["sample_size_regimes"]):
            entry = dict(regime) if isinstance(regime, dict) else {"sample_size": _coerce_sample_size(regime, 256)}
            entry.setdefault("name", f"n_{entry.get('sample_size', _DEFAULT_SAMPLE_SIZE_REGIMES[min(idx, 2)]['sample_size'])}")
            entry["sample_size"] = _coerce_sample_size(entry.get("sample_size"), int(_DEFAULT_SAMPLE_SIZE_REGIMES[min(idx, 2)]["sample_size"]))
            entry.setdefault("mc_replications", default_reps)
            enriched_regimes.append(entry)
        plan["sample_size_regimes"] = enriched_regimes
        plan["simulation_factors"] = {
            "instrument_strength": [
                {"name": "weak", "target_first_stage_f": 5},
                {"name": "moderate", "target_first_stage_f": 10},
                {"name": "strong", "target_first_stage_f": 20},
            ],
            "endogeneity_correlation": [0.3, 0.6],
            "instrument_count": [1, 5],
        }
        plan["tuning_parameters"] = {
            "FullerLIML": {"alpha": [1, 4]},
            "JIVE": {"ridge_stabilization": [0.0, 1e-8, 1e-6]},
            "TwoStageLeastSquares": {"ridge_stabilization": [0.0, 1e-8]},
        }
        plan["model_definitions"] = _append_named_dicts(
            plan.get("model_definitions"),
            _IV_ESTIMATOR_DEFINITIONS,
        )
        plan["metric_definitions"] = _normalize_metric_definitions(
            plan.get("metric_definitions"),
            plan.get("metrics"),
            config,
        )
        _append_metric_definitions(plan, _IV_MONTE_CARLO_METRICS)
        plan["metrics"] = [
            metric["name"]
            for metric in plan["metric_definitions"]
            if isinstance(metric, dict) and metric.get("name")
        ]
        plan["required_figures"] = _append_unique_strings(
            plan.get("required_figures"),
            [
                "bias_variance_tradeoff",
                "rmse_comparison",
                "coverage_rate_comparison",
                "first_stage_strength_sensitivity",
                "sample_size_scaling",
                "tuning_ablation_comparison",
                "runtime_comparison",
            ],
        )
        plan["ablation_requirements"] = _append_unique_strings(
            plan.get("ablation_requirements"),
            [
                "Instrument-strength ablation: compare weak, moderate, and strong target first-stage F regimes.",
                "Estimator-tuning ablation: compare Fuller alpha values and ridge stabilization settings for numerically sensitive estimators.",
                "Sample-size ablation: evaluate all estimators at every planned sample-size regime with Monte Carlo replications.",
            ],
        )
        plan["ablations"] = _append_named_dicts(
            plan.get("ablations"),
            [
                {
                    "name": "instrument_strength_ablation",
                    "factor": "target first-stage F statistic",
                    "levels": plan["simulation_factors"]["instrument_strength"],
                    "purpose": "test weak-instrument sensitivity of each estimator",
                },
                {
                    "name": "estimator_tuning_ablation",
                    "factor": "estimator tuning/stabilization parameter",
                    "levels": plan["tuning_parameters"],
                    "purpose": "separate estimator choice from tuning/stabilization effects",
                },
            ],
        )
        plan["canonical_results_schema"] = {
            "required": True,
            "format": "results.json must contain a `cells` list",
            "cell_fields": [
                "condition",
                "role",
                "sample_size",
                "mc_replications",
                "instrument_strength",
                "tuning_setting",
                "metrics",
            ],
            "metric_keys": [
                "bias",
                "variance",
                "rmse",
                "coverage_rate",
                "rejection_rate_5pct",
                "first_stage_f_stat",
                "runtime_sec",
            ],
            "notes": (
                "Every estimator x sample_size x instrument_strength x tuning setting must "
                "produce a cell; Stage 14 tables and figures are built from these cells."
            ),
        }
    if _looks_like_classical_classification_task(config, plan):
        plan["domain_id"] = "ml_tabular"
        plan["experiment_type"] = "classical_binary_classification_comparison"
        plan["objectives"] = _append_unique_strings(
            plan.get("objectives"),
            [
                "Compare classical tabular classifiers for binary breast-cancer presence prediction under the same preprocessing, split, and tuning protocol.",
                "Report discrimination, thresholded classification, calibration, robustness, and runtime metrics for every model.",
                "Evaluate sensitivity to sample size and tuning settings without replacing the requested classical models with generic protocol labels.",
            ],
        )
        plan["datasets"] = _append_unique_strings(
            plan.get("datasets"),
            ["Breast Cancer Wisconsin Diagnostic"],
        )
        plan["baselines"] = [
            {
                "name": "LogisticRegression",
                "description": "regularized linear probabilistic classifier and primary transparent reference model",
            },
            {
                "name": "LinearDiscriminantAnalysis",
                "description": "classical linear Gaussian discriminant classifier",
            },
            {
                "name": "GaussianNaiveBayes",
                "description": "classical generative probabilistic baseline with conditional-independence assumption",
            },
        ]
        plan["proposed_methods"] = [
            {
                "name": "KNearestNeighbors",
                "description": "instance-based classical classifier using scaled feature-space neighborhoods",
            },
            {
                "name": "SupportVectorMachineRBF",
                "description": "kernel SVM classical nonlinear margin classifier",
            },
            {
                "name": "RandomForestClassifier",
                "description": "bagged-tree classical ensemble classifier for nonlinear tabular effects",
            },
            {
                "name": "GradientBoostingClassifier",
                "description": "boosted-tree classical ensemble classifier for tabular prediction",
            },
        ]
        plan["sample_size_regimes"] = _normalize_sample_size_regimes(
            plan.get("sample_size_regimes")
        )
        plan["model_definitions"] = _append_named_dicts(
            [],
            _CLASSICAL_CLASSIFIER_DEFINITIONS,
        )
        plan["metric_definitions"] = _normalize_metric_definitions(
            plan.get("metric_definitions"),
            plan.get("metrics"),
            config,
        )
        _append_metric_definitions(plan, _CATEGORICAL_PREDICTION_METRICS)
        _append_metric_definitions(plan, _CLASSICAL_CLASSIFICATION_METRICS)
        plan["metrics"] = [
            metric["name"]
            for metric in plan["metric_definitions"]
            if isinstance(metric, dict) and metric.get("name")
        ]
        plan["tuning_parameters"] = {
            "LogisticRegression": {
                "C": [0.01, 0.1, 1.0, 10.0],
                "penalty": ["l2", "l1"],
            },
            "LinearDiscriminantAnalysis": {
                "solver": ["svd", "lsqr"],
                "shrinkage": [None, "auto"],
            },
            "GaussianNaiveBayes": {
                "var_smoothing": [1e-9, 1e-8, 1e-7],
            },
            "KNearestNeighbors": {
                "n_neighbors": [3, 5, 11, 21],
                "weights": ["uniform", "distance"],
            },
            "SupportVectorMachineRBF": {
                "C": [0.1, 1.0, 10.0],
                "gamma": ["scale", 0.01, 0.1],
            },
            "RandomForestClassifier": {
                "n_estimators": [100, 300],
                "max_depth": [None, 4, 8],
                "min_samples_leaf": [1, 3],
            },
            "GradientBoostingClassifier": {
                "n_estimators": [100, 300],
                "learning_rate": [0.03, 0.1],
                "max_depth": [2, 3],
            },
        }
        plan["ablations"] = _append_named_dicts(
            plan.get("ablations"),
            [
                {
                    "name": "sample_size_ablation",
                    "factor": "sample_size",
                    "levels": [dict(regime) for regime in plan["sample_size_regimes"]],
                    "purpose": "test whether classical-model ranking is stable as training size changes",
                },
                {
                    "name": "tuning_ablation",
                    "factor": "tuning_setting",
                    "levels": ["default", "moderate_search", "expanded_search"],
                    "purpose": "separate classifier choice from tuning-budget effects",
                },
            ],
        )
        plan["required_figures"] = _append_unique_strings(
            plan.get("required_figures"),
            [
                "roc_auc_comparison",
                "precision_recall_comparison",
                "confusion_matrix_comparison",
                "calibration_brier_comparison",
                "metric_by_sample_size",
                "runtime_comparison",
            ],
        )
        plan["required_tables"] = _append_unique_strings(
            plan.get("required_tables"),
            [
                "classical_model_metric_comparison_table",
                "sensitivity_specificity_table",
                "sample_size_ablation_table",
                "tuning_ablation_table",
            ],
        )
        plan["code_generation_requirements"] = _append_unique_strings(
            plan.get("code_generation_requirements"),
            [
                "Implement exactly the named classical classifiers; do not replace them with generic protocol labels.",
                "Use a shared preprocessing pipeline, split strategy, and metric function for every classifier.",
                "Prefer sklearn built-in breast cancer data when available; otherwise generate a deterministic tabular binary classification dataset with feature names and n > 200.",
                "Write one results.json cell per classifier x sample_size x tuning_setting with all classification metrics.",
            ],
        )
        plan["canonical_results_schema"] = {
            "required": True,
            "format": "results.json must contain a `cells` list",
            "cell_fields": [
                "condition",
                "role",
                "dataset",
                "sample_size",
                "tuning_setting",
                "seed_or_replication",
                "metrics",
            ],
            "metric_keys": [
                "Accuracy",
                "Precision",
                "Recall",
                "F1",
                "ROC_AUC",
                "Sensitivity",
                "Specificity",
                "BalancedAccuracy",
                "PR_AUC",
                "BrierScore",
                "runtime_sec",
                "success_rate",
            ],
            "notes": (
                "Every classical classifier x sample_size x tuning setting must "
                "produce comparable cells; Stage 14 tables and figures are built "
                "from these cells."
            ),
        }
    if _looks_like_tabular_classification_task(config, plan) and _needs_predictive_model_suite(plan):
        plan["domain_id"] = "ml_tabular"
        plan["experiment_type"] = "tabular_classification_model_comparison"
        plan["objectives"] = _append_unique_strings(
            plan.get("objectives"),
            [
                "Compare a concrete suite of standard tabular classification models under the same preprocessing, split, and tuning protocol.",
                "Report discrimination, thresholded classification, calibration, robustness, and runtime metrics for every classifier.",
                "Evaluate whether model ranking is stable across sample-size and tuning regimes.",
            ],
        )
        plan["datasets"] = _append_unique_strings(
            plan.get("datasets"),
            ["Synthetic tabular classification benchmark"],
        )
        plan["baselines"] = [
            {"name": "LogisticRegression", "description": "regularized linear probabilistic classifier"},
            {"name": "GaussianNaiveBayes", "description": "classical generative probabilistic classifier"},
            {"name": "KNearestNeighbors", "description": "instance-based neighborhood classifier"},
        ]
        plan["proposed_methods"] = [
            {"name": "SupportVectorMachineRBF", "description": "kernel margin classifier"},
            {"name": "RandomForestClassifier", "description": "bagged-tree ensemble classifier"},
            {"name": "GradientBoostingClassifier", "description": "boosted-tree ensemble classifier"},
        ]
        plan["model_definitions"] = _append_named_dicts(
            [],
            [
                item
                for item in _CLASSICAL_CLASSIFIER_DEFINITIONS
                if item["name"] != "LinearDiscriminantAnalysis"
            ],
        )
        plan["metric_definitions"] = _normalize_metric_definitions(
            plan.get("metric_definitions"),
            plan.get("metrics"),
            config,
        )
        _append_metric_definitions(plan, _CATEGORICAL_PREDICTION_METRICS)
        _append_metric_definitions(plan, _CLASSICAL_CLASSIFICATION_METRICS)
        plan["metrics"] = [
            metric["name"]
            for metric in plan["metric_definitions"]
            if isinstance(metric, dict) and metric.get("name")
        ]
        plan["tuning_parameters"] = {
            "LogisticRegression": {"C": [0.01, 0.1, 1.0, 10.0], "penalty": ["l2", "l1"]},
            "GaussianNaiveBayes": {"var_smoothing": [1e-9, 1e-8, 1e-7]},
            "KNearestNeighbors": {"n_neighbors": [3, 5, 11, 21], "weights": ["uniform", "distance"]},
            "SupportVectorMachineRBF": {"C": [0.1, 1.0, 10.0], "gamma": ["scale", 0.01, 0.1]},
            "RandomForestClassifier": {"n_estimators": [100, 300], "max_depth": [None, 4, 8]},
            "GradientBoostingClassifier": {"n_estimators": [100, 300], "learning_rate": [0.03, 0.1], "max_depth": [2, 3]},
        }
        plan["required_figures"] = _append_unique_strings(
            plan.get("required_figures"),
            [
                "roc_auc_comparison",
                "precision_recall_comparison",
                "confusion_matrix_comparison",
                "calibration_brier_comparison",
                "metric_by_sample_size",
                "runtime_comparison",
            ],
        )
        plan["required_tables"] = _append_unique_strings(
            plan.get("required_tables"),
            [
                "classification_model_metric_comparison_table",
                "classification_threshold_metric_table",
                "sample_size_ablation_table",
                "tuning_ablation_table",
            ],
        )
        plan["code_generation_requirements"] = _append_unique_strings(
            plan.get("code_generation_requirements"),
            [
                "Implement exactly the named classifiers; do not replace them with generic protocol labels.",
                "Use one shared preprocessing, split, and evaluation pipeline for all classifiers.",
                "Write one results.json cell per classifier x sample_size x tuning_setting with all classification metrics.",
            ],
        )
    if _looks_like_tabular_regression_task(config, plan) and _needs_predictive_model_suite(plan):
        plan["domain_id"] = "ml_tabular"
        plan["experiment_type"] = "tabular_regression_model_comparison"
        plan["objectives"] = _append_unique_strings(
            plan.get("objectives"),
            [
                "Compare a concrete suite of standard tabular regression models under the same preprocessing, split, and tuning protocol.",
                "Report absolute error, squared error, explained-variance, robustness, and runtime metrics for every regressor.",
                "Evaluate whether model ranking is stable across sample-size and tuning regimes.",
            ],
        )
        plan["datasets"] = _append_unique_strings(
            plan.get("datasets"),
            ["Synthetic tabular regression benchmark"],
        )
        plan["baselines"] = [
            {"name": "LinearRegression", "description": "ordinary least-squares linear reference model"},
            {"name": "RidgeRegression", "description": "L2-regularized linear model"},
            {"name": "LassoRegression", "description": "L1-regularized sparse linear model"},
        ]
        plan["proposed_methods"] = [
            {"name": "ElasticNetRegression", "description": "combined L1/L2 regularized linear model"},
            {"name": "KNearestNeighborsRegressor", "description": "instance-based nonlinear regressor"},
            {"name": "SupportVectorRegressionRBF", "description": "kernel support-vector regressor"},
            {"name": "RandomForestRegressor", "description": "bagged-tree ensemble regressor"},
            {"name": "GradientBoostingRegressor", "description": "boosted-tree ensemble regressor"},
        ]
        plan["model_definitions"] = _append_named_dicts(
            [],
            _REGRESSION_MODEL_DEFINITIONS,
        )
        plan["metric_definitions"] = _normalize_metric_definitions(
            plan.get("metric_definitions"),
            plan.get("metrics"),
            config,
        )
        _append_metric_definitions(plan, _CONTINUOUS_PREDICTION_METRICS)
        _append_metric_definitions(plan, _REGRESSION_EXTRA_METRICS)
        plan["metrics"] = [
            metric["name"]
            for metric in plan["metric_definitions"]
            if isinstance(metric, dict) and metric.get("name")
        ]
        plan["tuning_parameters"] = {
            "RidgeRegression": {"alpha": [0.01, 0.1, 1.0, 10.0, 100.0]},
            "LassoRegression": {"alpha": [0.001, 0.01, 0.1, 1.0]},
            "ElasticNetRegression": {"alpha": [0.001, 0.01, 0.1, 1.0], "l1_ratio": [0.2, 0.5, 0.8]},
            "KNearestNeighborsRegressor": {"n_neighbors": [3, 5, 11, 21], "weights": ["uniform", "distance"]},
            "SupportVectorRegressionRBF": {"C": [0.1, 1.0, 10.0], "epsilon": [0.01, 0.1], "gamma": ["scale", 0.01, 0.1]},
            "RandomForestRegressor": {"n_estimators": [100, 300], "max_depth": [None, 4, 8]},
            "GradientBoostingRegressor": {"n_estimators": [100, 300], "learning_rate": [0.03, 0.1], "max_depth": [2, 3]},
        }
        plan["required_figures"] = _append_unique_strings(
            plan.get("required_figures"),
            [
                "regression_error_metric_comparison",
                "predicted_vs_observed",
                "residual_plot",
                "metric_by_sample_size",
                "runtime_comparison",
            ],
        )
        plan["required_tables"] = _append_unique_strings(
            plan.get("required_tables"),
            [
                "regression_model_metric_comparison_table",
                "sample_size_ablation_table",
                "tuning_ablation_table",
                "model_and_tuning_summary_table",
            ],
        )
        plan["code_generation_requirements"] = _append_unique_strings(
            plan.get("code_generation_requirements"),
            [
                "Implement exactly the named regressors; do not replace them with generic protocol labels.",
                "Use one shared preprocessing, split, and evaluation pipeline for all regressors.",
                "Write one results.json cell per regressor x sample_size x tuning_setting with all regression metrics.",
            ],
        )
    if _looks_like_ambiguous_tabular_predictive_task(config, plan) and _needs_predictive_model_suite(plan):
        plan["domain_id"] = "ml_tabular"
        plan["experiment_type"] = "target_resolved_tabular_predictive_comparison"
        intent = dict(plan.get("input_intent") or _detect_input_intent(config, plan))
        intent["target_resolution_required"] = True
        plan["input_intent"] = intent
        plan["objectives"] = _append_unique_strings(
            plan.get("objectives"),
            [
                "Resolve whether the predictive target is categorical or continuous before selecting the executable model suite.",
                "If the target is categorical, compare the tabular classification candidate suite under a shared protocol.",
                "If the target is continuous, compare the tabular regression candidate suite under a shared protocol.",
            ],
        )
        plan["datasets"] = _append_unique_strings(
            plan.get("datasets"),
            ["Synthetic tabular predictive benchmark with target type resolved at runtime"],
        )
        classification_candidates = [
            "LogisticRegression",
            "GaussianNaiveBayes",
            "KNearestNeighbors",
            "SupportVectorMachineRBF",
            "RandomForestClassifier",
            "GradientBoostingClassifier",
        ]
        regression_candidates = [
            "LinearRegression",
            "RidgeRegression",
            "LassoRegression",
            "ElasticNetRegression",
            "KNearestNeighborsRegressor",
            "SupportVectorRegressionRBF",
            "RandomForestRegressor",
            "GradientBoostingRegressor",
        ]
        plan["candidate_model_suites"] = {
            "classification": classification_candidates,
            "regression": regression_candidates,
        }
        plan["target_resolution_protocol"] = {
            "required": True,
            "rules": [
                "If the target has two or finite unordered labels, select classification.",
                "If the target is numeric/continuous or ordered magnitude, select regression.",
                "If synthetic data must be generated because no application data is provided, infer target type from the research topic; if still ambiguous, generate both a classification and a regression benchmark and label them separately.",
            ],
            "reporting": "Write selected_target_type and skipped_incompatible_suite to results.json metadata.",
        }
        plan["baselines"] = [
            {"name": "LogisticRegression", "description": "classification reference if target is categorical"},
            {"name": "LinearRegression", "description": "regression reference if target is continuous"},
        ]
        plan["proposed_methods"] = [
            {"name": "RandomForestClassifier", "description": "classification tree ensemble candidate"},
            {"name": "GradientBoostingClassifier", "description": "classification boosted-tree candidate"},
            {"name": "RandomForestRegressor", "description": "regression tree ensemble candidate"},
            {"name": "GradientBoostingRegressor", "description": "regression boosted-tree candidate"},
        ]
        plan["model_definitions"] = _append_named_dicts(
            [],
            [
                item
                for item in (_CLASSICAL_CLASSIFIER_DEFINITIONS + _REGRESSION_MODEL_DEFINITIONS)
                if item["name"] in set(classification_candidates + regression_candidates)
            ],
        )
        plan["metric_definitions"] = _normalize_metric_definitions(
            plan.get("metric_definitions"),
            plan.get("metrics"),
            config,
        )
        _append_metric_definitions(plan, _CATEGORICAL_PREDICTION_METRICS)
        _append_metric_definitions(plan, _CLASSICAL_CLASSIFICATION_METRICS)
        _append_metric_definitions(plan, _CONTINUOUS_PREDICTION_METRICS)
        _append_metric_definitions(plan, _REGRESSION_EXTRA_METRICS)
        plan["metrics"] = [
            metric["name"]
            for metric in plan["metric_definitions"]
            if isinstance(metric, dict) and metric.get("name")
        ]
        plan["code_generation_requirements"] = _append_unique_strings(
            plan.get("code_generation_requirements"),
            [
                "Resolve target type before running models; execute classification candidates only for categorical targets and regression candidates only for continuous targets.",
                "Record selected_target_type, target_resolution_reason, and skipped_incompatible_suite in results.json metadata.",
                "If the topic remains ambiguous and synthetic data is required, generate one categorical and one continuous benchmark track and label all cells by target_type.",
                "Do not replace candidate model names with generic protocol labels.",
            ],
        )
    model_definitions = plan.get("model_definitions")
    if not isinstance(model_definitions, list):
        model_definitions = []
    existing_model_names = {
        str(item.get("name")).casefold()
        for item in model_definitions
        if isinstance(item, dict) and item.get("name")
    }
    model_name_candidates: list[str] = []
    for model_key in ("proposed_methods", "baselines"):
        value = plan.get(model_key)
        for item in _normalize_named_sequence(value):
            name = _item_name(item)
            if name:
                model_name_candidates.append(name)
    for model_name in model_name_candidates:
        if model_name.casefold() in existing_model_names:
            continue
        model_definitions.append({
            "name": model_name,
            "mathematical_form": "state the model equation, link/decision rule, and all symbols",
            "assumptions": [
                "state distributional or error assumptions when applicable",
                "state independence, feature, calibration, and identifiability assumptions when applicable",
            ],
            "objective_or_loss": "state the optimization objective, likelihood, risk, or fitting criterion",
            "hyperparameters_and_tuning": "state default values, tuning grid/search space, and selected values",
            "interpretation": "state how fitted parameters, scores, predictions, or selections should be interpreted",
        })
        existing_model_names.add(model_name.casefold())
    plan["model_definitions"] = model_definitions
    plan["ablation_requirements"] = _append_unique_strings(
        plan.get("ablation_requirements"),
        [
            "Sample-size ablation: evaluate at least small, medium, and full-data regimes with explicit sample_size values greater than 200, or justify why the source data makes this impossible.",
            "Tuning ablation: compare default/untuned settings with at least two tuned hyperparameter configurations or search budgets.",
            "Simulation ablation: for simulation studies, vary at least one simulation setup parameter such as noise, effect size, dimensionality, missingness, class balance, or regime difficulty when applicable.",
            "Application-data ablation: for application studies, vary model tuning/search settings and scientifically meaningful preprocessing/model variants rather than cosmetic labels.",
            "Avoid cosmetic ablations; every ablation must change data scale, tuning, model component, or preprocessing in a scientifically interpretable way.",
        ],
    )
    ablations = plan.get("ablations")
    if not isinstance(ablations, list):
        ablations = []
    existing_ablation_names = {
        str(item.get("name")).casefold()
        for item in ablations
        if isinstance(item, dict) and item.get("name")
    }
    ablation_entries = [
        {
            "name": "sample_size_ablation",
            "factor": "training sample size",
            "levels": [dict(regime) for regime in plan["sample_size_regimes"]],
            "purpose": "measure whether conclusions are stable across data regimes",
        },
        {
            "name": "tuning_ablation",
            "factor": "hyperparameter tuning or search budget",
            "levels": ["default_or_untuned", "moderate_tuning", "stronger_tuning"],
            "purpose": "separate algorithmic benefit from tuning-budget benefit",
        },
    ]
    if study_mode in {"simulation", "both"}:
        ablation_entries.append({
            "name": "simulation_setup_ablation",
            "factor": "simulation setup parameter",
            "levels": ["low_difficulty_or_noise", "medium_difficulty_or_noise", "high_difficulty_or_noise"],
            "purpose": "test whether conclusions persist across simulated data-generating regimes",
        })
    for ablation_entry in ablation_entries:
        if ablation_entry["name"].casefold() not in existing_ablation_names:
            ablations.append(ablation_entry)
            existing_ablation_names.add(ablation_entry["name"].casefold())
    for ablation in ablations:
        if not isinstance(ablation, dict):
            continue
        if str(ablation.get("name", "")).casefold() == "sample_size_ablation":
            ablation["factor"] = "training sample size"
            ablation["levels"] = [dict(regime) for regime in plan["sample_size_regimes"]]
    plan["ablations"] = ablations
    plan["metric_definitions"] = _normalize_metric_definitions(
        plan.get("metric_definitions"),
        plan.get("metrics"),
        config,
    )
    if _looks_like_predictive_continuous_task(config, plan):
        _append_metric_definitions(plan, _CONTINUOUS_PREDICTION_METRICS)
        required_figures = plan.get("required_figures")
        if not isinstance(required_figures, list):
            required_figures = []
        for figure_name in [
            "feature_inclusion_probability",
            "predicted_vs_observed",
            "residual_plot",
            "residual_distribution",
            "continuous_metric_comparison",
        ]:
            if figure_name not in required_figures:
                required_figures.append(figure_name)
        plan["required_figures"] = required_figures
        plan["prediction_artifacts"] = {
            "required": True,
            "files": [
                "predictions.json with y_true, y_pred, condition, fold, and optional uncertainty fields",
                "prediction_residuals.json with observed, predicted, residual, condition, and fold",
                "feature_inclusion_probabilities.json with variable and probability columns when model features are interpretable",
                "kfold_metrics.json with per-fold MAE, MSE, RMSE, and R2 values for 80/20 train/test cross-validation",
            ],
        }
    if _looks_like_predictive_categorical_task(config, plan):
        _append_metric_definitions(plan, _CATEGORICAL_PREDICTION_METRICS)
        required_figures = plan.get("required_figures")
        if not isinstance(required_figures, list):
            required_figures = []
        for figure_name in [
            "feature_inclusion_probability",
            "confusion_matrix",
            "roc_curve",
            "accuracy_comparison",
            "f1_comparison",
            "precision_comparison",
            "recall_comparison",
            "roc_auc_comparison",
            "kfold_80_20_cv_boxplot",
        ]:
            if figure_name not in required_figures:
                required_figures.append(figure_name)
        plan["required_figures"] = required_figures
        plan["prediction_artifacts"] = {
            "required": True,
            "files": [
                "predictions.json with y_true, y_pred, y_score/probabilities, condition, fold",
                "feature_inclusion_probabilities.json with variable and probability columns",
                "kfold_metrics.json with per-fold values for 80/20 train/test cross-validation",
            ],
        }
    if "evaluation_protocol" not in plan:
        plan["evaluation_protocol"] = {
            "benchmark_strategy": "prefer multiple datasets and sample-size regimes before adding many repeated seeds",
            "reporting": [
                "per-dataset results",
                "per-sample-size results when applicable",
                "cross-dataset comparison",
                "implementation and preprocessing details",
            ],
        }
    return _enforce_universal_experiment_contract(plan, config)


def _execute_experiment_design(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    hypotheses = _read_prior_artifact(run_dir, "hypotheses.md") or ""
    preamble = _build_context_preamble(
        config, run_dir, include_goal=True, include_hypotheses=True
    )
    study_mode = str(getattr(config.experiment, "study_mode", "simulation") or "simulation").strip().lower()
    application_data = getattr(config.experiment, "application_data", {}) if hasattr(config.experiment, "application_data") else {}
    app_file_count = len(application_data.get("files", []) or []) if isinstance(application_data, dict) else 0
    app_link_count = len(application_data.get("links", []) or []) if isinstance(application_data, dict) else 0
    study_mode_guidance = [
        f"Experiment study mode: {study_mode}.",
    ]
    if study_mode == "simulation":
        study_mode_guidance.append(
            "This run is simulation-study-only. Design programmatic/synthetic data generation, parameter sweeps, and evaluation of the proposed method on simulated data only. Use explicit simulation and sample-size ablation regimes with sample_size > 200 whenever data can be generated. Report simulation sample sizes, train/validation/test sizes when predictive models are simulated, and ablations over sample size, simulation setup parameters, and model tuning/search settings. Do not require uploaded application datasets or application-data results sections."
        )
    elif study_mode == "application":
        study_mode_guidance.append(
            "This run is application-data-only. Design the experiment around the uploaded files/links, include missing-value handling, preprocessing, dataset-specific train/validation/test splits, application sample size, training size, validation size when used, test size, and per-dataset result reporting. Ablation must focus on model tuning/search settings plus scientifically meaningful preprocessing/model variants. Do not include a simulation-study section unless it is needed as a validation sanity check."
        )
    else:
        study_mode_guidance.append(
            "This run is BOTH simulation and application. Design separate simulation-study and application-data tracks, with distinct datasets, sample sizes, train/validation/test sizes, tables, figures, runtime analysis, and interpretation for each track. Simulation ablations must vary sample sizes greater than 200, simulation setup parameters, and model tuning; application ablations must focus on model tuning/search settings and meaningful preprocessing/model variants."
        )
    if app_file_count or app_link_count:
        study_mode_guidance.append(
            f"Uploaded application data summary: {app_file_count} file(s), {app_link_count} link(s)."
        )
    preamble = f"{preamble}\n\n{' '.join(study_mode_guidance)}"
    plan: dict[str, Any] | None = None

    # â”€â”€ Domain detection â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    # Detect the research domain early so we can adapt experiment design
    # and code generation. For ML domains, existing behavior is unchanged.
    _domain_profile = None
    try:
        from researchclaw.domains.detector import detect_domain as _detect_domain_adv
        _domain_profile = _detect_domain_adv(
            topic=config.research.topic,
            hypotheses=hypotheses,
        )
        logger.info(
            "Domain detected: %s (%s)",
            _domain_profile.display_name,
            _domain_profile.domain_id,
        )
        # Persist domain profile for Stage 10
        import json as _json_dd
        (stage_dir / "domain_profile.json").write_text(
            _json_dd.dumps({
                "domain_id": _domain_profile.domain_id,
                "display_name": _domain_profile.display_name,
                "experiment_paradigm": _domain_profile.experiment_paradigm,
                "core_libraries": _domain_profile.core_libraries,
                "gpu_required": _domain_profile.gpu_required,
            }, indent=2),
            encoding="utf-8",
        )
    except Exception:  # noqa: BLE001
        logger.debug("Domain detection unavailable", exc_info=True)
    if llm is not None:
        _pm = prompts or PromptManager()
        # Pass dataset_guidance block for experiment design
        try:
            _dg_block = _pm.block("dataset_guidance")
        except (KeyError, Exception):  # noqa: BLE001
            _dg_block = ""
        # I-08: Inject RL step guidance for RL topics
        _rl_kws = ("reinforcement learning", "ppo", "sac", "td3", "ddpg",
                    "dqn", "mujoco", "continuous control", "actor-critic",
                    "policy gradient", "exploration bonus")
        _is_rl_topic = any(kw in config.research.topic.lower() for kw in _rl_kws)
        _time_budget_unlimited = config.experiment.time_budget_sec <= 0
        if _is_rl_topic:
            try:
                _dg_block += _pm.block("rl_step_guidance")
            except Exception:  # noqa: BLE001
                pass
            # Improvement G: For RL with short budget, constrain to classic control
            if not _time_budget_unlimited and config.experiment.time_budget_sec <= 3600:
                _dg_block += (
                    "\n\n## RL TIME CONSTRAINT (MANDATORY):\n"
                    f"Your time budget is {config.experiment.time_budget_sec}s (â‰¤ 3600s).\n"
                    "You MUST use ONLY classic control environments: "
                    "CartPole-v1, Pendulum-v1, MountainCar-v0, Acrobot-v1, LunarLander-v3.\n"
                    "Do NOT use MuJoCo (HalfCheetah, Hopper, Walker2d, Ant, Humanoid) â€” "
                    "they require >5000s for meaningful training.\n"
                )
            if not _time_budget_unlimited and config.experiment.time_budget_sec <= 1800:
                _dg_block += (
                    "Time budget â‰¤ 1800s: use ONLY CartPole-v1 or Pendulum-v1 "
                    "(the simplest environments).\n"
                )
        # F-01: Inject framework docs for experiment design
        try:
            from researchclaw.data import detect_frameworks, load_framework_docs
            _fw_ids = detect_frameworks(config.research.topic, hypotheses)
            if _fw_ids:
                _fw_docs = load_framework_docs(_fw_ids, max_chars=4000)
                if _fw_docs:
                    _dg_block += _fw_docs
        except Exception:  # noqa: BLE001
            pass
        # Improvement A: Compute hardware profile + per-condition budget
        _hw_profile_str = (
            "- GPU: NVIDIA RTX 6000 Ada (49140 MB VRAM)\n"
            "- GPU count: 1\n"
            "- CPU: shared server"
        )
        _time_budget_prompt = (
            "unlimited"
            if _time_budget_unlimited
            else str(config.experiment.time_budget_sec)
        )
        _per_condition_sec = (
            "unbounded"
            if _time_budget_unlimited
            else str(int(config.experiment.time_budget_sec * 0.7 / 6))
        )
        _tier1 = "CIFAR-10, CIFAR-100, MNIST, FashionMNIST, STL-10, SVHN"

        _overlay = _get_evolution_overlay(run_dir, "experiment_design")
        sp = _pm.for_stage(
            "experiment_design",
            evolution_overlay=_overlay,
            preamble=preamble,
            hypotheses=hypotheses,
            dataset_guidance=_dg_block,
            time_budget_sec=_time_budget_prompt,
            metric_key=config.experiment.metric_key,
            metric_direction=config.experiment.metric_direction,
            hardware_profile=_hw_profile_str,
            per_condition_budget_sec=_per_condition_sec,
            available_tier1_datasets=_tier1,
        )
        resp = _chat_with_prompt(
            llm,
            sp.system,
            sp.user,
            json_mode=sp.json_mode,
            max_tokens=sp.max_tokens,
        )
        raw_yaml = _extract_yaml_block(resp.content)
        try:
            parsed = yaml.safe_load(raw_yaml)
        except yaml.YAMLError:
            parsed = None
        # Fallback: reasoning models sometimes emit the YAML without fences
        # or wrapped in prose. Try parsing the whole response as YAML.
        if not isinstance(parsed, dict):
            try:
                parsed = yaml.safe_load(resp.content)
            except yaml.YAMLError:
                pass
        # Last fallback: try to find any YAML-like dict in the response
        if not isinstance(parsed, dict):
            import re as _re_yaml

            # Look for lines starting with known keys
            _yaml_lines = []
            _capturing = False
            for line in resp.content.splitlines():
                if _re_yaml.match(
                    r"^(baselines|proposed_methods|ablations|datasets|"
                    r"metrics|objectives|risks|compute_budget)\s*:",
                    line,
                ):
                    _capturing = True
                if _capturing:
                    if line.strip() == "" or line.startswith("```"):
                        continue
                    if line.startswith("#") or line.startswith("**"):
                        continue
                    _yaml_lines.append(line)
            if _yaml_lines:
                try:
                    parsed = yaml.safe_load("\n".join(_yaml_lines))
                except yaml.YAMLError:
                    pass
        if isinstance(parsed, dict):
            plan = parsed
        else:
            logger.warning(
                "Stage 09: LLM response could not be parsed as YAML "
                "(len=%d, first 200 chars: %s). Content extraction method "
                "returned: %s",
                len(resp.content),
                resp.content[:200],
                raw_yaml[:200] if raw_yaml else "<empty>",
            )
            # BUG-12: Retry with a stricter, shorter prompt
            if llm is not None:
                logger.info("Stage 09: Retrying with strict YAML-only prompt...")
                _retry_prompt = (
                    "Output ONLY valid YAML. No prose, no markdown fences, no explanation.\n"
                    f"Topic: {config.research.topic}\n"
                    "Required keys: baselines, proposed_methods, ablations, "
                    "datasets, dataset_details, sample_size_regimes, preprocessing, metrics, metric_definitions, "
                    "model_definitions, simulation_factors, tuning_parameters, canonical_results_schema, experiment_contract, "
                    "required_tables, presentation_requirements, ablation_requirements, study_mode_reporting_requirements, objectives, risks, compute_budget.\n"
                    "All keys except dataset_details, model_definitions, metric_definitions, canonical_results_schema, and experiment_contract map to lists of strings or simple scalars. "
                    "dataset_details must include sample_size, training_size, validation_size if used, test_size, feature_count/input_dim, target, split, preprocessing, and rationale. "
                    "sample_size_regimes must list explicit numeric sample_size values greater than 200 for simulation/generated-data regimes when feasible. "
                    "metric_definitions must be a list of dictionaries with: name, role, direction, units, formula, interpretation, literature_basis, citation_keys, is_novel, novelty_justification, proof_or_validation. "
                    "experiment_contract must require at least 2 comparable conditions, at least 3 sample-size/regime levels, at least 3 metrics, and comparative tables/figures."
                )
                _retry_resp = _chat_with_prompt(
                    llm,
                    "You output ONLY valid YAML. Nothing else.",
                    _retry_prompt,
                    max_tokens=4096,
                )
                try:
                    _retry_parsed = yaml.safe_load(_retry_resp.content)
                    if isinstance(_retry_parsed, dict):
                        plan = _retry_parsed
                        logger.info("Stage 09: Strict YAML retry succeeded.")
                except yaml.YAMLError:
                    pass

    # BUG-12: Fallback 4 â€” extract method/baseline names from Stage 8 hypotheses
    if plan is None:
        _hyp_text = _read_prior_artifact(run_dir, "hypotheses.md") or ""
        if _hyp_text:
            import re as _re_hyp
            # Extract method-like names from hypothesis text
            _method_candidates = _re_hyp.findall(
                r"(?:proposed|our|novel|new)\s+(?:method|approach|algorithm|framework|model)[:\s]+[\"']?([A-Za-z][\w-]+)",
                _hyp_text, _re_hyp.IGNORECASE,
            )
            _baseline_candidates = _re_hyp.findall(
                r"(?:baseline|compare|existing|standard|traditional)\s+(?:method|approach|model)?[:\s]+[\"']?([A-Za-z][\w-]+)",
                _hyp_text, _re_hyp.IGNORECASE,
            )
            if _method_candidates or _baseline_candidates:
                logger.info(
                    "Stage 09: Extracted names from hypotheses: methods=%s, baselines=%s",
                    _method_candidates[:3], _baseline_candidates[:3],
                )
                plan = {
                    "topic": config.research.topic,
                    "generated": _utcnow_iso(),
                    "objectives": ["Evaluate hypotheses with controlled experiments"],
                    "datasets": ["primary_dataset"],
                    "baselines": _baseline_candidates[:3] or ["baseline_1", "baseline_2"],
                    "proposed_methods": _method_candidates[:3] or ["proposed_method"],
                    "ablations": ["without_key_component", "simplified_version"],
                    "metrics": [config.experiment.metric_key, "secondary_metric"],
                    "risks": ["validity threats", "confounding variables"],
                    "compute_budget": {"max_gpu": 1, "max_hours": 4},
                }

    if plan is None:
        # BUG-12: Use domain-aware names instead of fully generic placeholders
        _topic_prefix = config.research.topic.split()[0] if config.research.topic else "method"
        logger.warning(
            "Stage 09: LLM failed to produce valid experiment plan YAML. "
            "Using topic-derived fallback."
        )
        plan = {
            "topic": config.research.topic,
            "generated": _utcnow_iso(),
            "objectives": ["Evaluate hypotheses with controlled experiments"],
            "datasets": ["primary_dataset", "secondary_dataset"],
            "baselines": [f"{_topic_prefix}_baseline_1", f"{_topic_prefix}_baseline_2"],
            "proposed_methods": [f"{_topic_prefix}_proposed", f"{_topic_prefix}_variant"],
            "ablations": ["without_key_component", "simplified_version"],
            "metrics": [config.experiment.metric_key, "secondary_metric"],
            "risks": ["validity threats", "confounding variables"],
            "compute_budget": {"max_gpu": 1, "max_hours": 4},
        }
    # â”€â”€ BA: BenchmarkAgent â€” intelligent dataset/baseline selection â”€â”€â”€â”€â”€â”€
    _benchmark_plan = None
    _benchmark_dataset_names: list[str] = []
    # BUG-40: Skip BenchmarkAgent for non-ML domains â€” it has no relevant
    # benchmarks for physics/chemistry/mathematics/etc. and would inject
    # wrong datasets (e.g., CIFAR-10 for PDE topics).
    _ba_domain_profile = _domain_profile
    if _ba_domain_profile is None:
        try:
            from researchclaw.domains.detector import detect_domain as _detect_domain_adv
            _ba_domain_profile = _detect_domain_adv(
                topic=config.research.topic,
                hypotheses=hypotheses,
            )
        except Exception:  # noqa: BLE001
            logger.debug("BenchmarkAgent domain detection unavailable", exc_info=True)
    _ba_domain_id = (
        _ba_domain_profile.domain_id
        if _ba_domain_profile is not None
        else "generic"
    )
    _ba_domain_ok = _ba_domain_id.startswith("ml_")
    if not _ba_domain_ok:
        logger.info(
            "BenchmarkAgent skipped: domain profile '%s' is not an ML profile (topic: %s)",
            _ba_domain_id, config.research.topic[:80],
        )
    if (
        _ba_domain_ok
        and config.experiment.benchmark_agent.enabled
        and config.experiment.mode in ("sandbox", "docker")
        and llm is not None
    ):
        try:
            from researchclaw.agents.benchmark_agent import BenchmarkOrchestrator
            from researchclaw.agents.benchmark_agent.orchestrator import (
                BenchmarkAgentConfig as _BACfg,
            )

            _ba_cfg_raw = config.experiment.benchmark_agent
            _ba_cfg = _BACfg(
                enabled=_ba_cfg_raw.enabled,
                enable_hf_search=_ba_cfg_raw.enable_hf_search,
                max_hf_results=_ba_cfg_raw.max_hf_results,
                enable_web_search=_ba_cfg_raw.enable_web_search,
                max_web_results=_ba_cfg_raw.max_web_results,
                web_search_min_local=_ba_cfg_raw.web_search_min_local,
                tier_limit=_ba_cfg_raw.tier_limit,
                min_benchmarks=_ba_cfg_raw.min_benchmarks,
                min_baselines=_ba_cfg_raw.min_baselines,
                prefer_cached=_ba_cfg_raw.prefer_cached,
                max_iterations=_ba_cfg_raw.max_iterations,
            )

            _hw = _load_hardware_profile(run_dir)
            _ba = BenchmarkOrchestrator(
                llm,
                config=_ba_cfg,
                gpu_memory_mb=(
                    _hw.get("gpu_memory_mb", 49000) if _hw else 49000
                ),
                time_budget_sec=config.experiment.time_budget_sec,
                network_policy=(
                    config.experiment.docker.network_policy
                    if config.experiment.mode == "docker"
                    else "full"
                ),
                stage_dir=stage_dir / "benchmark_agent",
            )
            _benchmark_plan = _ba.orchestrate({
                "topic": config.research.topic,
                "hypothesis": hypotheses,
                "experiment_plan": plan.get("objectives", "") if isinstance(plan, dict) else "",
            })

            # Inject BenchmarkAgent selections into experiment plan
            if isinstance(plan, dict) and _benchmark_plan.selected_benchmarks:
                _benchmark_dataset_names = [
                    b.get("name", "Unknown") for b in _benchmark_plan.selected_benchmarks
                ]
                plan["datasets"] = [
                    b.get("name", "Unknown") for b in _benchmark_plan.selected_benchmarks
                ]
                # Normalize existing baselines to list of strings
                # BUG-35: LLM may emit baselines as dict, list of dicts,
                # or list of strings â€” normalize all to list[str].
                _baselines_from_plan = plan.get("baselines", [])
                if isinstance(_baselines_from_plan, dict):
                    _baselines_from_plan = list(_baselines_from_plan.keys())
                elif isinstance(_baselines_from_plan, list):
                    _baselines_from_plan = [
                        item["name"] if isinstance(item, dict) else str(item)
                        for item in _baselines_from_plan
                    ]
                else:
                    _baselines_from_plan = []
                plan["baselines"] = [
                    bl.get("name", "Unknown") for bl in _benchmark_plan.selected_baselines
                ] + _baselines_from_plan
                # Deduplicate baselines
                plan["baselines"] = list(dict.fromkeys(plan["baselines"]))

            logger.info(
                "BenchmarkAgent: %d benchmarks, %d baselines selected (%d LLM calls, %.1fs)",
                len(_benchmark_plan.selected_benchmarks),
                len(_benchmark_plan.selected_baselines),
                _benchmark_plan.total_llm_calls,
                _benchmark_plan.elapsed_sec,
            )
        except Exception as _ba_exc:
            logger.warning("BenchmarkAgent failed (non-fatal): %s", _ba_exc)

    if isinstance(plan, dict):
        plan = _enrich_experiment_plan(plan, config, _benchmark_dataset_names)

    # Save benchmark plan for code_generation stage
    if _benchmark_plan is not None:
        try:
            (stage_dir / "benchmark_plan.json").write_text(
                json.dumps(_benchmark_plan.to_dict(), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:  # noqa: BLE001
            pass

    plan.setdefault("topic", config.research.topic)

    # BUG-R41-09: Enforce condition count limit based on time budget.
    # Too many conditions (30+) guarantee timeouts and wasted compute.
    _time_budget = getattr(
        getattr(config, "experiment", None), "time_budget_sec", 3600
    )
    _unlimited_time_budget = _time_budget <= 0
    _max_conditions = 10**9 if _unlimited_time_budget else 8  # default for finite budgets <= 3600s
    if not _unlimited_time_budget and _time_budget > 3600:
        _max_conditions = 12
    if not _unlimited_time_budget and _time_budget > 7200:
        _max_conditions = 20

    _baselines = plan.get("baselines", [])
    if isinstance(_baselines, dict):
        _baselines = list(_baselines.values())
    _proposed = plan.get("proposed_methods", [])
    if isinstance(_proposed, dict):
        _proposed = list(_proposed.values())
    _ablations = plan.get("ablations", [])
    if isinstance(_ablations, dict):
        _ablations = list(_ablations.values())
    _total = len(_baselines) + len(_proposed) + len(_ablations)

    if _total > _max_conditions:
        logger.warning(
            "Stage 9: Plan has %d conditions (limit %d for %ds budget). "
            "Trimming to fit.",
            _total, _max_conditions, _time_budget,
        )
        if _looks_like_tabular_classification_task(config, plan) or _looks_like_tabular_regression_task(config, plan):
            _model_total = len(_baselines) + len(_proposed)
            if _model_total < _max_conditions:
                _baseline_budget = len(_baselines)
                _proposed_count = len(_proposed)
                _ablation_budget = max(0, _max_conditions - _model_total)
            else:
                _baseline_budget = max(1, min(len(_baselines), _max_conditions // 2))
                _proposed_count = max(1, _max_conditions - _baseline_budget)
                _ablation_budget = 0
            logger.info(
                "Stage 9: Predictive model trim keeps model suite first "
                "(baselines=%d, proposed=%d, ablations=%d).",
                _baseline_budget,
                _proposed_count,
                _ablation_budget,
            )
        else:
            # Keep all proposed methods (up to max), trim baselines and ablations
            _proposed_count = min(len(_proposed), max(1, _max_conditions - 4))
            _remaining = max(0, _max_conditions - _proposed_count)
            _baseline_budget = max(1, _remaining // 2)
            _ablation_budget = max(0, _remaining - _baseline_budget)
        if len(_proposed) > _proposed_count:
            plan["proposed_methods"] = _proposed[:_proposed_count]
            logger.info(
                "Stage 9: Trimmed proposed methods %d â†’ %d",
                len(_proposed), _proposed_count,
            )

        if len(_baselines) > _baseline_budget:
            plan["baselines"] = _baselines[:_baseline_budget]
            logger.info(
                "Stage 9: Trimmed baselines %d â†’ %d",
                len(_baselines), _baseline_budget,
            )
        if len(_ablations) > _ablation_budget:
            plan["ablations"] = _ablations[:_ablation_budget]
            logger.info(
                "Stage 9: Trimmed ablations %d â†’ %d",
                len(_ablations), _ablation_budget,
            )

    # --- HITL: Read human guidance if available ---
    guidance_file = stage_dir / "hitl_guidance.md"
    if guidance_file.exists():
        try:
            guidance = guidance_file.read_text(encoding="utf-8").strip()
            if guidance and llm is not None and isinstance(plan, dict):
                logger.info("Applying HITL guidance to experiment design")
                resp = llm.chat(
                    [{"role": "user", "content": (
                        f"The human researcher provided this guidance for "
                        f"the experiment design:\n\n{guidance}\n\n"
                        f"Current experiment plan:\n"
                        f"```yaml\n{yaml.dump(plan, default_flow_style=False)}\n```\n\n"
                        f"Update the YAML plan to incorporate the guidance. "
                        f"Return ONLY the updated YAML."
                    )}],
                    max_tokens=4096,
                )
                updated = _extract_yaml_block(resp.content)
                try:
                    parsed_update = yaml.safe_load(updated)
                    if isinstance(parsed_update, dict):
                        plan = parsed_update
                except yaml.YAMLError:
                    pass
        except Exception:
            logger.debug("HITL guidance application failed (non-blocking)")

    if isinstance(plan, dict):
        plan = _enforce_universal_experiment_contract(plan, config)

    # --- HITL: Baseline Navigator data persistence ---
    try:
        from researchclaw.hitl.workshops.baseline import BaselineNavigator, BaselineCandidate

        nav = BaselineNavigator(run_dir, llm_client=llm)
        if isinstance(plan, dict):
            baselines = plan.get("baselines", [])
            if isinstance(baselines, list):
                for b in baselines:
                    if isinstance(b, dict):
                        nav.baselines.append(BaselineCandidate(
                            name=b.get("name", str(b)),
                            description=b.get("description", ""),
                        ))
                    elif isinstance(b, str):
                        nav.baselines.append(BaselineCandidate(name=b))
            metrics = plan.get("metrics", [])
            if isinstance(metrics, list):
                nav.metrics = [str(m) for m in metrics]
        nav.save()
    except Exception:
        pass

    (stage_dir / "exp_plan.yaml").write_text(
        yaml.dump(plan, default_flow_style=False, allow_unicode=True),
        encoding="utf-8",
    )
    return StageResult(
        stage=Stage.EXPERIMENT_DESIGN,
        status=StageStatus.DONE,
        artifacts=("exp_plan.yaml",),
        evidence_refs=("stage-09/exp_plan.yaml",),
    )
