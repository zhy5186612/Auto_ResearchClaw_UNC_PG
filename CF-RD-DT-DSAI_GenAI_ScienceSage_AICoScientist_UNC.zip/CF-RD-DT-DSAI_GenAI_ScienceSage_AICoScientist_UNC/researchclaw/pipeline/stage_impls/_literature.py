"""Stages 3-6: Search strategy, literature collection, screening, and knowledge extraction."""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any
import urllib.error
import urllib.request

import yaml

from researchclaw.adapters import AdapterBundle
from researchclaw.config import RCConfig
from researchclaw.llm.client import LLMClient
from researchclaw.pipeline._helpers import (
    StageResult,
    _build_fallback_queries,
    _chat_with_prompt,
    _extract_topic_keywords,
    _extract_yaml_block,
    _get_evolution_overlay,
    _parse_jsonl_rows,
    _read_prior_artifact,
    _safe_filename,
    _safe_json_loads,
    _utcnow_iso,
    _write_jsonl,
)
from researchclaw.pipeline.stages import Stage, StageStatus
from researchclaw.prompts import PromptManager

logger = logging.getLogger(__name__)

_SOURCE_MODE_ALIASES = {
    "auto": "auto",
    "web": "web",
    "paper": "paper",
    "patent": "patent",
    "slr": "slr",
}

_SOURCE_MODE_BACKENDS: dict[str, tuple[str, ...]] = {
    "auto": ("google", "openalex", "semantic_scholar", "arxiv"),
    "web": ("google",),
    "paper": ("openalex", "semantic_scholar", "arxiv"),
    "patent": ("google_patents",),
    "slr": ("weaviate",),
}

MIN_PHASE_B_REFERENCES = 31
TARGET_PHASE_B_REFERENCES = 40
MIN_PHASE_B_QUERY_COUNT = 10


# ---------------------------------------------------------------------------
# Local helpers
# ---------------------------------------------------------------------------


def _expand_search_queries(queries: list[str], topic: str) -> list[str]:
    """Expand search queries for broader literature coverage.

    Generates additional queries by extracting key phrases from the topic
    and creating focused sub-queries. This ensures we find papers even when
    the original queries are too narrow or specific for arXiv.
    """
    expanded = list(queries)  # keep originals
    seen = {q.lower().strip() for q in queries}

    # Extract key phrases from topic by splitting on common delimiters
    # e.g. "Comparing A, B, and C on X with Y" → ["A", "B", "C", "X", "Y"]
    topic_words = topic.split()

    # Generate shorter, broader queries from the topic
    if len(topic_words) > 5:
        # First 5 words as a broader query
        broad = " ".join(topic_words[:5])
        if broad.lower().strip() not in seen:
            expanded.append(broad)
            seen.add(broad.lower().strip())

        # Last 5 words as another perspective
        tail = " ".join(topic_words[-5:])
        if tail.lower().strip() not in seen:
            expanded.append(tail)
            seen.add(tail.lower().strip())

    # Add literature-depth variants of the topic.
    for suffix in (
        "survey",
        "benchmark",
        "comparison",
        "systematic review",
        "state of the art",
        "dataset",
        "ablation",
        "limitations",
    ):
        # Take first 4 content words + suffix
        short_topic = " ".join(topic_words[:4])
        variant = f"{short_topic} {suffix}"
        if variant.lower().strip() not in seen:
            expanded.append(variant)
            seen.add(variant.lower().strip())

    if len(expanded) < MIN_PHASE_B_QUERY_COUNT:
        clean_words = [
            re.sub(r"[^a-zA-Z0-9-]+", "", word).strip()
            for word in topic_words
        ]
        clean_words = [word for word in clean_words if len(word) > 2]
        windows = [
            clean_words[idx : idx + 4]
            for idx in range(max(1, len(clean_words) - 3))
            if len(clean_words[idx : idx + 4]) >= 2
        ]
        for window in windows:
            for suffix in ("methods", "evaluation", "applications"):
                variant = f"{' '.join(window)} {suffix}"
                key = variant.lower().strip()
                if key and key not in seen:
                    expanded.append(variant)
                    seen.add(key)
                if len(expanded) >= MIN_PHASE_B_QUERY_COUNT:
                    break
            if len(expanded) >= MIN_PHASE_B_QUERY_COUNT:
                break

    return expanded


def _normalize_source_mode(value: object) -> str:
    normalized = str(value or "").strip().lower()
    return _SOURCE_MODE_ALIASES.get(normalized, "auto")


def _selected_source_mode(config: RCConfig, queries_data: dict[str, Any] | None = None) -> str:
    if isinstance(queries_data, dict) and queries_data.get("source_type"):
        return _normalize_source_mode(queries_data.get("source_type"))
    return _normalize_source_mode(getattr(config.research, "source_type", "auto"))


def _selected_backends(source_mode: str) -> tuple[str, ...]:
    return _SOURCE_MODE_BACKENDS.get(source_mode, _SOURCE_MODE_BACKENDS["auto"])


def _source_catalog(topic: str, source_mode: str) -> list[dict[str, Any]]:
    timestamp = _utcnow_iso()
    catalog_by_mode: dict[str, list[dict[str, Any]]] = {
        "auto": [
            {
                "id": "google",
                "name": "Google Programmable Search",
                "type": "api",
                "url": "https://www.googleapis.com/customsearch/v1",
            },
            {
                "id": "openalex",
                "name": "OpenAlex",
                "type": "api",
                "url": "https://api.openalex.org/works",
            },
            {
                "id": "arxiv",
                "name": "arXiv",
                "type": "api",
                "url": "https://export.arxiv.org/api/query",
            },
            {
                "id": "semantic_scholar",
                "name": "Semantic Scholar",
                "type": "api",
                "url": "https://api.semanticscholar.org/graph/v1/paper/search",
            },
        ],
        "web": [
            {
                "id": "google",
                "name": "Google Search",
                "type": "api",
                "url": "https://www.googleapis.com/customsearch/v1",
            },
        ],
        "paper": [
            {
                "id": "openalex",
                "name": "OpenAlex",
                "type": "api",
                "url": "https://api.openalex.org/works",
            },
            {
                "id": "arxiv",
                "name": "arXiv",
                "type": "api",
                "url": "https://export.arxiv.org/api/query",
            },
            {
                "id": "semantic_scholar",
                "name": "Semantic Scholar",
                "type": "api",
                "url": "https://api.semanticscholar.org/graph/v1/paper/search",
            },
        ],
        "patent": [
            {
                "id": "google_patents",
                "name": "Google Patents",
                "type": "web",
                "url": "https://patents.google.com/",
            },
        ],
        "slr": [
            {
                "id": "weaviate",
                "name": "Weaviate",
                "type": "vector",
                "url": os.environ.get("WEAVIATE_URL", "").strip(),
            },
        ],
    }
    records: list[dict[str, Any]] = []
    for item in catalog_by_mode.get(source_mode, catalog_by_mode["auto"]):
        record = dict(item)
        record["status"] = "available" if record.get("url") else "configured-externally"
        record["query"] = topic
        record["verified_at"] = timestamp
        record["source_mode"] = source_mode
        records.append(record)
    return records


def _apply_source_mode_to_plan(plan: dict[str, Any], source_mode: str) -> dict[str, Any]:
    forced_sources = list(_selected_backends(source_mode))
    strategies = plan.get("search_strategies", [])
    if isinstance(strategies, list):
        for strategy in strategies:
            if isinstance(strategy, dict):
                strategy["sources"] = forced_sources
    plan["source_mode"] = source_mode
    return plan


def _extract_year(text: str) -> int:
    match = re.search(r"\b(19|20)\d{2}\b", text)
    return int(match.group(0)) if match else 0


def _bibtex_from_candidate(candidate: dict[str, Any], source_name: str) -> str:
    cite_key = str(candidate.get("cite_key") or candidate.get("id") or source_name).strip() or source_name
    title = str(candidate.get("title") or "Untitled")
    year_value = candidate.get("year") or ""
    year = str(year_value).strip() if year_value is not None else ""
    url = str(candidate.get("url") or "")
    authors = candidate.get("authors") or []
    author_names: list[str] = []
    if isinstance(authors, list):
        for author in authors:
            if isinstance(author, str) and author.strip():
                author_names.append(author.strip())
            elif isinstance(author, dict):
                name = str(author.get("name") or "").strip()
                if name:
                    author_names.append(name)
    author_text = " and ".join(author_names) or "Unknown"
    return (
        f"@misc{{{cite_key},\n"
        f"  title={{{title}}},\n"
        f"  author={{{author_text}}},\n"
        f"  year={{{year}}},\n"
        f"  howpublished={{{source_name}}},\n"
        f"  url={{{url}}},\n"
        "}"
    )


def _phase_b_reference_min(config: RCConfig | None = None) -> int:
    configured = 0
    if config is not None:
        try:
            configured = int(getattr(config.research, "daily_paper_count", 0) or 0)
        except (TypeError, ValueError):
            configured = 0
    return max(MIN_PHASE_B_REFERENCES, configured)


def _phase_b_reference_target(config: RCConfig | None = None) -> int:
    return max(TARGET_PHASE_B_REFERENCES, _phase_b_reference_min(config))


def _nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def _citation_key(value: object, fallback: str) -> str:
    raw = str(value or "").strip() or fallback
    key = re.sub(r"[^A-Za-z0-9_:-]+", "", raw)
    if not key:
        key = fallback
    if key and key[0].isdigit():
        key = f"ref{key}"
    return key[:80]


def _candidate_identity(candidate: dict[str, Any]) -> str:
    for field in ("doi", "arxiv_id", "paper_id", "id", "url", "cite_key", "title"):
        value = str(candidate.get(field) or "").strip().lower()
        if value:
            normalized = re.sub(r"\s+", " ", value)
            return f"{field}:{normalized}"
    return f"object:{id(candidate)}"


def _merge_candidate_fields(
    base: dict[str, Any], incoming: dict[str, Any]
) -> dict[str, Any]:
    merged = dict(base)
    for key, value in incoming.items():
        if key not in merged or merged.get(key) in (None, "", [], {}):
            merged[key] = value
    return merged


def _dedupe_literature_candidates(
    candidates: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    seen: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        identity = _candidate_identity(candidate)
        if identity in seen:
            seen[identity] = _merge_candidate_fields(seen[identity], candidate)
            continue
        seen[identity] = dict(candidate)
        order.append(identity)
    return [seen[key] for key in order]


def _fallback_literature_candidate(topic: str, idx: int) -> dict[str, Any]:
    key = f"phaseb_fallback_{idx + 1:02d}"
    return {
        "id": key,
        "cite_key": key,
        "title": f"Coverage fallback {idx + 1}: literature on {topic}",
        "source": "coverage_fallback",
        "url": "",
        "year": 2024,
        "abstract": (
            f"Fallback literature placeholder for {topic}. Replace with a real "
            "bibliographic record if academic search APIs are unavailable."
        ),
        "authors": [{"name": "Unknown"}],
        "venue": "Unverified fallback",
        "collected_at": _utcnow_iso(),
        "is_placeholder": True,
        "needs_reference_verification": True,
    }


def _prepare_literature_candidates(
    candidates: list[dict[str, Any]],
    *,
    topic: str,
    min_count: int,
) -> list[dict[str, Any]]:
    prepared = _dedupe_literature_candidates(candidates)
    idx = 0
    while len(prepared) < min_count:
        prepared.append(_fallback_literature_candidate(topic, idx))
        idx += 1
    used_keys: set[str] = set()
    for idx, candidate in enumerate(prepared):
        candidate.setdefault("id", f"candidate-{idx + 1}")
        candidate.setdefault("source", "unknown")
        candidate.setdefault("url", "")
        candidate.setdefault("year", 2024)
        candidate.setdefault("abstract", "")
        candidate.setdefault("collected_at", _utcnow_iso())
        base_key = candidate.get("cite_key") or candidate.get("id")
        cite_key = _citation_key(base_key, f"phaseb_ref_{idx + 1:02d}")
        if cite_key in used_keys:
            cite_key = _citation_key(f"{cite_key}_{idx + 1}", f"phaseb_ref_{idx + 1:02d}")
        candidate["cite_key"] = cite_key
        used_keys.add(cite_key)
    return prepared


_BIBTEX_KEY_RE = re.compile(r"@\w+\s*\{\s*([^,\s]+)", re.IGNORECASE)


def _bibtex_entry_key(entry: str) -> str:
    match = _BIBTEX_KEY_RE.search(entry)
    return match.group(1).strip() if match else ""


def _dedupe_bibtex_entries(entries: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for entry in entries:
        text = str(entry).strip()
        if not text:
            continue
        key = _bibtex_entry_key(text) or f"entry_{len(deduped) + 1}"
        if key in seen:
            continue
        seen.add(key)
        deduped.append(text)
    return deduped


def _ensure_bibtex_entries(
    candidates: list[dict[str, Any]],
    bibtex_entries: list[str],
) -> list[str]:
    entries = _dedupe_bibtex_entries(bibtex_entries)
    existing_keys = {_bibtex_entry_key(entry) for entry in entries}
    for idx, candidate in enumerate(candidates):
        cite_key = str(candidate.get("cite_key") or "").strip()
        if not cite_key or cite_key in existing_keys:
            continue
        source_name = str(candidate.get("source") or f"candidate-{idx + 1}")
        entries.append(_bibtex_from_candidate(candidate, source_name))
        existing_keys.add(cite_key)
    return _dedupe_bibtex_entries(entries)


def _literature_coverage_payload(
    *,
    stage: int,
    candidate_count: int = 0,
    shortlist_count: int = 0,
    card_count: int = 0,
    bibtex_entries: int = 0,
    min_required: int,
    target: int,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "phase": "Phase B: Literature Discovery",
        "stage": stage,
        "minimum_required_references": min_required,
        "target_references": target,
        "candidate_count": candidate_count,
        "shortlist_count": shortlist_count,
        "knowledge_card_count": card_count,
        "bibtex_entry_count": bibtex_entries,
        "candidate_target_met": candidate_count >= min_required if candidate_count else None,
        "shortlist_target_met": shortlist_count >= min_required if shortlist_count else None,
        "knowledge_target_met": card_count >= min_required if card_count else None,
        "bibliography_target_met": bibtex_entries >= min_required if bibtex_entries else None,
        "generated_at": _utcnow_iso(),
    }
    if extra:
        payload.update(extra)
    return payload


def _search_google_patents_multi_query(
    queries: list[str],
    *,
    limit_per_query: int = 20,
    inter_query_delay: float = 1.5,
) -> tuple[list[dict[str, Any]], list[str]]:
    import time

    from researchclaw.web.search import WebSearchClient

    client = WebSearchClient(api_key="", max_results=limit_per_query)
    candidates: list[dict[str, Any]] = []
    bibtex_entries: list[str] = []
    seen_urls: set[str] = set()

    for index, query in enumerate(queries):
        if index > 0:
            time.sleep(inter_query_delay)
        patent_query = f"site:patents.google.com/patent {query}"
        response = client.search(patent_query, max_results=limit_per_query)
        for result in response.results:
            url = result.url.strip()
            if not url or "patents.google.com" not in url or url in seen_urls:
                continue
            seen_urls.add(url)
            candidate = {
                "id": f"patent-{abs(hash(url))}",
                "title": result.title.strip() or url,
                "source": "google_patents",
                "url": url,
                "year": _extract_year(result.snippet or ""),
                "abstract": (result.snippet or "").strip(),
                "authors": [],
                "venue": "Google Patents",
                "collected_at": _utcnow_iso(),
            }
            candidates.append(candidate)
            bibtex_entries.append(_bibtex_from_candidate(candidate, "Google Patents"))

    return candidates, bibtex_entries


def _fetch_weaviate_class_schema(base_url: str, class_name: str, headers: dict[str, str]) -> dict[str, Any]:
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/v1/schema/{class_name}",
        headers=headers,
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return payload if isinstance(payload, dict) else {}


def _search_weaviate_multi_query(
    queries: list[str],
    *,
    limit_per_query: int = 20,
) -> tuple[list[dict[str, Any]], list[str]]:
    base_url = os.environ.get("WEAVIATE_URL", "").strip()
    class_name = (
        os.environ.get("WEAVIATE_COLLECTION")
        or os.environ.get("WEAVIATE_CLASS")
        or os.environ.get("WEAVIATE_CLASS_NAME")
        or ""
    ).strip()
    if not base_url or not class_name:
        logger.warning("[weaviate] Missing WEAVIATE_URL or WEAVIATE_COLLECTION/CLASS")
        return [], []

    headers = {"Content-Type": "application/json"}
    api_key = os.environ.get("WEAVIATE_API_KEY", "").strip()
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        schema = _fetch_weaviate_class_schema(base_url, class_name, headers)
    except (OSError, ValueError, urllib.error.URLError, urllib.error.HTTPError):
        logger.warning("[weaviate] Failed to load schema for %s", class_name, exc_info=True)
        return [], []

    properties = {
        str(item.get("name"))
        for item in schema.get("properties", [])
        if isinstance(item, dict) and item.get("name")
    }
    title_field = "title" if "title" in properties else "name" if "name" in properties else None
    abstract_field = next((field for field in ("abstract", "summary", "content", "text") if field in properties), None)
    url_field = "url" if "url" in properties else "link" if "link" in properties else None
    doi_field = "doi" if "doi" in properties else None
    year_field = "year" if "year" in properties else None
    authors_field = "authors" if "authors" in properties else None
    source_field = "source" if "source" in properties else None
    requested_fields = [field for field in (title_field, abstract_field, url_field, doi_field, year_field, authors_field, source_field) if field]
    if not requested_fields:
        logger.warning("[weaviate] No usable fields available on %s", class_name)
        return [], []

    gql_fields = "\n              ".join(requested_fields)
    candidates: list[dict[str, Any]] = []
    bibtex_entries: list[str] = []
    seen_ids: set[str] = set()

    for query in queries:
        gql_query = {
            "query": (
                "{ Get { "
                f"{class_name}(limit: {limit_per_query}, bm25: {{ query: {json.dumps(query)} }}) {{ "
                f"{gql_fields} "
                "_additional { id score } "
                "} } }"
            )
        }
        request = urllib.request.Request(
            f"{base_url.rstrip('/')}/v1/graphql",
            data=json.dumps(gql_query).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (OSError, ValueError, urllib.error.URLError, urllib.error.HTTPError):
            logger.warning("[weaviate] Query failed for %r", query, exc_info=True)
            continue

        rows = payload.get("data", {}).get("Get", {}).get(class_name, [])
        if not isinstance(rows, list):
            continue

        for row in rows:
            if not isinstance(row, dict):
                continue
            additional = row.get("_additional", {}) if isinstance(row.get("_additional", {}), dict) else {}
            record_id = str(additional.get("id") or row.get(url_field or "") or row.get(title_field or ""))
            if not record_id or record_id in seen_ids:
                continue
            seen_ids.add(record_id)

            authors_value = row.get(authors_field) if authors_field else []
            authors: list[dict[str, str]] = []
            if isinstance(authors_value, list):
                for author in authors_value:
                    if isinstance(author, str) and author.strip():
                        authors.append({"name": author.strip()})
                    elif isinstance(author, dict):
                        name = str(author.get("name") or author.get("text") or "").strip()
                        if name:
                            authors.append({"name": name})

            candidate = {
                "id": f"weaviate-{record_id}",
                "title": str(row.get(title_field or "") or record_id),
                "source": str(row.get(source_field or "") or "weaviate"),
                "url": str(row.get(url_field or "") or ""),
                "year": row.get(year_field or "") or 0,
                "abstract": str(row.get(abstract_field or "") or ""),
                "authors": authors,
                "doi": str(row.get(doi_field or "") or ""),
                "venue": "Weaviate",
                "score": additional.get("score"),
                "collected_at": _utcnow_iso(),
            }
            candidates.append(candidate)
            bibtex_entries.append(_bibtex_from_candidate(candidate, "Weaviate"))

    return candidates, bibtex_entries


# ---------------------------------------------------------------------------
# Stage executors
# ---------------------------------------------------------------------------


def _execute_search_strategy(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    problem_tree = _read_prior_artifact(run_dir, "problem_tree.md") or ""
    topic = config.research.topic
    source_mode = _selected_source_mode(config)
    min_references = _phase_b_reference_min(config)
    target_references = _phase_b_reference_target(config)
    plan: dict[str, Any] | None = None
    sources: list[dict[str, Any]] | None = None
    if llm is not None:
        _pm = prompts or PromptManager()
        _overlay = _get_evolution_overlay(run_dir, "search_strategy")
        sp = _pm.for_stage("search_strategy", evolution_overlay=_overlay, topic=topic, problem_tree=problem_tree)
        resp = _chat_with_prompt(
            llm,
            sp.system,
            sp.user,
            json_mode=sp.json_mode,
            max_tokens=sp.max_tokens,
        )
        payload = _safe_json_loads(resp.content, {})
        if isinstance(payload, dict):
            yaml_text = str(payload.get("search_plan_yaml", "")).strip()
            if yaml_text:
                try:
                    parsed = yaml.safe_load(_extract_yaml_block(yaml_text))
                except yaml.YAMLError:
                    parsed = None
                if isinstance(parsed, dict):
                    plan = parsed
            src = payload.get("sources", [])
            if isinstance(src, list):
                sources = [item for item in src if isinstance(item, dict)]
    if plan is None:
        # Build smart fallback queries by extracting key terms from topic
        # instead of using the raw (often very long) topic string.
        _fallback_queries = _build_fallback_queries(topic)
        plan = {
            "topic": topic,
            "generated": _utcnow_iso(),
            "search_strategies": [
                {
                    "name": "keyword_core",
                    "queries": _fallback_queries[:5],
                    "sources": list(_selected_backends(source_mode)),
                    "max_results_per_query": 80,
                },
                {
                    "name": "backward_forward_citation",
                    "queries": _fallback_queries[5:10] or _fallback_queries[:3],
                    "sources": list(_selected_backends(source_mode)),
                    "depth": 1,
                },
            ],
            "filters": {
                "min_year": 2020,
                "language": ["en"],
                "peer_review_preferred": True,
            },
            "coverage": {
                "phase": "Phase B: Literature Discovery",
                "minimum_required_references": min_references,
                "target_references": target_references,
                "minimum_unique_queries": MIN_PHASE_B_QUERY_COUNT,
            },
            "deduplication": {"method": "title_doi_hash", "fuzzy_threshold": 0.9},
        }
    plan = _apply_source_mode_to_plan(plan, source_mode)
    plan["minimum_required_references"] = min_references
    plan["target_references"] = target_references
    plan["minimum_unique_queries"] = MIN_PHASE_B_QUERY_COUNT
    coverage = plan.get("coverage")
    if not isinstance(coverage, dict):
        coverage = {}
    coverage.update(
        {
            "phase": "Phase B: Literature Discovery",
            "minimum_required_references": min_references,
            "target_references": target_references,
            "minimum_unique_queries": MIN_PHASE_B_QUERY_COUNT,
        }
    )
    plan["coverage"] = coverage
    if not sources:
        sources = _source_catalog(topic, source_mode)
    if config.openclaw_bridge.use_web_fetch:
        for src in sources:
            try:
                response = adapters.web_fetch.fetch(str(src.get("url", "")))
                src["status"] = (
                    "verified"
                    if response.status_code in (200, 301, 302, 405)
                    else "unreachable"
                )
                src["http_status"] = response.status_code
            except Exception:  # noqa: BLE001
                src["status"] = "unknown"
    (stage_dir / "search_plan.yaml").write_text(
        yaml.dump(plan, default_flow_style=False, allow_unicode=True),
        encoding="utf-8",
    )
    (stage_dir / "sources.json").write_text(
        json.dumps(
            {
                "sources": sources,
                "count": len(sources),
                "generated": _utcnow_iso(),
                "source_type": source_mode,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    # F1.5: Extract queries from plan for Stage 4 real literature search
    queries_list: list[str] = []
    year_min = 2020
    if isinstance(plan, dict):
        strategies = plan.get("search_strategies", [])
        if isinstance(strategies, list):
            for strat in strategies:
                if isinstance(strat, dict):
                    qs = strat.get("queries", [])
                    if isinstance(qs, list):
                        queries_list.extend(str(q) for q in qs if q)
        filters = plan.get("filters", {})
        if isinstance(filters, dict) and filters.get("min_year"):
            try:
                year_min = int(filters["min_year"])
            except (ValueError, TypeError):
                pass

    # --- Sanitize queries: shorten overly long queries ---
    # LLMs often produce the full topic title as a query, which is too long for
    # Google / academic APIs work best with concise 3-8 keyword queries.
    _stop = {
        "a", "an", "the", "of", "for", "in", "on", "and", "or", "with",
        "to", "by", "from", "its", "is", "are", "was", "be", "as", "at",
        "via", "using", "based", "study", "analysis", "empirical",
        "towards", "toward", "into", "exploring", "comparison", "tasks",
        "effectiveness", "investigation", "comprehensive", "novel",
        "challenge", "challenges", "gaps", "gap", "critical", "survey", "review",
    }

    def _extract_search_terms(text: str) -> list[str]:
        """Extract meaningful search terms from text, removing stop words."""
        return [
            w for w in re.split(r"[^a-zA-Z0-9]+", text)
            if w.lower() not in _stop and len(w) > 1
        ]

    _MAX_QUERY_LEN = 60  # characters — beyond this, shorten to keywords
    _SEARCH_SUFFIXES = ["benchmark", "survey", "seminal", "state of the art"]

    def _shorten_query(q: str, max_kw: int = 6) -> str:
        """Shorten a query to *max_kw* keywords, preserving any trailing suffix."""
        q_stripped = q.strip()
        # Check if query ends with a known search suffix
        suffix = ""
        q_core = q_stripped
        for sfx in _SEARCH_SUFFIXES:
            if q_stripped.lower().endswith(sfx):
                suffix = sfx
                q_core = q_stripped[: -len(sfx)].strip()
                break
        # Extract keywords from the core part
        kws = _extract_search_terms(q_core)
        shortened = " ".join(kws[:max_kw])
        if suffix:
            shortened = f"{shortened} {suffix}"
        return shortened

    if queries_list:
        sanitized: list[str] = []
        for q in queries_list:
            if len(q) > _MAX_QUERY_LEN:
                shortened = _shorten_query(q)
                if shortened.strip():
                    sanitized.append(shortened)
            else:
                sanitized.append(q)
        queries_list = sanitized

    def _build_default_search_queries(topic_text: str) -> list[str]:
        """Generate concept-style search queries from the topic instead of copying the title."""
        _words = _extract_search_terms(topic_text)
        if not _words:
            return [topic_text[:60]]
        kw_primary = " ".join(_words[:6])
        kw_short = " ".join(_words[:4])
        kw_alt = " ".join(_words[1:5]) if len(_words) > 4 else kw_short
        return [
            kw_primary,
            f"{kw_short} benchmark",
            f"{kw_short} survey",
            kw_alt,
            f"{kw_short} recent advances",
        ]

    if not queries_list:
        queries_list = _build_default_search_queries(topic)

    # Ensure minimum query diversity — if dedup leaves too few, add variants
    _all_kw = _extract_search_terms(topic)
    _seen_q: set[str] = set()
    unique_queries: list[str] = []
    for q in queries_list:
        q_lower = q.strip().lower()
        if q_lower and q_lower not in _seen_q:
            _seen_q.add(q_lower)
            unique_queries.append(q.strip())
    # If dedup leaves too few queries, generate supplemental keyword variants.
    if len(unique_queries) < MIN_PHASE_B_QUERY_COUNT and len(_all_kw) >= 3:
        supplements = [
            " ".join(_all_kw[:4]) + " survey",
            " ".join(_all_kw[:4]) + " benchmark",
            " ".join(_all_kw[:4]) + " systematic review",
            " ".join(_all_kw[:4]) + " state of the art",
            " ".join(_all_kw[1:5]),  # shifted window for diversity
            " ".join(_all_kw[:3]) + " comparison",
            " ".join(_all_kw[:3]) + " deep learning",
            " ".join(_all_kw[:3]) + " evaluation",
            " ".join(_all_kw[:3]) + " dataset",
            " ".join(_all_kw[:3]) + " ablation",
            " ".join(_all_kw[2:6]),  # another shifted window
        ]
        for s in supplements:
            s_lower = s.strip().lower()
            if s_lower not in _seen_q:
                _seen_q.add(s_lower)
                unique_queries.append(s.strip())
            if len(unique_queries) >= MIN_PHASE_B_QUERY_COUNT:
                break
    if len(unique_queries) < MIN_PHASE_B_QUERY_COUNT:
        for q in _expand_search_queries(unique_queries or [topic], topic):
            q_lower = q.strip().lower()
            if q_lower and q_lower not in _seen_q:
                _seen_q.add(q_lower)
                unique_queries.append(q.strip())
            if len(unique_queries) >= MIN_PHASE_B_QUERY_COUNT:
                break
    queries_list = unique_queries
    (stage_dir / "queries.json").write_text(
        json.dumps(
            {
                "queries": queries_list,
                "year_min": year_min,
                "source_type": source_mode,
                "sources": list(_selected_backends(source_mode)),
                "phase": "Phase B: Literature Discovery",
                "minimum_required_references": min_references,
                "target_references": target_references,
                "minimum_unique_queries": MIN_PHASE_B_QUERY_COUNT,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return StageResult(
        stage=Stage.SEARCH_STRATEGY,
        status=StageStatus.DONE,
        artifacts=("search_plan.yaml", "sources.json", "queries.json"),
        evidence_refs=(
            "stage-03/search_plan.yaml",
            "stage-03/sources.json",
            "stage-03/queries.json",
        ),
    )


def _execute_literature_collect(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    """Stage 4: Collect literature — prefer real APIs, fallback to LLM."""
    topic = config.research.topic

    # Read queries.json from Stage 3 (F1.5 output)
    queries_text = _read_prior_artifact(run_dir, "queries.json")
    queries_data = _safe_json_loads(queries_text or "{}", {})
    queries: list[str] = queries_data.get("queries", [topic])
    year_min: int = queries_data.get("year_min", 2020)
    source_mode = _selected_source_mode(config, queries_data)
    selected_sources = tuple(queries_data.get("sources", ())) or _selected_backends(source_mode)
    min_references = max(
        _phase_b_reference_min(config),
        _nonnegative_int(queries_data.get("minimum_required_references")),
    )
    target_references = max(
        _phase_b_reference_target(config),
        _nonnegative_int(queries_data.get("target_references")),
        min_references,
    )

    # --- Try real API search first ---
    candidates: list[dict[str, Any]] = []
    bibtex_entries: list[str] = []
    real_search_succeeded = False

    try:
        from researchclaw.literature.search import (
            search_papers_multi_query,
        )

        # Expand queries for broader coverage
        expanded_queries = _expand_search_queries(queries, config.research.topic)
        logger.info(
            "[literature] Searching %d queries (expanded from %d) in %s mode",
            len(expanded_queries),
            len(queries),
            source_mode,
        )
        if source_mode == "patent":
            candidates, bibtex_entries = _search_google_patents_multi_query(
                expanded_queries,
                limit_per_query=80,
            )
            real_search_succeeded = bool(candidates)
        elif source_mode == "slr":
            candidates, bibtex_entries = _search_weaviate_multi_query(
                expanded_queries,
                limit_per_query=40,
            )
            real_search_succeeded = bool(candidates)
        else:
            papers = search_papers_multi_query(
                expanded_queries,
                limit_per_query=80,
                sources=selected_sources,
                year_min=year_min,
                s2_api_key=config.llm.s2_api_key,
            )
            if papers:
                real_search_succeeded = True
                src_counts: dict[str, int] = {}
                for p in papers:
                    src_counts[p.source] = src_counts.get(p.source, 0) + 1
                    d = p.to_dict()
                    d["collected_at"] = _utcnow_iso()
                    candidates.append(d)
                    bibtex_entries.append(p.to_bibtex())
                src_str = ", ".join(f"{s}: {n}" for s, n in src_counts.items())
                logger.info(
                    "[literature] Found %d papers (%s)", len(papers), src_str
                )
    except Exception:  # noqa: BLE001
        logger.warning(
            "[rate-limit] Literature search failed — falling back to LLM",
            exc_info=True,
        )

    # --- Inject foundational/seminal papers ---
    try:
        from researchclaw.data import load_seminal_papers
        seminal = load_seminal_papers(topic) if source_mode == "auto" else []
        if seminal:
            _existing_titles = {c.get("title", "").lower() for c in candidates}
            _injected = 0
            for sp in seminal:
                if sp.get("title", "").lower() not in _existing_titles:
                    candidates.append({
                        "id": f"seminal-{sp.get('cite_key', '')}",
                        "title": sp.get("title", ""),
                        "source": "seminal_library",
                        "url": "",
                        "year": sp.get("year", 2020),
                        "abstract": f"Foundational paper on {', '.join(sp.get('keywords', [])[:3])}.",
                        "authors": [{"name": sp.get("authors", "")}],
                        "cite_key": sp.get("cite_key", ""),
                        "venue": sp.get("venue", ""),
                        "collected_at": _utcnow_iso(),
                    })
                    _injected += 1
            if _injected:
                logger.info("Stage 4: Injected %d seminal papers from seed library", _injected)
    except Exception:  # noqa: BLE001
        logger.debug("Seminal paper injection skipped", exc_info=True)

    # --- Fallback: LLM-generated candidates ---
    if not candidates and llm is not None:
        plan_text = _read_prior_artifact(run_dir, "search_plan.yaml") or ""
        _pm = prompts or PromptManager()
        _overlay = _get_evolution_overlay(run_dir, "literature_collect")
        sp = _pm.for_stage("literature_collect", evolution_overlay=_overlay, topic=topic, plan_text=plan_text)
        resp = _chat_with_prompt(
            llm,
            sp.system,
            sp.user,
            json_mode=sp.json_mode,
            max_tokens=sp.max_tokens,
        )
        payload = _safe_json_loads(resp.content, {})
        if isinstance(payload, dict) and isinstance(payload.get("candidates"), list):
            candidates = [row for row in payload["candidates"] if isinstance(row, dict)]

    # --- Web search augmentation (Google/Tavily/DDG + Google Scholar + Crawl4AI) ---
    web_context_parts: list[str] = []
    if config.web_search.enabled and source_mode == "auto":
        try:
            from researchclaw.web.agent import WebSearchAgent
            import os

            tavily_key = config.web_search.tavily_api_key or os.environ.get(
                config.web_search.tavily_api_key_env, ""
            )
            google_api_key = config.web_search.google_api_key or os.environ.get(
                config.web_search.google_api_key_env, ""
            ) or os.environ.get("GOOGLE_API_KEY", "")
            google_cse_id = config.web_search.google_cse_id or os.environ.get(
                config.web_search.google_cse_id_env, ""
            ) or os.environ.get("GOOGLE_SEARCH_ENGINE_ID", "")
            web_agent = WebSearchAgent(
                tavily_api_key=tavily_key,
                google_api_key=google_api_key,
                google_cse_id=google_cse_id,
                enable_scholar=config.web_search.enable_scholar,
                enable_crawling=config.web_search.enable_crawling,
                enable_pdf=config.web_search.enable_pdf_extraction,
                max_web_results=config.web_search.max_web_results,
                max_scholar_results=config.web_search.max_scholar_results,
                max_crawl_urls=config.web_search.max_crawl_urls,
            )
            web_result = web_agent.search_and_extract(
                topic, search_queries=queries,
            )

            # Convert Google Scholar papers into candidates
            for sp in web_result.scholar_papers:
                _existing_titles = {
                    str(c.get("title", "")).lower().strip() for c in candidates
                }
                if sp.title.lower().strip() not in _existing_titles:
                    lit_paper = sp.to_literature_paper()
                    d = lit_paper.to_dict()
                    d["collected_at"] = _utcnow_iso()
                    candidates.append(d)
                    bibtex_entries.append(lit_paper.to_bibtex())

            # Save web search context for downstream stages
            web_context = web_result.to_context_string(max_length=20_000)
            if web_context.strip():
                (stage_dir / "web_context.md").write_text(
                    web_context, encoding="utf-8"
                )
                web_context_parts.append(web_context)

            # Save full web search metadata
            (stage_dir / "web_search_result.json").write_text(
                json.dumps(web_result.to_dict(), indent=2, default=str),
                encoding="utf-8",
            )

            logger.info(
                "[web-search] Added %d scholar papers, %d web results, %d crawled pages",
                len(web_result.scholar_papers),
                len(web_result.web_results),
                len(web_result.crawled_pages),
            )
        except Exception:  # noqa: BLE001
            logger.warning(
                "[web-search] Web search augmentation failed — continuing with academic APIs only",
                exc_info=True,
            )

    # --- Ultimate fallback: placeholder data ---
    # BUG-L2: Do NOT overwrite real_search_succeeded here — it was already
    # set correctly in the search block above. Overwriting would mislabel
    # LLM-hallucinated or seminal papers as "real search" results.
    if not candidates:
        logger.warning("Stage 4: All literature searches failed — using placeholder papers")
        candidates = [
            {
                "id": f"candidate-{idx + 1}",
                "cite_key": f"phaseb_placeholder_{idx + 1:02d}",
                "title": f"[Placeholder] Study {idx + 1} on {topic}",
                "source": "arxiv" if idx % 2 == 0 else "semantic_scholar",
                "url": f"https://example.org/{_safe_filename(topic.lower())}/{idx + 1}",
                "year": 2024,
                "abstract": f"This candidate investigates {topic} and reports preliminary findings.",
                "collected_at": _utcnow_iso(),
                "is_placeholder": True,
                "needs_reference_verification": True,
            }
            for idx in range(target_references)
        ]

    raw_candidate_count = len(candidates)
    candidates = _prepare_literature_candidates(
        candidates,
        topic=topic,
        min_count=target_references,
    )
    placeholder_count = sum(1 for row in candidates if row.get("is_placeholder"))
    if len(candidates) != raw_candidate_count:
        logger.info(
            "Stage 4: Prepared %d literature candidates for Phase B coverage "
            "(raw=%d, minimum=%d, target=%d)",
            len(candidates),
            raw_candidate_count,
            min_references,
            target_references,
        )

    # Write candidates
    out = stage_dir / "candidates.jsonl"
    _write_jsonl(out, candidates)

    bibtex_entries = _ensure_bibtex_entries(candidates, bibtex_entries)
    logger.info(
        "Stage 4: Prepared %d BibTeX entries from %d candidates",
        len(bibtex_entries),
        len(candidates),
    )

    # Write references.bib (F2.4)
    artifacts = ["candidates.jsonl"]
    if web_context_parts:
        artifacts.append("web_context.md")
    if (stage_dir / "web_search_result.json").exists():
        artifacts.append("web_search_result.json")
    if bibtex_entries:
        bib_content = "\n\n".join(bibtex_entries) + "\n"
        (stage_dir / "references.bib").write_text(bib_content, encoding="utf-8")
        artifacts.append("references.bib")
        logger.info(
            "Stage 4: Wrote %d BibTeX entries to references.bib", len(bibtex_entries)
        )

    # Write search metadata
    (stage_dir / "search_meta.json").write_text(
        json.dumps(
            {
                "real_search": real_search_succeeded,
                "queries_used": queries,
                "year_min": year_min,
                "source_type": source_mode,
                "sources_used": list(selected_sources),
                "total_candidates": len(candidates),
                "bibtex_entries": len(bibtex_entries),
                "minimum_required_references": min_references,
                "target_references": target_references,
                "placeholder_count": placeholder_count,
                "ts": _utcnow_iso(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    artifacts.append("search_meta.json")

    coverage_report = _literature_coverage_payload(
        stage=4,
        candidate_count=len(candidates),
        bibtex_entries=len(bibtex_entries),
        min_required=min_references,
        target=target_references,
        extra={
            "real_search": real_search_succeeded,
            "source_type": source_mode,
            "sources_used": list(selected_sources),
            "queries_used": queries,
            "raw_candidate_count": raw_candidate_count,
            "placeholder_count": placeholder_count,
        },
    )
    (stage_dir / "literature_coverage_report.json").write_text(
        json.dumps(coverage_report, indent=2),
        encoding="utf-8",
    )
    artifacts.append("literature_coverage_report.json")

    return StageResult(
        stage=Stage.LITERATURE_COLLECT,
        status=StageStatus.DONE,
        artifacts=tuple(artifacts),
        evidence_refs=tuple(f"stage-04/{a}" for a in artifacts),
    )


_MAX_ABSTRACT_LEN = 800  # Truncate long abstracts to reduce token usage
_MAX_CANDIDATES_CHARS = 75_000  # Preserve broader literature context for screening


def _execute_literature_screen(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    candidates_text = _read_prior_artifact(run_dir, "candidates.jsonl") or ""
    min_references = _phase_b_reference_min(config)
    target_references = _phase_b_reference_target(config)
    all_candidate_rows = _prepare_literature_candidates(
        _parse_jsonl_rows(candidates_text),
        topic=config.research.topic,
        min_count=min_references,
    )

    # --- P1-1: keyword relevance pre-filter ---
    # Before LLM screening, drop papers whose title+abstract share no keywords
    # with the research topic.  This catches cross-domain noise cheaply.
    topic_keywords = _extract_topic_keywords(
        config.research.topic, config.research.domains
    )
    filtered_rows: list[dict[str, Any]] = []
    dropped_count = 0
    for row in all_candidate_rows:
        title = str(row.get("title", "")).lower()
        abstract = str(row.get("abstract", "")).lower()
        text_blob = f"{title} {abstract}"
        overlap = sum(1 for kw in topic_keywords if kw in text_blob)
        # T2.2: Relaxed from ≥2 to ≥1 keyword hit — previous threshold was
        # too aggressive (94% rejection rate).  Single-keyword matches are
        # still screened by the LLM in the next step.
        if overlap >= 1:
            row["keyword_overlap"] = overlap
            filtered_rows.append(row)
        else:
            dropped_count += 1
    # If pre-filter dropped everything, fall back to original (safety valve)
    if not filtered_rows:
        filtered_rows = list(all_candidate_rows)
    elif len(filtered_rows) < min_references:
        existing = {_candidate_identity(row) for row in filtered_rows}
        for row in all_candidate_rows:
            if len(filtered_rows) >= min_references:
                break
            identity = _candidate_identity(row)
            if identity in existing:
                continue
            row = dict(row)
            row["keyword_overlap"] = row.get("keyword_overlap", 0)
            row["screening_note"] = "Supplemented to preserve Phase B coverage"
            filtered_rows.append(row)
            existing.add(identity)
    # Truncate abstracts and strip authors to reduce token usage
    for row in filtered_rows:
        abstract = row.get("abstract", "")
        if isinstance(abstract, str) and len(abstract) > _MAX_ABSTRACT_LEN:
            row["abstract"] = abstract[:_MAX_ABSTRACT_LEN] + "..."
        # Strip authors list — not needed for screening and inflates tokens
        row.pop("authors", None)

    # Rebuild candidates_text from filtered rows
    candidates_text = "\n".join(
        json.dumps(r, ensure_ascii=False) for r in filtered_rows
    )
    # Cap total candidates text size to avoid blowing token budget
    if len(candidates_text) > _MAX_CANDIDATES_CHARS:
        # Truncate at newline boundaries while preserving the required minimum.
        kept_lines: list[str] = []
        char_count = 0
        for idx, line in enumerate(candidates_text.splitlines()):
            line_len = len(line) + 1
            if idx < min_references or char_count + line_len <= _MAX_CANDIDATES_CHARS:
                kept_lines.append(line)
                char_count += line_len
            else:
                break
        candidates_text = "\n".join(kept_lines)
        logger.info(
            "Candidates text truncated to %d chars for screening",
            len(candidates_text),
        )
    logger.info(
        "Domain pre-filter: kept %d, dropped %d (keywords: %s)",
        len(filtered_rows),
        dropped_count,
        topic_keywords[:8],
    )

    shortlist: list[dict[str, Any]] = []
    if llm is not None:
        _pm = prompts or PromptManager()
        _overlay = _get_evolution_overlay(run_dir, "literature_screen")
        sp = _pm.for_stage(
            "literature_screen",
            evolution_overlay=_overlay,
            topic=config.research.topic,
            domains=", ".join(config.research.domains)
            if config.research.domains
            else "general",
            quality_threshold=config.research.quality_threshold,
            candidates_text=candidates_text,
        )
        resp = _chat_with_prompt(
            llm,
            sp.system,
            sp.user,
            json_mode=sp.json_mode,
            max_tokens=sp.max_tokens,
        )
        payload = _safe_json_loads(resp.content, {})
        if isinstance(payload, dict) and isinstance(payload.get("shortlist"), list):
            shortlist = [row for row in payload["shortlist"] if isinstance(row, dict)]
    # Journal-grade papers need more than 30 screened references.
    _MIN_SHORTLIST = min_references
    if not shortlist:
        rows = (
            filtered_rows[:_MIN_SHORTLIST]
            if filtered_rows
            else all_candidate_rows[:_MIN_SHORTLIST]
        )
        for idx, item in enumerate(rows):
            item["relevance_score"] = round(0.75 - idx * 0.02, 3)
            item["quality_score"] = round(0.72 - idx * 0.015, 3)
            item["keep_reason"] = "Template screened entry"
            shortlist.append(item)
    elif len(shortlist) < _MIN_SHORTLIST:
        # T2.2: LLM returned too few — supplement from filtered candidates
        existing_ids = {_candidate_identity(s) for s in shortlist}
        candidate_pool = _dedupe_literature_candidates(filtered_rows + all_candidate_rows)
        for row in candidate_pool:
            if len(shortlist) >= _MIN_SHORTLIST:
                break
            identity = _candidate_identity(row)
            if identity not in existing_ids:
                row.setdefault("relevance_score", 0.5)
                row.setdefault("quality_score", 0.5)
                row.setdefault("keep_reason", "Supplemented to meet minimum shortlist")
                shortlist.append(row)
                existing_ids.add(identity)
        logger.info(
            "Stage 5: Supplemented shortlist to %d papers (minimum: %d)",
            len(shortlist), _MIN_SHORTLIST,
        )
    out = stage_dir / "shortlist.jsonl"
    _write_jsonl(out, shortlist)
    coverage_report = _literature_coverage_payload(
        stage=5,
        candidate_count=len(all_candidate_rows),
        shortlist_count=len(shortlist),
        min_required=min_references,
        target=target_references,
        extra={
            "filtered_candidate_count": len(filtered_rows),
            "dropped_candidate_count": dropped_count,
            "keyword_count": len(topic_keywords),
        },
    )
    (stage_dir / "screening_coverage_report.json").write_text(
        json.dumps(coverage_report, indent=2),
        encoding="utf-8",
    )
    return StageResult(
        stage=Stage.LITERATURE_SCREEN,
        status=StageStatus.DONE,
        artifacts=("shortlist.jsonl", "screening_coverage_report.json"),
        evidence_refs=(
            "stage-05/shortlist.jsonl",
            "stage-05/screening_coverage_report.json",
        ),
    )


def _execute_knowledge_extract(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    shortlist = _read_prior_artifact(run_dir, "shortlist.jsonl") or ""
    min_references = _phase_b_reference_min(config)
    target_references = _phase_b_reference_target(config)
    shortlist_rows = _prepare_literature_candidates(
        _parse_jsonl_rows(shortlist),
        topic=config.research.topic,
        min_count=min_references,
    )
    shortlist_for_prompt = "\n".join(
        json.dumps(row, ensure_ascii=False) for row in shortlist_rows
    )

    # Inject web context from Stage 4 if available
    web_context = _read_prior_artifact(run_dir, "web_context.md") or ""
    if web_context:
        shortlist_for_prompt = (
            shortlist_for_prompt
            + "\n\n--- Web Search Context ---\n"
            + web_context[:10_000]
        )

    cards_dir = stage_dir / "cards"
    cards_dir.mkdir(parents=True, exist_ok=True)
    cards: list[dict[str, Any]] = []
    if llm is not None:
        _pm = prompts or PromptManager()
        _overlay = _get_evolution_overlay(run_dir, "knowledge_extract")
        sp = _pm.for_stage(
            "knowledge_extract",
            evolution_overlay=_overlay,
            shortlist=shortlist_for_prompt,
        )
        resp = _chat_with_prompt(
            llm,
            sp.system,
            sp.user,
            json_mode=sp.json_mode,
            max_tokens=sp.max_tokens,
        )
        payload = _safe_json_loads(resp.content, {})
        if isinstance(payload, dict) and isinstance(payload.get("cards"), list):
            cards = [item for item in payload["cards"] if isinstance(item, dict)]

    def _template_card(paper: dict[str, Any], idx: int) -> dict[str, Any]:
        title = str(paper.get("title", f"Paper {idx + 1}"))
        return {
            "card_id": f"card-{idx + 1}",
            "title": title,
            "problem": f"How to improve {config.research.topic}",
            "method": str(paper.get("method") or "Template method summary"),
            "data": str(paper.get("data") or "Template dataset"),
            "metrics": str(paper.get("metrics") or "Template metric"),
            "findings": str(
                paper.get("findings")
                or paper.get("abstract")
                or "Template key finding"
            ),
            "limitations": str(paper.get("limitations") or "Template limitation"),
            "citation": str(paper.get("url", "")),
            "cite_key": str(paper.get("cite_key", "")),
        }

    if not cards:
        for idx, paper in enumerate(shortlist_rows[:min_references]):
            cards.append(_template_card(paper, idx))
    elif len(cards) < min_references:
        existing_ids = {_candidate_identity(card) for card in cards}
        for paper in shortlist_rows:
            if len(cards) >= min_references:
                break
            identity = _candidate_identity(paper)
            if identity in existing_ids:
                continue
            cards.append(_template_card(paper, len(cards)))
            existing_ids.add(identity)
        logger.info(
            "Stage 6: Supplemented knowledge cards to %d papers (minimum: %d)",
            len(cards),
            min_references,
        )
    for idx, card in enumerate(cards):
        card_id = _safe_filename(str(card.get("card_id", f"card-{idx + 1}")))
        parts = [f"# {card.get('title', card_id)}", ""]
        for key in (
            "cite_key",
            "problem",
            "method",
            "data",
            "metrics",
            "findings",
            "limitations",
            "citation",
        ):
            parts.append(f"## {key.title()}")
            parts.append(str(card.get(key, "")))
            parts.append("")
        (cards_dir / f"{card_id}.md").write_text("\n".join(parts), encoding="utf-8")
    coverage_report = _literature_coverage_payload(
        stage=6,
        shortlist_count=len(shortlist_rows),
        card_count=len(cards),
        min_required=min_references,
        target=target_references,
        extra={
            "web_context_included": bool(web_context),
        },
    )
    (stage_dir / "knowledge_coverage_report.json").write_text(
        json.dumps(coverage_report, indent=2),
        encoding="utf-8",
    )
    return StageResult(
        stage=Stage.KNOWLEDGE_EXTRACT,
        status=StageStatus.DONE,
        artifacts=("cards/", "knowledge_coverage_report.json"),
        evidence_refs=("stage-06/cards/", "stage-06/knowledge_coverage_report.json"),
    )
