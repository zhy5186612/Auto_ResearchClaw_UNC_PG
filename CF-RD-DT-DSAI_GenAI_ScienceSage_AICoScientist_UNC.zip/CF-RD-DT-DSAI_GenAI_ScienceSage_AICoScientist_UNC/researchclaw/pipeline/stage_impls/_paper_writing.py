"""Stages 16-17: Paper outline and paper draft generation."""

from __future__ import annotations

import json
import logging
import math
import re
from pathlib import Path
from typing import Any

import yaml

from researchclaw.adapters import AdapterBundle
from researchclaw.config import RCConfig
from researchclaw.llm.client import LLMClient
from researchclaw.pipeline._domain import _detect_domain, _is_ml_domain
from researchclaw.pipeline._helpers import (
    StageResult,
    _build_context_preamble,
    _chat_with_prompt,
    _collect_experiment_results,
    _default_paper_outline,
    _extract_paper_title,
    _generate_framework_diagram_prompt,
    _generate_neurips_checklist,
    _get_evolution_overlay,
    _existing_progress_artifact,
    _read_best_analysis,
    _read_prior_artifact,
    _safe_json_loads,
    _topic_constraint_block,
    _utcnow_iso,
)
from researchclaw.pipeline.stages import Stage, StageStatus
from researchclaw.prompts import PromptManager

logger = logging.getLogger(__name__)

_FAILED_RUN_DIAGNOSTIC_MARKER = "<!-- RC_FAILED_RUN_DIAGNOSTIC -->"

_TOPIC_GUARD_STOP_WORDS = frozenset(
    {
        "a",
        "an",
        "the",
        "and",
        "or",
        "of",
        "for",
        "to",
        "in",
        "on",
        "with",
        "via",
        "using",
        "based",
        "from",
        "into",
        "by",
        "study",
        "analysis",
        "approach",
        "method",
        "methods",
        "framework",
        "frameworks",
        "system",
        "systems",
    }
)


def _topic_is_literature_first(config: RCConfig) -> bool:
    """Return True when the topic is a survey/review or the project uses docs-first mode.

    Literature-first topics produce papers grounded in existing work rather
    than novel experiments, so the "all simulated" and "no real metrics"
    hard blocks should be bypassed.
    """
    topic_lower = config.research.topic.lower()
    if any(kw in topic_lower for kw in ("survey", "review", "meta-analysis", "literature review")):
        return True
    project_mode = getattr(config.research, "project_mode", None)
    if isinstance(project_mode, str) and project_mode.lower() == "docs-first":
        return True
    return False


def _normalize_topic_text(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", text.lower())).strip()


def _topic_guard_keywords(topic: str) -> list[str]:
    keywords: list[str] = []
    seen: set[str] = set()
    for token in re.findall(r"[A-Za-z0-9]+", topic.lower()):
        if len(token) < 4 or token in _TOPIC_GUARD_STOP_WORDS:
            continue
        if token not in seen:
            seen.add(token)
            keywords.append(token)
    return keywords


def _extract_markdown_section(md_text: str, headings: tuple[str, ...]) -> str:
    pattern = "|".join(re.escape(h) for h in headings)
    match = re.search(
        rf"^##?\s*(?:\d+(?:\.\d+)*)?\s*[:.)-]?\s*(?:{pattern})\s*$\n?(.*?)(?=^##?\s+(?:\d+(?:\.\d+)*)?\s*[:.)-]?\s*\S|\Z)",
        md_text,
        re.IGNORECASE | re.MULTILINE | re.DOTALL,
    )
    return match.group(1).strip() if match else ""


def _section_has_topic_focus(
    text: str,
    topic: str,
    *,
    require_exact: bool = False,
    min_keyword_matches: int = 2,
) -> bool:
    if not text.strip():
        return False
    normalized_text = _normalize_topic_text(text)
    normalized_topic = _normalize_topic_text(topic)
    if normalized_topic and normalized_topic in normalized_text:
        return True
    if require_exact:
        return False
    keywords = _topic_guard_keywords(topic)
    if not keywords:
        return False
    matches = sum(1 for keyword in keywords if keyword in normalized_text)
    return matches >= min(min_keyword_matches, len(keywords))


def _topic_clarification_issue(topic: str) -> str | None:
    stripped = re.sub(r"\s+", " ", topic).strip()
    if not stripped:
        return "Research topic is empty."
    if len(re.findall(r"\w+", stripped)) < 3:
        return "Research topic is too short to preserve exactly without clarification."
    if re.search(r"\b(tbd|todo|something|misc|general topic|various|etc)\b", stripped, re.IGNORECASE):
        return "Research topic contains placeholder wording and needs clarification."
    return None


def _evaluate_topic_integrity(paper_text: str, topic: str) -> dict[str, Any]:
    title = _extract_paper_title(paper_text)
    sections = {
        "abstract": _extract_markdown_section(paper_text, ("Abstract",)),
        "introduction": _extract_markdown_section(paper_text, ("Introduction",)),
        "method": _extract_markdown_section(
            paper_text,
            ("Method", "Methods", "Methodology", "Approach", "Proposed Method", "Technical Approach"),
        ),
        "experiments": _extract_markdown_section(
            paper_text,
            ("Experiments", "Experimental Setup", "Evaluation Setup"),
        ),
        "results": _extract_markdown_section(
            paper_text,
            ("Results", "Results and Discussion", "Experimental Results"),
        ),
        "conclusion": _extract_markdown_section(paper_text, ("Conclusion", "Conclusions")),
    }
    checks: dict[str, bool] = {}
    failures: list[str] = []

    def _record(name: str, ok: bool, message: str) -> None:
        checks[name] = ok
        if not ok:
            failures.append(message)

    _record(
        "title_preserves_exact_topic",
        _section_has_topic_focus(title, topic, require_exact=True),
        "Title must preserve the exact user topic phrase.",
    )
    _record(
        "abstract_addresses_topic",
        _section_has_topic_focus(sections["abstract"], topic, require_exact=True),
        "Abstract must directly address the exact user topic.",
    )
    _record(
        "introduction_preserves_topic",
        _section_has_topic_focus(sections["introduction"], topic, require_exact=True),
        "Introduction must explicitly preserve the exact user topic.",
    )
    _record(
        "method_relevant_to_topic",
        _section_has_topic_focus(sections["method"], topic),
        "Method section is no longer centered on the user topic.",
    )
    _record(
        "experiments_relevant_to_topic",
        _section_has_topic_focus(sections["experiments"], topic),
        "Experiments section is no longer centered on the user topic.",
    )
    _record(
        "results_relevant_to_topic",
        _section_has_topic_focus(sections["results"], topic),
        "Results section is no longer centered on the user topic.",
    )
    _record(
        "conclusion_relevant_to_topic",
        _section_has_topic_focus(sections["conclusion"], topic),
        "Conclusion is no longer centered on the user topic.",
    )

    normalized_topic = _normalize_topic_text(topic)
    if ":" in title and normalized_topic and normalized_topic in _normalize_topic_text(title):
        prefix = title.split(":", 1)[0].strip()
        if prefix and _normalize_topic_text(prefix) not in normalized_topic:
            _record(
                "title_has_no_invented_prefix",
                False,
                "Title adds an invented prefix or framework label before the user topic.",
            )
        else:
            checks["title_has_no_invented_prefix"] = True
    else:
        checks["title_has_no_invented_prefix"] = True

    invented_name_patterns = (
        r"\b(?:framework|method|system|pipeline|approach|model)\s+(?:called|named|dubbed)\s+[A-Z][A-Za-z0-9-]{1,20}\b",
        r"\bwe\s+(?:call|name|dub)\s+(?:this|the)?\s*(?:framework|method|system|pipeline|approach|model)?\s*[\"']?[A-Z][A-Za-z0-9-]{1,20}\b",
    )
    has_invented_name = any(
        re.search(pattern, paper_text, re.IGNORECASE) for pattern in invented_name_patterns
    )
    _record(
        "no_invented_framework_name",
        not has_invented_name,
        "Paper invents a framework or method name that can change the topic framing.",
    )

    return {
        "topic": topic,
        "title": title,
        "checks": checks,
        "failures": failures,
        "passed": not failures,
    }


def _write_topic_integrity_report(stage_dir: Path, report: dict[str, Any]) -> None:
    (stage_dir / "topic_integrity_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )


def _repair_topic_integrity(
    llm: LLMClient,
    paper_text: str,
    topic: str,
    report: dict[str, Any],
    *,
    max_tokens: int = 24000,
) -> str:
    failures = report.get("failures", []) or []
    user = (
        "The user-provided research topic is FIXED and must remain exactly as written.\n\n"
        f"TOPIC: {topic}\n\n"
        "Revise the paper so the title, abstract, introduction, method, experiments, results, "
        "and conclusion stay centered on that exact topic. Do NOT invent a framework name, "
        "acronym, replacement title, or prefixed label. Preserve all real numbers, citations, "
        "tables, and experiment evidence.\n\n"
        "Current topic-integrity failures:\n"
        + "\n".join(f"- {failure}" for failure in failures)
        + "\n\nReturn revised markdown only.\n\n"
        f"Paper:\n{paper_text}"
    )
    resp = _chat_with_prompt(
        llm,
        "You repair academic papers for exact topic fidelity while preserving evidence.",
        user,
        max_tokens=max_tokens,
    )
    return resp.content.strip()


def _execute_paper_outline(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    clarification_issue = _topic_clarification_issue(config.research.topic)
    if clarification_issue:
        outline = (
            _default_paper_outline(config.research.topic).rstrip()
            + "\n\n## Evidence Status\n"
            "The topic needs clarification, so the downstream draft must preserve "
            "the exact user wording and avoid adding unsupported domain claims. "
            f"Clarification note: {clarification_issue}\n"
        )
        (stage_dir / "outline.md").write_text(outline, encoding="utf-8")
        rewrite_report = _write_paper_auto_rewrite_report(
            stage_dir,
            artifact="outline.md",
            source="topic_clarification_gate",
            reason=f"The topic requires clarification: {clarification_issue}",
            action="replaced_with_evidence_limited_outline",
        )
        return StageResult(
            stage=Stage.PAPER_OUTLINE,
            status=StageStatus.DONE,
            artifacts=("outline.md", rewrite_report),
            evidence_refs=("stage-16/outline.md", f"stage-16/{rewrite_report}"),
            decision="degraded",
        )

    analysis = _read_best_analysis(run_dir)
    decision = _read_prior_artifact(run_dir, "decision.md") or ""
    preamble = _build_context_preamble(
        config,
        run_dir,
        include_analysis=True,
        include_decision=True,
        include_exp_plan=True,
        include_experiment_data=True,
    )

    # WS-5.2: Read iteration feedback if available (multi-round iteration)
    feedback = ""
    iter_ctx_path = _existing_progress_artifact(run_dir, "iteration_context.json")
    if iter_ctx_path is not None:
        try:
            ctx = json.loads(iter_ctx_path.read_text(encoding="utf-8"))
            iteration = ctx.get("iteration", 1)
            prev_score = ctx.get("quality_score")
            reviews_excerpt = ctx.get("reviews_excerpt", "")
            if iteration > 1 and reviews_excerpt:
                feedback = (
                    f"\n\n## Iteration {iteration} Feedback\n"
                    f"Previous quality score: {prev_score}/10\n"
                    f"Reviewer feedback to address:\n{reviews_excerpt[:2000]}\n"
                    f"\nYou MUST address these reviewer concerns in this revision.\n"
                )
        except (json.JSONDecodeError, KeyError):
            pass

    outline_degraded = False
    if llm is not None:
        try:
            _pm = prompts or PromptManager()
            # IMP-20: Pass academic style guide block for outline stage
            try:
                _asg = _pm.block("academic_style_guide")
            except (KeyError, Exception):
                _asg = ""
            _overlay = _get_evolution_overlay(run_dir, "paper_outline")
            sp = _pm.for_stage(
                "paper_outline",
                evolution_overlay=_overlay,
                preamble=preamble,
                topic_constraint=_pm.block("topic_constraint", topic=config.research.topic),
                feedback=feedback,
                analysis=analysis,
                decision=decision,
                academic_style_guide=_asg,
            )
            resp = _chat_with_prompt(
                llm,
                sp.system,
                sp.user,
                json_mode=sp.json_mode,
                max_tokens=sp.max_tokens,
            )
            outline = resp.content
            # Reasoning models may consume all tokens on CoT — retry with more
            if not outline.strip() and sp.max_tokens:
                logger.warning("Empty outline from LLM — retrying with 2x tokens")
                resp = _chat_with_prompt(
                    llm,
                    sp.system,
                    sp.user,
                    json_mode=sp.json_mode,
                    max_tokens=sp.max_tokens * 2,
                )
                outline = resp.content
            if not outline.strip():
                logger.warning("LLM returned empty outline — using default")
                outline = _default_paper_outline(config.research.topic)
                outline_degraded = True
        except Exception as exc:  # noqa: BLE001
            outline_degraded = True
            logger.warning("Stage 16: outline LLM failed; using default outline: %s", exc)
            (stage_dir / "outline_generation_error_report.json").write_text(
                json.dumps({"error": str(exc), "generated": _utcnow_iso()}, indent=2),
                encoding="utf-8",
            )
            outline = _default_paper_outline(config.research.topic)
    else:
        outline = _default_paper_outline(config.research.topic)
    (stage_dir / "outline.md").write_text(outline, encoding="utf-8")
    return StageResult(
        stage=Stage.PAPER_OUTLINE,
        status=StageStatus.DONE,
        artifacts=(
            ("outline.md", "outline_generation_error_report.json")
            if outline_degraded
            else ("outline.md",)
        ),
        evidence_refs=(
            ("stage-16/outline.md", "stage-16/outline_generation_error_report.json")
            if outline_degraded
            else ("stage-16/outline.md",)
        ),
        decision="degraded" if outline_degraded else "proceed",
    )


def _collect_raw_experiment_metrics(run_dir: Path) -> tuple[str, bool]:
    """Collect raw experiment metric lines from stdout for paper writing.

    Returns a tuple of (formatted block, has_parsed_metrics).
    ``has_parsed_metrics`` is True when at least one run had a non-empty
    ``metrics`` dict in its JSON payload — a reliable signal of real data.
    """
    metric_lines: list[str] = []
    run_count = 0
    has_parsed_metrics = False

    for stage_subdir in sorted(run_dir.glob("stage-*/runs")):
        for run_file in sorted(stage_subdir.glob("*.json")):
            if run_file.name == "results.json":
                continue
            try:
                payload = json.loads(run_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if not isinstance(payload, dict):
                continue

            # R10: Skip simulated data — only collect real experiment results
            if payload.get("status") == "simulated":
                continue

            run_count += 1

            # Extract from parsed metrics (check both 'metrics' and 'key_metrics')
            metrics = payload.get("metrics", {}) or payload.get("key_metrics", {})
            if isinstance(metrics, dict) and metrics:
                has_parsed_metrics = True
                for k, v in metrics.items():
                    metric_lines.append(f"  {k}: {v}")

            # Also extract from stdout for full detail
            # BUG-23: Filter out infrastructure lines that are NOT experiment results
            _INFRA_KEYS = {
                "SEED_COUNT", "TIME_ESTIMATE", "TRAINING_STEPS",
                "REGISTERED_CONDITIONS", "METRIC_DEF", "GPU_MEMORY",
                "BATCH_SIZE", "NUM_WORKERS", "TOTAL_PARAMS",
                "time_budget_sec", "max_epochs", "num_seeds",
            }
            stdout = payload.get("stdout", "")
            if stdout:
                for line in stdout.splitlines():
                    line = line.strip()
                    if ":" in line:
                        parts = line.rsplit(":", 1)
                        try:
                            float(parts[1].strip())
                            key_part = parts[0].strip().split("/")[-1]  # last segment
                            if key_part in _INFRA_KEYS:
                                continue  # skip infrastructure lines
                            metric_lines.append(f"  {line}")
                        except (ValueError, TypeError, IndexError):
                            pass

    # R19-4 + R23-1: Collect metrics from refinement_log.json (Stage 13).
    # If refinement has richer data than Stage 12 runs/, REPLACE Stage 12 data
    # to avoid confusing the paper writer with conflicting sources.
    _refine_lines: list[str] = []
    _refine_run_count = 0
    # Scan ALL refinement logs across versions, pick by quality (primary
    # metric) then richness (metric count).  BUG-207: Previous logic picked
    # the sandbox entry with the most metric keys regardless of whether it
    # represented a regression (e.g. sandbox_after_fix with 1.29% accuracy
    # winning over sandbox with 78.93% because it had 6 more keys).
    _best_refine_metrics: dict[str, Any] = {}
    _best_refine_stdout = ""
    _best_refine_primary: float | None = None
    for _rl_path in sorted(run_dir.glob("stage-13*/refinement_log.json")):
        try:
            _rlog = json.loads(_rl_path.read_text(encoding="utf-8"))
            for _it in _rlog.get("iterations", []):
                for _sbx_key in ("sandbox", "sandbox_after_fix"):
                    _sbx = _it.get(_sbx_key, {})
                    if not isinstance(_sbx, dict):
                        continue
                    _sbx_metrics = _sbx.get("metrics", {})
                    if not isinstance(_sbx_metrics, dict) or not _sbx_metrics:
                        continue
                    # Extract primary metric value for quality comparison
                    _sbx_primary: float | None = None
                    for _pm_key in ("primary_metric", "best_metric"):
                        if _pm_key in _sbx_metrics:
                            try:
                                _sbx_primary = float(_sbx_metrics[_pm_key])
                            except (ValueError, TypeError):
                                pass
                            break
                    # Prefer higher primary metric; fall back to count
                    _dominated = False
                    if _best_refine_primary is not None and _sbx_primary is not None:
                        if _sbx_primary > _best_refine_primary:
                            _dominated = True  # new is better
                        elif _sbx_primary < _best_refine_primary * 0.5:
                            continue  # skip: regression (>50% worse)
                    # Accept if quality-dominant or richer-with-no-regression
                    if _dominated or len(_sbx_metrics) > len(_best_refine_metrics):
                        _best_refine_metrics = _sbx_metrics
                        _best_refine_stdout = _sbx.get("stdout", "")
                        _best_refine_primary = _sbx_primary
        except (json.JSONDecodeError, OSError):
            pass

    if _best_refine_metrics and len(_best_refine_metrics) > len(metric_lines) // 2:
        # Refinement has richer data — REPLACE Stage 12 data to avoid conflicts
        metric_lines = []
        run_count = 1
        for k, v in _best_refine_metrics.items():
            metric_lines.append(f"  {k}: {v}")
        # Also extract PAIRED and metric lines from stdout
        if _best_refine_stdout:
            for _line in _best_refine_stdout.splitlines():
                _line = _line.strip()
                if _line.startswith("PAIRED:"):
                    metric_lines.append(f"  {_line}")
                elif ":" in _line:
                    parts = _line.rsplit(":", 1)
                    try:
                        float(parts[1].strip())
                        metric_lines.append(f"  {_line}")
                    except (ValueError, TypeError, IndexError):
                        pass
    elif _best_refine_metrics:
        # Refinement has some data but not richer — append to existing
        run_count += 1
        for k, v in _best_refine_metrics.items():
            metric_lines.append(f"  {k}: {v}")
        if _best_refine_stdout:
            for _line in _best_refine_stdout.splitlines():
                _line = _line.strip()
                if _line.startswith("PAIRED:"):
                    metric_lines.append(f"  {_line}")

    if not metric_lines:
        return "", has_parsed_metrics

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for line in metric_lines:
        if line not in seen:
            seen.add(line)
            unique.append(line)

    # BUG-29: Reformat raw metric lines into human-readable condition summaries
    # to prevent LLM from pasting raw path-style lines into the paper
    _grouped: dict[str, list[str]] = {}
    _ungrouped: list[str] = []
    for line in unique[:200]:
        stripped = line.strip()
        # Match pattern: condition/env/step/metric: value
        parts = stripped.split("/")
        if len(parts) >= 3 and ":" in parts[-1]:
            cond = parts[0]
            detail = "/".join(parts[1:])
            _grouped.setdefault(cond, []).append(f"  - {detail}")
        else:
            _ungrouped.append(stripped)

    formatted_lines: list[str] = []
    if _grouped:
        for cond, details in sorted(_grouped.items()):
            formatted_lines.append(f"## Condition: {cond}")
            formatted_lines.extend(details[:30])
    if _ungrouped:
        formatted_lines.extend(_ungrouped)

    return (
        f"\n\nACTUAL EXPERIMENT DATA (from {run_count} run(s) — use ONLY these numbers):\n"
        "```\n"
        + "\n".join(formatted_lines[:200])
        + "\n```\n"
        "CRITICAL: Every number in the Results table MUST come from the data above. "
        "Do NOT round excessively, do NOT invent numbers, do NOT change values. "
        f"The experiment ran {run_count} time(s) — state this accurately in the methodology.\n"
        "NEVER paste raw metric paths (like 'condition/env/step/metric: value') "
        "into the paper. Always convert to formatted LaTeX tables or inline prose.\n"
    ), has_parsed_metrics


def _write_paper_sections(
    *,
    llm: LLMClient,
    pm: PromptManager,
    run_dir: Path | None = None,
    study_mode: str = "simulation",
    preamble: str,
    topic_constraint: str,
    exp_metrics_instruction: str,
    citation_instruction: str,
    outline: str,
    model_name: str = "",
) -> str:
    """Write a conference-grade paper in 3 sequential LLM calls.

    Call 1: Title + Abstract + Introduction + Related Work
    Call 2: Method + Experiments (with full experiment data)
    Call 3: Results + Discussion + Limitations + Conclusion

    Each call receives prior sections for coherence.
    """
    # Render writing_structure block for injection
    try:
        _writing_structure = pm.block("writing_structure")
    except (KeyError, Exception):  # noqa: BLE001
        _writing_structure = ""

    _overlay = _get_evolution_overlay(run_dir, "paper_draft")
    system = pm.for_stage(
        "paper_draft",
        evolution_overlay=_overlay,
        preamble=preamble,
        topic_constraint=topic_constraint,
        exp_metrics_instruction=exp_metrics_instruction,
        citation_instruction=citation_instruction,
        writing_structure=_writing_structure,
        outline=outline,
    ).system

    sections: list[str] = []
    study_mode = str(study_mode or "simulation").strip().lower() or "simulation"
    if study_mode == "simulation":
        study_mode_requirement = (
            "This run is simulation-only. Keep the Experiments section limited to synthetic/simulation design, "
            "parameter sweeps, and simulated results. Do not require application datasets or application-data results sections. "
            "Explicitly report simulation sample sizes, train/validation/test sizes when predictive models are simulated, and ablations over simulation setup parameters plus model tuning/search settings."
        )
        study_mode_experiment_instruction = (
            "Do not include application-data subsections unless real application data were provided. "
            "For simulation-only work, report simulation sample sizes, regime factors, train/test split sizes when applicable, random seeds, and ablations over sample size, simulation setup parameters, and model tuning/search settings.\n"
        )
    elif study_mode == "application":
        study_mode_requirement = (
            "This run is application-only. Center the Experiments section on uploaded real-world datasets, "
            "missing-value handling, preprocessing, and per-dataset reporting. Do not invent a simulation-study subsection "
            "unless it is explicitly used as a small validation check. Explicitly report application sample size, training size, validation size if used, test size, and model-tuning ablations."
        )
        study_mode_experiment_instruction = (
            "If study mode is application-only, include a dedicated subsection for missing-value handling and describe exactly "
            "how missing values were replaced or imputed. If multiple application datasets are used, give each dataset a generic "
            "name and report sample size, training/test split sizes, results, and interpretation separately for each. "
            "Ablation must focus on model tuning/search settings and scientifically meaningful preprocessing/model variants.\n"
        )
    else:
        study_mode_requirement = (
            "This run is both simulation and application. Include separate simulation-study and application-data tracks, "
            "each with its own datasets, sample sizes, training/test sizes, tables, figures, runtime analysis, interpretation, and ablation focus."
        )
        study_mode_experiment_instruction = (
            "If study mode is Both, include a simulation-study subsection and an application-data subsection, each with its own "
            "tables/figures/runtime analysis/interpretation. Simulation ablations must vary sample sizes, simulation setup parameters, and model tuning; application ablations must focus on model tuning/search settings and scientifically meaningful preprocessing/model variants.\n"
        )

    # --- R4-3: Title guidelines and abstract structure ---
    try:
        title_guidelines = pm.block("title_guidelines")
    except (KeyError, Exception):  # noqa: BLE001
        title_guidelines = ""
    try:
        abstract_structure = pm.block("abstract_structure")
    except (KeyError, Exception):  # noqa: BLE001
        abstract_structure = ""

    # IMP-20/25/31/24: Academic style, narrative, anti-hedging, anti-repetition
    try:
        academic_style_guide = pm.block("academic_style_guide")
    except (KeyError, Exception):  # noqa: BLE001
        academic_style_guide = ""
    try:
        narrative_writing_rules = pm.block("narrative_writing_rules")
    except (KeyError, Exception):  # noqa: BLE001
        narrative_writing_rules = ""
    try:
        anti_hedging_rules = pm.block("anti_hedging_rules")
    except (KeyError, Exception):  # noqa: BLE001
        anti_hedging_rules = ""
    try:
        anti_repetition_rules = pm.block("anti_repetition_rules")
    except (KeyError, Exception):  # noqa: BLE001
        anti_repetition_rules = ""

    # --- Call 1: Title + Abstract + Introduction + Related Work ---
    call1_user = (
        f"{preamble}\n\n"
        f"{topic_constraint}"
        f"{citation_instruction}\n\n"
        f"{title_guidelines}\n\n"
        f"{academic_style_guide}\n"
        f"{narrative_writing_rules}\n"
        f"{anti_hedging_rules}\n"
        f"{anti_repetition_rules}\n\n"
        "Write the following sections of a NeurIPS/ICML-quality paper in markdown. "
        "Follow the LENGTH REQUIREMENTS strictly:\n\n"
        "1. **Title** (HARD RULE: preserve the exact user topic phrase verbatim. Do NOT "
        "invent a catchy method name, acronym, or framework title. If brevity conflicts with "
        "topic fidelity, preserve the topic exactly. NEVER use 'Untitled Paper'.)\n"
        f"2. **Abstract** (150-220 words — HARD LIMIT. Do NOT exceed 220 words. "
        f"Do NOT include raw metric paths or 16-digit decimals. The abstract MUST lead with the problem, the scientific gap, and the study contribution; it MUST define what problem the topic addresses; it MUST report the strongest comparative finding in a submission-ready way; and it MUST NOT foreground protocol logistics, run counts, or output limitations unless those belong in Limitations.){abstract_structure}\n"
        "3. **Introduction** (800-1000 words): real-world motivation, problem statement, "
        "research gap analysis with citations, method overview, 3-4 contributions as bullet points, "
        "paper organization paragraph. MUST cite 10-15 references. The gap paragraph must explicitly name the most relevant prior studies, explain exactly why they are insufficient for this topic, and state precisely how this study closes that gap through a novel or refined methodological idea. The Introduction must not read like a short conference summary: it should define the research context, explain the theoretical and practical importance of the problem, clarify the stakes of the topic, and build a coherent narrative from motivation to gap to contribution. Include enough detail that a reader understands why the problem matters and why the chosen approach is scientifically justified.\n"
        "4. **Related Work** (1200-1600 words): organized into 4-6 thematic subsections, each discussing "
        "5-8 papers with proper citations. The section MUST synthesize at least 18 distinct references, compare approaches critically, identify methodological limitations, describe dataset/evaluation differences, and position this work precisely. End with a synthesis-and-gap paragraph that reads like expert scholarly judgment, not a broad survey summary. Related Work should be organized by method family, assumptions, and scientific tradeoffs, not as a list of citations. Every subsection should explain what the prior work assumes, what it achieves, what it misses, and why those misses matter for the present study.\n\n"
        f"Outline:\n{outline}\n\n"
        "Output markdown with ## headers. Do NOT include a References section.\n"
        "IMPORTANT: Start DIRECTLY with '## Title'. Do NOT include any preamble, "
        "data verification, condition listing, or metric enumeration before the title. "
        "The paper should read like a published manuscript, not a data report."
    )
    # R14-1: Higher token limit for reasoning models
    _paper_max_tokens = 12000
    if any(model_name.startswith(p) for p in ("gpt-5", "o3", "o4")):
        _paper_max_tokens = 24000

    # T3.5: Retry once on failure, use placeholder if still fails
    try:
        resp1 = _chat_with_prompt(llm, system, call1_user, max_tokens=_paper_max_tokens, retries=1)
        part1 = resp1.content.strip()
    except Exception:  # noqa: BLE001
        logger.error("Stage 17: Part 1 LLM call failed after retry — using placeholder")
        part1 = (
            "## Title\n[PLACEHOLDER — LLM call failed]\n\n"
            "## Abstract\n[This section could not be generated due to an LLM error. "
            "Please regenerate this stage.]\n\n"
            "## Introduction\n[PLACEHOLDER]\n\n"
            "## Related Work\n[PLACEHOLDER]"
        )
    sections.append(part1)
    logger.info("Stage 17: Part 1 (Title+Abstract+Intro+Related Work) — %d chars", len(part1))

    # --- Call 2: Method + Experiments ---
    call2_user = (
        f"{preamble}\n\n"
        f"{topic_constraint}"
        f"{exp_metrics_instruction}\n\n"
        f"{narrative_writing_rules}\n"
        f"{anti_hedging_rules}\n\n"
        # IMP-21: Citation instruction for Method + Experiments
        "CITATION REQUIREMENT: The Method section MUST cite at least 6-10 related "
        "technical papers (foundations your method builds on). The Experiments section "
        "MUST cite baseline method papers and evaluation-protocol references where appropriate. Use [cite_key] syntax.\n"
        f"{citation_instruction}\n\n"
        "You are continuing a paper. The sections written so far are:\n\n"
        f"---\n{part1}\n---\n\n"
        f"STUDY-MODE REQUIREMENT: {study_mode_requirement}\n\n"
        "Now write the next sections, maintaining consistency with the above:\n\n"
        "5. **Method** (1800-2600 words): formal problem definition with mathematical notation "
        "($x$, $\\theta$, etc.), detailed algorithm description with equations, step-by-step procedure, "
        "complexity analysis, design rationale for key choices. Include algorithm pseudocode if applicable. "
        "Write as FLOWING PROSE — do NOT use bullet-point lists for method components. "
        "The method must stay explicitly tied to the exact user topic rather than a renamed framework. Include modeling assumptions, parameter definitions, preprocessing design, estimation or optimization details, calibration or thresholding procedure when relevant, inference procedure, reproducibility-critical implementation details, and the reasoning linking these choices to the topic and prior-work gap. For every model or submodel, state the governing equations, define all symbols, give the assumptions under which the model is valid, derive the parameter estimates or estimators step by step, and explain how any non-estimable quantities are obtained in practice. If a closed-form estimate does not exist, state the numerical or statistical procedure used instead and why it is appropriate. Explicitly state the distributional form whenever a distribution is assumed or implied, and explain the practical interpretation of the model both in theory and in the experimental setting. Add a dedicated subsection on parameter identifiability (what is identifiable, assumptions required, and what is not identifiable) and a dedicated subsection on bias-variance trade-off linked to model complexity and data regime.\n"
        "   Methodology checklist (apply items relevant to the topic): main idea and model formulation, novelty/refinement relative to prior methods, assumptions, equations, priors/likelihood/parameters or algorithm details, inference or optimization procedure, method appropriateness, theoretical/computational motivation, computational complexity, and derivations/proofs/full conditionals plus algorithm blocks when needed for reproducibility and rigor. Use coherent subsections and subsubsections; do NOT create a standalone section that merely lists generated figures or says figures are included for completeness.\n"
        "6. **Experiments** (1000-1400 words): detailed experimental setup, datasets with statistics "
        "(size, splits, features), all baselines and their implementations, hyperparameter settings "
        "in a markdown table, evaluation metrics with mathematical definitions, hardware and runtime info. Explicitly state preprocessing, dataset suitability, sample-size regimes, and why each evaluation condition is scientifically informative. "
        "For every model, baseline, or estimator named in the paper, define the model equation or decision rule, response/target, assumptions, objective/loss or likelihood, hyperparameters, tuning/search space, selected values, diagnostics, and practical interpretation. "
        "For continuous-response prediction, define MAE, MSE, RMSE, R2, and any additional reported regression metric with formula, direction, units/scale, and scientific interpretation before Results uses it. "
        "If the study predicts a categorical response, explicitly state that the final paper should include: feature-inclusion probability/feature-importance figure (x-axis probability of inclusion, y-axis variables), confusion matrix, ROC curve, Accuracy/F1/Precision/Recall/ROC-AUC comparison figures, and an 80/20 train/test k-fold cross-validation boxplot when the required outputs are available. "
        "For every metric present in the results, provide a formula, direction, units/scale, and interpretation before the metric is used in Results. Metric tables must contain only actual reported numeric values; if a value is unavailable, the correctness gate should produce a diagnostic instead of a final manuscript. "
        "Ablation analysis MUST include sample-size regimes and hyperparameter/tuning variants when feasible; do not present cosmetic or arbitrary ablations that do not change sample size, tuning/search budget, model component, or preprocessing. "
        f"{study_mode_experiment_instruction}"
        "METHOD NAMES IN TABLES: Use SHORT abbreviations (4-8 chars) for method names "
        "in tables. Define abbreviation mappings in a footnote. "
        "NEVER put method names longer than 20 characters in table cells.\n\n"
        f"Outline:\n{outline}\n\n"
        "Output markdown with ## headers. Continue from where Part 1 ended."
    )
    try:
        resp2 = _chat_with_prompt(llm, system, call2_user, max_tokens=_paper_max_tokens, retries=1)
        part2 = resp2.content.strip()
    except Exception:  # noqa: BLE001
        logger.error("Stage 17: Part 2 LLM call failed after retry — using placeholder")
        part2 = (
            "## Method\n[PLACEHOLDER — LLM call failed. Please regenerate this stage.]\n\n"
            "## Experiments\n[PLACEHOLDER]"
        )
    sections.append(part2)
    logger.info("Stage 17: Part 2 (Method+Experiments) — %d chars", len(part2))

    # --- Call 3: Results + Discussion + Limitations + Conclusion ---
    call3_user = (
        f"{preamble}\n\n"
        f"{topic_constraint}"
        f"{exp_metrics_instruction}\n\n"
        f"{narrative_writing_rules}\n"
        f"{anti_hedging_rules}\n"
        f"{anti_repetition_rules}\n\n"
        # IMP-21: Citation instruction for Results + Discussion + Conclusion
        "CITATION REQUIREMENT: The Discussion section MUST cite at least 3-5 papers "
        "when comparing findings with prior work. The Conclusion may cite 1-2 "
        "foundational references.\n"
        f"{citation_instruction}\n\n"
        "You are completing a paper. The sections written so far are:\n\n"
        f"---\n{part1}\n\n{part2}\n---\n\n"
        "Now write the final sections, maintaining consistency:\n\n"
        "7. **Results** (600-800 words):\n"
        "   - START with an AGGREGATED comparative results table (Table 1): rows = methods/conditions, columns = key metrics and datasets or regimes where appropriate.\n"
        "     Do NOT create a result table with only one body row; if only one method/condition/sample-size regime is available, report the scalar result in prose and state that comparative evidence is unavailable.\n"
        "     Each cell should report the primary estimate and any available uncertainty summary (CI, std, or other justified dispersion measure). Bold the best value per column.\n"
        "     EVERY table MUST have a descriptive caption that allows understanding without "
        "     reading the main text. NEVER use just 'Table 1' as a caption.\n"
        f"   - {('Do not invent an application-data subsection.' if study_mode == 'simulation' else 'Center the results on application datasets and missing-value handling.' if study_mode == 'application' else 'Include both simulation and application-data subsections, and keep them separate.') }\n"
        "   - Follow with a PER-DATASET or PER-SAMPLE-SIZE table (Table 2) showing where gains are strong, weak, or inconsistent.\n"
        "   - Include a STATISTICAL or EFFECT-SIZE comparison table (Table 3) when the evidence supports it; otherwise provide comparative deltas and dataset-linked interpretation.\n"
        "   - Include a dedicated **Model Diagnostics** subsection that pre-explains which diagnostics are necessary for this model class and why, reports those diagnostics, interprets what they show, and states whether model assumptions appear supported or violated.\n"
        "   - For categorical-response prediction, include and interpret all required visuals/tables generated from outputs: feature-inclusion probability figure, confusion matrix, ROC curve, Accuracy comparison, F1 comparison, Precision comparison, Recall comparison, ROC-AUC comparison, and 80/20 k-fold cross-validation boxplot.\n"
        "   - For continuous-response prediction, include and interpret generated regression metrics and diagnostics: MAE, MSE, RMSE, R2, predicted-versus-observed plot, residual plot/distribution, feature-inclusion probability figure when interpretable, and an 80/20 k-fold metric boxplot.\n"
        "   - Include an Ablation subsection that compares sample-size regimes and tuning/search-budget variants. Avoid arbitrary ablation names that do not map to a real experimental factor.\n"
        "   - NEVER dump raw log paths or raw replicate traces in the main text. Aggregate first, then discuss the scientific meaning.\n"
        "   - MUST include at least 2 figures using markdown image syntax: ![Caption](charts/filename.png)\n"
        "     One figure MUST be a performance comparison chart. Figures MUST be referenced "
        "     in text: 'As shown in Figure 1, ...'\n"
        "     Do NOT include a result bar figure with only one bar; result figures must compare at least two methods, conditions, datasets, or sample-size regimes for the metric.\n"
        "8. **Discussion** (500-800 words): The Discussion must answer 'So what do the results mean?' and contain clear subsections: Main Findings, Interpretation, Comparison with Existing Work, Contribution, Practical/Scientific Implications, Limitations, and Future Work. Do not just repeat results. "
        "Include comparison with prior work (CITE 3-5 papers here!) and explain agreements/disagreements with reasons.\n"
        "9. **Limitations** (200-300 words): honest assessment of scope, dataset, methodology. "
        "ALL caveats consolidated HERE — nowhere else in the paper.\n"
        "10. **Conclusion** (150-260 words): The Conclusion must answer 'What is the final takeaway?' and include: brief restatement of the problem, core achievement, strongest supporting evidence, final contribution, and future directions that are specific to methodology, benchmarks, theory, and deployment. "
        "Do NOT repeat long numeric dumps from Results. Keep the exact user topic framing rather than an invented replacement title.\n\n"
        "CRITICAL FORMATTING RULES FOR ALL SECTIONS:\n"
        "- Write as FLOWING PROSE paragraphs, NOT bullet-point lists\n"
        "- NEVER dump raw metric paths like 'config/method_name/seed_3/primary_metric'\n"
        "- All numbers must be rounded to 4 decimal places maximum\n"
        "- Every table MUST have a descriptive caption (not just 'Table 1')\n"
        "- Every table MUST have at least two body rows. One-row tables are invalid; use prose instead.\n"
        "- Every result bar figure MUST have at least two bars/categories. One-bar result figures are invalid.\n"
        "- Every equation, figure, and table MUST be numbered and cross-referenced in prose before or immediately after it appears\n"
        "- Do not create an 'Additional Visual Summaries' section or any boilerplate list saying 'Figure X provides a visual summary'; integrate figures into the relevant Method, Experiments, Results, or Ablation subsection\n"
        "- Do not use internal pipeline storage terms in the final paper; write 'figure', 'table', 'output', 'diagnostic', or 'result' instead\n"
        "- Use \\begin{algorithm} or pseudocode notation, NOT \\begin{verbatim}\n\n"
        "Output markdown with ## headers. Do NOT include a References section."
    )
    try:
        resp3 = _chat_with_prompt(llm, system, call3_user, max_tokens=_paper_max_tokens, retries=1)
        part3 = resp3.content.strip()
    except Exception:  # noqa: BLE001
        logger.error("Stage 17: Part 3 LLM call failed after retry — using placeholder")
        part3 = (
            "## Results\n[PLACEHOLDER — LLM call failed. Please regenerate this stage.]\n\n"
            "## Discussion\n[PLACEHOLDER]\n\n"
            "## Limitations\n[PLACEHOLDER]\n\n"
            "## Conclusion\n[PLACEHOLDER]"
        )
    sections.append(part3)
    logger.info("Stage 17: Part 3 (Results+Discussion+Limitations+Conclusion) — %d chars", len(part3))

    # Combine all sections
    draft = "\n\n".join(sections)

    # R32: Strip data verification preamble that LLMs sometimes emit before
    # the actual paper.  The preamble typically starts with "## Tested Conditions"
    # or similar headings and ends before "## Title".
    import re as _re_strip
    _title_match = _re_strip.search(r"^## Title\b", draft, _re_strip.MULTILINE)
    if _title_match and _title_match.start() > 200:
        _stripped = draft[_title_match.start():]
        logger.info(
            "R32: Stripped %d-char preamble before '## Title'",
            _title_match.start(),
        )
        draft = _stripped

    total_words = len(draft.split())
    logger.info("Stage 17: Full draft — %d chars, ~%d words", len(draft), total_words)

    return draft


# ---------------------------------------------------------------------------
# Draft quality validation (section balance + bullet-point density)
# ---------------------------------------------------------------------------

# Sections where bullets/numbered lists are acceptable.
_BULLET_LENIENT_SECTIONS = frozenset({
    "introduction", "limitations", "limitation",
    "limitations and future work", "abstract",
})

# Main body sections used for balance ratio check.
_BALANCE_SECTIONS = frozenset({
    "introduction", "related work", "method", "experiments", "results",
    "discussion",
})


def _validate_draft_quality(
    draft: str,
    stage_dir: Path | None = None,
    exp_summary_parsed: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate a paper draft for section balance and prose quality.

    Checks:
    1. Per-section word count vs ``SECTION_WORD_TARGETS``.
    2. Bullet-point / numbered-list density per section.
    3. Largest-to-smallest main-section word-count ratio.

    Returns a dict with ``section_analysis``, ``overall_warnings``, and
    ``revision_directives``.  Optionally writes ``draft_quality.json`` to
    *stage_dir*.
    """
    from researchclaw.prompts import SECTION_WORD_TARGETS, _SECTION_TARGET_ALIASES

    _heading_re = re.compile(r"^(#{1,4})\s+(.+)$", re.MULTILINE)
    matches = list(_heading_re.finditer(draft))

    sections_data: list[dict[str, Any]] = []
    for i, m in enumerate(matches):
        level = len(m.group(1))
        heading = m.group(2).strip()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(draft)
        body = draft[start:end].strip()
        sections_data.append({
            "heading": heading,
            "heading_lower": heading.strip().lower(),
            "level": level,
            "body": body,
        })

    section_analysis: list[dict[str, Any]] = []
    overall_warnings: list[str] = []
    revision_directives: list[str] = []
    main_section_words: dict[str, int] = {}

    _bullet_re = re.compile(r"^\s*[-*]\s+", re.MULTILINE)
    _numbered_re = re.compile(r"^\s*\d+\.\s+", re.MULTILINE)

    def _looks_like_placeholder(value: Any) -> bool:
        text = str(value or "").strip().lower()
        if not text:
            return True
        return any(token in text for token in (
            "specify",
            "state ",
            "add cite",
            "canonical paper",
            "provide theoretical",
            "if novel",
        ))

    def _get_main_section_bodies(*names: str) -> str:
        wanted = {name.lower() for name in names}
        collected: list[str] = []
        for sec in sections_data:
            if sec["level"] <= 2 and sec["heading_lower"] in wanted:
                body_parts = [sec["body"]]
                body_parts.extend(
                    child["body"]
                    for child in sections_data
                    if child["level"] > 2
                    and _section_parent.get(id(child), "") == sec["heading_lower"]
                )
                collected.append("\n\n".join(part for part in body_parts if part))
        return "\n\n".join(collected)

    # BUG-24: Accumulate subsection (H3+) word counts into parent H2 sections
    _subsection_words: dict[str, int] = {}
    _current_parent = ""
    _section_parent: dict[int, str] = {}
    for sec in sections_data:
        if sec["level"] <= 2:
            _current_parent = sec["heading_lower"]
            _subsection_words.setdefault(_current_parent, 0)
        else:
            _section_parent[id(sec)] = _current_parent
            # Add subsection words to parent
            _subsection_words[_current_parent] = (
                _subsection_words.get(_current_parent, 0) + len(sec["body"].split())
            )

    for sec in sections_data:
        if sec["level"] > 2:
            continue
        heading_lower: str = sec["heading_lower"]
        body: str = sec["body"]
        # BUG-24: Include subsection words in the parent's word count
        word_count = len(body.split()) + _subsection_words.get(heading_lower, 0)
        canon = heading_lower
        if canon not in SECTION_WORD_TARGETS:
            canon = _SECTION_TARGET_ALIASES.get(heading_lower, "")
        entry: dict[str, Any] = {
            "heading": sec["heading"],
            "word_count": word_count,
            "canonical": canon,
        }
        if canon and canon in SECTION_WORD_TARGETS:
            lo, hi = SECTION_WORD_TARGETS[canon]
            entry["target"] = [lo, hi]
            if word_count < int(lo * 0.7):
                overall_warnings.append(
                    f"{sec['heading']} is severely under target "
                    f"({word_count} words, target {lo}-{hi})"
                )
                revision_directives.append(
                    f"EXPAND {sec['heading']} from {word_count} to {lo}+ words. "
                    f"Add substantive content \u2014 do NOT pad with filler."
                )
                entry["status"] = "severely_short"
            elif word_count < lo:
                overall_warnings.append(
                    f"{sec['heading']} is under target "
                    f"({word_count} words, target {lo}-{hi})"
                )
                revision_directives.append(
                    f"Expand {sec['heading']} from {word_count} to {lo}+ words."
                )
                entry["status"] = "short"
            elif word_count > int(hi * 1.3):
                overall_warnings.append(
                    f"{sec['heading']} exceeds target "
                    f"({word_count} words, target {lo}-{hi})"
                )
                revision_directives.append(
                    f"Compress {sec['heading']} from {word_count} to {hi} words or fewer."
                )
                entry["status"] = "long"
            else:
                entry["status"] = "ok"
        if body:
            total_lines = len([ln for ln in body.splitlines() if ln.strip()])
            bullet_lines = len(_bullet_re.findall(body)) + len(_numbered_re.findall(body))
            density = bullet_lines / total_lines if total_lines > 0 else 0.0
            entry["bullet_density"] = round(density, 2)
            threshold = 0.50 if heading_lower in _BULLET_LENIENT_SECTIONS else 0.25
            if density > threshold and total_lines >= 4:
                overall_warnings.append(
                    f"{sec['heading']} has {bullet_lines}/{total_lines} "
                    f"bullet/numbered lines ({density:.0%} density, "
                    f"threshold {threshold:.0%})"
                )
                revision_directives.append(
                    f"REWRITE {sec['heading']} as flowing academic prose. "
                    f"Convert bullet points to narrative paragraphs."
                )
                entry["bullet_status"] = "high"
            else:
                entry["bullet_status"] = "ok"
        canon_balance = canon or heading_lower
        if canon_balance in _BALANCE_SECTIONS:
            main_section_words[canon_balance] = word_count
        section_analysis.append(entry)

    if len(main_section_words) >= 2:
        wc_values = list(main_section_words.values())
        max_wc = max(wc_values)
        min_wc = min(wc_values)
        if min_wc > 0 and max_wc / min_wc > 3.0:
            largest = max(main_section_words, key=main_section_words.get)  # type: ignore[arg-type]
            smallest = min(main_section_words, key=main_section_words.get)  # type: ignore[arg-type]
            overall_warnings.append(
                f"Section imbalance: {largest} ({max_wc} words) vs "
                f"{smallest} ({min_wc} words) \u2014 ratio {max_wc / min_wc:.1f}x"
            )
            revision_directives.append(
                f"Rebalance sections: expand {smallest} and/or compress {largest} "
                f"to achieve more even section lengths."
            )

    # --- C-4/C-5: Citation count and recency checks ---
    _cite_pattern = re.compile(r"\[([a-zA-Z][a-zA-Z0-9_-]*\d{4}[a-zA-Z0-9]*)\]")
    cited_keys = set(_cite_pattern.findall(draft))
    if cited_keys:
        n_citations = len(cited_keys)
        if n_citations < 31:
            overall_warnings.append(
                f"Only {n_citations} unique citations found (target: >30 for a journal-grade full paper)"
            )
            revision_directives.append(
                f"Add more references — a strong scientific paper typically cites 35-60 works when the literature supports it. "
                f"Currently only {n_citations} unique citations."
            )
        elif n_citations < 35:
            overall_warnings.append(
                f"Citation coverage is still light for a high-index paper: {n_citations} unique citations (preferred: >=35)"
            )
        # Check recency: count citations with year >= current_year - 2
        _year_pat = re.compile(r"(\d{4})")
        import datetime as _dt_cit
        _cur_year = _dt_cit.datetime.now().year
        recent_count = sum(
            1 for k in cited_keys
            for m in [_year_pat.search(k)]
            if m and int(m.group(1)) >= _cur_year - 2
        )
        recency_ratio = recent_count / n_citations if n_citations > 0 else 0.0
        if recency_ratio < 0.4 and n_citations >= 10:
            overall_warnings.append(
                f"Citation recency low: only {recent_count}/{n_citations} "
                f"({recency_ratio:.0%}) from last 3 years (target: >=40%%)"
            )
    else:
        overall_warnings.append(
            "No in-text citations found — a scientific paper requires literature support throughout the manuscript"
        )
        revision_directives.append(
            "ADD in-text citations across Introduction, Related Work, Method, Experiments, and Discussion using the verified bibliography."
        )

    # --- Abstract and Conclusion length enforcement ---
    for sec in sections_data:
        hl = sec["heading_lower"]
        body_text: str = sec["body"]
        wc = len(body_text.split())
        if hl == "abstract" and wc > 250:
            overall_warnings.append(
                f"Abstract is too long: {wc} words (target: 150-220 words)"
            )
            revision_directives.append(
                f"COMPRESS the Abstract from {wc} to 150-220 words. "
                f"Remove raw metric values, redundant context, and self-references."
            )
        if hl in ("conclusion", "conclusions", "conclusion and future work"):
            if wc > 300:
                overall_warnings.append(
                    f"Conclusion is too long: {wc} words (target: 150-260 words)"
                )
                revision_directives.append(
                    f"COMPRESS the Conclusion from {wc} to 150-260 words. "
                    f"Do NOT repeat specific metric values from Results. "
                    f"Include: brief problem restatement, core achievement, strongest supporting evidence, "
                    f"final contribution, and a strong closing impact sentence."
                )

    # --- Raw metric path detection (log dumps in prose) ---
    _raw_path_re = re.compile(
        r"\\texttt\{[a-zA-Z0-9_/.-]+(?:/[a-zA-Z0-9_/.-]+){2,}",
    )
    raw_path_count = len(_raw_path_re.findall(draft))
    if raw_path_count > 3:
        overall_warnings.append(
            f"Raw metric paths in prose: {raw_path_count} instances of "
            f"\\texttt{{config/path/metric}} style dumps"
        )
        revision_directives.append(
            "REMOVE raw experiment log paths from prose. Replace "
            "\\texttt{config/metric/path} with human-readable metric names "
            "and summarize values in tables, not inline text."
        )

    # --- Writing quality lint ---
    _weasel_words = re.compile(
        r"\b(various|many|several|quite|fairly|really|very|rather|"
        r"somewhat|relatively|arguably|interestingly|importantly|"
        r"it is well known that|it is obvious that|clearly)\b",
        re.IGNORECASE,
    )
    _duplicate_words = re.compile(r"\b(\w+)\s+\1\b", re.IGNORECASE)
    weasel_count = len(_weasel_words.findall(draft))
    dup_matches = _duplicate_words.findall(draft)
    dup_count = len([d for d in dup_matches if d.lower() not in ("that", "had")])
    if weasel_count > 20:
        overall_warnings.append(
            f"High weasel-word count: {weasel_count} instances "
            f"(consider replacing vague words with precise language)"
        )
        revision_directives.append(
            "Replace vague hedging words (various, several, quite, fairly, "
            "rather, somewhat) with precise quantities or remove them."
        )
    if dup_count > 0:
        overall_warnings.append(
            f"Duplicate adjacent words found: {dup_count} instance(s) "
            f"(e.g., 'the the', 'is is')"
        )
        revision_directives.append(
            "Fix duplicate adjacent words (likely typos)."
        )

    # --- Structural checks: diagnostics + discussion/conclusion scaffolding ---
    _results_body = _get_main_section_bodies("results", "results and discussion", "experimental results")
    if _results_body:
        if not re.search(r"\bmodel diagnostics?\b", _results_body, re.IGNORECASE):
            overall_warnings.append(
                "Results section is missing an explicit 'Model Diagnostics' subsection"
            )
            revision_directives.append(
                "ADD a dedicated 'Model Diagnostics' subsection in Results that pre-specifies necessary diagnostics, "
                "reports diagnostic outcomes, interprets them, and concludes whether model assumptions are supported."
            )

    _discussion_body = _get_main_section_bodies("discussion")
    if _discussion_body:
        _required_disc_heads = [
            "main findings",
            "interpretation",
            "comparison with existing work",
            "contribution",
            "practical",
            "limitations",
            "future work",
        ]
        _missing_disc = [h for h in _required_disc_heads if h not in _discussion_body.lower()]
        if len(_missing_disc) >= 3:
            overall_warnings.append(
                "Discussion lacks the requested subsection-style structure (main findings/interpretation/comparison/contribution/implications/limitations/future work)"
            )
            revision_directives.append(
                "RESTRUCTURE Discussion using clear subsection headings: Main Findings, Interpretation, Comparison with Existing Work, "
                "Contribution, Practical/Scientific Implications, Limitations, and Future Work."
            )

    _conclusion_body = _get_main_section_bodies("conclusion", "conclusions")
    if _conclusion_body:
        _required_conc_terms = [
            "problem",
            "achievement",
            "evidence",
            "contribution",
            "impact",
        ]
        _missing_conc = [t for t in _required_conc_terms if t not in _conclusion_body.lower()]
        if len(_missing_conc) >= 2:
            overall_warnings.append(
                "Conclusion may be missing required final-takeaway elements (problem, achievement, evidence, contribution, impact)"
            )
            revision_directives.append(
                "REWRITE Conclusion to include: brief problem restatement, core achievement, strongest evidence, final contribution, and a strong impact-oriented closing sentence."
            )

    # --- AI-slop / boilerplate detection ---
    _BOILERPLATE_PHRASES = [
        "delves into", "delve into", "it is worth noting",
        "it should be noted", "it is important to note",
        "leverage the power of", "leverages the power of",
        "in this paper, we propose", "in this work, we propose",
        "to the best of our knowledge",
        "in the realm of", "in the landscape of",
        "plays a crucial role", "plays a pivotal role",
        "groundbreaking", "cutting-edge", "state-of-the-art",
        "game-changing", "paradigm shift",
        "a myriad of", "a plethora of",
        "aims to bridge the gap", "bridge the gap",
        "shed light on", "sheds light on",
        "pave the way", "paves the way",
        "the advent of", "with the advent of",
        "in recent years", "in recent times",
        "has gained significant attention",
        "has attracted considerable interest",
        "has emerged as a promising",
        "a comprehensive overview",
        "a holistic approach", "holistic understanding",
        "showcasing the efficacy", "demonstrate the efficacy",
        "multifaceted", "underscores the importance",
        "navigate the complexities",
        "harness the potential", "harnessing the power",
        "it is imperative to", "it is crucial to",
        "a nuanced understanding", "nuanced approach",
        "robust and scalable", "seamlessly integrates",
        "the intricacies of", "intricate interplay",
        "facilitate a deeper understanding",
        "a testament to",
    ]
    draft_lower = draft.lower()
    boilerplate_hits: list[str] = []
    for phrase in _BOILERPLATE_PHRASES:
        count = draft_lower.count(phrase)
        if count > 0:
            boilerplate_hits.extend([phrase] * count)
    if len(boilerplate_hits) > 5:
        unique_phrases = sorted(set(boilerplate_hits))[:5]
        overall_warnings.append(
            f"AI boilerplate detected: {len(boilerplate_hits)} instances "
            f"of generic LLM phrases (e.g., {', '.join(repr(p) for p in unique_phrases[:3])})"
        )
        revision_directives.append(
            "REWRITE sentences containing AI-generated boilerplate phrases. "
            "Replace generic language (e.g., 'delves into', 'it is worth noting', "
            "'leverages the power of', 'plays a crucial role', 'paves the way') "
            "with precise, specific academic language."
        )

    # --- Introduction contribution / gap check ---
    intro_body = _get_main_section_bodies("introduction")
    if intro_body and len(intro_body.split()) > 80:
        _gap_keywords = re.compile(
            r"\b(gap|limitation|limitations|fails?|fall short|shortcoming|insufficient|"
            r"unresolved|underexplored|missing|overlooked|inadequate|weakness)\b",
            re.IGNORECASE,
        )
        _contrib_keywords = re.compile(
            r"\b(contribution|contributions|we propose|we study|we show|we demonstrate|"
            r"this study|this work addresses|we address)\b",
            re.IGNORECASE,
        )
        _gap_hits = len(_gap_keywords.findall(intro_body))
        _contrib_hits = len(_contrib_keywords.findall(intro_body))
        if _gap_hits < 2 or _contrib_hits < 2:
            overall_warnings.append(
                "Introduction does not make the contribution and prior-work gap sufficiently explicit"
            )
            revision_directives.append(
                "STRENGTHEN the Introduction with a sharper gap paragraph that names the most relevant prior studies, "
                "explains exactly where they fail on this topic, and states precisely how this study improves on them."
            )

    # --- Related work depth check ---
    _rw_headings = {"related work", "related works", "background", "literature review"}
    rw_body = _get_main_section_bodies("related work", "related works", "background", "literature review")
    if rw_body and len(rw_body.split()) > 50:
        rw_word_count = len(rw_body.split())
        rw_citations = set(_cite_pattern.findall(rw_body))
        rw_subsections = sum(
            1
            for sec in sections_data
            if sec["heading_lower"] not in _rw_headings
            and sec["level"] >= 3
            and _section_parent.get(id(sec), "") in _rw_headings
        )
        _comparative_pats = re.compile(
            r"\b(unlike|in contrast|whereas|while .+ focus|"
            r"however|differ(?:s|ent)|our (?:method|approach) .+ instead|"
            r"we (?:instead|differ)|compared to|as opposed to|"
            r"goes beyond|extends|improves upon|addresses the limitation)\b",
            re.IGNORECASE,
        )
        sentences = [s.strip() for s in re.split(r"[.!?]+", rw_body) if s.strip()]
        comparative_sents = sum(1 for s in sentences if _comparative_pats.search(s))
        ratio = comparative_sents / len(sentences) if sentences else 0.0
        if rw_word_count < 1000:
            overall_warnings.append(
                f"Related Work is too short for a publication-grade paper: {rw_word_count} words (target: >=1000)"
            )
            revision_directives.append(
                "EXPAND Related Work into a deeper expert synthesis with thematic subsections, stronger comparison, and more direct engagement with prior studies."
            )
        if len(rw_citations) < 12:
            overall_warnings.append(
                f"Related Work cites only {len(rw_citations)} distinct references (target: >=12 minimum, preferably >=18)"
            )
            revision_directives.append(
                "ENRICH Related Work with more directly relevant citations and compare papers by dataset, modeling assumptions, evaluation protocol, and limitations."
            )
        if rw_subsections < 3:
            overall_warnings.append(
                f"Related Work has only {rw_subsections} thematic subsections (target: >=3)"
            )
            revision_directives.append(
                "RESTRUCTURE Related Work into multiple thematic subsections so the literature review reads like a mature synthesis rather than a flat list of papers."
            )
        if ratio < 0.2 and len(sentences) >= 5:
            overall_warnings.append(
                f"Related Work is purely descriptive: only {comparative_sents}/{len(sentences)} "
                f"sentences ({ratio:.0%}) contain comparative language (target: >=20%)"
            )
            revision_directives.append(
                "REWRITE Related Work to critically compare with prior methods. "
                "Use phrases like 'unlike X, our approach...', 'in contrast to...', "
                "'while X focuses on... we address...' for at least 20% of sentences."
            )

    # --- Method depth and implementation check ---
    method_body = _get_main_section_bodies("method", "methods", "methodology")
    if method_body and len(method_body.split()) > 80:
        method_word_count = len(method_body.split())
        method_citations = set(_cite_pattern.findall(method_body))
        _math_hits = len(re.findall(r"\$[^$]+\$|\\begin\{equation\}|\\theta|\\alpha|\\beta|=", method_body))
        _assumption_hits = len(re.findall(r"\b(assume|assumption|objective|loss|optimi[sz]e|estimate|inference|parameter|hyperparameter|preprocess|calibration|threshold|regulariz|training|optimization|split)\b", method_body, re.IGNORECASE))
        _method_checks = {
            "formulation": bool(re.search(r"\b(model formulation|problem formulation|we formulate|objective function|model is defined)\b", method_body, re.IGNORECASE)),
            "assumptions": bool(re.search(r"\b(assume|assumption|identifiability|valid when)\b", method_body, re.IGNORECASE)),
            "equations": bool(re.search(r"\$[^$]+\$|\\begin\{equation\}", method_body)),
            "inference_optimization": bool(re.search(r"\b(inference|posterior|optimization|optimizer|estimate|estimation|variational|mcmc|em algorithm)\b", method_body, re.IGNORECASE)),
            "appropriateness_motivation": bool(re.search(r"\b(appropriate|suitable|motivat|theoretical|computational rationale|why this method)\b", method_body, re.IGNORECASE)),
            "complexity": bool(re.search(r"\b(complexity|time complexity|space complexity|runtime|big-o|o\([^)]*\))\b", method_body, re.IGNORECASE)),
        }
        _bayes_or_conditional_hits = bool(re.search(r"\b(prior|priors|likelihood|posterior|full conditional|full conditionals)\b", method_body, re.IGNORECASE))
        _algorithm_or_proof_hits = bool(re.search(r"\b(algorithm|pseudocode|proof|derivation|proposition|theorem|lemma)\b", method_body, re.IGNORECASE))
        _check_score = sum(1 for ok in _method_checks.values() if ok)
        if method_word_count < 1200:
            overall_warnings.append(
                f"Method section is too short for replication-grade detail: {method_word_count} words (target: >=1200)"
            )
            revision_directives.append(
                "EXPAND the Method section with explicit preprocessing, model-family details, optimization steps, calibration/inference procedure, and reproducibility-critical implementation detail."
            )
        if len(method_citations) < 5:
            overall_warnings.append(
                f"Method section cites only {len(method_citations)} references (target: >=5 foundational/protocol citations)"
            )
            revision_directives.append(
                "ADD methodological citations to foundational algorithms, preprocessing choices, calibration procedures, and evaluation protocol where those choices are scientifically consequential."
            )
        if _math_hits < 4 or _assumption_hits < 8:
            overall_warnings.append(
                "Method section is too general and lacks sufficient equations, assumptions, or implementation detail"
            )
            revision_directives.append(
                "DEEPEN the Method section with formal notation, equations, modeling assumptions, parameter definitions, "
                "estimation or optimization steps, inference procedure, preprocessing, and implementation rationale."
            )
        if _check_score < 5:
            overall_warnings.append(
                "Methodology section is missing parts of the expected core checklist (formulation/assumptions/equations/inference-optimization/motivation/complexity)"
            )
            revision_directives.append(
                "RESTRUCTURE Methodology to include: main idea + model/problem formulation, assumptions, mathematical equations with symbol definitions, "
                "inference or optimization procedure, why the method is appropriate, theoretical/computational motivation, and computational complexity."
            )
        if not _bayes_or_conditional_hits and re.search(r"\b(probabilistic|bayesian|latent variable|posterior|likelihood)\b", method_body, re.IGNORECASE):
            overall_warnings.append(
                "Method appears probabilistic but does not clearly report priors/likelihood/posterior or full-conditionals details"
            )
            revision_directives.append(
                "If the method is probabilistic/Bayesian, EXPLICITLY define priors, likelihood, posterior quantities, and full conditionals (or state why unavailable) with equations."
            )
        if not _algorithm_or_proof_hits:
            overall_warnings.append(
                "Method lacks explicit algorithm/derivation/proof cues; rigor may be insufficient for technical reproducibility"
            )
            revision_directives.append(
                "ADD algorithmic detail (pseudocode or procedural algorithm) and include derivation/proof elements where the topic requires theoretical guarantees or conditional updates."
            )

    # --- Dataset and metric completeness check ---
    exp_body = _get_main_section_bodies("experiments", "evaluation", "experimental results")
    if exp_body and len(exp_body.split()) > 80:
        _dataset_checks = {
            "sample_size": bool(re.search(r"sample size|n\s*=|\b\d+\s+samples?\b", exp_body, re.IGNORECASE)),
            "features": bool(re.search(r"feature|dimensionality|input dim|feature count", exp_body, re.IGNORECASE)),
            "target": bool(re.search(r"target variable|label|response", exp_body, re.IGNORECASE)),
            "split": bool(re.search(r"train/test|validation|split|holdout|cross-validation", exp_body, re.IGNORECASE)),
            "preprocessing": bool(re.search(r"preprocess|normaliz|standardiz|encoding|imputation|feature engineering", exp_body, re.IGNORECASE)),
            "rationale": bool(re.search(r"appropriate|suitable|benchmark|chosen because|selected because", exp_body, re.IGNORECASE)),
        }
        if sum(_dataset_checks.values()) < 4:
            overall_warnings.append(
                "Experiments section lacks complete dataset description (sample size, features, target, split, preprocessing, rationale)"
            )
            revision_directives.append(
                "EXPAND dataset reporting to state sample sizes, feature counts, targets, train/validation/test splits, "
                "preprocessing steps, and why each dataset is appropriate for the topic."
            )

        _metric_checks = {
            "formula": bool(re.search(r"formula|defined as|computed as|=", exp_body, re.IGNORECASE)),
            "units": bool(re.search(r"unit|units|scale|percentage|seconds|ms|mse|rmse|mae|accuracy", exp_body, re.IGNORECASE)),
            "direction": bool(re.search(r"higher is better|lower is better|maximi[sz]e|minimi[sz]e|direction", exp_body, re.IGNORECASE)),
            "interpretation": bool(re.search(r"measures|interpreted as|indicates|captures", exp_body, re.IGNORECASE)),
        }
        if sum(_metric_checks.values()) < 3:
            overall_warnings.append(
                "Experiments section does not fully define the primary metrics with formula, units, direction, and interpretation"
            )
            revision_directives.append(
                "DEFINE every key metric explicitly: give the formula, units or scale, direction (higher/lower is better), "
                "and scientific interpretation before presenting results."
            )

        _metric_definitions = []
        if isinstance(exp_summary_parsed, dict):
            _metric_definitions = exp_summary_parsed.get("metric_definitions", [])
        if isinstance(_metric_definitions, list) and _metric_definitions:
            _planned_metric_names = [
                str(_metric_def.get("name") or "").strip()
                for _metric_def in _metric_definitions
                if isinstance(_metric_def, dict) and str(_metric_def.get("name") or "").strip()
            ]
            _provenance_missing: list[str] = []
            _novel_missing: list[str] = []
            for _metric_def in _metric_definitions:
                if not isinstance(_metric_def, dict):
                    continue
                _metric_name = str(_metric_def.get("name") or "primary metric")
                _literature_basis = _metric_def.get("literature_basis")
                _citation_keys = _metric_def.get("citation_keys")
                _novelty_justification = _metric_def.get("novelty_justification")
                _proof_or_validation = _metric_def.get("proof_or_validation")
                _is_novel = bool(_metric_def.get("is_novel"))
                _has_citations = bool(_citation_keys) and not (
                    isinstance(_citation_keys, list) and all(_looks_like_placeholder(item) for item in _citation_keys)
                )
                if not _is_novel and (_looks_like_placeholder(_literature_basis) or not _has_citations):
                    _provenance_missing.append(_metric_name)
                if _is_novel and (
                    _looks_like_placeholder(_novelty_justification)
                    or _looks_like_placeholder(_proof_or_validation)
                ):
                    _novel_missing.append(_metric_name)
            if _provenance_missing:
                overall_warnings.append(
                    "Experiment plan includes metrics without literature-backed justification "
                    f"({', '.join(_provenance_missing[:3])})"
                )
                revision_directives.append(
                    "JUSTIFY metric selection from the literature: state which benchmark paper, evaluation guideline, or domain standard supports each reported metric and cite it directly in the Experiments section."
                )
            if _novel_missing:
                overall_warnings.append(
                    "Novel metrics are introduced without a complete motivation and proof/validation plan "
                    f"({', '.join(_novel_missing[:3])})"
                )
                revision_directives.append(
                    "If a new metric is proposed, LABEL it explicitly as novel, explain why standard metrics are insufficient, define it mathematically, and provide its proof, properties, or empirical validation against established metrics before using it for core claims."
                )
            if len(_metric_definitions) < 3:
                overall_warnings.append(
                    f"Experiment plan defines only {len(_metric_definitions)} metrics; the study may be under-instrumented relative to literature-backed comparative standards"
                )
                revision_directives.append(
                    "EXPAND the experimental evaluation to include a broader literature-backed metric suite with complementary metrics, unless the benchmark literature clearly standardizes on fewer."
                )

            _reported_metric_count = 0
            _reported_metric_names: list[str] = []
            if isinstance(exp_summary_parsed, dict):
                _metrics_summary = exp_summary_parsed.get("metrics_summary", {})
                if isinstance(_metrics_summary, dict):
                    _reported_metric_names = [str(k) for k in _metrics_summary.keys() if str(k).strip()]
                _reported_metric_count = int(
                    exp_summary_parsed.get("total_metric_keys")
                    or len(_reported_metric_names)
                )
            if _reported_metric_count and _reported_metric_count < len(_metric_definitions):
                overall_warnings.append(
                    f"Run reports only {_reported_metric_count} metric keys although {len(_metric_definitions)} metrics were planned"
                )
                revision_directives.append(
                    "DO NOT present planned-but-unreported metrics as measured results. Restrict the Results section, tables, abstract claims, and quantitative comparisons to metric keys that were actually reported by the run; move the rest to planned evaluation or limitations."
                )
                if _reported_metric_names:
                    _reported_list = ", ".join(_reported_metric_names[:12])
                    _planned_list = ", ".join(_planned_metric_names[:12]) if _planned_metric_names else "(none listed)"
                    overall_warnings.append(
                        "Results must use only actually reported metrics, not the broader planned metric list"
                    )
                    revision_directives.append(
                        f"ACTUAL REPORTED METRICS: {_reported_list}. PLANNED METRICS: {_planned_list}. Only the reported metrics may appear with numeric values in Results tables or headline claims."
                    )

        _exp_has_metric_rationale = bool(re.search(
            r"literature|benchmark protocol|evaluation guideline|standard metric|widely used|following prior work|consistent with .*\[[^\]]+\]",
            exp_body,
            re.IGNORECASE,
        ))
        _exp_mentions_novel_metric = bool(re.search(
            r"novel metric|proposed metric|new metric|we introduce .* metric",
            exp_body,
            re.IGNORECASE,
        ))
        _exp_novel_metric_support = bool(re.search(
            r"proof|theorem|property|monotonic|bounded|consistent|calibrat|validated against|compared with standard metric|correlat",
            exp_body,
            re.IGNORECASE,
        ))
        if not _exp_has_metric_rationale:
            overall_warnings.append(
                "Experiments section does not explain why the chosen metrics are standard or appropriate for this task"
            )
            revision_directives.append(
                "ADD a metric-selection rationale grounded in prior literature or benchmark protocol. State why each metric is appropriate for this task rather than assumed by intuition."
            )
        _metric_name_mentions = len(set(re.findall(
            r"\b(?:auroc|auc|auprc|f1|precision|recall|sensitivity|specificity|mcc|brier|ece|nll|log loss|accuracy|balanced accuracy|mae|rmse|r2|runtime|latency|throughput)\b",
            exp_body,
            re.IGNORECASE,
        )))
        if _metric_name_mentions < 3:
            overall_warnings.append(
                "Experiments section appears to discuss too few complementary metrics; the evaluation still reads as a thin single-metric study"
            )
            revision_directives.append(
                "EXPAND the Experiments and Results sections to cover multiple complementary metrics from the literature-backed metric suite, not only the headline primary metric."
            )
        if _exp_mentions_novel_metric and not _exp_novel_metric_support:
            overall_warnings.append(
                "Experiments section proposes a new metric without proof, properties, or empirical validation against standard metrics"
            )
            revision_directives.append(
                "SUPPORT any proposed metric with a full mathematical definition and either a theoretical proof of desirable properties or explicit empirical validation against literature-backed standard metrics."
            )

    # --- Output-defensive tone outside Limitations ---
    non_limitations_text = "\n\n".join(
        sec["body"]
        for sec in sections_data
        if sec["heading_lower"] not in {"limitations", "limitation", "limitations and future work"}
    )
    _artifact_phrases = [
        "provided evidence",
        "arti" + "fact",
        "not recoverable",
        "future output",
    ]
    _artifact_hits = [phrase for phrase in _artifact_phrases if phrase in non_limitations_text.lower()]
    if _artifact_hits:
        overall_warnings.append(
            f"Output-defensive language appears outside Limitations ({', '.join(_artifact_hits[:3])})"
        )
        revision_directives.append(
            "REMOVE output-defensive phrasing from the Abstract, Introduction, Related Work, Method, Results, and Discussion. "
            "Keep genuine caveats in the Limitations section only."
        )

    # --- Claim support risk check ---
    claim_text = _get_main_section_bodies("abstract", "conclusion", "conclusions")
    if claim_text:
        _strong_claims = len(re.findall(r"\b(outperform|superior|best|state-of-the-art|dominates|clearly better|substantially better)\b", claim_text, re.IGNORECASE))
        _claim_support = bool(re.search(r"\d|\[.+?\]|p\s*<|confidence interval|\bCI\b", claim_text, re.IGNORECASE))
        if _strong_claims > 0 and not _claim_support:
            overall_warnings.append(
                "Abstract or Conclusion contains strong comparative claims without direct local support"
            )
            revision_directives.append(
                "SOFTEN or SUPPORT strong claims in the Abstract and Conclusion. Comparative superiority claims must be backed by cited prior work or explicit experimental evidence."
            )

    # --- Discussion quality / repetition check ---
    discussion_body = _get_main_section_bodies("discussion")
    if discussion_body and len(discussion_body.split()) > 80:
        _disc_quality = len(re.findall(r"\b(practitioner|practice|deployment|recommend|guidance|failure|underperform|mechanism|because|implies|use when)\b", discussion_body, re.IGNORECASE))
        _disc_numeric = len(re.findall(r"\b\d+(?:\.\d+)?%?\b", discussion_body))
        if _disc_quality < 4 or (_disc_numeric > 12 and _disc_quality < 6):
            overall_warnings.append(
                "Discussion appears to repeat results more than it interprets mechanisms, practice implications, or failure cases"
            )
            revision_directives.append(
                "REWRITE the Discussion to add mechanism-level interpretation, practitioner recommendations, failure cases, and decision guidance instead of restating numeric results."
            )

    # --- Statistical rigor check (result sections) ---
    _results_headings = {"results", "experiments", "experimental results", "evaluation"}
    results_body = ""
    for sec in sections_data:
        if sec["heading_lower"] in _results_headings and sec["level"] <= 2:
            results_body += sec["body"] + "\n"
    if results_body and len(results_body.split()) > 100:
        has_std = bool(re.search(r"\u00b1|\\pm|\bstd\b|\\std\b|standard deviation", results_body, re.IGNORECASE))
        has_ci = bool(re.search(r"confidence interval|\bCI\b|95%|p-value|p\s*<", results_body, re.IGNORECASE))
        has_repetition = bool(re.search(r"(?:seed|run|trial)s?\s*[:=]\s*\d|averaged?\s+over\s+\d+\s+(?:seed|run|trial)", results_body, re.IGNORECASE))
        has_breadth = bool(re.search(r"dataset|benchmark|sample size|regime|subset", results_body, re.IGNORECASE))
        if not has_std and not has_ci and not has_repetition and not has_breadth:
            overall_warnings.append(
                "Results section lacks uncertainty estimates and comparative evidence framing"
            )
            revision_directives.append(
                "ADD confidence intervals, significance tests when appropriate, and explicit per-dataset or per-sample-size comparisons. "
                "If repeated runs exist, report their aggregate uncertainty; otherwise strengthen comparative breadth."
            )

    result: dict[str, Any] = {
        "section_analysis": section_analysis,
        "overall_warnings": overall_warnings,
        "revision_directives": revision_directives,
    }
    if stage_dir is not None:
        (stage_dir / "draft_quality.json").write_text(
            json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        if overall_warnings:
            logger.warning(
                "Draft quality: %d warning(s) \u2014 %s",
                len(overall_warnings),
                "; ".join(overall_warnings[:3]),
            )
        else:
            logger.info("Draft quality: all checks passed")
    return result


def _review_compiled_pdf(
    pdf_path: Path,
    llm: LLMClient,
    topic: str,
) -> dict[str, Any]:
    """Multi-dimensional LLM review of compiled paper (AI-Scientist style).

    Scores the paper on 7 academic review dimensions (1-10 each),
    identifies specific strengths/weaknesses, and provides an overall
    accept/reject recommendation with confidence.

    Returns a dict with dimensional scores, issues, and decision.
    """
    if not pdf_path.exists():
        return {}

    # Use source-based review since not all models support vision
    tex_path = pdf_path.with_suffix(".tex")
    if not tex_path.exists():
        return {}

    tex_content = tex_path.read_text(encoding="utf-8")[:12000]

    review_prompt = (
        "You are a senior Area Chair at a top AI conference (NeurIPS/ICML/ICLR) "
        "reviewing a paper submission. Provide a rigorous, structured review.\n\n"
        f"PAPER TOPIC: {topic}\n\n"
        f"LaTeX source:\n```latex\n{tex_content}\n```\n\n"
        "REVIEW INSTRUCTIONS:\n"
        "Score each dimension 1-10 (1=unacceptable, 5=borderline, 8=strong accept, "
        "10=best paper candidate). Be critical but fair.\n\n"
        "DIMENSIONS:\n"
        "1. SOUNDNESS: Are claims well-supported? Is methodology correct? "
        "Are there logical gaps or unsupported claims?\n"
        "2. PRESENTATION: Is the writing clear, flowing, and professional? "
        "Are there grammar errors, bullet lists in prose sections, or "
        "boilerplate phrases? Is it free of AI-generated slop?\n"
        "3. CONTRIBUTION: Is the contribution significant? Does it advance "
        "the field beyond incremental improvement?\n"
        "4. ORIGINALITY: Is the approach novel? Does it differentiate clearly "
        "from prior work?\n"
        "5. CLARITY: Are the method and results easy to understand? Are figures "
        "and tables well-designed with descriptive captions?\n"
        "6. SIGNIFICANCE: Would the community benefit from this work? Does it "
        "open new research directions?\n"
        "7. REPRODUCIBILITY: Are experimental details sufficient to reproduce "
        "results? Are hyperparameters, datasets, and metrics clearly stated?\n\n"
        "Also evaluate:\n"
        "- Are all figures referenced in the text?\n"
        "- Are tables properly formatted (booktabs style, no vertical rules)?\n"
        "- Does the related work critically compare, not just list papers?\n"
        "- Are uncertainty measures or comparative evidence summaries (CI, std, per-dataset/per-regime results) reported?\n"
        "- Is there a clear limitations section?\n\n"
        "Return a JSON object:\n"
        "{\n"
        '  "soundness": N,\n'
        '  "presentation": N,\n'
        '  "contribution": N,\n'
        '  "originality": N,\n'
        '  "clarity": N,\n'
        '  "significance": N,\n'
        '  "reproducibility": N,\n'
        '  "overall_score": N,\n'
        '  "confidence": N,\n'
        '  "decision": "accept" or "reject",\n'
        '  "strengths": ["strength1", "strength2", ...],\n'
        '  "weaknesses": ["weakness1", "weakness2", ...],\n'
        '  "critical_issues": ["issue requiring revision", ...],\n'
        '  "minor_issues": ["formatting/typo issues", ...],\n'
        '  "summary": "2-3 sentence overall assessment"\n'
        "}\n"
    )

    try:
        resp = llm.chat(
            messages=[{"role": "user", "content": review_prompt}],
            system=(
                "You are a meticulous, critical academic reviewer. "
                "You have reviewed 100+ papers at top venues. "
                "Score honestly — most papers deserve 4-6, not 7-9. "
                "Flag any sign of AI-generated boilerplate."
            ),
        )
        review_data = _safe_json_loads(resp.content, {})
        if isinstance(review_data, dict) and "overall_score" in review_data:
            # Compute weighted aggregate if individual scores present
            dim_scores = {
                k: review_data.get(k, 0)
                for k in (
                    "soundness", "presentation", "contribution",
                    "originality", "clarity", "significance",
                    "reproducibility",
                )
            }
            valid = {k: v for k, v in dim_scores.items() if isinstance(v, (int, float)) and v > 0}
            if valid:
                review_data["mean_score"] = round(sum(valid.values()) / len(valid), 2)
            return review_data
    except Exception as exc:  # noqa: BLE001
        logger.debug("PDF review LLM call failed: %s", exc)

    return {}


def _check_ablation_effectiveness(
    exp_summary: dict[str, Any],
    threshold: float = 0.02,
) -> list[str]:
    """P7: Check if ablation results are within *threshold* of baseline.

    Returns a list of warning strings for ineffective ablations.
    Threshold tightened from 5% to 2% (Improvement C) — ablations with
    < 2% relative difference AND < 1pp absolute difference are flagged
    as TRIVIAL.
    """
    warnings: list[str] = []
    cond_summaries = exp_summary.get("condition_summaries", {})
    if not isinstance(cond_summaries, dict) or not cond_summaries:
        return warnings

    # Find baseline/control condition
    baseline_name = None
    baseline_mean = None
    for name, data in cond_summaries.items():
        if not isinstance(data, dict):
            continue
        name_lower = name.lower()
        if any(tag in name_lower for tag in ("baseline", "control", "vanilla", "standard")):
            metrics = data.get("metrics") or {}
            if not isinstance(metrics, dict):
                metrics = {}
            # Use the first metric that has a _mean suffix or the first available
            for mk, mv in metrics.items():
                if mk.endswith("_mean"):
                    baseline_name = name
                    baseline_mean = float(mv)
                    break
            if baseline_mean is None:
                for mk, mv in metrics.items():
                    try:
                        baseline_name = name
                        baseline_mean = float(mv)
                        break
                    except (TypeError, ValueError):
                        continue
            if baseline_name:
                break

    if baseline_name is None or baseline_mean is None:
        return warnings

    # Check each ablation condition
    for name, data in cond_summaries.items():
        if not isinstance(data, dict):
            continue
        name_lower = name.lower()
        if name == baseline_name:
            continue
        if not any(tag in name_lower for tag in ("ablation", "no_", "without", "reduced")):
            continue
        metrics = data.get("metrics") or {}
        if not isinstance(metrics, dict):
            metrics = {}
        for mk, mv in metrics.items():
            if not mk.endswith("_mean"):
                continue
            try:
                abl_val = float(mv)
            except (TypeError, ValueError):
                continue
            if baseline_mean != 0:
                rel_diff = abs(abl_val - baseline_mean) / abs(baseline_mean)
            else:
                rel_diff = abs(abl_val - baseline_mean)
            abs_diff = abs(abl_val - baseline_mean)
            # Improvement C: Tighter check — both relative < threshold
            # AND absolute < 1pp → TRIVIAL
            if rel_diff < threshold and abs_diff < 1.0:
                warnings.append(
                    f"TRIVIAL: Ablation '{name}' {mk}={abl_val:.4f} is within "
                    f"{rel_diff:.1%} (abs {abs_diff:.4f}pp) of baseline "
                    f"'{baseline_name}' {mk}={baseline_mean:.4f} — "
                    f"ablation is ineffective"
                )
            elif rel_diff < threshold:
                warnings.append(
                    f"Ablation '{name}' {mk}={abl_val:.4f} is within "
                    f"{rel_diff:.1%} of baseline '{baseline_name}' "
                    f"{mk}={baseline_mean:.4f} — ablation may be ineffective"
                )
            break  # Only check the first _mean metric per condition

    # Improvement C: Prepend CRITICAL summary if >50% trivial
    trivial_count = sum(1 for w in warnings if w.startswith("TRIVIAL:"))
    if trivial_count > 0 and len(warnings) > 0 and trivial_count / len(warnings) > 0.5:
        warnings.insert(0, (
            f"CRITICAL: {trivial_count}/{len(warnings)} ablations are trivially "
            f"similar to baseline (<{threshold:.0%} relative, <1pp absolute). "
            f"The ablation design is likely broken — components are not effectively removed."
        ))

    return warnings


def _detect_result_contradictions(
    exp_summary: dict[str, Any],
    metric_direction: str = "maximize",
) -> list[str]:
    """P10: Detect contradictions in experiment results before paper writing.

    Returns a list of advisory strings to inject into paper writing prompt.
    """
    advisories: list[str] = []
    cond_summaries = exp_summary.get("condition_summaries", {})
    if not isinstance(cond_summaries, dict) or not cond_summaries:
        return advisories

    # Collect primary metric means per condition
    means: dict[str, float] = {}
    for name, data in cond_summaries.items():
        if not isinstance(data, dict):
            continue
        metrics = data.get("metrics", {})
        for mk, mv in metrics.items():
            if mk.endswith("_mean"):
                try:
                    means[name] = float(mv)
                except (TypeError, ValueError):
                    pass
                break

    if len(means) < 2:
        return advisories

    # Check 1: All methods within noise margin (2% relative spread)
    vals = list(means.values())
    val_range = max(vals) - min(vals)
    val_mean = sum(vals) / len(vals)
    if val_mean != 0 and (val_range / abs(val_mean)) < 0.02:
        advisories.append(
            "NULL RESULT: All methods produce nearly identical primary metric values "
            f"(range={val_range:.4f}, mean={val_mean:.4f}). Frame this as a null result — "
            "the methods are statistically indistinguishable. Do NOT claim any method "
            "is superior. Discuss possible explanations (task too easy/hard, metric "
            "insensitive, insufficient differentiation in methods)."
        )

    # Check 2: Control/simple baseline outperforms proposed method
    # BUG-P1: Respect metric_direction — "higher is better" vs "lower is better"
    _maximize = metric_direction == "maximize"
    baseline_val = None
    baseline_name = None
    proposed_val = None
    proposed_name = None
    for name, val in means.items():
        name_lower = name.lower()
        if any(tag in name_lower for tag in ("baseline", "control", "random", "vanilla")):
            if baseline_val is None or (_maximize and val > baseline_val) or (not _maximize and val < baseline_val):
                baseline_val = val
                baseline_name = name
        elif any(tag in name_lower for tag in ("proposed", "our", "novel", "method")):
            if proposed_val is None or (_maximize and val > proposed_val) or (not _maximize and val < proposed_val):
                proposed_val = val
                proposed_name = name

    if baseline_val is not None and proposed_val is not None:
        _baseline_wins = (baseline_val > proposed_val) if _maximize else (baseline_val < proposed_val)
        if _baseline_wins:
            advisories.append(
                f"NEGATIVE RESULT: Baseline '{baseline_name}' ({baseline_val:.4f}) "
                f"outperforms proposed method '{proposed_name}' ({proposed_val:.4f}). "
                "This is a NEGATIVE result. Do NOT claim the proposed method is superior. "
                "Frame as 'An Empirical Study of...' or 'When X Falls Short'. "
                "Discuss why the baseline won and what this implies for future work."
            )

    return advisories


def _finite_metric_values_from_summary(summary: dict[str, Any]) -> list[float]:
    values: list[float] = []

    def visit(value: Any) -> None:
        if isinstance(value, bool):
            return
        if isinstance(value, (int, float)):
            number = float(value)
            if math.isfinite(number):
                values.append(number)
            return
        if isinstance(value, dict):
            for nested in value.values():
                visit(nested)
        elif isinstance(value, list):
            for nested in value:
                visit(nested)

    visit(summary.get("metrics_summary", {}))
    visit(summary.get("condition_summaries", {}))
    return values


def _is_missing_publication_field(value: Any) -> bool:
    text = str(value or "").strip().casefold()
    if not text:
        return True
    return any(token in text for token in (
        "specify",
        "state ",
        "tbd",
        "todo",
        "unknown",
        "not reported",
        "n/a",
        "placeholder",
        "add cite",
        "canonical paper",
        "provide theoretical",
        "if novel",
    ))


def _chart_stems_for_gate(run_dir: Path) -> set[str]:
    stems: set[str] = set()
    for charts_dir in sorted(run_dir.glob("stage-14*/charts"), reverse=True):
        if not charts_dir.is_dir():
            continue
        for chart_path in charts_dir.iterdir():
            if chart_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".pdf"}:
                stems.add(chart_path.stem.casefold())
    return stems


def _required_figure_aliases(figure_name: str) -> tuple[str, ...]:
    normalized = figure_name.casefold().replace("-", "_").replace(" ", "_")
    alias_map = {
        "feature_inclusion_probability": (
            "feature_inclusion_probability",
            "feature_importance",
            "feature_importances",
        ),
        "confusion_matrix": ("confusion_matrix",),
        "roc_curve": ("roc_curve",),
        "accuracy_comparison": ("accuracy_comparison",),
        "f1_comparison": ("f1_comparison",),
        "precision_comparison": ("precision_comparison",),
        "recall_comparison": ("recall_comparison",),
        "roc_auc_comparison": ("roc_auc_comparison", "auroc_comparison"),
        "kfold_80_20_cv_boxplot": (
            "kfold_80_20_cv_boxplot",
            "kfold_boxplot",
            "cv_boxplot",
            "cross_validation_boxplot",
        ),
        "predicted_vs_observed": ("predicted_vs_observed", "observed_vs_predicted"),
        "residual_plot": ("residual_plot",),
        "residual_distribution": ("residual_distribution",),
        "continuous_metric_comparison": (
            "mae_comparison",
            "mse_comparison",
            "rmse_comparison",
            "r2_comparison",
        ),
    }
    return alias_map.get(normalized, (normalized,))


def _experiment_correctness_gate(
    run_dir: Path,
    config: RCConfig,
    exp_summary_text: str | None,
    refinement_log: dict[str, Any] | None,
) -> dict[str, Any]:
    summary = _safe_json_loads(exp_summary_text or "", {}) if exp_summary_text else {}
    if not isinstance(summary, dict):
        summary = {}

    failures: list[str] = []
    warnings: list[str] = []
    metrics_summary = summary.get("metrics_summary")
    condition_summaries = summary.get("condition_summaries")
    finite_values = _finite_metric_values_from_summary(summary)

    if not isinstance(metrics_summary, dict) or not metrics_summary:
        failures.append("No structured metrics_summary was produced by the executed experiment.")
    if not isinstance(condition_summaries, dict) or not condition_summaries:
        failures.append("No condition-level results were produced, so model comparisons cannot be verified.")
    if isinstance(condition_summaries, dict):
        has_runtime_detail = bool(summary.get("runtime_by_condition"))
        has_uncertainty_detail = False
        planned_metric_names = [
            str(metric.get("name") or "").strip().casefold().replace("-", "_")
            for metric in (summary.get("metric_definitions") or [])
            if isinstance(metric, dict) and str(metric.get("name") or "").strip()
        ]
        for condition, condition_data in condition_summaries.items():
            if not isinstance(condition_data, dict):
                continue
            condition_text = json.dumps(condition_data, default=str).casefold()
            if any(term in condition_text for term in ("runtime", "elapsed", "seconds", "time_sec", "elapsed_sec")):
                has_runtime_detail = True
            if any(term in condition_text for term in ("ci95", "confidence", "std", "p-value", "p_value", "paired")):
                has_uncertainty_detail = True
            success_rate = condition_data.get("success_rate")
            try:
                if success_rate is not None and float(success_rate) < 1.0:
                    failures.append(
                        f"Condition '{condition}' has success_rate={float(success_rate):.4g}; all conditions must complete successfully before manuscript generation."
                    )
            except (TypeError, ValueError):
                warnings.append(f"Condition '{condition}' has a non-numeric success_rate value.")
            metrics = condition_data.get("metrics")
            if planned_metric_names and isinstance(metrics, dict):
                metric_keys = {
                    str(key).casefold().replace("-", "_").replace(" ", "_")
                    for key in metrics.keys()
                }
                for planned_metric in planned_metric_names:
                    if planned_metric and not any(planned_metric in key or key in planned_metric for key in metric_keys):
                        failures.append(
                            f"Condition '{condition}' is missing planned metric '{planned_metric}'."
                        )
        if condition_summaries and not has_runtime_detail:
            failures.append("Runtime per condition is missing; final papers must report execution cost or runtime for each evaluated condition.")
        if len(condition_summaries) >= 2 and not (has_uncertainty_detail or summary.get("paired_comparisons")):
            failures.append("Uncertainty/statistical comparison details are missing; confidence intervals, standard deviations, or p-values are required for comparative claims.")

    if not summary.get("software_versions") and not summary.get("environment") and not summary.get("hardware_profile"):
        failures.append("Software/runtime environment details are missing; final papers must report key library versions or execution environment.")

    metric_definitions = summary.get("metric_definitions")
    if not isinstance(metric_definitions, list) or not metric_definitions:
        failures.append("Metric definitions are missing; every reported metric needs formula, direction, units/scale, interpretation, and literature basis.")
    else:
        for metric_definition in metric_definitions:
            if not isinstance(metric_definition, dict):
                continue
            metric_name = str(metric_definition.get("name") or "metric")
            for field in ("name", "role", "direction", "units", "formula", "interpretation", "literature_basis"):
                if _is_missing_publication_field(metric_definition.get(field)):
                    failures.append(
                        f"Metric '{metric_name}' is missing publication-critical definition field: {field}."
                    )
            citation_keys = metric_definition.get("citation_keys")
            if not citation_keys or _is_missing_publication_field(citation_keys):
                failures.append(
                    f"Metric '{metric_name}' is missing literature citation keys."
                )
            if metric_definition.get("is_novel") and (
                _is_missing_publication_field(metric_definition.get("novelty_justification"))
                or _is_missing_publication_field(metric_definition.get("proof_or_validation"))
            ):
                failures.append(
                    f"Novel metric '{metric_name}' is missing novelty justification or proof/validation."
                )

    if not finite_values:
        failures.append("No finite numeric metric values were found.")
    elif any(abs(value) > 1e12 for value in finite_values):
        failures.append("At least one metric value is implausibly large, consistent with numerical overflow or an unbounded computation.")

    for warning in summary.get("ablation_warnings", []) or []:
        failures.append(f"Ablation correctness check failed: {warning}")

    warnings.extend(
        str(item)
        for item in (summary.get("evidence_coverage_warnings") or [])
        if str(item).strip()
    )
    for warning in warnings:
        if "GAP" in warning.upper():
            failures.append(f"Evidence completeness gate failed: {warning}")

    dataset_details = summary.get("dataset_details")
    if not isinstance(dataset_details, list) or not dataset_details:
        failures.append("Dataset-level details are missing; split definitions, sample sizes, feature counts, and targets must be available before paper generation.")
    else:
        for dataset in dataset_details:
            if not isinstance(dataset, dict):
                continue
            dataset_name = str(dataset.get("name") or "dataset")
            missing_fields = [
                field
                for field in ("sample_size", "training_size", "test_size", "feature_count", "target", "split")
                if _is_missing_publication_field(dataset.get(field))
            ]
            if missing_fields:
                failures.append(
                    f"Dataset '{dataset_name}' is missing publication-critical fields: {', '.join(missing_fields)}."
                )

    model_definitions = summary.get("model_definitions")
    if not isinstance(model_definitions, list) or not model_definitions:
        failures.append("Model definitions are missing; every executed model needs form, assumptions, objective/loss, hyperparameters, tuning, diagnostics, and interpretation.")
    else:
        for model in model_definitions:
            if not isinstance(model, dict):
                continue
            model_name = str(model.get("name") or model.get("model_name") or "model")
            model_text = json.dumps(model, default=str).casefold()
            for required_term in ("mathematical", "assumption", "objective", "parameter", "hyperparameter", "tuning", "interpretation"):
                if required_term not in model_text:
                    failures.append(
                        f"Model '{model_name}' is missing required reporting detail: {required_term}."
                    )
            for key, value in model.items():
                if key in {"name", "model_name"}:
                    continue
                if _is_missing_publication_field(value):
                    failures.append(
                        f"Model '{model_name}' contains placeholder or missing value for '{key}'."
                    )

    planned_conditions: set[str] = set()
    for key in ("baselines", "proposed_methods", "ablations"):
        value = summary.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    planned_conditions.add(str(item.get("name") or item.get("condition") or item.get("factor") or item))
                else:
                    planned_conditions.add(str(item))
    planned_conditions = {item for item in planned_conditions if item and item != "{}"}
    actual_condition_set = set(str(name) for name in (condition_summaries or {}).keys()) if isinstance(condition_summaries, dict) else set()
    if planned_conditions and actual_condition_set and len(actual_condition_set) < min(2, len(planned_conditions)):
        failures.append(
            "Executed conditions are too few to support the planned comparative study; abstract and flowchart claims would overstate the evidence."
        )
    ablation_text = json.dumps(summary.get("ablations") or summary.get("ablation_requirements") or [], default=str).casefold()
    if "ablation" in ablation_text:
        if "sample" not in ablation_text:
            failures.append("Ablation plan/results do not include a sample-size ablation.")
        if not any(term in ablation_text for term in ("tuning", "hyperparameter", "search budget", "search_budget")):
            failures.append("Ablation plan/results do not include a tuning or hyperparameter-search ablation.")

    required_figures = summary.get("required_figures")
    if isinstance(required_figures, list) and required_figures:
        chart_stems = _chart_stems_for_gate(run_dir)
        missing_figures: list[str] = []
        for figure_name in required_figures:
            figure_text = str(figure_name or "").strip()
            if not figure_text:
                continue
            if "framework" in figure_text.casefold():
                continue
            aliases = _required_figure_aliases(figure_text)
            if not any(alias in chart_stems or any(alias in stem for stem in chart_stems) for alias in aliases):
                missing_figures.append(figure_text)
        if missing_figures:
            failures.append(
                "Required publication figures were not generated from experiment outputs: "
                + ", ".join(missing_figures[:10])
                + ". Regenerate prediction artifacts/charts before manuscript generation."
            )

    runtime_issue_hits: list[str] = []
    if isinstance(refinement_log, dict):
        for iteration in refinement_log.get("iterations", []) or []:
            if not isinstance(iteration, dict):
                continue
            issue = str(iteration.get("runtime_issues") or "").strip()
            if issue:
                runtime_issue_hits.append(issue)
            for sandbox_key in ("sandbox", "sandbox_after_fix"):
                sandbox = iteration.get(sandbox_key)
                if not isinstance(sandbox, dict):
                    continue
                if sandbox.get("timed_out"):
                    runtime_issue_hits.append(f"{sandbox_key} timed out.")
                error = str(sandbox.get("error") or sandbox.get("stderr") or "").strip()
                if re.search(r"\b(overflow|nan|inf|traceback|exception|error|failed)\b", error, re.IGNORECASE):
                    runtime_issue_hits.append(error[:500])
    for issue in runtime_issue_hits:
        failures.append(f"Runtime correctness issue: {issue}")

    actual_conditions = []
    if isinstance(condition_summaries, dict):
        actual_conditions = [str(name) for name in condition_summaries.keys()]
    actual_metrics = []
    if isinstance(metrics_summary, dict):
        actual_metrics = [str(name) for name in metrics_summary.keys()]

    return {
        "passed": not failures,
        "failures": failures,
        "warnings": warnings,
        "actual_conditions": actual_conditions,
        "actual_metrics": actual_metrics,
        "finite_metric_count": len(finite_values),
        "generated": _utcnow_iso(),
        "topic": config.research.topic,
    }


def _render_failed_run_diagnostic_report(gate: dict[str, Any]) -> str:
    failures = gate.get("failures") or []
    warnings = gate.get("warnings") or []
    actual_conditions = gate.get("actual_conditions") or []
    actual_metrics = gate.get("actual_metrics") or []

    def bullet_lines(items: list[Any], empty: str) -> str:
        cleaned = [str(item).strip() for item in items if str(item).strip()]
        if not cleaned:
            return f"- {empty}"
        return "\n".join(f"- {item}" for item in cleaned[:30])

    return (
        f"{_FAILED_RUN_DIAGNOSTIC_MARKER}\n"
        "# Failed-Run Diagnostic Report\n\n"
        "## Correctness Gate Status\n"
        "**Status:** failed. A submission-style research paper was not generated because the executed experiment did not pass correctness gates.\n\n"
        "This report is intentionally a diagnostic output, not a final scientific manuscript. It prevents unsupported abstracts, broad method comparisons, and result claims from appearing before the experiment is valid.\n\n"
        "## Blocking Failures\n"
        f"{bullet_lines(failures, 'No blocking failures were recorded.')}\n\n"
        "## Evidence Snapshot\n"
        f"**Executed conditions:** {', '.join(actual_conditions) if actual_conditions else 'not available'}\n\n"
        f"**Reported metric keys:** {', '.join(actual_metrics[:30]) if actual_metrics else 'not available'}\n\n"
        f"**Finite metric values found:** {gate.get('finite_metric_count', 0)}\n\n"
        "## Non-Blocking Warnings\n"
        f"{bullet_lines(warnings, 'No additional warnings were recorded.')}\n\n"
        "## Required Repairs Before Paper Generation\n"
        "- Re-run the experiment until every condition completes without NaN, Inf, overflow, timeout, traceback, or failure markers.\n"
        "- Ensure every planned model has actual executed results, explicit hyperparameters, and documented assumptions.\n"
        "- Produce dataset-level results, split definitions, runtime per condition, software versions, confidence intervals, and statistical tests when repeated measurements are available.\n"
        "- Replace broken or cosmetic ablations with sample-size and tuning/search-budget ablations that change real experimental factors.\n"
        "- Generate publication-ready figures only from valid outputs; do not include placeholders or generic chart titles.\n\n"
        "## Claim Policy\n"
        "No abstract, conclusion, clinical implication, superiority claim, calibration claim, distribution-shift claim, selective-prediction claim, missingness claim, or ablation claim should be generated until the blocking failures above are resolved.\n"
    )


def _render_evidence_limited_paper_draft(
    gate: dict[str, Any],
    topic: str,
    *,
    reason: str = "The experiment correctness gate did not fully pass.",
    exp_summary_text: str | None = None,
) -> str:
    """Render a manuscript-shaped degraded draft without unsupported claims."""

    failures = [
        str(item).strip()
        for item in (gate.get("failures") or [])
        if str(item).strip()
    ]
    warnings = [
        str(item).strip()
        for item in (gate.get("warnings") or [])
        if str(item).strip()
    ]
    actual_conditions = [
        str(item).strip()
        for item in (gate.get("actual_conditions") or [])
        if str(item).strip()
    ]
    actual_metrics = [
        str(item).strip()
        for item in (gate.get("actual_metrics") or [])
        if str(item).strip()
    ]

    summary_lines: list[str] = []
    exp_summary = _safe_json_loads(exp_summary_text or "", {})
    if isinstance(exp_summary, dict):
        metrics_summary = exp_summary.get("metrics_summary")
        if isinstance(metrics_summary, dict):
            for metric_name, metric_data in list(metrics_summary.items())[:12]:
                if isinstance(metric_data, dict):
                    mean_value = metric_data.get("mean")
                    count_value = metric_data.get("count")
                    if mean_value is not None:
                        summary_lines.append(
                            f"- {metric_name}: mean={mean_value}, observations={count_value}"
                        )
                elif metric_data is not None:
                    summary_lines.append(f"- {metric_name}: {metric_data}")

    if not summary_lines:
        finite_count = gate.get("finite_metric_count", 0)
        summary_lines.append(
            f"- Finite metric values available for audit: {finite_count}"
        )
    if actual_conditions:
        summary_lines.append(
            "- Executed conditions detected: " + ", ".join(actual_conditions[:12])
        )
    if actual_metrics:
        summary_lines.append(
            "- Metric keys detected: " + ", ".join(actual_metrics[:20])
        )

    failure_text = "\n".join(f"- {item}" for item in failures[:10])
    if not failure_text:
        failure_text = "- No specific blocking failure text was recorded."
    warning_text = "\n".join(f"- {item}" for item in warnings[:10])
    if not warning_text:
        warning_text = "- No additional warnings were recorded."

    return (
        f"# {topic}\n\n"
        "## Abstract\n"
        "This evidence-limited manuscript reports the research question, planned "
        "experimental comparison, available execution evidence, and limitations. "
        "The experimental evidence did not satisfy every correctness gate, so the "
        "paper avoids unsupported superiority or deployment claims and presents "
        "the results as an auditable degraded run.\n\n"
        "## Introduction\n"
        f"The study addresses: {topic}. The intended contribution is a comparative "
        "evaluation grounded in the pipeline's experiment design and collected "
        "evidence. Because execution quality checks identified unresolved issues, "
        "the manuscript is intentionally conservative and focuses on what was "
        "actually observed.\n\n"
        "## Method\n"
        "The pipeline designed an experiment, generated executable code, ran the "
        "available evaluation workflow, and analyzed produced artifacts. The final "
        "draft uses only available experiment summaries and diagnostic metadata; "
        "unverified numerical claims are not promoted to scientific conclusions.\n\n"
        "## Experiment Status\n"
        f"{reason}\n\n"
        "The diagnostic report is stored separately as "
        "`failed_run_diagnostic_report.md` when available. The main manuscript "
        "does not include diagnostic markers or failed-run report text.\n\n"
        "### Correctness Gate Findings\n"
        f"{failure_text}\n\n"
        "### Non-Blocking Warnings\n"
        f"{warning_text}\n\n"
        "## Results\n"
        "The available quantitative evidence is summarized below. These values are "
        "reported as execution evidence, not as final claims of model superiority.\n\n"
        + "\n".join(summary_lines)
        + "\n\n"
        "## Limitations\n"
        "The run should be interpreted as degraded until the experiment artifacts "
        "satisfy all correctness gates. Required follow-up includes repairing "
        "failed or missing conditions, confirming comparative tables and figures, "
        "and rerunning citation and result verification before making strong "
        "scientific claims.\n\n"
        "## Conclusion\n"
        "The pipeline produced a traceable evidence-limited manuscript rather than "
        "blocking the downstream finalization stages. The current evidence can be "
        "used for debugging and audit, while the reported limitations identify "
        "what must be repaired before publication-quality conclusions are drawn.\n"
    )


def _write_paper_auto_rewrite_report(
    stage_dir: Path,
    *,
    artifact: str,
    reason: str,
    source: str,
    action: str = "replaced_with_evidence_limited_manuscript",
) -> str:
    """Record deterministic manuscript rewrites that keep later stages moving."""

    report_name = "paper_auto_rewrite_report.json"
    (stage_dir / report_name).write_text(
        json.dumps(
            {
                "artifact": artifact,
                "source": source,
                "reason": reason,
                "action": action,
                "generated": _utcnow_iso(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return report_name


def _contains_failed_run_diagnostic_text(text: str) -> bool:
    return (
        _FAILED_RUN_DIAGNOSTIC_MARKER in text
        or "Failed-Run Diagnostic Report" in text
    )


def _template_paper_draft(topic: str, exp_summary_text: str | None) -> str:
    results_section = "Template results summary."
    if exp_summary_text:
        exp_summary = _safe_json_loads(exp_summary_text, {})
        if isinstance(exp_summary, dict) and exp_summary.get("metrics_summary"):
            lines = ["Experiment results:"]
            for mk, mv in exp_summary["metrics_summary"].items():
                if isinstance(mv, dict):
                    lines.append(
                        f"- {mk}: mean={mv.get('mean')}, min={mv.get('min')}, "
                        f"max={mv.get('max')}, metric_observations={mv.get('count')}"
                    )
            results_section = "\n".join(lines)

    return f"""# Draft Title

## Abstract
Template draft abstract.

## Introduction
Template introduction for {topic}.

## Related Work
Template related work.

## Method
Template method description.

## Experiments
Template experimental setup.

## Results
{results_section}

## Limitations
Template limitations.

## Conclusion
Template conclusion.

## References
Template references.

Generated: {_utcnow_iso()}
"""


def _execute_paper_draft(
    stage_dir: Path,
    run_dir: Path,
    config: RCConfig,
    adapters: AdapterBundle,
    *,
    llm: LLMClient | None = None,
    prompts: PromptManager | None = None,
) -> StageResult:
    clarification_issue = _topic_clarification_issue(config.research.topic)
    if clarification_issue:
        clarification_gate = {
            "failures": [clarification_issue],
            "warnings": [
                "The user topic needs clarification, so Stage 17 produced a "
                "conservative evidence-limited manuscript instead of blocking."
            ],
            "actual_conditions": [],
            "actual_metrics": [],
            "finite_metric_count": 0,
        }
        draft_notice = _render_evidence_limited_paper_draft(
            clarification_gate,
            config.research.topic,
            reason=f"The topic requires clarification: {clarification_issue}",
        )
        (stage_dir / "paper_draft.md").write_text(draft_notice, encoding="utf-8")
        rewrite_report = _write_paper_auto_rewrite_report(
            stage_dir,
            artifact="paper_draft.md",
            source="topic_clarification_gate",
            reason=f"The topic requires clarification: {clarification_issue}",
        )
        return StageResult(
            stage=Stage.PAPER_DRAFT,
            status=StageStatus.DONE,
            artifacts=("paper_draft.md", rewrite_report),
            evidence_refs=("stage-17/paper_draft.md", f"stage-17/{rewrite_report}"),
            decision="degraded",
        )

    outline = _read_prior_artifact(run_dir, "outline.md") or ""
    preamble = _build_context_preamble(
        config,
        run_dir,
        include_goal=True,
        include_hypotheses=True,
        include_exp_plan=True,
        include_analysis=True,
        include_experiment_data=True,  # WS-5.1: inject real experiment data
    )

    # BUG-222: Read PROMOTED BEST experiment_summary for the paper prompt.
    # Previous code (R21-1) picked the "richest" experiment_summary across
    # all stage-14* dirs.  After REFINE regression, a later iteration with
    # more conditions but worse quality could win, feeding the LLM regressed
    # data.  Now: prefer experiment_summary_best.json (written by
    # _promote_best_stage14()), fall back to richest stage-14* for
    # non-REFINE runs.
    exp_summary_text = None
    _best_path = _existing_progress_artifact(run_dir, "experiment_summary_best.json")
    if _best_path is not None:
        try:
            _text = _best_path.read_text(encoding="utf-8")
            _parsed = _safe_json_loads(_text, {})
            if isinstance(_parsed, dict) and (
                _parsed.get("condition_summaries") or _parsed.get("metrics_summary")
            ):
                exp_summary_text = _text
                logger.info("BUG-222: Using promoted experiment_summary_best.json")
        except OSError:
            pass
    if exp_summary_text is None:
        # Fallback: pick richest stage-14* (pre-BUG-222 behavior)
        _best_metric_count = 0
        for _s14_dir in sorted(run_dir.glob("stage-14*")):
            _candidate = _s14_dir / "experiment_summary.json"
            if _candidate.is_file():
                _text = _candidate.read_text(encoding="utf-8")
                _parsed = _safe_json_loads(_text, {})
                if isinstance(_parsed, dict):
                    _mcount = _parsed.get("total_metric_keys", 0) or len(
                        _parsed.get("metrics_summary", {})
                    )
                    _paired_count = len(_parsed.get("paired_comparisons", []))
                    _cond_count = len(_parsed.get("condition_summaries", {}))
                    _score = _mcount + _paired_count * 10 + _cond_count * 5
                    if _score > _best_metric_count:
                        _best_metric_count = _score
                        exp_summary_text = _text
                        logger.info(
                            "R21-1 fallback: Selected %s (score=%d)",
                            _s14_dir.name, _score,
                        )
        if exp_summary_text is None:
            exp_summary_text = _read_prior_artifact(run_dir, "experiment_summary.json")
    exp_metrics_instruction = ""
    has_real_metrics = False
    _verified_registry = None  # Phase 1: anti-fabrication verified data registry
    # BUG-108: Load refinement_log so VerifiedRegistry has per-iteration metrics
    _refinement_log_for_vr: dict | None = None
    _rl_candidates = sorted(run_dir.glob("stage-13*/refinement_log.json"), reverse=True)
    _rl_path = _rl_candidates[0] if _rl_candidates else None
    if _rl_path and _rl_path.is_file():
        try:
            _refinement_log_for_vr = json.loads(_rl_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    _correctness_gate = _experiment_correctness_gate(
        run_dir,
        config,
        exp_summary_text,
        _refinement_log_for_vr,
    )
    (stage_dir / "experiment_correctness_gate.json").write_text(
        json.dumps(_correctness_gate, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    if not _correctness_gate.get("passed"):
        diagnostic_report = _render_failed_run_diagnostic_report(_correctness_gate)
        draft_notice = _render_evidence_limited_paper_draft(
            _correctness_gate,
            config.research.topic,
            reason="The Stage 17 experiment correctness gate did not fully pass.",
            exp_summary_text=exp_summary_text,
        )
        (stage_dir / "failed_run_diagnostic_report.md").write_text(
            diagnostic_report,
            encoding="utf-8",
        )
        (stage_dir / "paper_draft.md").write_text(
            draft_notice,
            encoding="utf-8",
        )
        rewrite_report = _write_paper_auto_rewrite_report(
            stage_dir,
            artifact="paper_draft.md",
            source="experiment_correctness_gate",
            reason="The Stage 17 experiment correctness gate did not fully pass.",
        )
        logger.warning(
            "Stage 17: correctness gate failed; wrote evidence-limited draft and diagnostic report"
        )
        return StageResult(
            stage=Stage.PAPER_DRAFT,
            status=StageStatus.DONE,
            artifacts=(
                "paper_draft.md",
                "failed_run_diagnostic_report.md",
                "experiment_correctness_gate.json",
                rewrite_report,
            ),
            evidence_refs=(
                "stage-17/paper_draft.md",
                "stage-17/failed_run_diagnostic_report.md",
                "stage-17/experiment_correctness_gate.json",
                f"stage-17/{rewrite_report}",
            ),
            decision="degraded",
        )
    if exp_summary_text:
        exp_summary = _safe_json_loads(exp_summary_text, {})
        # Phase 1: Build VerifiedRegistry from experiment data
        if isinstance(exp_summary, dict):
            try:
                from researchclaw.pipeline.verified_registry import VerifiedRegistry
                # BUG-222: Use best_only=True to ensure paper tables reflect
                # only the promoted best iteration, not regressed data
                _verified_registry = VerifiedRegistry.from_run_dir(
                    run_dir,
                    metric_direction=config.experiment.metric_direction,
                    best_only=True,
                )
                logger.info(
                    "Stage 17: VerifiedRegistry — %d verified values, %d conditions",
                    len(_verified_registry.values),
                    len(_verified_registry.condition_names),
                )
            except Exception as _vr_exc:
                logger.warning("Stage 17: Failed to build VerifiedRegistry: %s", _vr_exc)
        if isinstance(exp_summary, dict) and exp_summary.get("metrics_summary"):
            has_real_metrics = True
            exp_metrics_instruction = (
                "\n\nIMPORTANT: Use the ACTUAL experiment results provided in the context. "
                "All numbers in the Results and Experiments sections MUST reference real data. "
                "Do NOT write 'no quantitative results yet' or use placeholder numbers. "
                "Cite specific metrics with their actual values.\n"
            )

    # Collect raw experiment stdout metrics as hard constraint for the paper
    raw_metrics_block, _has_parsed_metrics = _collect_raw_experiment_metrics(run_dir)
    if raw_metrics_block:
        # BUG-23: Raw stdout alone is not sufficient — require either
        # metrics_summary data, parsed metrics from run JSONs,
        # OR at least 3 condition= patterns in raw block
        _has_condition_pattern = len(re.findall(
            r"condition[=:]", raw_metrics_block, re.IGNORECASE
        )) >= 3
        if has_real_metrics or _has_parsed_metrics or _has_condition_pattern:
            has_real_metrics = True
        exp_metrics_instruction += raw_metrics_block

    # R18-1 + R19-6: Inject paired statistical comparisons AND condition summaries
    if exp_summary_text:
        exp_summary_parsed = _safe_json_loads(exp_summary_text, {})
        if isinstance(exp_summary_parsed, dict):
            # R19-6: Inject experiment scale header so LLM knows the data richness
            _total_conds = exp_summary_parsed.get("total_conditions")
            _total_mkeys = exp_summary_parsed.get("total_metric_keys")
            _planned_mkeys = exp_summary_parsed.get("planned_metric_count")
            if _total_conds or _total_mkeys:
                scale_block = "\n\n## EXPERIMENT SCALE\n"
                if _total_conds:
                    scale_block += f"- Total conditions tested: {_total_conds}\n"
                if _total_mkeys:
                    scale_block += f"- Total metric keys collected: {_total_mkeys}\n"
                if _planned_mkeys:
                    scale_block += f"- Planned literature-backed metrics: {_planned_mkeys}\n"
                scale_block += (
                    "- Frame the study as a comparative experiment across datasets, regimes, or conditions.\n"
                    "- Report uncertainty where available, but do NOT reduce the narrative to seed counts.\n"
                    "- Do NOT describe results as 'single run' or 'preliminary'.\n"
                )
                exp_metrics_instruction += scale_block

            _coverage_warns = exp_summary_parsed.get("evidence_coverage_warnings", [])
            _legacy_seed_warns = exp_summary_parsed.get("seed_insufficiency_warnings", [])
            if _coverage_warns or _legacy_seed_warns:
                _sw_block = (
                    "\n\n## EVIDENCE COVERAGE NOTES\n"
                    "Keep the main narrative focused on the scientific study. "
                    "Mention the following constraints in Experiments or Limitations without letting them dominate the Abstract, Introduction, or Results.\n"
                )
                for _sw in _coverage_warns:
                    _sw_block += f"- {_sw}\n"
                for _sw in _legacy_seed_warns:
                    _sw_block += f"- {_sw}\n"
                exp_metrics_instruction += _sw_block

            # R19-6 + R33: Inject condition summaries with CIs
            cond_summaries = exp_summary_parsed.get("condition_summaries", {})
            if isinstance(cond_summaries, dict) and cond_summaries:
                cond_block = "\n\n## PER-CONDITION SUMMARY (use in Results tables)\n"
                for cname, cdata in sorted(cond_summaries.items()):
                    cond_block += f"\n### {cname}\n"
                    if not isinstance(cdata, dict):
                        continue
                    sr = cdata.get("success_rate")
                    if sr is not None:
                        try:
                            cond_block += f"- Success rate: {float(sr):.1%}\n"
                        except (ValueError, TypeError):
                            cond_block += f"- Success rate: {sr}\n"
                    ns = cdata.get("n_seeds") or cdata.get("n_seed_metrics")
                    if ns:
                        cond_block += f"- Repeated evaluations: {ns}\n"
                    ci_lo = cdata.get("ci95_low")
                    ci_hi = cdata.get("ci95_high")
                    if ci_lo is not None and ci_hi is not None:
                        try:
                            cond_block += f"- Bootstrap 95% CI: [{float(ci_lo):.4f}, {float(ci_hi):.4f}]\n"
                        except (ValueError, TypeError):
                            cond_block += f"- Bootstrap 95% CI: [{ci_lo}, {ci_hi}]\n"
                    cm = cdata.get("metrics") or {}
                    if isinstance(cm, dict) and cm:
                        for mk, mv in sorted(cm.items()):
                            if isinstance(mv, (int, float)):
                                cond_block += f"- {mk}: {mv:.4f}\n"
                            else:
                                cond_block += f"- {mk}: {mv}\n"
                exp_metrics_instruction += cond_block

            # R18-1: Inject paired statistical comparisons
            paired = exp_summary_parsed.get("paired_comparisons", [])
            if paired:
                paired_block = "\n\n## PAIRED STATISTICAL COMPARISONS (use these in Results)\n"
                paired_block += f"Total: {len(paired)} paired tests computed.\n"
                for pc in paired:
                    if not isinstance(pc, dict):
                        continue
                    method = pc.get("method", "?")
                    baseline = pc.get("baseline", "?")
                    regime = pc.get("regime", "all")
                    md = pc.get("mean_diff", "?")
                    sd = pc.get("std_diff", "?")
                    ts = pc.get("t_stat", "?")
                    pv = pc.get("p_value", "?")
                    ci_lo = pc.get("ci95_low")
                    ci_hi = pc.get("ci95_high")
                    ci_str = ""
                    if ci_lo is not None and ci_hi is not None:
                        try:
                            ci_str = f", 95% CI [{float(ci_lo):.3f}, {float(ci_hi):.3f}]"
                        except (ValueError, TypeError):
                            ci_str = f", 95% CI [{ci_lo}, {ci_hi}]"
                    paired_block += (
                        f"- {method} vs {baseline} (regime={regime}): "
                        f"mean_diff={md}, std_diff={sd}, "
                        f"t={ts}, p={pv}{ci_str}\n"
                    )
                exp_metrics_instruction += paired_block

            # R24: Method naming map — translate generic condition labels
            _cond_names = list(cond_summaries.keys()) if isinstance(cond_summaries, dict) and cond_summaries else []
            if _cond_names:
                naming_block = (
                    "\n\n## METHOD NAMING (CRITICAL — do NOT use generic labels in the paper)\n"
                    "The condition labels below come from the experiment code. In the paper, "
                    "you MUST use DESCRIPTIVE algorithm names, not generic labels.\n"
                    "- If a condition name is already descriptive (e.g., 'random_search', "
                    "'bayesian_optimization', 'ppo_policy'), use it directly as a proper name.\n"
                    "- If a condition name is generic (e.g., 'baseline_1', 'method_variant_1'), "
                    "you MUST infer the algorithm from the experiment code/context and use the "
                    "real algorithm name (e.g., 'Random Search', 'Bayesian Optimization', "
                    "'PPO', 'Curiosity-Driven RL').\n"
                    "- NEVER write `baseline_1` or `method_variant_1` in the paper text.\n"
                    f"- Conditions to name: {_cond_names}\n"
                )
                exp_metrics_instruction += naming_block

            # IMP-8: Inject broken ablation warnings
            abl_warnings = exp_summary_parsed.get("ablation_warnings", [])
            if abl_warnings:
                broken_block = (
                    "\n\n## BROKEN ABLATIONS (DO NOT discuss as valid results)\n"
                    "The following ablation conditions produced IDENTICAL outputs, "
                    "indicating implementation bugs. Do NOT present their differences "
                    "as findings. Mention them ONLY in a 'Limitations' sub-section "
                    "as known implementation issues:\n"
                )
                for _aw in abl_warnings:
                    broken_block += f"- {_aw}\n"
                broken_block += (
                    "\nIf you reference these conditions, state explicitly: "
                    "'Due to an implementation defect, conditions X and Y produced "
                    "identical outputs; their comparison is therefore uninformative.'\n"
                )
                exp_metrics_instruction += broken_block

            # R25: Statistical table format requirement
            if paired:
                stat_table_block = (
                    "\n\n## STATISTICAL TABLE REQUIREMENT (MANDATORY in Results section)\n"
                    "The Results section MUST include a statistical comparison table with columns:\n"
                    "| Comparison | Mean Diff | Std Diff | t-statistic | p-value | Significance |\n"
                    "Use the PAIRED STATISTICAL COMPARISONS data above to fill this table.\n"
                    "Mark significance: *** (p<0.001), ** (p<0.01), * (p<0.05), n.s.\n"
                    "This is non-negotiable — a top-venue paper MUST have statistical tests.\n"
                )
                exp_metrics_instruction += stat_table_block

            # R26: Metric definition requirement
            exp_metrics_instruction += (
                "\n\n## METRIC DEFINITIONS (MANDATORY in Experiments section)\n"
                "The Experiments section MUST define each metric:\n"
                "- **Primary metric**: what it measures, how it is computed, range, direction "
                "(higher/lower is better), and units if applicable.\n"
                "- **Secondary metric**: same details.\n"
                "- **Metric selection rationale**: explain which paper, benchmark protocol, clinical guideline, or domain standard justifies using each metric for this task.\n"
                "- **Metric suite coverage**: report multiple complementary metrics from the literature-backed suite, not just the single primary score, unless the benchmark standard truly uses only one.\n"
                "- Do NOT present a guessed or ad hoc metric without a literature-backed rationale.\n"
                "- If any metric is novel, explicitly label it as proposed, define it mathematically, explain why standard metrics are insufficient, and provide proof/properties or empirical validation against standard metrics before using it for primary claims.\n"
                "- For time-to-event metrics: explain the horizon, what constitutes success, "
                "and how failures are handled (e.g., set to max horizon).\n"
                "- These definitions MUST appear BEFORE any results tables.\n"
            )

            _dataset_details = exp_summary_parsed.get("dataset_details")
            _sample_size_regimes = exp_summary_parsed.get("sample_size_regimes")
            _has_breadth = bool(
                (isinstance(_dataset_details, list) and _dataset_details)
                or (isinstance(_sample_size_regimes, list) and _sample_size_regimes)
                or (_cond_names and len(_cond_names) >= 2)
            )
            if _has_breadth:
                exp_metrics_instruction += (
                    "\n\n## COMPARATIVE EVIDENCE FRAMING (CRITICAL)\n"
                    "This study contains comparative evidence across datasets, regimes, or experimental conditions.\n"
                    "- NEVER describe this as 'a single run' or '1 benchmark-output run'.\n"
                    "- Frame as a scientific comparison across benchmarks, sample sizes, or method variants.\n"
                    "- Include per-dataset or per-regime breakdowns as separate rows or columns in tables.\n"
                    "- Tie performance differences to dataset properties, preprocessing burden, scale, and task difficulty.\n"
                )

    # BUG-003: Inject actual evaluated datasets as a hard constraint
    if exp_summary_text:
        _ds_parsed = _safe_json_loads(exp_summary_text, {})
        if isinstance(_ds_parsed, dict):
            _datasets: set[str] = set()
            # Extract from condition names (often contain dataset info)
            for _cname in (_ds_parsed.get("condition_summaries") or {}).keys():
                _datasets.add(str(_cname))
            # Extract from explicit "datasets" field if present
            for _ds in (_ds_parsed.get("datasets") or []):
                if isinstance(_ds, str):
                    _datasets.add(_ds)
            # Extract from "benchmark" or "dataset" fields
            for _key in ("benchmark", "dataset", "dataset_name"):
                _dv = _ds_parsed.get(_key)
                if isinstance(_dv, str) and _dv:
                    _datasets.add(_dv)
            if _datasets:
                exp_metrics_instruction += (
                    "\n\n## ACTUAL EVALUATED DATASETS (HARD CONSTRAINT)\n"
                    "The following datasets/conditions were ACTUALLY tested in experiments:\n"
                    + "".join(f"- {d}\n" for d in sorted(_datasets))
                    + "\nCRITICAL: Do NOT claim evaluation on any dataset not listed above.\n"
                    "Do NOT fabricate results for datasets you did not run experiments on.\n"
                    "If you reference other datasets, clearly state they are 'not evaluated "
                    "in this work' or are 'left for future work'.\n"
                )

    # P7: Ablation effectiveness check
    if exp_summary_text:
        _exp_parsed_p7 = _safe_json_loads(exp_summary_text, {})
        if isinstance(_exp_parsed_p7, dict):
            _abl_warnings = _check_ablation_effectiveness(_exp_parsed_p7)
            if _abl_warnings:
                _abl_block = (
                    "\n\n## ABLATION EFFECTIVENESS WARNINGS\n"
                    "The following ablations showed minimal effect (within 5% of baseline). "
                    "Discuss this honestly — it may indicate the ablated component is not "
                    "important, or the ablation was not properly implemented:\n"
                )
                for _aw in _abl_warnings:
                    _abl_block += f"- {_aw}\n"
                exp_metrics_instruction += _abl_block
                logger.warning("P7: Ablation effectiveness warnings: %s", _abl_warnings)

    # P10: Contradiction detection
    if exp_summary_text:
        _exp_parsed_p10 = _safe_json_loads(exp_summary_text, {})
        if isinstance(_exp_parsed_p10, dict):
            _contradictions = _detect_result_contradictions(
                _exp_parsed_p10, metric_direction=config.experiment.metric_direction
            )
            if _contradictions:
                _contra_block = (
                    "\n\n## RESULT INTERPRETATION ADVISORIES (CRITICAL — read before writing)\n"
                )
                for _ca in _contradictions:
                    _contra_block += f"- {_ca}\n"
                exp_metrics_instruction += _contra_block
                logger.warning("P10: Contradiction advisories: %s", _contradictions)

    # R10: HARD BLOCK — refuse to write paper when all data is simulated
    # (skipped for literature-first / survey topics)
    _is_lit_first = _topic_is_literature_first(config)
    all_simulated = True
    for stage_subdir in sorted(run_dir.glob("stage-*/runs")):
        for run_file in sorted(stage_subdir.glob("*.json")):
            if run_file.name == "results.json":
                continue
            try:
                _payload = json.loads(run_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if isinstance(_payload, dict) and _payload.get("status") != "simulated":
                all_simulated = False
                break
        if not all_simulated:
            break

    if all_simulated and not _is_lit_first:
        logger.error(
            "BLOCKED: All experiment data is simulated (mode='simulated'). "
            "Cannot write a paper based on formulaic fake data. "
            "Switch to experiment.mode='sandbox' and re-run."
        )
        sim_gate = {
            "failures": [
                "All experiment results are from simulated mode rather than a sandbox or real execution backend."
            ],
            "warnings": [
                "The draft is evidence-limited and must not present simulated values as publication-quality empirical results."
            ],
            "actual_conditions": [],
            "actual_metrics": [],
            "finite_metric_count": 0,
        }
        (stage_dir / "paper_draft.md").write_text(
            _render_evidence_limited_paper_draft(
                sim_gate,
                config.research.topic,
                reason="All experiment results were produced in simulated mode.",
                exp_summary_text=exp_summary_text,
            ),
            encoding="utf-8",
        )
        return StageResult(
            stage=Stage.PAPER_DRAFT,
            status=StageStatus.DONE,
            artifacts=("paper_draft.md",),
            evidence_refs=(),
            decision="degraded",
        )

    # R4-2: HARD BLOCK — refuse to write paper with no real data (ML/empirical domains)
    # For non-empirical domains (math proofs, theoretical economics), allow proceeding
    _domain_id, _domain_name, _domain_venues = _detect_domain(
        config.research.topic, config.research.domains
    )
    _empirical_domains = {"ml", "engineering", "biology", "chemistry"}
    if not has_real_metrics and not _is_lit_first:
        if _domain_id in _empirical_domains:
            logger.error(
                "BLOCKED: Cannot write paper — experiment produced NO metrics. "
                "The pipeline will not fabricate results."
            )
            no_metrics_gate = {
                "failures": [
                    "The experiment stage produced no usable metrics for an empirical-domain manuscript."
                ],
                "warnings": [
                    "The draft is evidence-limited and reports missing evidence rather than fabricated results."
                ],
                "actual_conditions": [],
                "actual_metrics": [],
                "finite_metric_count": 0,
            }
            (stage_dir / "paper_draft.md").write_text(
                _render_evidence_limited_paper_draft(
                    no_metrics_gate,
                    config.research.topic,
                    reason="The experiment stage produced no usable metrics.",
                    exp_summary_text=exp_summary_text,
                ),
                encoding="utf-8",
            )
            return StageResult(
                stage=Stage.PAPER_DRAFT,
                status=StageStatus.DONE,
                artifacts=("paper_draft.md",),
                evidence_refs=(),
                decision="degraded",
            )
        else:
            logger.warning(
                "No experiment metrics found, but domain '%s' may be non-empirical "
                "(theoretical/mathematical). Proceeding with paper draft.",
                _domain_name,
            )

    # R11-5: Experiment quality minimum threshold before paper writing
    # Parse analysis.md for quality rating and condition completeness
    analysis_text = _read_best_analysis(run_dir)
    _quality_warnings: list[str] = []

    # Check 1: Was the analysis quality rating very low?
    import re as _re_q
    _rating_match = _re_q.search(
        r"(?:quality\s+rating|result\s+quality)[:\s]*\**(\d+)\s*/\s*10",
        analysis_text,
        _re_q.IGNORECASE,
    )
    if _rating_match:
        _analysis_rating = int(_rating_match.group(1))
        if _analysis_rating <= 3:
            _quality_warnings.append(
                f"Analysis rated experiment quality {_analysis_rating}/10"
            )
        # BUG-23: If quality rating is ≤ 2, force has_real_metrics = False
        # to prevent fabricated results even if stdout had stray numbers.
        # R5-BUG-05: Skip override when _has_parsed_metrics is True — the
        # analysis.md may be stale (from pre-refinement Stage 14) while
        # Stage 13 refinement produced real parsed metrics.
        if _analysis_rating <= 2 and has_real_metrics and not _has_parsed_metrics:
            logger.warning(
                "BUG-23 guard: Analysis quality %d/10 \u2264 2 — "
                "overriding has_real_metrics to False (experiment likely failed)",
                _analysis_rating,
            )
            has_real_metrics = False

    # Check 2: Are baselines missing?
    _analysis_lower = analysis_text.lower()
    if "no" in _analysis_lower and "baseline" in _analysis_lower:
        if any(phrase in _analysis_lower for phrase in [
            "no baseline", "no bo", "no random", "baselines are missing",
            "missing baselines", "baseline coverage is missing",
        ]):
            _quality_warnings.append("Baselines appear to be missing from results")

    # Check 3: Is the metric undefined?
    if any(phrase in _analysis_lower for phrase in [
        "metric is undefined", "primary_metric is undefined",
        "undefined metric", "metric undefined",
    ]):
        _quality_warnings.append("Primary metric is undefined (direction/units/formula unknown)")

    # Check 4: Very few conditions completed
    _condition_count = len(_re_q.findall(
        r"condition[=:\s]+\w+.*?(?:mean|primary_metric)",
        raw_metrics_block or "",
        _re_q.IGNORECASE,
    ))

    if _quality_warnings:
        _warning_block = "\n".join(f"  - {w}" for w in _quality_warnings)
        logger.warning(
            "Stage 17: Experiment quality concerns detected before paper writing:\n%s",
            _warning_block,
        )
        # Inject quality warnings into the paper writing prompt so the LLM
        # preserves honesty without collapsing into an output-status narrative.
        exp_metrics_instruction += (
            "\n\n## EXPERIMENT QUALITY WARNINGS (address these honestly in the paper)\n"
            + "\n".join(f"- {w}" for w in _quality_warnings)
            + "\n\nBecause of these issues, the paper MUST:\n"
            "- Keep unsupported caveats in the Limitations section instead of repeating them throughout the paper\n"
            "- Avoid unsupported superiority claims while still writing in a research-paper voice\n"
            "- Strengthen dataset, metric, preprocessing, and implementation detail wherever evidence exists\n"
            "- Make the contribution precise rather than overstated\n"
        )
        # Save warnings for tracking
        (stage_dir / "quality_warnings.json").write_text(
            json.dumps(_quality_warnings, indent=2), encoding="utf-8"
        )

    # Phase 1: Inject pre-built results tables from VerifiedRegistry
    if _verified_registry is not None:
        try:
            from researchclaw.templates.results_table_builder import (
                build_results_tables,
                build_condition_whitelist,
            )
            _prebuilt_tables = build_results_tables(
                _verified_registry,
                metric_direction=_verified_registry.metric_direction,
            )
            _condition_whitelist = build_condition_whitelist(_verified_registry)
            if _prebuilt_tables:
                _tables_block = "\n\n".join(t.latex_code for t in _prebuilt_tables)
                exp_metrics_instruction += (
                    "\n\n## PRE-BUILT RESULTS TABLES (MANDATORY — copy verbatim)\n"
                    "The tables below were AUTO-GENERATED from verified experiment data.\n"
                    "You MUST include these tables in the Results section EXACTLY as shown.\n"
                    "Do NOT modify any numbers. Do NOT add rows with fabricated data.\n"
                    "You MAY adjust formatting (bold, alignment) but NOT numerical values.\n\n"
                    + _tables_block
                )
                logger.info("Stage 17: Injected pre-built results tables into prompt")
            if _condition_whitelist:
                exp_metrics_instruction += (
                    "\n\n## VERIFIED CONDITIONS (ONLY mention these in the paper)\n"
                    + _condition_whitelist
                    + "\nDo NOT discuss conditions not in this list. Do NOT invent new conditions.\n"
                )
        except Exception as _tb_exc:
            logger.warning("Stage 17: Failed to build pre-built tables: %s", _tb_exc)

    # R4-2: Anti-fabrication data integrity instruction
    exp_metrics_instruction += (
        "\n\n## CRITICAL: Data Integrity Rules\n"
        "- You may ONLY report numbers that appear in the experiment data above\n"
        "- If the experiment data is incomplete (fewer conditions than planned), the correctness gate should emit a diagnostic/refinement request instead of a final paper\n"
        "- Distinguish PLANNED metrics from ACTUALLY REPORTED metrics: only metrics present in the run outputs may appear with numeric values in the Abstract, Results, tables, figure captions, or comparative claims\n"
        "- If a metric is defined in the experiment plan but not present in the reported results, do not write a final manuscript; treat the run as incomplete and regenerate experiments\n"
        "- Do NOT extrapolate, interpolate, or 'fill in' missing cells in tables\n"
        "- Do NOT invent confidence intervals, p-values, or statistical tests unless\n"
        "  the actual data supports them\n"
        "- Do not include metric-result tables with empty, N/A, dash, em-dash, or fabricated cells\n"
        "- FORBIDDEN: generating numbers that 'look right' based on your training data\n"
    )

    # IMP-6 + FA: Inject chart references into paper draft prompt
    # Prefer FigureAgent's figure_plan.json (rich descriptions) over raw file scan
    # BUG-FIX: figure_plan.json may be a list (from FigureAgent planner) or a dict
    # (from executor overwrite).  The orchestrator writes a list at planning time;
    # the executor overwrites with a dict only when figure_count > 0.  If the
    # FigureAgent renders 0 charts the list persists, and calling .get() on it
    # raises AttributeError.
    _fa_descriptions = ""
    # BUG-178: Iterate in reverse order so we read the LATEST stage-14
    # iteration's figure plan, matching Stage 22 which copies charts
    # from the newest iteration.
    for _s14_dir in sorted(run_dir.glob("stage-14*"), reverse=True):
        # Prefer the final plan (dict with figure_descriptions) if it exists
        for _fp_name in ("figure_plan_final.json", "figure_plan.json"):
            _fp_path = _s14_dir / _fp_name
            if not _fp_path.exists():
                continue
            try:
                _fp_data = json.loads(_fp_path.read_text(encoding="utf-8"))
                if isinstance(_fp_data, dict):
                    _fa_descriptions = _fp_data.get("figure_descriptions", "")
                elif isinstance(_fp_data, list) and _fp_data:
                    # List format from FigureAgent planner — synthesize descriptions
                    _desc_parts = ["## PLANNED FIGURES (from figure plan)\n"]
                    for _fig in _fp_data:
                        if isinstance(_fig, dict):
                            _fid = _fig.get("figure_id", "unnamed")
                            _ftitle = _fig.get("title", "")
                            _fcap = _fig.get("caption", "")
                            _fsec = _fig.get("section", "results")
                            _desc_parts.append(
                                f"- **{_fid}** ({_fsec}): {_ftitle}\n  {_fcap}"
                            )
                    if len(_desc_parts) > 1:
                        _fa_descriptions = "\n".join(_desc_parts)
            except (json.JSONDecodeError, OSError):
                pass
            if _fa_descriptions:
                break
        if _fa_descriptions:
            break

    if _fa_descriptions:
        exp_metrics_instruction += "\n\n" + _fa_descriptions
        logger.info("Stage 17: Injected FigureAgent figure descriptions into paper draft prompt")
    else:
        # Fallback: scan for chart files from the LATEST stage-14 iteration
        # BUG-178: Must use reverse order to match Stage 22 chart copy behavior
        _chart_files: list[str] = []
        for _s14_dir in sorted(run_dir.glob("stage-14*"), reverse=True):
            _charts_path = _s14_dir / "charts"
            if _charts_path.is_dir():
                _found = sorted(_charts_path.glob("*.png"))
                if _found:
                    _chart_files = [f.name for f in _found]
                    break  # Use only the latest iteration's charts
        if _chart_files:
            _chart_block = (
                "\n\n## AVAILABLE FIGURES (embed in the paper)\n"
                "The following figures were generated from actual experiment data. "
                "You MUST reference these in the relevant Method, Experiments, Results, or Ablation subsection "
                "using markdown image syntax: `![Caption](charts/filename.png)`\n\n"
            )
            for _cf_name in _chart_files:
                _label = _cf_name.replace("_", " ").replace(".png", "").title()
                _chart_block += f"- `charts/{_cf_name}` \u2014 {_label}\n"
            _chart_block += (
                "\nFor each figure referenced, write a descriptive caption without an in-image title, and "
                "discuss what the figure shows in 2-3 sentences. Do not create an 'Additional Visual Summaries' section.\n"
            )
            exp_metrics_instruction += _chart_block
            logger.info(
                "Stage 17: Injected %d chart references into paper draft prompt",
                len(_chart_files),
            )

    # WS-5.5: Framework diagram instruction
    exp_metrics_instruction += (
        "\n\n## FRAMEWORK DIAGRAM\n"
        "In the Method/Approach section, include the methodology flowchart figure. Insert this exactly:\n\n"
        "```\n"
        "![Methodology flowchart](charts/framework_diagram.png)\n"
        "```\n\n"
        "Reference it in prose with the automatic figure cross-reference after conversion, and discuss the top-down pipeline/architecture flow briefly. "
        "Do not write placeholder, unavailable-image, or 'will be generated separately' text.\n"
    )

    # P5: Extract hyperparameters from results.json for paper Method section
    _hp_table = ""
    for _s14_dir in sorted(run_dir.glob("stage-14*")):
        for _run_file in sorted(_s14_dir.glob("runs/*.json")):
            try:
                _run_data = json.loads(_run_file.read_text(encoding="utf-8"))
                if isinstance(_run_data, dict) and _run_data.get("hyperparameters"):
                    _hp = _run_data["hyperparameters"]
                    if isinstance(_hp, dict) and _hp:
                        _hp_table = "\n\n## HYPERPARAMETERS (include as a table in the Method section)\n"
                        _hp_table += "| Hyperparameter | Value |\n|---|---|\n"
                        for _hk, _hv in sorted(_hp.items()):
                            _hp_table += f"| {_hk} | {_hv} |\n"
                        _hp_table += (
                            "\nThis table MUST appear in the Method/Experiments section. "
                            "Include ALL hyperparameters used, with justification for key choices.\n"
                        )
                        break
            except (json.JSONDecodeError, OSError):
                continue
        if _hp_table:
            break
    # Also check staging dirs for results.json
    if not _hp_table:
        for _staging_dir in sorted(run_dir.glob("stage-*/runs/_docker_*")):
            _rjson = _staging_dir / "results.json"
            if _rjson.is_file():
                try:
                    _rdata = json.loads(_rjson.read_text(encoding="utf-8"))
                    if isinstance(_rdata, dict) and _rdata.get("hyperparameters"):
                        _hp = _rdata["hyperparameters"]
                        if isinstance(_hp, dict) and _hp:
                            _hp_table = "\n\n## HYPERPARAMETERS (include as a table in the Method section)\n"
                            _hp_table += "| Hyperparameter | Value |\n|---|---|\n"
                            for _hk, _hv in sorted(_hp.items()):
                                _hp_table += f"| {_hk} | {_hv} |\n"
                            _hp_table += (
                                "\nThis table MUST appear in the Method/Experiments section. "
                                "Include ALL hyperparameters used, with justification for key choices.\n"
                            )
                            break
                except (json.JSONDecodeError, OSError):
                    continue
    if _hp_table:
        exp_metrics_instruction += _hp_table

    # F2.6: Build citation list from references.bib / candidates with cite_keys
    citation_instruction = ""
    bib_text = _read_prior_artifact(run_dir, "references.bib")

    # P3: Pre-verify citations before paper draft — remove hallucinated refs
    if bib_text and bib_text.strip():
        from researchclaw.literature.verify import (
            filter_verified_bibtex,
            verify_citations as _verify_cit,
        )
        try:
            _pre_report = _verify_cit(bib_text, inter_verify_delay=0.5)
            _kept = _pre_report.verified + _pre_report.suspicious
            _removed = _pre_report.hallucinated
            if _removed > 0:
                bib_text = filter_verified_bibtex(
                    bib_text, _pre_report, include_suspicious=True
                )
                (stage_dir / "references_preverified.bib").write_text(
                    bib_text, encoding="utf-8"
                )
                logger.info(
                    "P3: Pre-verification kept %d/%d citations (removed %d hallucinated)",
                    _kept, _pre_report.total, _removed,
                )
        except Exception as exc:
            logger.warning("P3: Pre-verification failed, using original bib: %s", exc)

    candidates_text = _read_prior_artifact(run_dir, "candidates.jsonl")
    if candidates_text:
        cite_lines: list[str] = []
        for row_text in candidates_text.strip().splitlines():
            row = _safe_json_loads(row_text, {})
            if isinstance(row, dict) and row.get("cite_key"):
                authors_info = ""
                if isinstance(row.get("authors"), list) and row["authors"]:
                    first_author = row["authors"][0]
                    if isinstance(first_author, dict):
                        # BUG-38: name may be non-str (tuple/list) — force str
                        _name = first_author.get("name", "")
                        authors_info = _name if isinstance(_name, str) else str(_name)
                    elif isinstance(first_author, str):
                        authors_info = first_author
                    if len(row["authors"]) > 1:
                        authors_info += " et al."
                title = row.get("title", "")
                cite_lines.append(
                    f"- [{row['cite_key']}] \u2192 TITLE: \"{title}\" "
                    f"| {authors_info} "
                    f"({row.get('venue', '')}, {row.get('year', '')}, "
                    f"cited {row.get('citation_count', 0)} times) "
                    f"| ONLY cite this key when discussing: {title}"
                )
        if cite_lines:
            citation_instruction = (
                "\n\nAVAILABLE REFERENCES (use [cite_key] to cite in the text):\n"
                + "\n".join(cite_lines)
                + "\n\nCRITICAL CITATION RULES:\n"
                "- In the body text, cite using [cite_key] format, e.g. [smith2024transformer].\n"
                "- Do NOT write a References section \u2014 it will be auto-generated from the bibliography file.\n"
                "- Do NOT invent any references or arXiv IDs not in the above list.\n"
                "- You may cite a subset, but NEVER fabricate citations or change arXiv IDs.\n"
                "- SEMANTIC MATCHING: Before citing a reference, verify that its TITLE matches\n"
                "  the concept you are discussing. Do NOT use an unrelated cite_key just\n"
                "  because it sounds similar.\n"
                "- If no reference in the list matches the concept you want to cite,\n"
                "  write 'prior work has shown...' WITHOUT a citation, rather than using\n"
                "  a mismatched reference.\n"
                "- Each [cite_key] MUST correspond to the paper whose title is shown\n"
                "  next to that key in the list above. Cross-check before citing.\n"
                "\nCITATION QUANTITY & QUALITY CONSTRAINTS:\n"
                "- Cite 35-60 unique references in the paper body when the bibliography supports it.\n"
                "- The Related Work section alone should cite at least 18 references, and the Method/Experiments sections should cite foundational or protocol references where relevant.\n"
                "- Every citation MUST be directly relevant to the paper's topic.\n"
                "- DO NOT cite papers from unrelated domains (wireless communication, "
                "manufacturing, UAV, etc.).\n"
                "- Prefer well-known, highly-cited papers over obscure ones.\n"
                "- If unsure whether a paper exists or is relevant, DO NOT cite it.\n"
            )

    # Literature-first mode instruction for survey/review topics
    if _is_lit_first:
        exp_metrics_instruction += (
            "\n\n## LITERATURE-FIRST MODE\n"
            "This paper is a **survey / review / literature-first study**.\n"
            "- The contribution is the synthesis, taxonomy, and critical analysis of existing work.\n"
            "- Do NOT claim novel experimental results. Instead, summarize and compare findings\n"
            "  from the collected literature.\n"
            "- Structure the paper around themes, taxonomies, or chronological developments.\n"
            "- Include a comprehensive Related Work / Literature Review as the main body.\n"
            "- Tables should compare methods, datasets, and reported metrics FROM the literature.\n"
            "- The Conclusion should identify open problems and future directions.\n"
        )
        logger.info("Stage 17: Literature-first mode enabled for survey/review topic")

    draft_degraded = False
    if llm is not None:
        try:
            _pm = prompts or PromptManager()
            topic_constraint = _pm.block("topic_constraint", topic=config.research.topic)

            # --- Section-by-section writing (3 calls) for conference-grade depth ---
            draft = _write_paper_sections(
                llm=llm,
                pm=_pm,
                run_dir=run_dir,
                study_mode=str(getattr(config.experiment, "study_mode", "simulation") or "simulation"),
                preamble=preamble,
                topic_constraint=topic_constraint,
                exp_metrics_instruction=exp_metrics_instruction,
                citation_instruction=citation_instruction,
                outline=outline,
                model_name=config.llm.primary_model,
            )

            # R7: Strip LLM-generated References section — it often fabricates arXiv IDs.
            import re as _re_r7
            ref_pattern = _re_r7.compile(
                r'^(#{1,2}\s*References.*)', _re_r7.MULTILINE | _re_r7.DOTALL
            )
            ref_match = ref_pattern.search(draft)
            if ref_match:
                draft = draft[:ref_match.start()].rstrip()
                logger.info("Stage 17: Stripped LLM-generated References section (R7 fix)")
        except Exception as exc:  # noqa: BLE001
            draft_degraded = True
            logger.warning("Stage 17: draft LLM failed; using template draft: %s", exc)
            (stage_dir / "draft_generation_error_report.json").write_text(
                json.dumps({"error": str(exc), "generated": _utcnow_iso()}, indent=2),
                encoding="utf-8",
            )
            draft = _template_paper_draft(config.research.topic, exp_summary_text)
    else:
        draft = _template_paper_draft(config.research.topic, exp_summary_text)

    topic_report = _evaluate_topic_integrity(draft, config.research.topic)
    if not topic_report["passed"] and llm is not None and not draft_degraded:
        logger.warning(
            "Stage 17: Topic integrity check failed; attempting repair: %s",
            topic_report["failures"],
        )
        try:
            draft = _repair_topic_integrity(llm, draft, config.research.topic, topic_report)
            topic_report = _evaluate_topic_integrity(draft, config.research.topic)
        except Exception as exc:  # noqa: BLE001
            draft_degraded = True
            logger.warning("Stage 17: topic repair failed; continuing degraded: %s", exc)

    if _contains_failed_run_diagnostic_text(draft):
        leak_gate = {
            "failures": [
                "Draft generation attempted to publish failed-run diagnostic scaffolding."
            ],
            "warnings": [],
            "actual_conditions": [],
            "actual_metrics": [],
            "finite_metric_count": 0,
        }
        (stage_dir / "draft_diagnostic_leak_report.json").write_text(
            json.dumps(leak_gate, indent=2),
            encoding="utf-8",
        )
        draft = _render_evidence_limited_paper_draft(
            leak_gate,
            config.research.topic,
            reason="The generated draft leaked failed-run diagnostic text and was replaced with a clean evidence-limited manuscript.",
            exp_summary_text=exp_summary_text,
        )
        rewrite_report = _write_paper_auto_rewrite_report(
            stage_dir,
            artifact="paper_draft.md",
            source="draft_diagnostic_leak",
            reason="The generated draft leaked failed-run diagnostic text.",
        )
        (stage_dir / "paper_draft.md").write_text(draft, encoding="utf-8")
        _write_topic_integrity_report(stage_dir, topic_report)
        return StageResult(
            stage=Stage.PAPER_DRAFT,
            status=StageStatus.DONE,
            artifacts=(
                "paper_draft.md",
                "topic_integrity_report.json",
                "draft_diagnostic_leak_report.json",
                rewrite_report,
            ),
            evidence_refs=(
                "stage-17/paper_draft.md",
                "stage-17/topic_integrity_report.json",
                "stage-17/draft_diagnostic_leak_report.json",
                f"stage-17/{rewrite_report}",
            ),
            decision="degraded",
        )

    (stage_dir / "paper_draft.md").write_text(draft, encoding="utf-8")
    _write_topic_integrity_report(stage_dir, topic_report)

    if not topic_report["passed"]:
        topic_failures = [
            str(item).strip()
            for item in (topic_report.get("failures") or [])
            if str(item).strip()
        ]
        if not topic_failures:
            topic_failures = ["Paper draft drifted away from the original user topic."]
        topic_gate = {
            "failures": topic_failures,
            "warnings": [
                "The generated draft drifted from the requested topic and was rewritten as an evidence-limited manuscript."
            ],
            "actual_conditions": [],
            "actual_metrics": [],
            "finite_metric_count": 0,
        }
        draft = _render_evidence_limited_paper_draft(
            topic_gate,
            config.research.topic,
            reason="The generated draft did not preserve the requested topic closely enough.",
            exp_summary_text=exp_summary_text,
        )
        rewrite_report = _write_paper_auto_rewrite_report(
            stage_dir,
            artifact="paper_draft.md",
            source="topic_integrity_gate",
            reason="The generated draft did not preserve the requested topic closely enough.",
        )
        (stage_dir / "paper_draft.md").write_text(draft, encoding="utf-8")
        return StageResult(
            stage=Stage.PAPER_DRAFT,
            status=StageStatus.DONE,
            artifacts=("paper_draft.md", "topic_integrity_report.json", rewrite_report),
            evidence_refs=(
                "stage-17/paper_draft.md",
                "stage-17/topic_integrity_report.json",
                f"stage-17/{rewrite_report}",
            ),
            decision="degraded",
        )

    # Validate draft quality (section balance + bullet density)
    _validate_draft_quality(
        draft,
        stage_dir=stage_dir,
        exp_summary_parsed=exp_summary_parsed if isinstance(exp_summary_parsed, dict) else None,
    )

    # --- HITL: Read human guidance for paper draft ---
    guidance_file = stage_dir / "hitl_guidance.md"
    if guidance_file.exists():
        try:
            guidance = guidance_file.read_text(encoding="utf-8").strip()
            if guidance and llm is not None:
                draft_path = stage_dir / "paper_draft.md"
                if draft_path.exists():
                    current_draft = draft_path.read_text(encoding="utf-8")
                    logger.info("Applying HITL guidance to paper draft")
                    resp = llm.chat(
                        [{"role": "user", "content": (
                            f"The human researcher provided this guidance for the paper:\n\n"
                            f"{guidance}\n\n"
                            f"Apply these suggestions to improve the following draft. "
                            f"Preserve all existing content and citations. "
                            f"Only make changes that align with the guidance.\n\n"
                            f"## Current Draft\n{current_draft[:8000]}"
                        )}],
                        max_tokens=8192,
                    )
                    draft_path.write_text(resp.content, encoding="utf-8")
        except Exception:
            logger.debug("HITL guidance application to draft failed (non-blocking)")

    # --- HITL: Paper Co-Writer data persistence ---
    try:
        from researchclaw.hitl.workshops.paper import PaperCoWriter

        writer = PaperCoWriter(run_dir, llm_client=llm)
        writer.load_outline()
        draft_path = stage_dir / "paper_draft.md"
        if draft_path.exists():
            draft_text = draft_path.read_text(encoding="utf-8")
            for section in writer.sections:
                # Extract section content from draft
                import re as _re_pw
                pattern = rf"(?:^|\n)##?\s*{_re_pw.escape(section.name)}.*?\n(.*?)(?=\n##?\s|\Z)"
                match = _re_pw.search(draft_text, _re_pw.DOTALL)
                if match:
                    section.content = match.group(1).strip()
                    section.status = "ai_draft"
        writer.save()
    except Exception:
        pass

    return StageResult(
        stage=Stage.PAPER_DRAFT,
        status=StageStatus.DONE,
        artifacts=(
            ("paper_draft.md", "topic_integrity_report.json", "draft_generation_error_report.json")
            if draft_degraded
            else ("paper_draft.md", "topic_integrity_report.json")
        ),
        evidence_refs=(
            (
                "stage-17/paper_draft.md",
                "stage-17/topic_integrity_report.json",
                "stage-17/draft_generation_error_report.json",
            )
            if draft_degraded
            else ("stage-17/paper_draft.md", "stage-17/topic_integrity_report.json")
        ),
        decision="degraded" if draft_degraded else "proceed",
    )
