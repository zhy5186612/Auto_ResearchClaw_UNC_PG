"""Dialog / conversational research modules."""
