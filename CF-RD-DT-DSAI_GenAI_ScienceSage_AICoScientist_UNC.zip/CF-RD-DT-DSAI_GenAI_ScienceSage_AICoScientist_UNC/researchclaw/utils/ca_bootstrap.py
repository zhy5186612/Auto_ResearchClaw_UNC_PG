"""Assemble a merged CA bundle for corporate TLS-intercepting networks.

Modern ``pip`` builds a wheel from ``pg-root-ssl-python-mega-patch``'s sdist
and installs from that wheel, which bypasses the patch's ``install``-command
hook. As a result the P&G / Netskope roots never actually land in
``certifi/cacert.pem`` on many installs, and every outbound HTTPS call
(OpenAlex, Semantic Scholar, arXiv, LLM endpoints) fails with
``CERTIFICATE_VERIFY_FAILED``.

This module runs at import time to:

  1. Collect extra CA roots from (in order): a user-supplied env var, a
     per-user override file, a packaged ``extra-ca/`` directory, and — as a
     dev-tree fallback — the vendored ``pg-root-ssl-python-mega-patch-*.tar.gz``
     tarball at the repo root.
  2. Concatenate them with ``certifi.where()`` into
     ``~/.cache/researchclaw/ca/merged.pem``.
  3. Point ``SSL_CERT_FILE`` / ``REQUESTS_CA_BUNDLE`` at that merged file for
     the running process only.

If no extra roots are found (typical off-corporate machines), this is a
no-op — the default certifi bundle is used.
"""

from __future__ import annotations

import hashlib
import logging
import os
import sys
import tarfile
from pathlib import Path

logger = logging.getLogger(__name__)

_INSTALLED = False
_ENV_OVERRIDE = "RESEARCHCLAW_EXTRA_CA_BUNDLE"
_DISABLE_ENV = "RESEARCHCLAW_DISABLE_CA_BOOTSTRAP"
_CACHE_DIR = Path.home() / ".cache" / "researchclaw" / "ca"
_MERGED_NAME = "merged.pem"
_PEM_HEADER = b"-----BEGIN CERTIFICATE-----"


def _truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}


def _repo_root() -> Path:
    # researchclaw/utils/ca_bootstrap.py → repo root is 3 parents up.
    return Path(__file__).resolve().parents[2]


def _iter_extra_sources() -> list[Path]:
    """Ordered list of files/directories that may contribute extra roots.

    Missing entries are silently skipped. Order matters only for logging —
    duplicates are dropped by content hash later.
    """
    sources: list[Path] = []

    override = os.environ.get(_ENV_OVERRIDE, "").strip()
    if override:
        sources.append(Path(override).expanduser())

    user_file = Path.home() / ".researchclaw" / "extra-ca.pem"
    if user_file.exists():
        sources.append(user_file)

    packaged_dir = Path(__file__).resolve().parent.parent / "data" / "extra-ca"
    if packaged_dir.is_dir():
        sources.append(packaged_dir)

    # Dev-tree fallback: vendored PG patch tarball at repo root.
    repo = _repo_root()
    for tarball in sorted(repo.glob("pg-root-ssl-python-mega-patch-*.tar.gz")):
        sources.append(tarball)

    return sources


def _collect_pems_from_dir(directory: Path) -> list[bytes]:
    out: list[bytes] = []
    for pem in sorted(directory.glob("*.pem")):
        try:
            data = pem.read_bytes()
        except OSError as exc:
            logger.debug("ca_bootstrap: could not read %s: %s", pem, exc)
            continue
        if _PEM_HEADER in data:
            out.append(data)
    return out


def _collect_pems_from_tarball(tarball: Path) -> list[bytes]:
    out: list[bytes] = []
    try:
        with tarfile.open(tarball, "r:gz") as tf:
            for member in tf.getmembers():
                if not member.isfile() or not member.name.endswith(".pem"):
                    continue
                # Skip mozilla-ca.pem — that's a full Mozilla bundle used only
                # when no CA store exists; we want just the corporate roots.
                base = Path(member.name).name.lower()
                if base == "mozilla-ca.pem":
                    continue
                fp = tf.extractfile(member)
                if fp is None:
                    continue
                data = fp.read()
                if _PEM_HEADER in data:
                    out.append(data)
    except (tarfile.TarError, OSError) as exc:
        logger.debug("ca_bootstrap: could not read %s: %s", tarball, exc)
    return out


def _collect_extras() -> list[bytes]:
    seen: set[str] = set()
    collected: list[bytes] = []
    for src in _iter_extra_sources():
        pems: list[bytes]
        if src.is_dir():
            pems = _collect_pems_from_dir(src)
        elif src.suffix in {".gz", ".tgz"} and src.name.endswith(".tar.gz"):
            pems = _collect_pems_from_tarball(src)
        elif src.is_file():
            try:
                data = src.read_bytes()
            except OSError as exc:
                logger.debug("ca_bootstrap: could not read %s: %s", src, exc)
                continue
            pems = [data] if _PEM_HEADER in data else []
        else:
            continue
        for pem in pems:
            digest = hashlib.sha256(pem).hexdigest()
            if digest in seen:
                continue
            seen.add(digest)
            collected.append(pem)
    return collected


def _certifi_bundle() -> Path | None:
    try:
        import certifi
    except ImportError:
        return None
    path = Path(certifi.where())
    return path if path.exists() else None


def _write_merged(certifi_path: Path, extras: list[bytes]) -> Path | None:
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.debug("ca_bootstrap: cannot create cache dir %s: %s", _CACHE_DIR, exc)
        return None
    merged = _CACHE_DIR / _MERGED_NAME
    try:
        base = certifi_path.read_bytes()
        with merged.open("wb") as fp:
            fp.write(base)
            if not base.endswith(b"\n"):
                fp.write(b"\n")
            for pem in extras:
                fp.write(pem)
                if not pem.endswith(b"\n"):
                    fp.write(b"\n")
    except OSError as exc:
        logger.debug("ca_bootstrap: cannot write merged bundle: %s", exc)
        return None
    return merged


def install() -> Path | None:
    """Bootstrap the merged CA bundle. Idempotent, safe to call multiple times.

    Returns the path to the active bundle if one is in effect (either
    pre-existing ``SSL_CERT_FILE`` or the merged file), else ``None``.
    """
    global _INSTALLED
    if _INSTALLED:
        return Path(os.environ.get("SSL_CERT_FILE", "")) or None

    if _truthy(os.environ.get(_DISABLE_ENV)):
        return None

    # Honor an existing SSL_CERT_FILE — user opted in explicitly.
    existing = os.environ.get("SSL_CERT_FILE", "").strip()
    if existing and Path(existing).exists():
        _INSTALLED = True
        return Path(existing)

    extras = _collect_extras()
    if not extras:
        logger.debug(
            "ca_bootstrap: no extra CA roots found; using certifi default"
        )
        _INSTALLED = True
        return None

    certifi_path = _certifi_bundle()
    if certifi_path is None:
        logger.debug("ca_bootstrap: certifi unavailable; skipping merge")
        _INSTALLED = True
        return None

    merged = _write_merged(certifi_path, extras)
    if merged is None:
        _INSTALLED = True
        return None

    os.environ["SSL_CERT_FILE"] = str(merged)
    os.environ.setdefault("REQUESTS_CA_BUNDLE", str(merged))
    logger.info(
        "ca_bootstrap: merged %d extra CA root(s) into %s (SSL_CERT_FILE set)",
        len(extras),
        merged,
    )
    _INSTALLED = True
    return merged


def reset_for_tests() -> None:
    """Test-only: clear the install-once guard."""
    global _INSTALLED
    _INSTALLED = False
