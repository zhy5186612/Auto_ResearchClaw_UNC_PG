"""Compatibility fallback for Python HTTPS verification on Windows."""

from __future__ import annotations

import logging
import os
import ssl
from pathlib import Path

logger = logging.getLogger(__name__)

_INSTALLED = False


def _configured_cafile() -> str:
    for name in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE"):
        value = os.environ.get(name, "").strip()
        if value and Path(value).exists():
            return value

    try:
        import certifi
    except ImportError:
        return ""

    cafile = certifi.where()
    return cafile if cafile and Path(cafile).exists() else ""


def install_default_https_context_fallback() -> None:
    """Use a CA bundle fallback when the platform trust store is unreadable.

    Some Windows certificate stores contain malformed entries that make
    ``ssl.create_default_context()`` fail with ASN.1 parse errors before urllib
    can open any HTTPS connection. The Azure/GenAI calls then fail before
    credentials are tested. Keep the normal platform context when it works, and
    switch urllib's default HTTPS context to certifi only when it does not.
    """

    global _INSTALLED
    if _INSTALLED:
        return
    if os.environ.get("RESEARCHCLAW_DISABLE_SSL_COMPAT", "").strip().lower() in {
        "1",
        "true",
        "yes",
    }:
        return

    try:
        ssl.create_default_context()
        return
    except ssl.SSLError as exc:
        logger.debug(
            "Default HTTPS certificate context failed; using CA bundle fallback: %s",
            exc,
        )

    cafile = _configured_cafile()
    if not cafile:
        logger.warning("No CA bundle available for HTTPS fallback")
        return

    def _bundle_https_context(*args: object, **kwargs: object) -> ssl.SSLContext:
        if not any(kwargs.get(name) for name in ("cafile", "capath", "cadata")):
            kwargs["cafile"] = cafile
        return ssl.create_default_context(*args, **kwargs)

    ssl._create_default_https_context = _bundle_https_context  # type: ignore[attr-defined]
    _INSTALLED = True
