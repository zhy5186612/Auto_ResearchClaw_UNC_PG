"""Voice interaction modules."""
